import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

panel_old = "fun StudentFullDetailsPanel(student: Student, modifier: Modifier = Modifier) {"
panel_new = "fun StudentFullDetailsPanel(student: Student, modifier: Modifier = Modifier, showUserId: Boolean = false) {"
content = content.replace(panel_old, panel_new)

# Find where ID is shown in Panel
# Let's inspect the file around line 6268 to 6300
with open(filepath, 'w') as f:
    f.write(content)
