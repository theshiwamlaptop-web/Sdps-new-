import re

with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

gender_ui = """                        @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
                        androidx.compose.material3.ExposedDropdownMenuBox(
                            expanded = isTGenderExpanded,
                            onExpandedChange = { isTGenderExpanded = it },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = tGender,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Gender") },
                                trailingIcon = { androidx.compose.material3.ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTGenderExpanded) },
                                colors = androidx.compose.material3.ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            androidx.compose.material3.ExposedDropdownMenu(
                                expanded = isTGenderExpanded,
                                onDismissRequest = { isTGenderExpanded = false }
                            ) {
                                listOf("Male", "Female", "Other").forEach { g ->
                                    androidx.compose.material3.DropdownMenuItem(
                                        text = { Text(g) },
                                        onClick = { 
                                            tGender = g
                                            isTGenderExpanded = false 
                                        }
                                    )
                                }
                            }
                        }
"""

gender_ui_weight = """                        @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
                        androidx.compose.material3.ExposedDropdownMenuBox(
                            expanded = isTGenderExpanded,
                            onExpandedChange = { isTGenderExpanded = it },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = tGender,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Gender") },
                                trailingIcon = { androidx.compose.material3.ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTGenderExpanded) },
                                colors = androidx.compose.material3.ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            androidx.compose.material3.ExposedDropdownMenu(
                                expanded = isTGenderExpanded,
                                onDismissRequest = { isTGenderExpanded = false }
                            ) {
                                listOf("Male", "Female", "Other").forEach { g ->
                                    androidx.compose.material3.DropdownMenuItem(
                                        text = { Text(g) },
                                        onClick = { 
                                            tGender = g
                                            isTGenderExpanded = false 
                                        }
                                    )
                                }
                            }
                        }
"""

# Insert gender UI after tName in both wide and narrow layouts in the dialog
t1 = """                                modifier = Modifier.weight(1f).testTag("teacher_name_input")
                            )"""
r1 = t1 + "\n" + gender_ui_weight
content = content.replace(t1, r1)

t2 = """                                modifier = Modifier.fillMaxWidth().testTag("teacher_name_input")
                            )"""
r2 = t2 + "\n" + gender_ui
content = content.replace(t2, r2)


with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
    f.write(content)
