import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

content = content.replace('  implementation("com.google.firebase:firebase-messaging")\n', '')

with open("app/build.gradle.kts", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "r") as f:
    repo = f.read()

repo = repo.replace("import com.google.firebase.messaging.FirebaseMessaging\n", "")

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "w") as f:
    f.write(repo)
