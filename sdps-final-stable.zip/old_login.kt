fun LoginScreen(viewModel: SchoolViewModel) {
    var userId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf("PRINCIPAL") }
    var selectedAuthRoute by remember { mutableStateOf("STANDARD") } // "STANDARD" or "OTP"
    
    // OTP states
    var phoneInput by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf("") }
    
    // Forgot Password states
    var showResetDialog by remember { mutableStateOf(false) }
    var resetInput by remember { mutableStateOf("") }

    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val loginError by viewModel.loginError.collectAsState()
    val isAuthenticating by viewModel.isAuthenticating.collectAsState()

    val rolesPresets = listOf(
        Triple("PRINCIPAL", "Principal", "S.D.P.S. Principal"),
        Triple("ADMIN", "Admin", "S.D.P.S. Admin"),
        Triple("CLASS_TEACHER", "Teacher", "S.D.P.S. Teacher"),
        Triple("STUDENT", "Student", "S.D.P.S. Student")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        
        // Logo with Golden Radial Shadow
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(Color(0xFFFFB703).copy(alpha = 0.3f), Color.Transparent),
                        radius = 150f
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            SchoolLogoImage(
                contentDescription = "School Logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(84.dp).padding(4.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Text(
            text = "Welcome Back",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        )
        Text(
            text = "Sign in to S.D. Public School",
            style = MaterialTheme.typography.bodyLarge.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // Auth Route Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedAuthRoute == "STANDARD") MaterialTheme.colorScheme.surface else Color.Transparent)
                    .clickable { selectedAuthRoute = "STANDARD" }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "ID & Password",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = if (selectedAuthRoute == "STANDARD") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedAuthRoute == "OTP") MaterialTheme.colorScheme.surface else Color.Transparent)
                    .clickable { selectedAuthRoute = "OTP" }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Mobile OTP",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = if (selectedAuthRoute == "OTP") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        if (selectedAuthRoute == "STANDARD") {
            // Standard ID / Password Form
            OutlinedTextField(
                value = userId,
                onValueChange = { userId = it.uppercase() },
                label = { Text("User ID or Phone") },
                leadingIcon = { Icon(Icons.Filled.Person, null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_user_id_field"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Filled.Lock, null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_password_field"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        if (userId.isNotBlank() && password.isNotBlank() && !isAuthenticating) {
                            viewModel.loginUser(userId, selectedRole, "", password)
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { showResetDialog = true }) {
                    Text("Forgot Password?", color = MaterialTheme.colorScheme.primary)
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.loginUser(userId, selectedRole, "", password)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("login_button"),
                shape = RoundedCornerShape(12.dp),
                enabled = !isAuthenticating
            ) {
                if (isAuthenticating) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Sign In", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        } else {
            // OTP Form
            OutlinedTextField(
                value = phoneInput,
                onValueChange = { phoneInput = it },
                label = { Text("Phone Number (+91)") },
                leadingIcon = { Icon(Icons.Filled.Phone, null) },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = if (verificationId.isNotEmpty()) ImeAction.Next else ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        if (phoneInput.length >= 10 && activity != null && !isAuthenticating) {
                            viewModel.startPhoneVerification(phoneInput, activity, { vId -> verificationId = vId }, { /* error */ })
                        }
                    }
                ),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            if (verificationId.isNotEmpty()) {
                OutlinedTextField(
                    value = otpCode,
                    onValueChange = { otpCode = it },
                    label = { Text("6-digit OTP") },
                    leadingIcon = { Icon(Icons.Filled.Message, null) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (otpCode.length == 6 && !isAuthenticating) {
                                viewModel.verifyOtpAndLogin(verificationId, otpCode, phoneInput)
                            }
                        }
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.verifyOtpAndLogin(verificationId, otpCode, phoneInput)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("login_otp_verify_btn"),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isAuthenticating
                ) {
                    if (isAuthenticating) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Verify & Sign In", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        focusManager.clearFocus()
                        if(activity != null) {
                            viewModel.startPhoneVerification(phoneInput, activity, { vId -> verificationId = vId }, { /* error */ })
                        } else {
                            Toast.makeText(context, "Cannot send OTP (Activity context missing)", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("login_send_otp_btn"),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isAuthenticating && phoneInput.length >= 10
                ) {
                    if (isAuthenticating) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Send OTP", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        loginError?.let { err ->
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = err,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
        
        Text("Sign in as Demo User", style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            rolesPresets.forEach { preset ->
                ElevatedCard(
                    onClick = { 
                        selectedRole = preset.first
                        userId = when (preset.first) {
                            "PRINCIPAL" -> "SDPS-PRIN-01"
                            "ADMIN" -> "SDPS-ADM-01"
                            "CLASS_TEACHER" -> "SDPS-TCH-01"
                            "STUDENT" -> "SDPS-STU-01"
                            else -> "SDPS-STU-01"
                        }
                        password = "password123"
                    },
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = if (selectedRole == preset.first) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = preset.second,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (selectedRole == preset.first) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
    
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Forgot Password") },
            text = {
                Column {
                    Text("Temporary bypass using Default Password.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = resetInput,
                        onValueChange = { resetInput = it },
                        label = { Text("Enter User ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { 
                    viewModel.applyDefaultPassword(
                        resetInput.trim(),
                        onSuccess = { 
                            android.widget.Toast.makeText(context, "Default password applied. Please login with 'DefaultPassword123' and change your password.", android.widget.Toast.LENGTH_LONG).show()
                            showResetDialog = false 
                        },
                        onFailure = { 
                            android.widget.Toast.makeText(context, "Error: User ID not found.", android.widget.Toast.LENGTH_LONG).show()
                            showResetDialog = false 
                        }
                    )
                }) { Text("Use Default Password") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// 4. TEACHER MANAGEMENT
// ==========================================
@Composable
fun TeacherManagementScreen(viewModel: SchoolViewModel) {
    val teachers by viewModel.teachersState.collectAsState()
