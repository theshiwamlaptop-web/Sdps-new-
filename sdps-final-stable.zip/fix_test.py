import os

filepath = "app/src/test/java/com/example/ui/CriticalScreensUiTest.kt"
with open(filepath, "r") as f:
    content = f.read()

content = content.replace("import com.example.ui.screens.LoginScreen", "import com.example.ui.screens.PremiumLoginScreen")
content = content.replace("LoginScreen(viewModel = viewModel)", "PremiumLoginScreen(viewModel = viewModel)")

with open(filepath, "w") as f:
    f.write(content)
print("Success")
