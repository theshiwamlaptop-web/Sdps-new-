import re

with open('app/src/main/java/com/example/SchoolApplication.kt', 'r') as f:
    content = f.read()

bad = '''    override fun onCreate() {
        super.onCreate()
        instance = this

        // Safe Firebase initialization
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            // Gracefully ignore if google-services.json details are empty in build environments
        }'''

good = '''    override fun onCreate() {
        super.onCreate()
        instance = this
        android.util.Log.d("DEBUG_TRACE", "SchoolApplication.onCreate() started")

        // Safe Firebase initialization
        try {
            FirebaseApp.initializeApp(this)
            android.util.Log.d("DEBUG_TRACE", "FirebaseApp initialized")
            try {
                val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
                android.util.Log.d("DEBUG_TRACE", "FirebaseAuth currentUser at startup: ${auth.currentUser?.uid}")
            } catch (e: Exception) {
                android.util.Log.e("DEBUG_TRACE", "Failed to get FirebaseAuth", e)
            }
        } catch (e: Exception) {
            android.util.Log.e("DEBUG_TRACE", "FirebaseApp initialization failed", e)
            // Gracefully ignore if google-services.json details are empty in build environments
        }'''

content = content.replace(bad, good)

with open('app/src/main/java/com/example/SchoolApplication.kt', 'w') as f:
    f.write(content)
