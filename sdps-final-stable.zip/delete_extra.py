with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    lines = f.readlines()

new_lines = []
for i in range(len(lines)):
    if i > 0 and lines[i] in ["                }\n", "                }"]:
        prev = lines[i-1]
        if '}' in prev:
            spaces = len(prev) - len(prev.lstrip(' '))
            if spaces > 16:
                continue # DROP IT!
    new_lines.append(lines[i])

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.writelines(new_lines)
