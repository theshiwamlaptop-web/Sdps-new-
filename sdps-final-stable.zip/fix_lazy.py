with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "fun SettingsScreen(viewModel: SchoolViewModel)" in line:
        print(f"SettingsScreen at {i}")
    if "fun ProfileSettingsTab" in line:
        print(f"ProfileSettingsTab at {i}")
