with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

output = []
balance = 0
in_string = False
in_char = False
escape = False
in_line_comment = False
in_block_comment = False

i = 0
while i < len(text):
    char = text[i]
    
    if in_line_comment:
        if char == '\n':
            in_line_comment = False
        output.append(char)
        i += 1
        continue
        
    if in_block_comment:
        if char == '*' and i + 1 < len(text) and text[i+1] == '/':
            in_block_comment = False
            output.append(char)
            output.append('/')
            i += 2
            continue
        output.append(char)
        i += 1
        continue
        
    if in_string:
        if escape:
            escape = False
        elif char == '\\':
            escape = True
        elif char == '"':
            in_string = False
        output.append(char)
        i += 1
        continue
        
    if in_char:
        if escape:
            escape = False
        elif char == '\\':
            escape = True
        elif char == "'":
            in_char = False
        output.append(char)
        i += 1
        continue
        
    if char == '/' and i + 1 < len(text):
        if text[i+1] == '/':
            in_line_comment = True
            output.append(char)
            output.append('/')
            i += 2
            continue
        elif text[i+1] == '*':
            in_block_comment = True
            output.append(char)
            output.append('*')
            i += 2
            continue
            
    if char == '"':
        in_string = True
        output.append(char)
        i += 1
        continue
        
    if char == "'":
        in_char = True
        output.append(char)
        i += 1
        continue
        
    if char == '{':
        balance += 1
        output.append(char)
    elif char == '}':
        if balance > 0:
            balance -= 1
            output.append(char)
        else:
            # Extra brace! Do not append it.
            pass
    else:
        output.append(char)
        
    i += 1

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write("".join(output))

