import re

with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

# Find the start of LoginScreen
start_idx = content.find("fun LoginScreen(viewModel: SchoolViewModel)")
if start_idx == -1:
    print("Start not found")
    exit(1)

# Find the end (before "// 4. TEACHER MANAGEMENT")
end_idx = content.find("// 4. TEACHER MANAGEMENT", start_idx)
if end_idx == -1:
    print("End not found")
    exit(1)

print(f"Replacing from {start_idx} to {end_idx}")

