with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

text = text.replace("""                                }
                            )
                                                            ,
                    modifier = Modifier.testTag("submit_change_password")""", """                                }
                            )
                        }
                    },
                    modifier = Modifier.testTag("submit_change_password")""")

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
