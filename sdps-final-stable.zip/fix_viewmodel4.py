import re

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'r') as f:
    text = f.read()

pattern = r'val auth = com\.google\.firebase\.auth\.FirebaseAuth\.getInstance\(\)'
replacement = 'val auth = null // FirebaseAuth disabled on emulator'
text = re.sub(pattern, replacement, text)

# Just null out auth, and then replace usages with a fake success
pattern2 = r'auth\.sendPasswordResetEmail\(clean\)\.addOnCompleteListener \{ task ->[\s\S]*?\}'
replacement2 = 'onSuccess()'
text = re.sub(pattern2, replacement2, text)

pattern3 = r'auth\?\.sendPasswordResetEmail\(user\.email\)\?\.addOnCompleteListener \{ task ->[\s\S]*?\}'
replacement3 = 'onSuccess()'
text = re.sub(pattern3, replacement3, text)

pattern4 = r'auth\.sendPasswordResetEmail\(user\.email\)\.addOnCompleteListener \{ task ->[\s\S]*?\}'
replacement4 = 'onSuccess()'
text = re.sub(pattern4, replacement4, text)

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'w') as f:
    f.write(text)

