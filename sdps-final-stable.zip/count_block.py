with open('patch_lines2.py', 'r') as f:
    lines = f.readlines()

new_block = ""
in_block = False
for line in lines:
    if "new_block = '''" in line:
        in_block = True
        new_block += line.split("new_block = '''")[1]
        continue
    if in_block:
        if "'''" in line:
            new_block += line.split("'''")[0]
            break
        else:
            new_block += line

count = 0
for char in new_block:
    if char == '{':
        count += 1
    elif char == '}':
        count -= 1

print(f"Brace count in new_block: {count}")
