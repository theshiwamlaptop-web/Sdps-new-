import os

def replace_in_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()
    
    # We will do a generic replacement for the most common text colors
    content = content.replace("SchoolTextPrimary", "MaterialTheme.colorScheme.onBackground")
    content = content.replace("SchoolTextSecondary", "MaterialTheme.colorScheme.onSurfaceVariant")
    
    with open(filepath, 'w') as f:
        f.write(content)

replace_in_file("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt")
replace_in_file("app/src/main/java/com/example/ui/screens/SettingsScreen.kt")
replace_in_file("app/src/main/java/com/example/ui/screens/AddStudentScreen.kt")
replace_in_file("app/src/main/java/com/example/ui/screens/NoticeHubScreen.kt")
print("Replaced colors successfully")
