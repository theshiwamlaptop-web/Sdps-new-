with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    content = f.read()

old_str = """                                    Text("Release / Update Ledger", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }"""

new_str = """                                    Text("Release / Update Ledger", fontWeight = FontWeight.Bold)
                                }
                                }
                            }
                        }
                    }"""

content = content.replace(old_str, new_str)

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(content)
