import re

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    text = f.read()

# 1. Remove nestedScroll from MainSchoolAppContainer
pattern_scaffold = r'        Scaffold\(\n            modifier = if \(isDashboardOrLogin\) modifier else modifier\.nestedScroll\(scrollBehavior\.nestedScrollConnection\),'
replacement_scaffold = """        Scaffold(
            modifier = modifier,"""
text = re.sub(pattern_scaffold, replacement_scaffold, text)

# 2. Add Chat, Attendance, Add Student to the exclusions for TopAppBar
pattern_if = r'if \(currentScreen != AppScreen\.LOGIN && currentScreen != AppScreen\.SPLASH && currentScreen != AppScreen\.DASHBOARD\) \{'
replacement_if = """val screensWithoutMainTopBar = listOf(AppScreen.LOGIN, AppScreen.SPLASH, AppScreen.DASHBOARD, AppScreen.CHAT, AppScreen.ATTENDANCE, AppScreen.ADD_STUDENT)
                if (currentScreen !in screensWithoutMainTopBar) {"""
text = re.sub(pattern_if, replacement_if, text)

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(text)

