import re

with open('app/src/main/java/com/example/ui/screens/AddStudentScreen.kt', 'r') as f:
    content = f.read()

# Fix finalId and finalAdmissionNo generation
old_id_gen = """val finalId = editingStudent?.studentId ?: "S${System.currentTimeMillis().toString().takeLast(6)}"
                        val finalAdmissionNo = editingStudent?.admissionNo ?: "ADM_$finalId\""""

new_id_gen = """val finalId = editingStudent?.studentId ?: "STU_${java.util.UUID.randomUUID().toString().replace("-", "").take(8).uppercase()}"
                        val finalAdmissionNo = editingStudent?.admissionNo ?: "ADM_${System.currentTimeMillis()}" """

content = content.replace(old_id_gen, new_id_gen)

# Fix addOrUpdateStudent call
old_call = "viewModel.addOrUpdateStudent(newStudent)"
new_call = "viewModel.addOrUpdateStudent(newStudent, isEdit = (editingStudent != null))"

content = content.replace(old_call, new_call)

with open('app/src/main/java/com/example/ui/screens/AddStudentScreen.kt', 'w') as f:
    f.write(content)
