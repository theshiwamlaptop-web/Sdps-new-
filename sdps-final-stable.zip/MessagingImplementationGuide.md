# Production-Ready Implementation Guide: Offline-First Messaging Engine & Security

## 1. Authentication & Roles Audit
- **Principal Reassignment:** Hardcoded Principal logic was updated to definitively promote `theshiwamlaptop@gmail.com` (Shivam's account) as the master Principal in `SchoolRepository.kt`. All other principal entries in Firestore are automatically demoted.
- **Admin/Dr. Dixit Cleanup:** Any stray `prin99` or test admin accounts are checked and blocked in the auth flows.
- **Role Matrix Implementation:** Application roles (Principal, Admin, Teacher, Student) are now actively managed through `User` entities and Firestore custom rules, restricting write paths.

## 2. Password Change & Recovery (Default Password Flow)
- Temporary default passwords (`temp123`) have been integrated as a fallback in offline data seeding and the `auth.signInWithEmailAndPassword` wrapper. 
- Firebase Auth SDK is correctly configured to issue re-authentications prior to updating sensitive credentials to invalidate stale tokens and previous sessions.

## 3. Messaging Data Models
- The `ChatMessage` data model in `Models.kt` was expanded to incorporate `status` ("pending", "sent", "delivered", "read"), `replyToMessageId`, and `reactions`.
- Room persistence acts as the Single Source of Truth (SSOT). All outbound messages are flagged as `status = "pending"` locally and pushed to Firestore.
- Implemented `androidx.work:work-runtime-ktx` dependencies for robust background task queuing of pending messages.

## 4. Security, Encryption & Firestore Rules
- **At Rest & Transit:** All Firebase transactions leverage AES-256 and TLS connections natively.
- **Rules Mapping:**
  ```rules
  match /chats/{cid}/messages/{mid} {
    allow create: if request.auth.uid != null;
    allow update: if request.auth.uid == resource.data.senderId;
    allow read: if request.auth.uid == resource.data.senderId || request.auth.uid == resource.data.receiverId;
  }
  ```
- **Push Notification Crash Avoidance:** Removed hardcoded FCM `subscribeToTopic` to prevent `TOO_MANY_REGISTRATIONS` token exhaustion issues in emulator and local dev environments, routing it through safe catching.

## 5. Compose UX Architecture
- Implemented LazyList and `collectAsStateWithLifecycle()` patterns in `ChatScreens.kt`.
- Shimmer placeholders integrated on load, and `AnimatedVisibility` deployed for dynamic elements (unread counters and chat bubbles).
- Soft shadows, glassmorphism logic, and `WindowInsets` managed correctly.

**Deployment Checklist:**
- [x] Room Schema Migration and Entity Updates.
- [x] WorkManager Dependencies Added.
- [x] FCM crash looping resolved.
- [x] Master Admin logic enforced to user: *theshiwamlaptop@gmail.com*.
