import re

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "r") as f:
    content = f.read()

# Replace the TEST ID FOR USER VERIFICATION and ONE-TIME FORCE SYNC FOR THE USER to check for auth
old_block = """            // TEST ID FOR USER VERIFICATION
            val fs = firestore
            if (fs != null) {"""
new_block = """            // TEST ID FOR USER VERIFICATION
            val fs = firestore
            if (fs != null && firebaseAuth?.currentUser != null) {"""

content = content.replace(old_block, new_block)

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "w") as f:
    f.write(content)
