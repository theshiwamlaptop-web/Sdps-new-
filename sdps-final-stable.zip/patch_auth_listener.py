import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

bad_listener = '''        val auth = firebaseAuth
        if (auth != null) {
            authStateListener = FirebaseAuth.AuthStateListener { currentAuth ->
                val fUser = currentAuth.currentUser
                if (fUser == null) {
                    if (isFirebaseModeFlow.value && _currentUser.value != null) {
                        _currentUser.value = null
                        prefs.edit().remove("last_logged_in_user_id").apply()
                    }
                }
            }
            auth.addAuthStateListener(authStateListener!!)
        }'''
good_listener = '''        val auth = firebaseAuth
        if (auth != null) {
            authStateListener = FirebaseAuth.AuthStateListener { currentAuth ->
                val fUser = currentAuth.currentUser
                if (fUser == null) {
                    if (isFirebaseModeFlow.value && _currentUser.value != null) {
                        _currentUser.value = null
                        prefs.edit().remove("last_logged_in_user_id").apply()
                    }
                } else {
                    android.util.Log.i("SchoolRepository", "AuthStateListener: User is logged in (${fUser.uid}). Restoring session and starting sync...")
                    scope.launch {
                        if (_currentUser.value == null) {
                            checkAndRestoreSession()
                        }
                        startBackgroundFirebaseSync()
                    }
                }
            }
            auth.addAuthStateListener(authStateListener!!)
        }'''

content = content.replace(bad_listener, good_listener)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)

print("Patched auth listener.")
