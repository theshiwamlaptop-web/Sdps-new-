import re

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'r') as f:
    content = f.read()

old_tt = """    // TIMETABLE OPERATIONS
    fun saveTimetable(timetable: Timetable) {
        viewModelScope.launch {
            repository.saveTimetable(timetable)
        }
    }"""

new_tt = """    // TIMETABLE OPERATIONS
    fun saveTimetable(timetable: Timetable) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only management can modify timetables."
                return@launch
            }
            repository.saveTimetable(timetable)
        }
    }"""

content = content.replace(old_tt, new_tt)

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'w') as f:
    f.write(content)
