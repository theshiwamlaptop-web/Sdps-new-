import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

content = content.replace(
    'StudentIdentityBadge(student = student)',
    'StudentIdentityBadge(student = student, showUserId = showUserId)'
)
content = content.replace(
    'StudentFullDetailsPanel(student = student)',
    'StudentFullDetailsPanel(student = student, showUserId = showUserId)'
)

with open(filepath, 'w') as f:
    f.write(content)
