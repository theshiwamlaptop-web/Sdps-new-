with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

content = content.replace('?.addOnFailureListener { e -> android.os.Handler(android.os.Looper.getMainLooper()).post { android.widget.Toast.makeText(context, "Firebase Error: ${e.message}", android.widget.Toast.LENGTH_LONG).show() } }', '')
# Fix firestore!! where needed? Actually the build failed because I changed firestore!! to firestore? incorrectly.
# Let's fix line 1796 and 1810 manually
with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)

