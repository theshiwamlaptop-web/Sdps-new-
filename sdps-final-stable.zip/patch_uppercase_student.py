import re

with open("app/src/main/java/com/example/ui/screens/AddStudentScreen.kt", "r") as f:
    content = f.read()

# sName
content = re.sub(r'onValueChange = \{ sName = it \}', r'onValueChange = { sName = it.uppercase() }', content)
# sFather
content = re.sub(r'onValueChange = \{ sFather = it \}', r'onValueChange = { sFather = it.uppercase() }', content)
# sMother
content = re.sub(r'onValueChange = \{ sMother = it \}', r'onValueChange = { sMother = it.uppercase() }', content)
# sGuardian
content = re.sub(r'onValueChange = \{ sGuardian = it \}', r'onValueChange = { sGuardian = it.uppercase() }', content)

with open("app/src/main/java/com/example/ui/screens/AddStudentScreen.kt", "w") as f:
    f.write(content)
