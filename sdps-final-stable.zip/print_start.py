with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    lines = f.readlines()

count = 0
for i, line in enumerate(lines[:2000]):
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
    
    if "fun TeacherManagementScreen" in line:
        print(f"Start TeacherManagementScreen at Line {i+1}: count {count}")
