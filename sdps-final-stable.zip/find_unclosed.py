with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    lines = f.readlines()

stack = []
for i in range(136, 873):
    line = lines[i]
    clean = line.strip()
    if clean.startswith('//'): continue
    
    # We need to find character positions for better matching, but let's just do line level
    for char in clean:
        if char == '{':
            stack.append(i+1)
        elif char == '}':
            if stack:
                stack.pop()

print("Unclosed braces opened at lines:")
for l in stack:
    print(f"Line {l}: {lines[l-1].strip()}")
