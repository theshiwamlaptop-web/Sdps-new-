import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

target = """        if (selectedStudentForIDCard != null) {
            StudentIDCardLayout(
                student = selectedStudentForIDCard!!,
                onDismiss = { selectedStudentForIDCard = null }
            )
        }"""
        
replacement = """        if (selectedStudentForIDCard != null) {
            val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""
            StudentIDCardLayout(
                student = selectedStudentForIDCard!!,
                onDismiss = { selectedStudentForIDCard = null },
                showUserId = (roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN")
            )
        }"""

content = content.replace(target, replacement)

with open(filepath, 'w') as f:
    f.write(content)

