import re

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    content = f.read()

old_code = 'tId = "T-${System.currentTimeMillis().toString().takeLast(6)}"'
new_code = 'tId = "T-${java.util.UUID.randomUUID().toString().replace("-", "").take(6).uppercase()}"'

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(content)
