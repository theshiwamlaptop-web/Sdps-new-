import re

with open("app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt") as f:
    code = f.read()

# Extract all component names (capitalized words before '(' or '{')
components = re.findall(r'([A-Z][a-zA-Z0-9_]*)\s*[\(\{]', code)
for c in set(components):
    if c not in ["MaterialTheme", "Color", "String", "Int", "Boolean", "Float", "Modifier", "RoundedCornerShape", "Alignment", "Arrangement", "KeyboardOptions", "VisualTransformation", "PasswordVisualTransformation", "Icons", "ImeAction", "KeyboardType", "Toast", "Log", "Offset", "Brush", "EaseInOutSine", "LinearEasing", "EaseOutExpo", "RepeatMode", "LottieConstants", "MascotState", "Triple", "Unit"]:
        print(c)
