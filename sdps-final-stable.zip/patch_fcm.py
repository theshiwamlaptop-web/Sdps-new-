import re

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "r") as f:
    content = f.read()

content = content.replace(
"""            try {
                FirebaseMessaging.getInstance().subscribeToTopic("notices")
            } catch (e: Exception) {}""",
"""            // FirebaseMessaging.getInstance().subscribeToTopic("notices") // Removed to prevent TOO_MANY_REGISTRATIONS in emulator""")

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "w") as f:
    f.write(content)
