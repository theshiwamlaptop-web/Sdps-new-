import re

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "r") as f:
    content = f.read()

if "import androidx.room.withTransaction" not in content:
    content = content.replace("import kotlinx.coroutines.flow.map", "import kotlinx.coroutines.flow.map\nimport androidx.room.withTransaction")

# Step 1: Wrap snapshot?.documentChanges?.forEach with scope.launch { db.withTransaction { ... } }
content = content.replace("                snapshot?.documentChanges?.forEach { change ->", 
"""                scope.launch {
                    db.withTransaction {
                        snapshot?.documentChanges?.forEach { change ->""")

# Step 2: Remove inner scope.launch { ... }
# There are two forms of inner scope.launch in the sync method.
# Form 1:
content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.studentDao().insertStudent(student)
                            }
                        }""", 
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.studentDao().insertStudent(student)
                            } else {
                                db.studentDao().deleteStudentById(student.studentId)
                            }""")

content = content.replace("""                                scope.launch {
                                    if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                        db.studentDao().insertStudent(fallbackStudent)
                                    } else {
                                        val existing = db.studentDao().getStudentById(fallbackStudent.studentId)
                                        if (existing != null) {
                                            db.studentDao().insertStudent(existing.copy(isDeleted = true, status = "DELETED"))
                                        }
                                    }
                                }""",
"""                                    if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                        db.studentDao().insertStudent(fallbackStudent)
                                    } else {
                                        val existing = db.studentDao().getStudentById(fallbackStudent.studentId)
                                        if (existing != null) {
                                            db.studentDao().insertStudent(existing.copy(isDeleted = true, status = "DELETED"))
                                        }
                                    }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.teacherDao().insertTeacher(teacher)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.teacherDao().insertTeacher(teacher)
                            } else {
                                db.teacherDao().deleteTeacherById(teacher.teacherId)
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.attendanceDao().insertAttendance(listOf(att))
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.attendanceDao().insertAttendance(listOf(att))
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.feeDao().insertFee(fee)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.feeDao().insertFee(fee)
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.homeworkDao().insertHomework(homework)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.homeworkDao().insertHomework(homework)
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.noticeDao().insertNotice(notice)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.noticeDao().insertNotice(notice)
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.timetableDao().insertTimetable(timetable)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.timetableDao().insertTimetable(timetable)
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.chatDao().insertMessage(msg)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.chatDao().insertMessage(msg)
                            }""")

content = content.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.feeLedgerDao().insertLedgerEntry(entry)
                            }
                        }""",
"""                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.feeLedgerDao().insertLedgerEntry(entry)
                            }""")


# Step 3: Add closing braces for scope.launch { db.withTransaction {
# They need to be added before:
#             }
#             snapshotListeners.add(listener)
content = content.replace("""                }
            }
            snapshotListeners.add(listener)""", 
"""                }
                    }
                }
            }
            snapshotListeners.add(listener)""")

with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "w") as f:
    f.write(content)

