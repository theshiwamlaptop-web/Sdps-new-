with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    lines = f.readlines()

count = 0
for i, line in enumerate(lines[:450]):
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
    
    if "fun DashboardScreen" in line:
        count = 1
        print(f"Start Dashboard at {i+1}")
    if i > 390 and i <= 420:
        print(f"Line {i+1}: count {count} - {line.strip()}")
