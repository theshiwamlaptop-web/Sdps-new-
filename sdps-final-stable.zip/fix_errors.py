import re

# Fix PremiumLoginScreen
with open("app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    "LaunchedEffect(isPasswordFocused, isLoggingIn = isAuthenticating)",
    "LaunchedEffect(isPasswordFocused, isAuthenticating)"
)
content = content.replace("import androidx.compose.ui.draw.blur", "import androidx.compose.ui.draw.blur\nimport androidx.compose.ui.draw.clip")

with open("app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt", "w") as f:
    f.write(content)

# Fix SchoolAppScreens
with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

content = content.replace("AppScreen.LOGIN -> LoginScreen(viewModel = viewModel)", "AppScreen.LOGIN -> PremiumLoginScreen(viewModel = viewModel)")
content = content.replace("@Composable\n// 4. TEACHER MANAGEMENT", "// 4. TEACHER MANAGEMENT")

with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
    f.write(content)
