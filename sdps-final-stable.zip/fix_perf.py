import os

filepath = "app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt"
with open(filepath, "r") as f:
    content = f.read()

target = """    val bgBrush = Brush.linearGradient(
        colors = listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.tertiaryContainer),
        start = Offset(0f, 0f),
        end = Offset(gradientOffset, gradientOffset)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgBrush)
            .windowInsetsPadding(WindowInsets.ime),
        contentAlignment = Alignment.Center
    ) {"""

replacement = """    val color1 = MaterialTheme.colorScheme.primaryContainer
    val color2 = MaterialTheme.colorScheme.secondaryContainer
    val color3 = MaterialTheme.colorScheme.tertiaryContainer

    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                val bgBrush = Brush.linearGradient(
                    colors = listOf(color1, color2, color3),
                    start = Offset(0f, 0f),
                    end = Offset(gradientOffset, gradientOffset)
                )
                drawRect(bgBrush)
            }
            .windowInsetsPadding(WindowInsets.ime),
        contentAlignment = Alignment.Center
    ) {"""

if target in content:
    content = content.replace(target, replacement)
    with open(filepath, "w") as f:
        f.write(content)
    print("Success")
else:
    print("Target not found")
