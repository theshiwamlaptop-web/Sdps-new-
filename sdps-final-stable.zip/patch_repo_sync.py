import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

bad_int = '''    suspend fun performSchoolStructureMigration(): Result<Unit>
}'''

good_int = '''    suspend fun performSchoolStructureMigration(): Result<Unit>
    fun forceSync()
}'''
content = content.replace(bad_int, good_int)

bad_impl = '''    private fun startBackgroundFirebaseSync() {'''

good_impl = '''    override fun forceSync() {
        startBackgroundFirebaseSync()
    }

    private fun startBackgroundFirebaseSync() {'''
content = content.replace(bad_impl, good_impl)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
