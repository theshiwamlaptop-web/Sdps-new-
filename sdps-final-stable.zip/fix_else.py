with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

import re
# Replace `}\n                } else {` with `} else {`
text = re.sub(r'\}\s*\n\s*\}\s*else\s*\{', '} else {', text)

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)

