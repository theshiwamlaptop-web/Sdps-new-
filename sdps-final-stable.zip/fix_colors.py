import re

with open("app/src/main/java/com/example/ui/screens/ChatScreens.kt", "r") as f:
    content = f.read()

old_colors = """                colors = OutlinedTextFieldDefaults.colors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = MaterialTheme.colorScheme.primary
                ),"""

new_colors = """                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = MaterialTheme.colorScheme.primary
                ),"""

content = content.replace(old_colors, new_colors)

with open("app/src/main/java/com/example/ui/screens/ChatScreens.kt", "w") as f:
    f.write(content)

print("Fixed colors")
