with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

text = text.replace("""                                    )
                                }
                    }
                            }
                        }
                    }
                                1 -> { // CLASSES COMPREHENSIVE ASSIGNMENT""", """                                    )
                                }
                    }
                            }
                        }
                    }
                }
            }
                1 -> { // CLASSES COMPREHENSIVE ASSIGNMENT""")

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
