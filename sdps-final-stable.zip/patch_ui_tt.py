import re

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    content = f.read()

old_tt_start = """@Composable
fun TimetableScreen(viewModel: SchoolViewModel) {
    val timetables by viewModel.timetablesState.collectAsState()
    var selectedClassTab by remember { mutableStateOf("Class X") }"""

new_tt_start = """@Composable
fun TimetableScreen(viewModel: SchoolViewModel) {
    val timetables by viewModel.timetablesState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isAdmin = currentUser?.role in listOf("ADMIN", "HEAD_ADMIN", "PRINCIPAL")
    var selectedClassTab by remember { mutableStateOf("Class X") }"""

content = content.replace(old_tt_start, new_tt_start)

old_edit_button = """                    IconButton(onClick = { isEditState = !isEditState }) {"""
new_edit_button = """                    if (isAdmin) IconButton(onClick = { isEditState = !isEditState }) {"""

content = content.replace(old_edit_button, new_edit_button)

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(content)
