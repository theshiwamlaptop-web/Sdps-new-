package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.FeeLedgerEntry
import com.example.data.model.Student
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PaymentReceiptPdfHelper {

    fun generateReceiptPdf(
        context: Context,
        student: Student,
        entries: List<FeeLedgerEntry>,
        paymentMode: String,
        transactionRef: String,
        receiptNo: String,
        totalPaidAmount: Double,
        collectedBy: String
    ): File? {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size in points
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint()
            val titlePaint = Paint()
            val boldPaint = Paint()
            val headerBgPaint = Paint()

            // Background & Border
            paint.color = Color.WHITE
            canvas.drawRect(0f, 0f, 595f, 842f, paint)

            // Header Background Bar
            headerBgPaint.color = Color.parseColor("#1E3A8A") // Deep Navy Blue
            canvas.drawRect(20f, 20f, 575f, 100f, headerBgPaint)

            // Header Text
            titlePaint.color = Color.WHITE
            titlePaint.textSize = 22f
            titlePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("S.D. PUBLIC SCHOOL", 40f, 55f, titlePaint)

            val subTitlePaint = Paint().apply {
                color = Color.parseColor("#E0E7FF")
                textSize = 12f
            }
            canvas.drawText("Official Fee Payment Receipt | Academic Session 2026-27", 40f, 75f, subTitlePaint)

            // Draw School Logo Icon on Header
            try {
                val opts = android.graphics.BitmapFactory.Options().apply {
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                val logoBitmap = android.graphics.BitmapFactory.decodeResource(context.resources, com.example.R.drawable.app_logo, opts)
                if (logoBitmap != null) {
                    val scaledLogo = android.graphics.Bitmap.createScaledBitmap(logoBitmap, 60, 60, true)
                    canvas.drawBitmap(scaledLogo, 500f, 25f, null)
                    if (scaledLogo != logoBitmap) {
                        scaledLogo.recycle()
                    }
                    logoBitmap.recycle()
                }
            } catch (e: Exception) {
                // Ignore if logo unavailable
            }

            // Receipt Metadata Box
            val boxPaint = Paint().apply {
                color = Color.parseColor("#F3F4F6")
                style = Paint.Style.FILL
            }
            canvas.drawRect(20f, 110f, 575f, 160f, boxPaint)

            boldPaint.color = Color.parseColor("#111827")
            boldPaint.textSize = 12f
            boldPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

            val textPaint = Paint().apply {
                color = Color.parseColor("#374151")
                textSize = 11f
            }

            val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
            val currentDateStr = dateFormat.format(Date())

            canvas.drawText("Receipt No: $receiptNo", 35f, 132f, boldPaint)
            canvas.drawText("Date & Time: $currentDateStr", 300f, 132f, textPaint)
            canvas.drawText("Payment Mode: $paymentMode ${if (transactionRef.isNotBlank()) "($transactionRef)" else ""}", 35f, 150f, textPaint)
            canvas.drawText("Collected By: $collectedBy", 300f, 150f, textPaint)

            // Student Information Section
            boldPaint.textSize = 14f
            boldPaint.color = Color.parseColor("#1E3A8A")
            canvas.drawText("STUDENT INFORMATION", 20f, 185f, boldPaint)

            canvas.drawRect(20f, 195f, 575f, 265f, boxPaint)

            boldPaint.textSize = 11f
            boldPaint.color = Color.BLACK
            canvas.drawText("Student Name:", 35f, 215f, boldPaint)
            canvas.drawText(student.name, 140f, 215f, textPaint)

            canvas.drawText("Admission No:", 320f, 215f, boldPaint)
            canvas.drawText(student.admissionNo.ifBlank { "N/A" }, 420f, 215f, textPaint)

            canvas.drawText("Class & Roll No:", 35f, 235f, boldPaint)
            canvas.drawText("${student.className} (Roll No: ${student.rollNo})", 140f, 235f, textPaint)

            canvas.drawText("Father's Name:", 320f, 235f, boldPaint)
            canvas.drawText(student.fatherName.ifBlank { "N/A" }, 420f, 235f, textPaint)

            canvas.drawText("Phone Number:", 35f, 255f, boldPaint)
            canvas.drawText(student.phone.ifBlank { "N/A" }, 140f, 255f, textPaint)

            // Selected Months Breakdown
            boldPaint.textSize = 14f
            boldPaint.color = Color.parseColor("#1E3A8A")
            canvas.drawText("SELECTED MONTHS & BREAKDOWN", 20f, 290f, boldPaint)

            // Table Header
            val tableHeaderPaint = Paint().apply {
                color = Color.parseColor("#3B82F6")
            }
            canvas.drawRect(20f, 300f, 575f, 325f, tableHeaderPaint)

            val tableHeaderTxtPaint = Paint().apply {
                color = Color.WHITE
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            canvas.drawText("Month", 30f, 317f, tableHeaderTxtPaint)
            canvas.drawText("Tuition", 140f, 317f, tableHeaderTxtPaint)
            canvas.drawText("Exam", 220f, 317f, tableHeaderTxtPaint)
            canvas.drawText("Transport", 300f, 317f, tableHeaderTxtPaint)
            canvas.drawText("Ad/Game/Fine", 390f, 317f, tableHeaderTxtPaint)
            canvas.drawText("Paid Amount", 490f, 317f, tableHeaderTxtPaint)

            var yPos = 345f
            val linePaint = Paint().apply {
                color = Color.parseColor("#E5E7EB")
                strokeWidth = 1f
            }

            for (e in entries) {
                canvas.drawText(e.month, 30f, yPos, boldPaint)
                canvas.drawText("₹${"%.0f".format(e.tuitionFee)}", 140f, yPos, textPaint)
                canvas.drawText("₹${"%.0f".format(e.examFee)}", 220f, yPos, textPaint)
                canvas.drawText("₹${"%.0f".format(e.transportFee)}", 300f, yPos, textPaint)
                val otherSum = e.admissionFee + e.gameFee + e.lateFee - e.concession
                canvas.drawText("₹${"%.0f".format(otherSum)}", 390f, yPos, textPaint)
                val paidM = if (e.paidAmount > 0) e.paidAmount else (e.admissionFee + e.tuitionFee + e.gameFee + e.examFee + e.transportFee + e.lateFee - e.concession)
                canvas.drawText("₹${"%.0f".format(paidM)}", 490f, yPos, boldPaint)

                yPos += 15f
                canvas.drawLine(20f, yPos, 575f, yPos, linePaint)
                yPos += 18f

                if (yPos > 700f) break
            }

            // Total Summary Box
            yPos += 10f
            val totalBoxPaint = Paint().apply {
                color = Color.parseColor("#FEF3C7") // Light Amber
            }
            canvas.drawRect(20f, yPos, 575f, yPos + 45f, totalBoxPaint)

            boldPaint.textSize = 14f
            boldPaint.color = Color.parseColor("#92400E")
            canvas.drawText("TOTAL AMOUNT COLLECTED:", 35f, yPos + 28f, boldPaint)

            boldPaint.textSize = 16f
            canvas.drawText("₹${"%,.2f".format(totalPaidAmount)}", 380f, yPos + 28f, boldPaint)

            // Footer / Signatures
            yPos += 75f
            canvas.drawLine(400f, yPos, 550f, yPos, linePaint)
            textPaint.textSize = 10f
            canvas.drawText("Authorized Cashier / Principal Signature", 370f, yPos + 15f, textPaint)

            canvas.drawText("Note: Fee once paid is non-refundable. Please keep this receipt safe.", 20f, yPos + 40f, textPaint)
            canvas.drawText("This is an official computer-generated receipt issued by S.D. Public School.", 20f, yPos + 55f, textPaint)

            pdfDocument.finishPage(page)

            val file = File(context.getExternalFilesDir(null), "Receipt_$receiptNo.pdf")
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()

            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun openReceiptPdf(context: Context, pdfFile: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Open Fee Receipt PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "PDF saved to: ${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()
        }
    }

    fun shareReceiptPdf(context: Context, pdfFile: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "S.D. Public School Fee Receipt")
                putExtra(Intent.EXTRA_TEXT, "Attached is the fee receipt for S.D. Public School.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Fee Receipt PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to share PDF: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
