package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Student
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SchoolReportPdfHelper {

    fun generateReportCardPdf(
        context: Context,
        student: Student,
        examTitle: String,
        marksMap: Map<String, Int>,
        totalMaxMarks: Int,
        totalObtainedMarks: Int,
        percentage: Double,
        grade: String,
        remarks: String,
        issuedBy: String
    ): File? {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 standard size (points)
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val titlePaint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply { isAntiAlias = true }
            val textPaint = Paint().apply { isAntiAlias = true }
            val linePaint = Paint().apply { isAntiAlias = true }

            // Clean background
            paint.color = Color.WHITE
            canvas.drawRect(0f, 0f, 595f, 842f, paint)

            // Outer Border
            linePaint.color = Color.parseColor("#CBD5E1")
            linePaint.style = Paint.Style.STROKE
            linePaint.strokeWidth = 1.5f
            canvas.drawRect(15f, 15f, 580f, 827f, linePaint)

            // Header Banner
            val headerBg = Paint().apply {
                color = Color.parseColor("#1E3A8A") // Classic Navy School Blue
                style = Paint.Style.FILL
            }
            canvas.drawRect(20f, 20f, 575f, 110f, headerBg)

            // School Title
            titlePaint.color = Color.WHITE
            titlePaint.textSize = 22f
            titlePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("S.D. PUBLIC SCHOOL", 40f, 55f, titlePaint)

            val subTitlePaint = Paint().apply {
                color = Color.parseColor("#E0E7FF")
                textSize = 12f
                isAntiAlias = true
            }
            canvas.drawText("Affiliated to CBSE | Senior Secondary Institution", 40f, 75f, subTitlePaint)
            canvas.drawText("Official Student Academic Progress & Report Card", 40f, 95f, subTitlePaint)

            // Draw School Logo if available
            try {
                val opts = android.graphics.BitmapFactory.Options().apply {
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                val logoBitmap = android.graphics.BitmapFactory.decodeResource(context.resources, com.example.R.drawable.app_logo, opts)
                if (logoBitmap != null) {
                    val scaledLogo = android.graphics.Bitmap.createScaledBitmap(logoBitmap, 65, 65, true)
                    canvas.drawBitmap(scaledLogo, 495f, 30f, null)
                    if (scaledLogo != logoBitmap) {
                        scaledLogo.recycle()
                    }
                    logoBitmap.recycle()
                }
            } catch (e: Exception) {
                // Ignore fallback
            }

            // Student Info Card
            val cardBg = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(20f, 120f, 575f, 210f, 8f, 8f, cardBg)
            val cardBorder = Paint().apply {
                color = Color.parseColor("#E2E8F0")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(20f, 120f, 575f, 210f, 8f, 8f, cardBorder)

            boldPaint.color = Color.parseColor("#0F172A")
            boldPaint.textSize = 12f
            boldPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

            textPaint.color = Color.parseColor("#334155")
            textPaint.textSize = 11f

            val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH)
            val currentDateStr = dateFormat.format(Date())

            canvas.drawText("Student Name: ${student.name}", 35f, 145f, boldPaint)
            canvas.drawText("Admission No: ${student.admissionNo.ifBlank { student.studentId }}", 320f, 145f, textPaint)
            canvas.drawText("Class / Grade: ${student.className}", 35f, 165f, textPaint)
            canvas.drawText("Roll Number: ${student.rollNo.ifBlank { student.rollNumber.toString() }}", 320f, 165f, textPaint)
            canvas.drawText("Father's Name: ${student.fatherName.ifBlank { "N/A" }}", 35f, 185f, textPaint)
            canvas.drawText("Assessment Session: $examTitle (2026-27)", 320f, 185f, textPaint)
            canvas.drawText("Date of Issue: $currentDateStr", 35f, 202f, textPaint)
            canvas.drawText("Attendance Status: ${student.attendanceStatus}", 320f, 202f, textPaint)

            // Marks Table Header
            var y = 235f
            val tableHeaderPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                style = Paint.Style.FILL
            }
            canvas.drawRect(20f, y, 575f, y + 26f, tableHeaderPaint)

            val tableHeaderTxt = Paint().apply {
                color = Color.WHITE
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            canvas.drawText("S.No", 35f, y + 17f, tableHeaderTxt)
            canvas.drawText("Subject Name", 90f, y + 17f, tableHeaderTxt)
            canvas.drawText("Maximum Marks", 280f, y + 17f, tableHeaderTxt)
            canvas.drawText("Marks Obtained", 390f, y + 17f, tableHeaderTxt)
            canvas.drawText("Performance Grade", 490f, y + 17f, tableHeaderTxt)

            y += 26f

            // Marks Rows
            val rowBgAlt = Paint().apply {
                color = Color.parseColor("#F1F5F9")
                style = Paint.Style.FILL
            }

            var index = 1
            marksMap.forEach { (subject, marks) ->
                if (index % 2 == 0) {
                    canvas.drawRect(20f, y, 575f, y + 24f, rowBgAlt)
                }

                val subjGrade = when {
                    marks >= 90 -> "A+"
                    marks >= 80 -> "A"
                    marks >= 70 -> "B+"
                    marks >= 60 -> "B"
                    marks >= 50 -> "C"
                    marks >= 40 -> "D"
                    else -> "E (Needs Imp.)"
                }

                canvas.drawText("$index", 40f, y + 16f, textPaint)
                canvas.drawText(subject, 90f, y + 16f, boldPaint)
                canvas.drawText("100", 310f, y + 16f, textPaint)
                canvas.drawText("$marks", 420f, y + 16f, boldPaint)
                canvas.drawText(subjGrade, 510f, y + 16f, boldPaint)

                // Divider line
                linePaint.color = Color.parseColor("#E2E8F0")
                linePaint.strokeWidth = 0.8f
                canvas.drawLine(20f, y + 24f, 575f, y + 24f, linePaint)

                y += 24f
                index++
            }

            // Summary Totals Row
            val summaryBg = Paint().apply {
                color = Color.parseColor("#EEF2FF")
                style = Paint.Style.FILL
            }
            canvas.drawRect(20f, y, 575f, y + 32f, summaryBg)

            val summaryBold = Paint().apply {
                color = Color.parseColor("#1E3A8A")
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            canvas.drawText("Grand Total:", 90f, y + 20f, summaryBold)
            canvas.drawText("$totalMaxMarks", 310f, y + 20f, summaryBold)
            canvas.drawText("$totalObtainedMarks", 420f, y + 20f, summaryBold)
            canvas.drawText(grade, 510f, y + 20f, summaryBold)

            y += 45f

            // Assessment Evaluation Box
            val evalBox = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(20f, y, 575f, y + 100f, 8f, 8f, evalBox)
            canvas.drawRoundRect(20f, y, 575f, y + 100f, 8f, 8f, cardBorder)

            boldPaint.textSize = 13f
            canvas.drawText("Aggregate Percentage: ${"%.2f".format(percentage)}%", 35f, y + 25f, boldPaint)
            canvas.drawText("Overall Result: $grade", 320f, y + 25f, boldPaint)

            textPaint.textSize = 11f
            canvas.drawText("Principal & Class Teacher Observations:", 35f, y + 50f, boldPaint)
            canvas.drawText(remarks.ifBlank { "Satisfactory academic performance and steady progress throughout the term." }, 35f, y + 70f, textPaint)

            y += 120f

            // Signatures & Stamp Area
            canvas.drawLine(40f, y + 50f, 180f, y + 50f, linePaint)
            canvas.drawText("Class Teacher Signature", 45f, y + 65f, textPaint)

            canvas.drawLine(230f, y + 50f, 360f, y + 50f, linePaint)
            canvas.drawText("Parent / Guardian", 245f, y + 65f, textPaint)

            canvas.drawLine(410f, y + 50f, 550f, y + 50f, linePaint)
            boldPaint.textSize = 11f
            canvas.drawText("Principal / Authorized", 420f, y + 65f, boldPaint)
            if (issuedBy.isNotBlank()) {
                textPaint.textSize = 9f
                canvas.drawText("Issued by: $issuedBy", 420f, y + 78f, textPaint)
            }

            // Legal Footer
            val footerPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 9f
                isAntiAlias = true
            }
            canvas.drawText("This report card is generated electronically by S.D. Public School ERP System.", 120f, 810f, footerPaint)

            pdfDocument.finishPage(page)

            val studentSlug = student.name.trim().replace(Regex("[^a-zA-Z0-9]"), "_")
            val file = File(context.getExternalFilesDir(null), "ReportCard_${studentSlug}_${student.studentId}.pdf")
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()

            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun generateAnalyticsSummaryPdf(
        context: Context,
        totalStudents: Int,
        activeStudents: Int,
        totalTeachers: Int,
        totalFeesBilled: Double,
        totalFeesCollected: Double,
        totalFeesDues: Double,
        collectionRate: Double,
        studentAttendancePercent: Double,
        staffAttendancePercent: Double,
        noticesCount: Int,
        homeworkCount: Int,
        classDistribution: List<Pair<String, Int>>
    ): File? {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val titlePaint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply { isAntiAlias = true }
            val textPaint = Paint().apply { isAntiAlias = true }
            val linePaint = Paint().apply { isAntiAlias = true }

            paint.color = Color.WHITE
            canvas.drawRect(0f, 0f, 595f, 842f, paint)

            // Outer border
            linePaint.color = Color.parseColor("#CBD5E1")
            linePaint.style = Paint.Style.STROKE
            linePaint.strokeWidth = 1.5f
            canvas.drawRect(15f, 15f, 580f, 827f, linePaint)

            // Header Banner
            val headerBg = Paint().apply {
                color = Color.parseColor("#0F172A")
                style = Paint.Style.FILL
            }
            canvas.drawRect(20f, 20f, 575f, 100f, headerBg)

            titlePaint.color = Color.WHITE
            titlePaint.textSize = 20f
            titlePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("S.D. PUBLIC SCHOOL — EXECUTIVE ANALYTICS", 35f, 55f, titlePaint)

            val subTitlePaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 11f
                isAntiAlias = true
            }
            val dateFormat = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.ENGLISH)
            canvas.drawText("Institutional Performance & Operations Report | Generated: ${dateFormat.format(Date())}", 35f, 80f, subTitlePaint)

            var y = 115f

            // 1. FINANCIAL SUMMARY SECTION
            boldPaint.color = Color.parseColor("#1E3A8A")
            boldPaint.textSize = 14f
            boldPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("1. Financial & Fee Ledger Analytics", 25f, y + 15f, boldPaint)

            val sectionBg = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            val borderPaint = Paint().apply {
                color = Color.parseColor("#E2E8F0")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            y += 25f
            canvas.drawRoundRect(20f, y, 575f, y + 90f, 8f, 8f, sectionBg)
            canvas.drawRoundRect(20f, y, 575f, y + 90f, 8f, 8f, borderPaint)

            textPaint.color = Color.parseColor("#334155")
            textPaint.textSize = 11f
            boldPaint.color = Color.parseColor("#0F172A")
            boldPaint.textSize = 11f

            canvas.drawText("Total Billed Revenue: ₹${"%,.2f".format(totalFeesBilled)}", 35f, y + 25f, textPaint)
            canvas.drawText("Collected Amount: ₹${"%,.2f".format(totalFeesCollected)}", 35f, y + 45f, textPaint)
            canvas.drawText("Outstanding Dues: ₹${"%,.2f".format(totalFeesDues)}", 35f, y + 65f, textPaint)

            canvas.drawText("Fee Recovery Rate: ${"%.1f".format(collectionRate)}%", 320f, y + 25f, boldPaint)
            val statusStr = if (collectionRate >= 80) "Healthy / On Track" else "Action Required (Follow-up pending)"
            canvas.drawText("Collection Health: $statusStr", 320f, y + 45f, textPaint)

            y += 110f

            // 2. ATTENDANCE & DISCIPLINE
            boldPaint.color = Color.parseColor("#1E3A8A")
            boldPaint.textSize = 14f
            canvas.drawText("2. Attendance & Staff Metrics", 25f, y + 15f, boldPaint)

            y += 25f
            canvas.drawRoundRect(20f, y, 575f, y + 80f, 8f, 8f, sectionBg)
            canvas.drawRoundRect(20f, y, 575f, y + 80f, 8f, 8f, borderPaint)

            canvas.drawText("Student Daily Attendance Rate: ${"%.1f".format(studentAttendancePercent)}%", 35f, y + 25f, textPaint)
            canvas.drawText("Staff Attendance Quotient: ${"%.1f".format(staffAttendancePercent)}%", 35f, y + 45f, textPaint)
            canvas.drawText("Active Faculty Count: $totalTeachers Instructors", 320f, y + 25f, textPaint)
            val ratio = if (totalTeachers > 0) "1 : ${(totalStudents / totalTeachers.coerceAtLeast(1))}" else "N/A"
            canvas.drawText("Teacher-Student Ratio: $ratio", 320f, y + 45f, textPaint)

            y += 100f

            // 3. DEMOGRAPHICS & CLASS STRENGTH
            boldPaint.color = Color.parseColor("#1E3A8A")
            boldPaint.textSize = 14f
            canvas.drawText("3. Student Demographics & Strength Distribution", 25f, y + 15f, boldPaint)

            y += 25f
            canvas.drawRoundRect(20f, y, 575f, y + 170f, 8f, 8f, sectionBg)
            canvas.drawRoundRect(20f, y, 575f, y + 170f, 8f, 8f, borderPaint)

            canvas.drawText("Total Enrolled Students: $totalStudents", 35f, y + 22f, boldPaint)
            canvas.drawText("Active Scholars: $activeStudents", 220f, y + 22f, textPaint)
            canvas.drawText("Active Circulars: $noticesCount", 380f, y + 22f, textPaint)

            // Class breakdown grid (two columns)
            var classY = y + 45f
            var col = 0
            classDistribution.take(12).forEach { (className, count) ->
                val xPos = if (col == 0) 35f else 320f
                canvas.drawText("• $className: $count students", xPos, classY, textPaint)
                if (col == 1) {
                    classY += 18f
                    col = 0
                } else {
                    col = 1
                }
            }

            y += 190f

            // 4. CERTIFICATION FOOTER
            canvas.drawLine(40f, y + 45f, 200f, y + 45f, linePaint)
            canvas.drawText("Administrative In-charge", 45f, y + 60f, textPaint)

            canvas.drawLine(380f, y + 45f, 540f, y + 45f, linePaint)
            boldPaint.textSize = 11f
            canvas.drawText("Principal / Secretary", 400f, y + 60f, boldPaint)

            val footerPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 9f
                isAntiAlias = true
            }
            canvas.drawText("Official S.D. Public School ERP Analytics Report. System-generated and verifiable.", 100f, 810f, footerPaint)

            pdfDocument.finishPage(page)

            val file = File(context.getExternalFilesDir(null), "SD_School_Analytics_Summary.pdf")
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()

            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun openPdf(context: Context, pdfFile: File, title: String = "Open PDF") {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, title))
        } catch (e: Exception) {
            Toast.makeText(context, "PDF generated: ${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()
        }
    }

    fun sharePdf(context: Context, pdfFile: File, subject: String, body: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Report PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to share PDF: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
