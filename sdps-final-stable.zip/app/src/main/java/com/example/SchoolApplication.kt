package com.example

import android.app.Application
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.repository.SchoolRepository
import com.example.data.repository.SchoolRepositoryImpl
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class SchoolApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: SchoolRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Safe Firebase initialization
        try {
            FirebaseApp.initializeApp(this)

            try {
                val firebaseAppCheck = FirebaseAppCheck.getInstance()
                firebaseAppCheck.installAppCheckProviderFactory(
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                )
            } catch (e: Exception) {
                android.util.Log.w("SchoolApplication", "Firebase App Check init non-blocking: ${e.message}")
            }
        } catch (e: Exception) {
            android.util.Log.e("SchoolApplication", "FirebaseApp initialization failed", e)
        }

        // Database Initialization
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "sd_school_database"
        )
        // Never erase the offline cache on a forward schema upgrade. A real
        // migration can be added for a future schema change; downgrade fallback
        // remains available for development/recovery builds.
        .fallbackToDestructiveMigrationOnDowngrade()
        .build()

        // Repository Initialization
        repository = SchoolRepositoryImpl(applicationContext, database)
    }

    companion object {
        lateinit var instance: SchoolApplication
            private set
    }
}
