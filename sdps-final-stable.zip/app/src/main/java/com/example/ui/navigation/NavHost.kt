package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.SchoolViewModel
import com.example.ui.screens.PremiumLoginScreen
import com.example.ui.screens.MainSchoolAppContainer

@Composable
fun SchoolNavHost(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = "main_app",
        modifier = modifier
    ) {
        composable("main_app") {
            MainSchoolAppContainer(viewModel = viewModel)
        }
        composable("login") {
            PremiumLoginScreen(viewModel = viewModel)
        }
    }
}
