package com.example.ui.theme

import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val CornerSmallRadius = 8.dp
val CornerMediumRadius = 14.dp
val CornerLargeRadius = 20.dp
val CornerExtraLargeRadius = 28.dp
val CornerPillRadius = 999.dp

val ShapeSmall = RoundedCornerShape(CornerSmallRadius)
val ShapeMedium = RoundedCornerShape(CornerMediumRadius)
val ShapeLarge = RoundedCornerShape(CornerLargeRadius)
val ShapeExtraLarge = RoundedCornerShape(CornerExtraLargeRadius)
val ShapePill = RoundedCornerShape(CornerPillRadius)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = ShapeSmall,
    medium = ShapeMedium,
    large = ShapeLarge,
    extraLarge = ShapeExtraLarge
)
