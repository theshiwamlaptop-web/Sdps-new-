package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest

fun getAvatarVector(avatarKey: String?): ImageVector {
    return when (avatarKey) {
        "avatar_graduate" -> Icons.Filled.School
        "avatar_scholar" -> Icons.Filled.MenuBook
        "avatar_gamer" -> Icons.Filled.SportsEsports
        "avatar_teacher" -> Icons.Filled.Person
        "avatar_athlete" -> Icons.Filled.SportsBaseball
        "avatar_scientist" -> Icons.Filled.Science
        else -> Icons.Filled.Person
    }
}

fun isRemoteOrLocalImageUrl(avatar: String?): Boolean {
    if (avatar.isNullOrBlank()) return false
    val trimmed = avatar.trim()
    return trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("content://", ignoreCase = true) ||
            trimmed.startsWith("file://", ignoreCase = true) ||
            trimmed.startsWith("data:image", ignoreCase = true)
}

@Composable
fun UserProfileAvatar(
    avatarUrl: String?,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    fallbackIcon: ImageVector = Icons.Filled.Person,
    contentDescription: String = "User Profile Avatar",
    shape: Shape = CircleShape,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    borderColor: Color? = null,
    borderWidth: Dp = 0.dp,
    onClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val isUrl = isRemoteOrLocalImageUrl(avatarUrl)

    var boxModifier = modifier
        .size(size)
        .clip(shape)

    if (borderColor != null && borderWidth > 0.dp) {
        boxModifier = boxModifier.border(borderWidth, borderColor, shape)
    }

    if (onClick != null) {
        boxModifier = boxModifier.clickable(onClick = onClick)
    }

    Box(
        modifier = boxModifier.background(containerColor),
        contentAlignment = Alignment.Center
    ) {
        if (isUrl) {
            val validUrl = avatarUrl.orEmpty().trim()
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(context)
                    .data(validUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                loading = {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(size * 0.5f),
                            color = iconTint
                        )
                    }
                },
                error = {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = fallbackIcon,
                            contentDescription = contentDescription,
                            tint = iconTint,
                            modifier = Modifier.size(size * 0.6f)
                        )
                    }
                }
            )
        } else {
            val resolvedIcon = if (!avatarUrl.isNullOrBlank()) {
                getAvatarVector(avatarUrl)
            } else {
                fallbackIcon
            }
            Icon(
                imageVector = resolvedIcon,
                contentDescription = contentDescription,
                tint = iconTint,
                modifier = Modifier.size(size * 0.6f)
            )
        }
    }
}
