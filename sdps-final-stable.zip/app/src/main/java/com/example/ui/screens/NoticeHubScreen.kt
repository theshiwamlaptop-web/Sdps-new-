package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.Notice
import com.example.ui.SchoolViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NoticeHubScreen(viewModel: SchoolViewModel) {
    val notices by viewModel.noticesState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val students by viewModel.studentsState.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    
    val coroutineScope = rememberCoroutineScope()

    val myStudentInfo = remember(currentUser, students) {
        if (currentUser?.role == "STUDENT") students.find { it.studentId == currentUser?.userId } else null
    }

    val myTeacherInfo = remember(currentUser, teachers) {
        if (currentUser?.role == "CLASS_TEACHER" || currentUser?.role == "TEACHER") 
            teachers.find { it.teacherId == currentUser?.userId || it.email == currentUser?.email } 
        else null
    }

    val isPrincipal = currentUser?.role == "PRINCIPAL" || currentUser?.role == "ADMIN" || currentUser?.role == "HEAD_ADMIN"
    val isClassTeacher = currentUser?.role == "CLASS_TEACHER" || (myTeacherInfo?.classTeacherOf?.isNotBlank() == true)

    val canCreateNotice = isPrincipal || isClassTeacher

    var showCreateDialog by remember { mutableStateOf(false) }

    val tabs = listOf("All Notices", "Urgent Alerts", "Classroom", "Resources", "Events")
    val pagerState = rememberPagerState(pageCount = { tabs.size })

    // Filtering logic based on real-world visibility
    val accessibleNotices = remember(notices, currentUser, myStudentInfo, myTeacherInfo) {
        notices.filter { notice ->
            if (isPrincipal) {
                true // Principal sees everything
            } else if (notice.targetType == "ALL") {
                true // Global notices visible to all teachers and students
            } else {
                // Must be specific class target
                if (currentUser?.role == "STUDENT") {
                    myStudentInfo?.className == notice.targetClass
                } else if (isClassTeacher) {
                    myTeacherInfo?.classTeacherOf == notice.targetClass
                } else {
                    false
                }
            }
        }.sortedWith(
            compareBy<Notice> { !it.isUrgent } // Urgent pinned to top
            .thenByDescending { it.createdAt }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Communication Center",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Official S.D. Public School Hub",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (canCreateNotice) {
                FloatingActionButton(
                    onClick = { showCreateDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape,
                    modifier = Modifier.size(44.dp),
                    elevation = FloatingActionButtonDefaults.elevation(2.dp)
                ) {
                    Icon(Icons.Filled.AddAlert, contentDescription = "Publish Notice", modifier = Modifier.size(20.dp))
                }
            }
        }
        
        ScrollableTabRow(
            selectedTabIndex = pagerState.currentPage,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 12.dp,
            indicator = { tabPositions ->
                SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[pagerState.currentPage]),
                    height = 3.dp,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            divider = { HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant) }
        ) {
            tabs.forEachIndexed { index, title ->
                val selected = pagerState.currentPage == index
                Tab(
                    selected = selected,
                    onClick = { coroutineScope.launch { pagerState.animateScrollToPage(index) } },
                    text = { 
                        Text(
                            text = title, 
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        ) 
                    },
                    unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) { page ->
            when (page) {
                0 -> NoticeList(
                    notices = accessibleNotices,
                    onDelete = { viewModel.deleteNotice(it) },
                    canDelete = canCreateNotice,
                    emptyMessage = "No recent announcements."
                )
                1 -> NoticeList(
                    notices = accessibleNotices.filter { it.isUrgent || it.noticeCategory == "URGENT" },
                    onDelete = { viewModel.deleteNotice(it) },
                    canDelete = canCreateNotice,
                    emptyMessage = "No urgent alerts at this time."
                )
                2 -> NoticeList(
                    notices = accessibleNotices.filter { it.targetType == "SPECIFIC_CLASS" },
                    onDelete = { viewModel.deleteNotice(it) },
                    canDelete = canCreateNotice,
                    emptyMessage = "No classroom-specific notices."
                )
                3 -> NoticeList(
                    notices = accessibleNotices.filter { it.attachmentType != "NONE" || it.noticeCategory == "RESOURCE" },
                    onDelete = { viewModel.deleteNotice(it) },
                    canDelete = canCreateNotice,
                    emptyMessage = "No shared resources or materials."
                )
                4 -> NoticeList(
                    notices = accessibleNotices.filter { it.noticeCategory == "EVENT" || it.noticeCategory == "ACHIEVER" || it.noticeCategory == "LIFE" },
                    onDelete = { viewModel.deleteNotice(it) },
                    canDelete = canCreateNotice,
                    emptyMessage = "No upcoming events or activities."
                )
            }
        }
    }

    if (showCreateDialog) {
        CreateNoticeDialog(
            isPrincipal = isPrincipal,
            isClassTeacher = isClassTeacher,
            assignedClass = myTeacherInfo?.classTeacherOf ?: "",
            currentUserName = currentUser?.name ?: "Admin",
            currentUserRole = currentUser?.role ?: "STAFF",
            onDismiss = { showCreateDialog = false },
            onSubmit = { notice ->
                viewModel.addNotice(notice)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun NoticeList(
    notices: List<Notice>,
    onDelete: (String) -> Unit,
    canDelete: Boolean,
    emptyMessage: String
) {
    if (notices.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Icon(
                    imageVector = Icons.Outlined.NotificationsPaused,
                    contentDescription = "Empty",
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Text(
                    text = emptyMessage,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(notices, key = { it.noticeId }) { notice ->
                ProfessionalNoticeCard(notice = notice, onDelete = { onDelete(notice.noticeId) }, canDelete = canDelete)
            }
        }
    }
}

@Composable
fun ProfessionalNoticeCard(
    notice: Notice,
    onDelete: () -> Unit,
    canDelete: Boolean
) {
    var showDialog by remember { mutableStateOf(false) }

    val containerColor = if (notice.isUrgent) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface
    val contentColor = if (notice.isUrgent) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface

    val iconVector = when {
        notice.isUrgent -> Icons.Filled.Warning
        notice.noticeCategory == "EVENT" -> Icons.Filled.Event
        notice.attachmentType == "PDF" -> Icons.Filled.PictureAsPdf
        notice.attachmentType == "IMAGE" -> Icons.Filled.Image
        notice.attachmentType == "VIDEO" -> Icons.Filled.VideoLibrary
        else -> Icons.Filled.Announcement
    }

    val displayDate = remember(notice.createdAt) {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        sdf.format(Date(notice.createdAt))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showDialog = true },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(contentColor.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = iconVector, contentDescription = "Category", tint = contentColor, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = notice.noticeCategory,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                            color = contentColor.copy(alpha = 0.8f)
                        )
                        if (notice.targetType == "ALL") {
                            Badge(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
                                Text("GLOBAL", fontSize = 9.sp)
                            }
                        } else {
                            Badge(containerColor = MaterialTheme.colorScheme.tertiary, contentColor = MaterialTheme.colorScheme.onTertiary) {
                                Text("${notice.targetClass} ".trim(), fontSize = 9.sp)
                            }
                        }
                    }
                    Text(
                        text = notice.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = contentColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (notice.verifiedByPrincipal) {
                    Icon(Icons.Filled.Verified, contentDescription = "Verified by Principal", tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                }
            }

            if (notice.attachmentType == "IMAGE" && notice.attachmentUrl.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                AsyncImage(
                    model = notice.attachmentUrl,
                    contentDescription = "Notice Media",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = notice.description,
                style = MaterialTheme.typography.bodyMedium,
                color = contentColor.copy(alpha = 0.9f),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = contentColor.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Person, contentDescription = "Creator", modifier = Modifier.size(14.dp), tint = contentColor.copy(alpha = 0.6f))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${notice.createdBy} (${notice.senderRole})", style = MaterialTheme.typography.labelMedium, color = contentColor.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.width(10.dp))
                    Icon(Icons.Outlined.AccessTime, contentDescription = "Date", modifier = Modifier.size(14.dp), tint = contentColor.copy(alpha = 0.6f))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(displayDate, style = MaterialTheme.typography.labelSmall, color = contentColor.copy(alpha = 0.7f))
                }
                
                if (canDelete) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = contentColor.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    if (showDialog) {
        Dialog(
            onDismissRequest = { showDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.9f)
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(containerColor)
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(contentColor.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
                                Icon(imageVector = iconVector, contentDescription = "", tint = contentColor)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(notice.noticeCategory, style = MaterialTheme.typography.labelSmall, color = contentColor.copy(alpha = 0.8f))
                                Text(displayDate, style = MaterialTheme.typography.labelMedium, color = contentColor)
                            }
                        }
                        IconButton(onClick = { showDialog = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = contentColor)
                        }
                    }

                    // Body
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = notice.title,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("By: ${notice.createdBy} (${notice.senderRole})", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (notice.verifiedByPrincipal) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(Icons.Filled.Verified, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                            }
                        }

                        if (notice.attachmentType == "IMAGE" && notice.attachmentUrl.isNotBlank()) {
                            AsyncImage(
                                model = notice.attachmentUrl,
                                contentDescription = "Notice Media",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.FillWidth
                            )
                        } else if (notice.attachmentType != "NONE") {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        when (notice.attachmentType) {
                                            "PDF" -> Icons.Filled.PictureAsPdf
                                            "VIDEO" -> Icons.Filled.VideoFile
                                            else -> Icons.Filled.AttachFile
                                        }, 
                                        contentDescription = null, 
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("Attachment available: ${notice.attachmentUrl}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                        }

                        Text(
                            text = notice.description,
                            style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 26.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(top = 16.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Groups, contentDescription = "", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (notice.targetType == "ALL") "Visible to: All School Entities" else "Visible to: Classroom ${notice.targetClass} ", 
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                    
                    // Footer
                    if (canDelete) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = { 
                                    onDelete()
                                    showDialog = false 
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = "")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Delete Notice")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateNoticeDialog(
    isPrincipal: Boolean,
    isClassTeacher: Boolean,
    assignedClass: String,
    currentUserName: String,
    currentUserRole: String,
    onDismiss: () -> Unit,
    onSubmit: (Notice) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var noticeCategory by remember { mutableStateOf(if (isPrincipal) "ACADEMIC" else "CLASS") }
    var isUrgent by remember { mutableStateOf(false) }
    var attachmentType by remember { mutableStateOf("NONE") } 
    var attachmentUrl by remember { mutableStateOf("") }
    
    // Target Selection
    var targetType by remember { mutableStateOf(if (isPrincipal) "ALL" else "SPECIFIC_CLASS") }
    var targetClass by remember { mutableStateOf(if (isPrincipal) "" else assignedClass) }
    

    val context = LocalContext.current

    // Options
    val categories = listOf("ACADEMIC", "URGENT", "EVENT", "ACHIEVER", "RESOURCE", "CLASS", "LIFE")
    val attachmentTypes = listOf("NONE", "IMAGE", "PDF", "VIDEO")
    val classes = listOf("Nursery", "LKG", "UKG", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10")
    val sections = listOf("All", "A", "B", "C", "D")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 560.dp)
                .heightIn(max = (LocalConfiguration.current.screenHeightDp * 0.85).dp)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Create Notice Broadcast", 
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notice Title") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notice Description") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    maxLines = 8
                )

                // Target Selector
                Text("Target Audience", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                if (isPrincipal) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = targetType == "ALL",
                            onClick = { targetType = "ALL"; targetClass = "";  },
                            label = { Text("All Students & Staff") }
                        )
                        FilterChip(
                            selected = targetType == "SPECIFIC_CLASS",
                            onClick = { targetType = "SPECIFIC_CLASS"; targetClass = classes.firstOrNull() ?: "" },
                            label = { Text("Specific Class") }
                        )
                    }

                    if (targetType == "SPECIFIC_CLASS") {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            var expandedClass by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(
                                expanded = expandedClass,
                                onExpandedChange = { expandedClass = !expandedClass },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = targetClass,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Class") },
                                    modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedClass) }
                                )
                                ExposedDropdownMenu(expanded = expandedClass, onDismissRequest = { expandedClass = false }) {
                                    classes.forEach { kl ->
                                        DropdownMenuItem(text = { Text(kl) }, onClick = { targetClass = kl; expandedClass = false })
                                    }
                                }
                            }

                            var expandedSection by remember { mutableStateOf(false) }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = assignedClass,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Target Class (Locked)") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = false
                    )
                }

                // Notice Category
                Text("Category & Flags", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                var expandedCat by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expandedCat,
                    onExpandedChange = { expandedCat = !expandedCat }
                ) {
                    OutlinedTextField(
                        value = noticeCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCat) }
                    )
                    ExposedDropdownMenu(expanded = expandedCat, onDismissRequest = { expandedCat = false }) {
                        categories.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { noticeCategory = c; expandedCat = false })
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isUrgent, onCheckedChange = { isUrgent = it })
                    Text("Mark as Urgent Alert")
                }

                // Attachment
                Text("Attachments", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                ScrollableTabRow(
                    selectedTabIndex = attachmentTypes.indexOf(attachmentType),
                    edgePadding = 0.dp,
                    indicator = { },
                    divider = { }
                ) {
                    attachmentTypes.forEachIndexed { index, t ->
                        FilterChip(
                            selected = attachmentType == t,
                            onClick = { attachmentType = t },
                            label = { Text(t) },
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                }

                if (attachmentType != "NONE") {
                    OutlinedTextField(
                        value = attachmentUrl,
                        onValueChange = { attachmentUrl = it },
                        label = { Text("$attachmentType URL") },
                        placeholder = { Text("https://...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss, modifier = Modifier.padding(end = 8.dp)) { 
                        Text("Cancel") 
                    }
                    Button(
                        onClick = {
                            if (title.isBlank() || description.isBlank()) {
                                Toast.makeText(context, "Title and Description required", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val finalTargetClass = if (targetType == "ALL") "" else targetClass
                            

                            val notice = Notice(
                                noticeId = "NOT_${System.currentTimeMillis()}",
                                title = title.trim(),
                                description = description.trim(),
                                createdBy = currentUserName,
                                senderRole = currentUserRole,
                                createdAt = System.currentTimeMillis(),
                                targetType = targetType,
                                targetClass = finalTargetClass,
                                noticeCategory = noticeCategory,
                                isUrgent = isUrgent,
                                attachmentType = attachmentType,
                                attachmentUrl = attachmentUrl.trim(),
                                verifiedByPrincipal = isPrincipal
                            )
                            onSubmit(notice)
                        }
                    ) {
                        Text("Send Notice", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
