package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FeeLedgerEntry

@Composable
fun MonthlyFeeEngine(
    academicMonths: List<String>,
    calculatedLedger: List<FeeLedgerEntry>,
    selectedMonths: Set<String>,
    onMonthSelected: (String) -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val isPhone = maxWidth < 480.dp
        val colCount = if (isPhone) 3 else 4
        val chunkedMonths = academicMonths.chunked(colCount)

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            chunkedMonths.forEach { rowMonths ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowMonths.forEach { monthName ->
                        val entry = calculatedLedger.find { it.month == monthName }
                        val isPaid = entry != null && entry.paidAmount >= entry.totalPayable && entry.totalPayable > 0
                        val isSelected = selectedMonths.contains(monthName)
                        val remainingForMonth = entry?.balance ?: 1000.0

                        val cardBg = when {
                            isPaid -> Color(0xFFE6F4EA)
                            isSelected -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }
                        val cardBorderColor = when {
                            isPaid -> Color(0xFF34A853)
                            isSelected -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.outlineVariant
                        }

                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(72.dp)
                                .border(
                                    width = if (isSelected || isPaid) 2.dp else 1.dp,
                                    color = cardBorderColor,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable(enabled = !isPaid) {
                                    onMonthSelected(monthName)
                                },
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    monthName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isPaid) Color(0xFF34A853) else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                if (isPaid) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF34A853), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("PAID", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF34A853))
                                    }
                                } else {
                                    Text(
                                        "₹${"%.0f".format(remainingForMonth)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                    
                    // Fill remaining empty space if row has fewer items
                    val emptySlots = colCount - rowMonths.size
                    for (i in 0 until emptySlots) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
