package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush

// Bold & Premium Modern Palette — One UI inspired, no violet/purple anywhere.

// Common Colors
val PrimaryGlow = Color(0xFF00E5FF)
val SuccessGreen = Color(0xFF10B981)
val WarningYellow = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val PurpleAccent = Color(0xFF8B5CF6) // kept only for any legacy reference; not used by the theme below
val PinkAccent = Color(0xFFEC4899)
val OrangeAccent = Color(0xFFF97316)
val BlueAccent = Color(0xFF3B82F6)

// New Brand Colors — Ocean Blue + Gold + Emerald
val OceanBlue = Color(0xFF0284C7)
val SkyBlueLight = Color(0xFF38BDF8) // pops on dark backgrounds
val GoldAccent = Color(0xFFF59E0B)
val EmeraldAccent = Color(0xFF10B981)
val GraphiteBlack = Color(0xFF0D1117)

// Light Theme
val LightPrimary = OceanBlue
val LightSecondary = GoldAccent
val LightTertiary = EmeraldAccent
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF3F9)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnSecondary = Color(0xFF241A00)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF11151C)
val LightOnSurface = Color(0xFF171B23)
val LightOnSurfaceVariant = Color(0xFF4B5563)
val LightOutline = Color(0xFFD5DCE5)

// Premium Dark Theme (Graphite + Neon Sky Blue)
val DarkPrimary = SkyBlueLight
val DarkSecondary = GoldAccent
val DarkTertiary = EmeraldAccent
val DarkBackground = GraphiteBlack
val DarkSurface = Color(0xFF161B22) // slightly lifted panel color
val DarkSurfaceVariant = Color(0xFF1F2731) // floating card color
val DarkOnPrimary = Color(0xFF00263B)
val DarkOnSecondary = Color(0xFF241A00)
val DarkOnTertiary = Color(0xFF04261C)
val DarkOnBackground = Color(0xFFF0F3F8)
val DarkOnSurface = Color(0xFFE8ECF2)
val DarkOnSurfaceVariant = Color(0xFF9AA5B1)
val DarkOutline = Color(0xFF2B333D)

// Reusable premium gradients — use on hero headers, key CTA buttons, dashboard cards.
// Not part of the Material3 color scheme (which only takes flat colors), so apply these
// directly as a background Brush where a bold accent surface is wanted.
val PremiumGradientLight = Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF10B981)))
val PremiumGradientDark = Brush.linearGradient(listOf(Color(0xFF0369A1), Color(0xFF0D9488)))
val PremiumGoldGradient = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFF97316)))

// Glassmorphism support colors — semi-transparent surfaces for the "floating glass" look.
// True background blur needs Android 12+ RenderEffect; these translucent + soft-border
// tones approximate the frosted-glass feel reliably on every Android version.
val GlassLightTint = Color(0xFFFFFFFF)
val GlassDarkTint = Color(0xFF1F2731)
val GlassBorderLight = Color(0xCCFFFFFF)
val GlassBorderDark = Color(0x33FFFFFF)

// Legacy aliases to prevent build errors during migration
val SchoolPrimary = Color(0xFF10B981)
val SchoolSecondary = Color(0xFFD97706)
val SchoolTertiary = Color(0xFF0369A1)
val SchoolBackground = Color(0xFFF8FAFC)
val SchoolSurface = Color(0xFFFFFFFF)


