package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SchoolViewModel
import com.example.ui.theme.premiumGlassSurface
import com.example.ui.theme.ShapeExtraLarge
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class MascotState { IDLE, TYPING_USER, TYPING_PASSWORD, LOADING, SUCCESS, ERROR }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumLoginScreen(viewModel: SchoolViewModel) {
    var userId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf("PRINCIPAL") }
    var selectedAuthRoute by remember { mutableStateOf("STANDARD") } // "STANDARD" or "OTP"
    
    // OTP states
    var phoneInput by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf("") }
    
    // Forgot Password states
    var showResetDialog by remember { mutableStateOf(false) }
    var resetStep by remember { mutableStateOf(1) }
    var resetInput by remember { mutableStateOf("") }
    var resetDobInput by remember { mutableStateOf("") }
    var resetNewPassInput by remember { mutableStateOf("") }
    var resetConfirmPassInput by remember { mutableStateOf("") }
    var resetPassVisible by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val loginError by viewModel.loginError.collectAsState()
    val isAuthenticating by viewModel.isAuthenticating.collectAsState()

    val haptic = LocalHapticFeedback.current

    val rolesPresets = listOf(
        Triple("PRINCIPAL", "Principal", "S.D.P.S. Principal"),
        Triple("ADMIN", "Admin", "S.D.P.S. Admin"),
        Triple("CLASS_TEACHER", "Teacher", "S.D.P.S. Teacher"),
        Triple("STUDENT", "Student", "S.D.P.S. Student")
    )

    var isUsernameFocused by remember { mutableStateOf(false) }
    var isPasswordFocused by remember { mutableStateOf(false) }
    var loginSuccess by remember { mutableStateOf(false) }

    // Purely reactive to the real auth outcome — never delays navigation. It just lets
    // the success mascot flash during the screen transition that's already happening,
    // instead of being unreachable dead state (it was declared and read but never set).
    val navTarget by viewModel.navigationState.collectAsState()
    LaunchedEffect(navTarget) {
        if (navTarget != com.example.ui.NavigationTarget.Idle && navTarget != com.example.ui.NavigationTarget.LOGIN_SCREEN) {
            loginSuccess = true
        }
    }

    // Static elegant background colors
    val color1 = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
    val color2 = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
    val color3 = MaterialTheme.colorScheme.surface

    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                val bgBrush = Brush.verticalGradient(
                    colors = listOf(color1, color2, color3)
                )
                drawRect(bgBrush)
            },
        contentAlignment = Alignment.Center
    ) {
        val mascotState = remember(loginSuccess, loginError, isAuthenticating, isPasswordFocused, isUsernameFocused) {
            when {
                loginSuccess -> MascotState.SUCCESS
                loginError != null -> MascotState.ERROR
                isAuthenticating -> MascotState.LOADING
                isPasswordFocused -> MascotState.TYPING_PASSWORD
                isUsernameFocused -> MascotState.TYPING_USER
                else -> MascotState.IDLE
            }
        }

        val mascotScale by animateFloatAsState(
            targetValue = when (mascotState) {
                MascotState.TYPING_USER -> 1.03f
                MascotState.TYPING_PASSWORD -> 1.03f
                MascotState.LOADING -> 1.06f
                MascotState.SUCCESS -> 1.15f
                MascotState.ERROR -> 0.96f
                else -> 1f
            },
            animationSpec = spring(dampingRatio = 0.7f, stiffness = 250f),
            label = "mascotScale"
        )

        val mascotRotation by animateFloatAsState(
            targetValue = when (mascotState) {
                MascotState.TYPING_USER -> -6f
                MascotState.TYPING_PASSWORD -> 6f
                MascotState.SUCCESS -> 10f
                MascotState.ERROR -> -8f
                else -> 0f
            },
            animationSpec = spring(dampingRatio = 0.7f, stiffness = 250f),
            label = "mascotRotation"
        )

        val mascotOffsetY by animateDpAsState(
            targetValue = when (mascotState) {
                MascotState.LOADING -> (-8).dp
                MascotState.SUCCESS -> (-14).dp
                MascotState.TYPING_USER -> 4.dp
                MascotState.TYPING_PASSWORD -> 6.dp
                MascotState.ERROR -> 6.dp
                else -> 0.dp
            },
            animationSpec = spring(dampingRatio = 0.7f, stiffness = 250f),
            label = "mascotOffsetY"
        )
        
        val mascotOffsetX by animateDpAsState(
            targetValue = when (mascotState) {
                MascotState.TYPING_USER -> (-8).dp
                MascotState.TYPING_PASSWORD -> 8.dp
                else -> 0.dp
            },
            animationSpec = spring(dampingRatio = 0.7f, stiffness = 250f),
            label = "mascotOffsetX"
        )

        val mascotRotationY by animateFloatAsState(
            targetValue = when (mascotState) {
                MascotState.TYPING_PASSWORD -> 180f
                MascotState.SUCCESS -> 360f
                else -> 0f
            },
            animationSpec = spring(dampingRatio = 0.6f, stiffness = 200f),
            label = "mascotRotationY"
        )

        val shakeOffsetX = remember { Animatable(0f) }

        LaunchedEffect(mascotState) {
            if (mascotState == MascotState.ERROR) {
                shakeOffsetX.snapTo(0f)
                shakeOffsetX.animateTo(12f, tween(45, easing = LinearEasing))
                shakeOffsetX.animateTo(-12f, tween(45, easing = LinearEasing))
                shakeOffsetX.animateTo(12f, tween(45, easing = LinearEasing))
                shakeOffsetX.animateTo(-12f, tween(45, easing = LinearEasing))
                shakeOffsetX.animateTo(0f, tween(45, easing = LinearEasing))
            } else {
                shakeOffsetX.snapTo(0f)
            }
        }

        val scrollState = rememberScrollState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val mascotModifier = Modifier
                .offset { androidx.compose.ui.unit.IntOffset((shakeOffsetX.value + mascotOffsetX.toPx()).toInt(), mascotOffsetY.roundToPx()) }
                .graphicsLayer {
                    scaleX = mascotScale
                    scaleY = mascotScale
                    rotationZ = mascotRotation
                    rotationY = mascotRotationY
                    cameraDistance = 8f * density
                }

            ComposeMascot(
                state = mascotState,
                modifier = mascotModifier.size(140.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // --- Staggered entrance animation ---------------------------------------
            // Card first, then brand text, fields and button in a quick cascade.
            // Purely visual: it never gates or delays the actual authentication call.
            var entranceStarted by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { entranceStarted = true }

            val cardAlpha by animateFloatAsState(
                targetValue = if (entranceStarted) 1f else 0f,
                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                label = "cardAlpha"
            )
            val cardScale by animateFloatAsState(
                targetValue = if (entranceStarted) 1f else 0.97f,
                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                label = "cardScale"
            )
            val cardOffsetY by animateDpAsState(
                targetValue = if (entranceStarted) 0.dp else 18.dp,
                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                label = "cardOffsetY"
            )
            // Each subsequent element waits a little longer, giving the cascade effect.
            val brandAlpha by animateFloatAsState(
                targetValue = if (entranceStarted) 1f else 0f,
                animationSpec = tween(durationMillis = 260, delayMillis = 90, easing = FastOutSlowInEasing),
                label = "brandAlpha"
            )
            val brandOffset by animateDpAsState(
                targetValue = if (entranceStarted) 0.dp else 12.dp,
                animationSpec = tween(durationMillis = 260, delayMillis = 90, easing = FastOutSlowInEasing),
                label = "brandOffset"
            )
            val fieldsAlpha by animateFloatAsState(
                targetValue = if (entranceStarted) 1f else 0f,
                animationSpec = tween(durationMillis = 260, delayMillis = 170, easing = FastOutSlowInEasing),
                label = "fieldsAlpha"
            )
            val fieldsOffset by animateDpAsState(
                targetValue = if (entranceStarted) 0.dp else 12.dp,
                animationSpec = tween(durationMillis = 260, delayMillis = 170, easing = FastOutSlowInEasing),
                label = "fieldsOffset"
            )
            val actionAlpha by animateFloatAsState(
                targetValue = if (entranceStarted) 1f else 0f,
                animationSpec = tween(durationMillis = 260, delayMillis = 250, easing = FastOutSlowInEasing),
                label = "actionAlpha"
            )
            val actionOffset by animateDpAsState(
                targetValue = if (entranceStarted) 0.dp else 12.dp,
                animationSpec = tween(durationMillis = 260, delayMillis = 250, easing = FastOutSlowInEasing),
                label = "actionOffset"
            )
            // ------------------------------------------------------------------------

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = cardOffsetY)
                    .graphicsLayer {
                        alpha = cardAlpha
                        scaleX = cardScale
                        scaleY = cardScale
                    }
                    .premiumGlassSurface(shape = ShapeExtraLarge, elevation = 16.dp)
                    .padding(horizontal = 20.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Welcome to SDPS",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.offset(y = brandOffset).graphicsLayer { alpha = brandAlpha }
                )
                Text(
                    text = "Sign in to continue",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.offset(y = brandOffset).graphicsLayer { alpha = brandAlpha }
                )
                Spacer(modifier = Modifier.height(20.dp))

                // Roles Dropdown
                var expanded by remember { mutableStateOf(false) }
                val currentRoleName = rolesPresets.find { it.first == selectedRole }?.second ?: "Role"
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = currentRoleName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Log in as") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("role_selector"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        rolesPresets.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(selectionOption.second, fontWeight = FontWeight.Bold)
                                        Text(selectionOption.third, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                onClick = {
                                    selectedRole = selectionOption.first
                                    expanded = false
                                },
                                modifier = Modifier.testTag("role_item_${selectionOption.first.lowercase()}")
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))

                // Tabs for STANDARD / OTP
                TabRow(
                    selectedTabIndex = if (selectedAuthRoute == "STANDARD") 0 else 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)),
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    indicator = {}
                ) {
                    Tab(
                        selected = selectedAuthRoute == "STANDARD",
                        onClick = { selectedAuthRoute = "STANDARD" },
                        modifier = Modifier
                            .background(if (selectedAuthRoute == "STANDARD") MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clip(RoundedCornerShape(12.dp))
                            .testTag("tab_password")
                    ) {
                        Text(
                            "Password",
                            modifier = Modifier.padding(12.dp),
                            color = if (selectedAuthRoute == "STANDARD") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Tab(
                        selected = selectedAuthRoute == "OTP",
                        onClick = { selectedAuthRoute = "OTP" },
                        modifier = Modifier
                            .background(if (selectedAuthRoute == "OTP") MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clip(RoundedCornerShape(12.dp))
                            .testTag("tab_otp")
                    ) {
                        Text(
                            "Phone OTP",
                            modifier = Modifier.padding(12.dp),
                            color = if (selectedAuthRoute == "OTP") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                if (selectedAuthRoute == "STANDARD") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .offset(y = fieldsOffset)
                            .graphicsLayer { alpha = fieldsAlpha }
                    ) {
                        OutlinedTextField(
                            value = userId,
                            onValueChange = { userId = it },
                            label = { Text("User ID or Email") },
                            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = "User ID") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { isUsernameFocused = it.isFocused }
                                .testTag("login_userid_field"),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                cursorColor = MaterialTheme.colorScheme.primary,
                                focusedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        var passwordVisible by remember { mutableStateOf(false) }
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Password") },
                            trailingIcon = {
                                val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(image, contentDescription = if (passwordVisible) "Hide password" else "Show password")
                                }
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { isPasswordFocused = it.isFocused }
                                .testTag("login_password_field"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                focusManager.clearFocus()
                                if (userId.isNotBlank() && password.isNotBlank() && !isAuthenticating) {
                                    viewModel.loginUser(userId.trim(), selectedRole, "", password)
                                }
                            }),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                cursorColor = MaterialTheme.colorScheme.primary,
                                focusedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(
                                onClick = { showResetDialog = true },
                                modifier = Modifier.testTag("forgot_password_button")
                            ) {
                                Text("Forgot Password?", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        val interactionSource = remember { MutableInteractionSource() }
                        val isPressed by interactionSource.collectIsPressedAsState()
                        val scale by animateFloatAsState(targetValue = if (isPressed) 0.97f else 1f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f), label = "btnScale")
                        Button(
                            onClick = {
                                focusManager.clearFocus()
                                viewModel.loginUser(userId.trim(), selectedRole, "", password)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .offset(y = actionOffset)
                                .graphicsLayer { alpha = actionAlpha }
                                .height(56.dp)
                                .scale(scale)
                                .testTag("login_button"),
                            shape = RoundedCornerShape(16.dp),
                            enabled = !isAuthenticating && userId.isNotBlank() && password.isNotBlank(),
                            interactionSource = interactionSource
                        ) {
                            if (isAuthenticating) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.5.dp)
                            } else {
                                Text("Log In", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                } else {
                    // OTP Layout
                    Column(modifier = Modifier.fillMaxWidth()) {
                        var isPhoneFocused by remember { mutableStateOf(false) }

                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it },
                            label = { Text("Phone Number (+91...)") },
                            leadingIcon = { Icon(Icons.Outlined.Phone, contentDescription = "Phone") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { isPhoneFocused = it.isFocused }
                                .testTag("login_phone_field"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = if (verificationId.isNotEmpty()) ImeAction.Next else ImeAction.Done),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Down) },
                                onDone = { focusManager.clearFocus() }
                            ),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                cursorColor = MaterialTheme.colorScheme.primary,
                                focusedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        if (verificationId.isNotEmpty()) {
                            var isOtpFocused by remember { mutableStateOf(false) }

                            OutlinedTextField(
                                value = otpCode,
                                onValueChange = { otpCode = it },
                                label = { Text("6-Digit OTP") },
                                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "OTP") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isOtpFocused = it.isFocused }
                                    .testTag("login_otp_field"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = {
                                    focusManager.clearFocus()
                                    if (otpCode.isNotBlank() && !isAuthenticating) {
                                        viewModel.verifyOtpAndLogin(verificationId, otpCode.trim(), phoneInput.trim())
                                    }
                                }),
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                    cursorColor = MaterialTheme.colorScheme.primary,
                                    focusedLabelColor = MaterialTheme.colorScheme.primary
                                )
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            val otpInteractionSource = remember { MutableInteractionSource() }
                            val isOtpPressed by otpInteractionSource.collectIsPressedAsState()
                            val otpScale by animateFloatAsState(targetValue = if (isOtpPressed) 0.97f else 1f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f), label = "otpBtnScale")
                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    viewModel.verifyOtpAndLogin(verificationId, otpCode.trim(), phoneInput.trim())
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .scale(otpScale)
                                    .testTag("login_verify_otp_button"),
                                shape = RoundedCornerShape(16.dp),
                                enabled = !isAuthenticating && otpCode.isNotBlank(),
                                interactionSource = otpInteractionSource
                            ) {
                                if (isAuthenticating) {
                                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.5.dp)
                                } else {
                                    Text("Verify & Sign In", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        } else {
                            val reqInteractionSource = remember { MutableInteractionSource() }
                            val isReqPressed by reqInteractionSource.collectIsPressedAsState()
                            val reqScale by animateFloatAsState(targetValue = if (isReqPressed) 0.97f else 1f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f), label = "reqBtnScale")
                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    if (activity != null) {
                                        viewModel.startPhoneVerification(phoneInput.trim(), activity, { vId -> verificationId = vId }, { /* error */ })
                                    } else {
                                        Toast.makeText(context, "Cannot send OTP (Activity context missing)", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .scale(reqScale)
                                    .testTag("login_send_otp_button"),
                                shape = RoundedCornerShape(16.dp),
                                enabled = !isAuthenticating && phoneInput.isNotBlank(),
                                interactionSource = reqInteractionSource
                            ) {
                                if (isAuthenticating) {
                                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.5.dp)
                                } else {
                                    Text("Send OTP", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }

                if (loginError != null) {
                    LaunchedEffect(loginError) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = loginError ?: "",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                                .testTag("login_error_text")
                        )
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { 
                showResetDialog = false 
                resetStep = 1
                resetInput = ""
                resetDobInput = ""
                resetNewPassInput = ""
                resetConfirmPassInput = ""
            },
            title = { Text("Reset Password") },
            text = {
                Column {
                    if (resetStep == 1) {
                        Text("Verify your identity to reset password.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = resetInput,
                            onValueChange = { resetInput = it },
                            label = { Text("User ID (e.g. S101)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                            shape = RoundedCornerShape(16.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = resetDobInput,
                            onValueChange = { resetDobInput = it },
                            label = { Text("Date of Birth (DD-MM-YYYY)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            shape = RoundedCornerShape(16.dp)
                        )
                    } else if (resetStep == 2) {
                        Text("Create a new strong password.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = resetNewPassInput,
                            onValueChange = { resetNewPassInput = it },
                            label = { Text("New Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = if (resetPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next),
                            shape = RoundedCornerShape(16.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = resetConfirmPassInput,
                            onValueChange = { resetConfirmPassInput = it },
                            label = { Text("Confirm New Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = if (resetPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                val image = if (resetPassVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                                IconButton(onClick = { resetPassVisible = !resetPassVisible }) {
                                    Icon(image, "Toggle password visibility")
                                }
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            shape = RoundedCornerShape(16.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (resetStep == 1) {
                        if (resetInput.isBlank() || resetDobInput.isBlank()) {
                            Toast.makeText(context, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }
                        viewModel.verifyResetDetails(
                            userId = resetInput.trim(),
                            dob = resetDobInput.trim(),
                            onSuccess = { 
                                resetStep = 2 
                            },
                            onFailure = { err: String ->
                                Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                            }
                        )
                    } else if (resetStep == 2) {
                        val newPass = resetNewPassInput.trim()
                        val confirmPass = resetConfirmPassInput.trim()
                        if (newPass.length < 8 || !newPass.any { it.isUpperCase() } || !newPass.any { it.isDigit() }) {
                            Toast.makeText(context, "Password must be at least 8 chars, 1 uppercase, 1 number!", Toast.LENGTH_LONG).show()
                            return@TextButton
                        }
                        if (newPass != confirmPass) {
                            Toast.makeText(context, "Passwords do not match!", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }
                        
                        viewModel.resetPasswordWithDob(
                            userId = resetInput.trim(),
                            newPassword = newPass,
                            onSuccess = { 
                                Toast.makeText(context, "Password reset successfully! You can now log in.", Toast.LENGTH_LONG).show()
                                showResetDialog = false 
                                resetStep = 1
                                resetInput = ""
                                resetDobInput = ""
                                resetNewPassInput = ""
                                resetConfirmPassInput = ""
                            },
                            onFailure = { err: String ->
                                Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                }) { Text(if (resetStep == 1) "Verify" else "Reset Password") }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showResetDialog = false 
                    resetStep = 1
                    resetInput = ""
                    resetDobInput = ""
                    resetNewPassInput = ""
                    resetConfirmPassInput = ""
                }) { Text("Cancel") }
            }
        )
    }
}
