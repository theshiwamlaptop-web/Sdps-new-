package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Student
import com.example.ui.SchoolViewModel
import com.example.ui.components.SearchTextField
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.premiumGlassSurface
import com.example.ui.components.UserProfileAvatar
import kotlinx.coroutines.delay
import com.example.ui.theme.glassCardColors

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun StudentManagementScreen(viewModel: SchoolViewModel, onNavigate: (AppScreen) -> Unit) {
    val students by viewModel.studentsState.collectAsState()
    val syncState by viewModel.syncStatus.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    val currentUser by viewModel.currentUser.collectAsState()
    val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""
    val isTeacher = roleStr == "TEACHER" || roleStr == "CLASS_TEACHER"
    val isStudent = roleStr == "STUDENT"
    val isManagement = roleStr == "ADMIN" || roleStr == "HEAD_ADMIN" || roleStr == "PRINCIPAL"
    val isPrincipal = roleStr == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)

    val flowPrefillClass by viewModel.prefillClass.collectAsState()
    var selectedClass by remember { mutableStateOf(if (isTeacher) "" else flowPrefillClass) } // Simplification

    var selectedStudent by remember { mutableStateOf<Student?>(null) }
    
    val visibleStudents = remember(students, currentUser, isTeacher, isStudent, selectedClass) {
        if (isStudent) {
            students.filter { it.studentId == (currentUser?.userId ?: "") }
        } else {
            if (selectedClass.isNotEmpty() && selectedClass != "All") {
                students.filter { it.className.equals(selectedClass, ignoreCase = true) }
            } else {
                students
            }
        }
    }

    // Debounce logic for search
    var debouncedSearchQuery by remember { mutableStateOf("") }
    LaunchedEffect(searchQuery) {
        delay(300)
        debouncedSearchQuery = searchQuery
    }

    val filteredVisibleStudents = remember(visibleStudents, debouncedSearchQuery) {
        if (debouncedSearchQuery.isBlank()) {
            visibleStudents
        } else {
            visibleStudents.filter {
                it.name.contains(debouncedSearchQuery, ignoreCase = true) ||
                it.studentId.contains(debouncedSearchQuery, ignoreCase = true) ||
                it.rollNo.contains(debouncedSearchQuery, ignoreCase = true) ||
                it.admissionNo.contains(debouncedSearchQuery, ignoreCase = true) ||
                it.fatherName.contains(debouncedSearchQuery, ignoreCase = true) ||
                it.phone.contains(debouncedSearchQuery, ignoreCase = true)
            }
        }
    }

    val context = LocalContext.current

    if (selectedStudent != null) {
        StudentProfileScreen(
            student = selectedStudent!!,
            viewModel = viewModel,
            onBack = { selectedStudent = null },
            canEdit = isManagement,
            onEdit = { 
                viewModel.setEditingStudent(selectedStudent!!)
                onNavigate(AppScreen.ADD_STUDENT)
            }
        )
    } else {
        Scaffold(
            floatingActionButton = {
                if (isManagement) {
                    FloatingActionButton(
                        onClick = {
                            viewModel.setEditingStudent(null)
                            viewModel.setStudentPrefill(selectedClass)
                            onNavigate(AppScreen.ADD_STUDENT)
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Icon(Icons.Filled.Add, "Add Student")
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(padding)
            ) {
                // Top Search and Filter
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(16.dp)
                ) {
                    SearchTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = "Search by name, ID, phone..."
                    )
                    
                    if (isManagement) {
                        Spacer(modifier = Modifier.height(12.dp))
                        // Filters (Class)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedClass == "All" || selectedClass.isEmpty(),
                                    onClick = { selectedClass = "All" },
                                    label = { Text("All Classes") }
                                )
                            }
                            items(SchoolClassesList) { cl ->
                                FilterChip(
                                    selected = selectedClass == cl,
                                    onClick = { selectedClass = cl },
                                    label = { Text(cl) }
                                )
                            }
                        }
                    }
                }
                
                val listState = rememberLazyListState()
                
                if (filteredVisibleStudents.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        // Never claim "no students" when the real problem was a cloud read
                        // failure — that made a permissions/auth bug look like an empty school.
                        when (val sync = syncState) {
                            is com.example.data.repository.CloudSyncStatus.NotAuthenticated ->
                                EmptyStateLayout(
                                    "Not connected to cloud",
                                    "Your session isn't authenticated with Firebase, so student records can't be loaded. Please log out and log in again."
                                )
                            is com.example.data.repository.CloudSyncStatus.Failed ->
                                EmptyStateLayout(
                                    if (sync.isPermissionDenied) "Access denied by server" else "Couldn't load students",
                                    if (sync.isPermissionDenied)
                                        "Your account isn't authorised to read student records (${sync.collection}). This is a permissions problem, not an empty list."
                                    else
                                        "Sync failed while loading ${sync.collection}: ${sync.reason}"
                                )
                            is com.example.data.repository.CloudSyncStatus.Syncing ->
                                EmptyStateLayout("Loading students…", "Fetching records from the cloud.")
                            else ->
                                EmptyStateLayout("No Students Found", "Try adjusting your search or filters.")
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filteredVisibleStudents, key = { it.studentId }) { student ->
                            StudentListItem(
                                student = student,
                                modifier = Modifier.animateItemPlacement(),
                                onClick = { selectedStudent = student }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentListItem(student: Student, modifier: Modifier = Modifier, onClick: () -> Unit) {
    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = glassCardColors(),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (student.photoUrl.isNotBlank()) {
                    AsyncImage(
                        model = student.photoUrl,
                        contentDescription = "Photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = student.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${student.className} • Roll ${student.rollNo}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    BadgeText(text = student.status, color = if(student.status == "Active") Color(0xFF10B981) else Color.Red)
                    if (student.hasTransport) {
                        BadgeText(text = "Transport", color = Color(0xFF0EA5E9))
                    }
                    if (student.feeStatus == "Unpaid") {
                        BadgeText(text = "Fee Due", color = Color(0xFFF59E0B))
                    }
                }
            }
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "View Details",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun BadgeText(text: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = color
        )
    }
}

@Composable
fun StudentIDCardLayout(student: Student, onDismiss: () -> Unit, showUserId: Boolean = false) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .premiumGlassSurface(shape = RoundedCornerShape(24.dp), elevation = 18.dp)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "S. D. Public School",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Student Identity Card",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))

            UserProfileAvatar(
                avatarUrl = student.photoUrl,
                size = 96.dp,
                shape = RoundedCornerShape(12.dp),
                borderColor = MaterialTheme.colorScheme.primary,
                borderWidth = 2.dp
            )
            Spacer(modifier = Modifier.height(12.dp))

            Text(student.name, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
            Text("${student.className} • Roll No. ${student.rollNo}", color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))

            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                IDCardRow("Admission No.", student.admissionNo.ifBlank { "—" })
                IDCardRow("Date of Birth", student.DOB.ifBlank { "—" })
                IDCardRow("Father's Name", student.fatherName.ifBlank { "—" })
                IDCardRow("Contact", student.phone.ifBlank { "—" })
                if (showUserId) {
                    IDCardRow("Student ID", student.studentId)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                Text("Close")
            }
        }
    }
}

@Composable
private fun IDCardRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
fun StudentDetailDialogLayout(
    student: Student,
    fee: com.example.data.model.Fee?,
    attendance: List<com.example.data.model.Attendance>,
    onDismiss: () -> Unit,
    canEdit: Boolean,
    onSave: (Student) -> Unit,
    onOpenFeeLedger: () -> Unit,
    showUserId: Boolean = false,
    allStudents: List<Student> = emptyList(),
    currentUser: com.example.data.model.User? = null
) {
    var isEditing by remember(student.studentId) { mutableStateOf(false) }
    var editPhone by remember(student.studentId) { mutableStateOf(student.phone) }
    var editAddress by remember(student.studentId) { mutableStateOf(student.address) }
    var editFatherName by remember(student.studentId) { mutableStateOf(student.fatherName) }
    var editMotherName by remember(student.studentId) { mutableStateOf(student.motherName) }
    var editGuardianName by remember(student.studentId) { mutableStateOf(student.guardianName) }

    val presentCount = attendance.count { it.status.equals("Present", ignoreCase = true) }
    val attendancePercent = if (attendance.isNotEmpty()) (presentCount * 100 / attendance.size) else 0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .premiumGlassSurface(shape = RoundedCornerShape(20.dp), elevation = 18.dp)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserProfileAvatar(avatarUrl = student.photoUrl, size = 56.dp, shape = RoundedCornerShape(12.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(student.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("${student.className} • Roll ${student.rollNo}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (showUserId) {
                        Text(student.studentId, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = "Close")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Fee + Attendance summary
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryChipCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Filled.CurrencyRupee,
                label = "Fee Status",
                value = fee?.status?.ifBlank { "Unpaid" } ?: "Unpaid",
                color = if (fee?.status.equals("Paid", ignoreCase = true)) Color(0xFF10B981) else Color(0xFFEF4444)
            )
            SummaryChipCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Filled.EventAvailable,
                label = "Attendance",
                value = "$attendancePercent%",
                color = if (attendancePercent >= 75) Color(0xFF10B981) else Color(0xFFF59E0B)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Profile Details", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            if (canEdit) {
                TextButton(onClick = { isEditing = !isEditing }) {
                    Text(if (isEditing) "Cancel" else "Edit")
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        if (!isEditing) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                IDCardRow("Date of Birth", student.DOB.ifBlank { "—" })
                IDCardRow("Admission No.", student.admissionNo.ifBlank { "—" })
                IDCardRow("Father's Name", student.fatherName.ifBlank { "—" })
                IDCardRow("Mother's Name", student.motherName.ifBlank { "—" })
                IDCardRow("Guardian", student.guardianName.ifBlank { "—" })
                IDCardRow("Phone", student.phone.ifBlank { "—" })
                IDCardRow("Address", student.address.ifBlank { "—" })
            }

            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = onOpenFeeLedger, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Receipt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Fee Ledger")
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = editFatherName, onValueChange = { editFatherName = it }, label = { Text("Father's Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = editMotherName, onValueChange = { editMotherName = it }, label = { Text("Mother's Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = editGuardianName, onValueChange = { editGuardianName = it }, label = { Text("Guardian") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = editPhone, onValueChange = { editPhone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = editAddress, onValueChange = { editAddress = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())

                Button(
                    onClick = {
                        onSave(
                            student.copy(
                                phone = editPhone.trim(),
                                address = editAddress.trim(),
                                fatherName = editFatherName.trim(),
                                motherName = editMotherName.trim(),
                                guardianName = editGuardianName.trim()
                            )
                        )
                        isEditing = false
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save Changes")
                }
            }
        }
    }
}

@Composable
private fun SummaryChipCard(modifier: Modifier = Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String, color: Color) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, fontWeight = FontWeight.Bold, color = color, fontSize = 16.sp)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
