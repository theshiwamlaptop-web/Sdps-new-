package com.example.ui.screens

import com.example.ui.components.SecureScreen
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessage
import com.example.data.model.Student
import com.example.data.model.Teacher
import com.example.data.model.User
import com.example.ui.SchoolViewModel
import com.example.ui.components.UserProfileAvatar
import java.text.SimpleDateFormat
import java.util.*
import com.example.ui.theme.glassCardColors

data class OversightParticipant(
    val id: String,
    val name: String,
    val role: String,
    val roleCategory: String, // "STUDENT", "TEACHER", "ADMIN"
    val subtitle: String,
    val avatarUrl: String = "",
    val email: String = "",
    val phone: String = ""
)

data class OversightConversation(
    val conversationKey: String,
    val participantA: OversightParticipant,
    val participantB: OversightParticipant,
    val messageCount: Int,
    val lastMessage: ChatMessage,
    val messages: List<ChatMessage>
)

enum class OversightFilter(val label: String) {
    ALL("All Chats"),
    STUDENT_TEACHER("Student ↔ Teacher"),
    STAFF_ADMIN("Faculty ↔ Admin"),
    STUDENT_ADMIN("Student ↔ Admin")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatOversightScreen(
    viewModel: SchoolViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    SecureScreen()
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allChats by viewModel.chatsState.collectAsStateWithLifecycle()
    val teachers by viewModel.teachersState.collectAsStateWithLifecycle()
    val students by viewModel.studentsState.collectAsStateWithLifecycle()
    val users by viewModel.usersState.collectAsStateWithLifecycle()

    val userRole = currentUser?.role?.uppercase()?.trim() ?: ""
    val isPrincipalOrHead = userRole == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)

    // Role Guard
    if (!isPrincipalOrHead) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = glassCardColors()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = "Access Restricted",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Principal Authorization Required",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = "School Chat Oversight is strictly restricted to Principal / Head Administrator for school safety and communication audit compliance.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = { onNavigate(AppScreen.DASHBOARD) },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text("Return to Dashboard")
                    }
                }
            }
        }
        return
    }

    var selectedConversation by remember { mutableStateOf<OversightConversation?>(null) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedFilter by rememberSaveable { mutableStateOf(OversightFilter.ALL) }

    BackHandler(enabled = selectedConversation != null) {
        selectedConversation = null
    }

    // Map participants helper
    fun resolveParticipant(userId: String): OversightParticipant {
        val student = students.find { it.studentId.equals(userId, ignoreCase = true) || it.id.equals(userId, ignoreCase = true) }
        if (student != null) {
            return OversightParticipant(
                id = student.studentId,
                name = student.name,
                role = "Student (Class ${student.className})",
                roleCategory = "STUDENT",
                subtitle = "Roll #${student.rollNo.ifBlank { student.rollNumber.toString() }} • Class ${student.className}",
                avatarUrl = student.photoUrl,
                phone = student.phone
            )
        }

        val teacher = teachers.find { it.teacherId.equals(userId, ignoreCase = true) }
        if (teacher != null) {
            val roleDesc = if (teacher.classTeacherOf.isNotBlank()) "Class Teacher (${teacher.classTeacherOf})" else "Teacher (${teacher.subject})"
            return OversightParticipant(
                id = teacher.teacherId,
                name = teacher.name,
                role = roleDesc,
                roleCategory = "TEACHER",
                subtitle = "${teacher.subject} • ${teacher.qualification}",
                avatarUrl = teacher.photoUrl,
                email = teacher.email,
                phone = teacher.phone
            )
        }

        val user = users.find { it.userId.equals(userId, ignoreCase = true) }
        if (user != null) {
            val cat = when (user.role.uppercase()) {
                "PRINCIPAL", "HEAD_ADMIN", "ADMIN" -> "ADMIN"
                "TEACHER", "CLASS_TEACHER" -> "TEACHER"
                else -> "STUDENT"
            }
            return OversightParticipant(
                id = user.userId,
                name = user.name,
                role = user.role.replace("_", " "),
                roleCategory = cat,
                subtitle = user.email.ifBlank { "Registered School Account" },
                avatarUrl = user.avatarUrl,
                email = user.email,
                phone = user.phone
            )
        }

        return OversightParticipant(
            id = userId,
            name = "User ($userId)",
            role = "Account",
            roleCategory = "OTHER",
            subtitle = "ID: $userId"
        )
    }

    // Group all ChatMessage records into unique conversations
    val conversations = remember(allChats, students, teachers, users) {
        val map = mutableMapOf<String, MutableList<ChatMessage>>()
        allChats.forEach { msg ->
            if (msg.senderId.isNotBlank() && msg.receiverId.isNotBlank()) {
                val p1 = if (msg.senderId < msg.receiverId) msg.senderId else msg.receiverId
                val p2 = if (msg.senderId < msg.receiverId) msg.receiverId else msg.senderId
                val key = "${p1}___${p2}"
                map.getOrPut(key) { mutableListOf() }.add(msg)
            }
        }

        map.map { (key, msgs) ->
            val sortedMsgs = msgs.sortedBy { it.timestamp }
            val parts = key.split("___")
            val pA = resolveParticipant(parts[0])
            val pB = resolveParticipant(parts[1])
            val last = sortedMsgs.last()
            OversightConversation(
                conversationKey = key,
                participantA = pA,
                participantB = pB,
                messageCount = sortedMsgs.size,
                lastMessage = last,
                messages = sortedMsgs
            )
        }.sortedByDescending { it.lastMessage.timestamp }
    }

    // Filter conversations
    val filteredConversations = remember(conversations, selectedFilter, searchQuery) {
        var list = conversations

        when (selectedFilter) {
            OversightFilter.STUDENT_TEACHER -> {
                list = list.filter {
                    (it.participantA.roleCategory == "STUDENT" && it.participantB.roleCategory == "TEACHER") ||
                    (it.participantA.roleCategory == "TEACHER" && it.participantB.roleCategory == "STUDENT")
                }
            }
            OversightFilter.STAFF_ADMIN -> {
                list = list.filter {
                    (it.participantA.roleCategory == "TEACHER" && it.participantB.roleCategory == "ADMIN") ||
                    (it.participantA.roleCategory == "ADMIN" && it.participantB.roleCategory == "TEACHER")
                }
            }
            OversightFilter.STUDENT_ADMIN -> {
                list = list.filter {
                    (it.participantA.roleCategory == "STUDENT" && it.participantB.roleCategory == "ADMIN") ||
                    (it.participantA.roleCategory == "ADMIN" && it.participantB.roleCategory == "STUDENT")
                }
            }
            else -> {}
        }

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.participantA.name.lowercase().contains(q) ||
                it.participantB.name.lowercase().contains(q) ||
                it.participantA.id.lowercase().contains(q) ||
                it.participantB.id.lowercase().contains(q) ||
                it.participantA.role.lowercase().contains(q) ||
                it.participantB.role.lowercase().contains(q)
            }
        }

        list
    }

    if (selectedConversation != null) {
        // Detailed Conversation Inspector
        OversightConversationInspector(
            conversation = selectedConversation!!,
            currentUser = currentUser,
            onBack = { selectedConversation = null }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "School Chat Oversight",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Administrative Safety & Compliance Audit",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { onNavigate(AppScreen.DASHBOARD) },
                            modifier = Modifier.testTag("chat_oversight_back_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Dashboard")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                viewModel.forceSync()
                                Toast.makeText(context, "Synchronizing all school chat channels...", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Filled.Sync, contentDescription = "Sync Chats")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding)
            ) {
                // Regulatory Notice Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Policy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Institutional Oversight Policy",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "All conversation inspection events are recorded in the institutional audit log with timestamp and administrator identity.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Search & Filter controls
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search by student, teacher, or staff name...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("oversight_search_input")
                    )

                    // Filter chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OversightFilter.values().forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter.label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }

                // Conversations List
                if (filteredConversations.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Forum,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Text(
                                text = "No active conversations found",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "School chat threads will be catalogued here for review.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredConversations, key = { it.conversationKey }) { conv ->
                            OversightConversationCard(
                                conversation = conv,
                                onClick = {
                                    // Log audit access
                                    viewModel.logChatOversightAccess(
                                        viewerUserId = currentUser?.userId ?: "PRIN001",
                                        viewerUserName = currentUser?.name ?: "Principal",
                                        participantAName = conv.participantA.name,
                                        participantBName = conv.participantB.name
                                    )
                                    selectedConversation = conv
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OversightConversationCard(
    conversation: OversightConversation,
    onClick: () -> Unit
) {
    val formattedTime = remember(conversation.lastMessage.timestamp) {
        SimpleDateFormat("hh:mm a • dd MMM", Locale.getDefault()).format(Date(conversation.lastMessage.timestamp))
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("oversight_card_${conversation.conversationKey}"),
        shape = RoundedCornerShape(14.dp),
        colors = glassCardColors()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row with Channel Badge and Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "${conversation.messageCount} Messages",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                Text(
                    text = formattedTime,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Participants Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Participant A
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = conversation.participantA.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = conversation.participantA.role,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Icon(
                    imageVector = Icons.Filled.SwapHoriz,
                    contentDescription = "Exchange",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )

                // Participant B
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = conversation.participantB.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = conversation.participantB.role,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Last message snippet
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ChatBubbleOutline,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val senderName = if (conversation.lastMessage.senderId == conversation.participantA.id) conversation.participantA.name else conversation.participantB.name
                    Text(
                        text = "$senderName: ${conversation.lastMessage.message.ifBlank { "[Attachment]" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OversightConversationInspector(
    conversation: OversightConversation,
    currentUser: com.example.data.model.User?,
    onBack: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(conversation.messages.size) {
        if (conversation.messages.isNotEmpty()) {
            listState.scrollToItem(conversation.messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "${conversation.participantA.name} ↔ ${conversation.participantB.name}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Administrative Oversight Transcript (${conversation.messages.size} Messages)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("inspector_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to list")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Prominent Administrative Warning Banner
            Card(
                shape = RoundedCornerShape(0.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = Color(0xFFB45309),
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "🔒 READ-ONLY COMPLIANCE TRANSCRIPT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF92400E)
                        )
                        Text(
                            text = "Administrative review by ${currentUser?.name ?: "Principal"}. Messages are strictly non-editable.",
                            fontSize = 11.sp,
                            color = Color(0xFF78350F)
                        )
                    }
                }
            }

            // Participant Profile Info Card
            ElevatedCard(
                shape = RoundedCornerShape(12.dp),
                colors = glassCardColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Participant 1: ${conversation.participantA.name}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${conversation.participantA.role} • ${conversation.participantA.subtitle}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    VerticalDivider(modifier = Modifier.height(32.dp).padding(horizontal = 8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Participant 2: ${conversation.participantB.name}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${conversation.participantB.role} • ${conversation.participantB.subtitle}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Messages LazyColumn Transcript
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(conversation.messages, key = { it.messageId.ifBlank { "${it.timestamp}_${it.senderId}" } }) { msg ->
                    val isFromA = msg.senderId == conversation.participantA.id
                    val senderObj = if (isFromA) conversation.participantA else conversation.participantB
                    val bubbleColor = if (isFromA) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                    val textColor = if (isFromA) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer
                    val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(msg.timestamp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isFromA) Alignment.Start else Alignment.End
                    ) {
                        Text(
                            text = "${senderObj.name} (${senderObj.role})",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = bubbleColor,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (msg.attachmentType.isNotBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.AttachFile,
                                            contentDescription = "Attachment",
                                            modifier = Modifier.size(14.dp),
                                            tint = textColor
                                        )
                                        Text(
                                            text = "Attachment: ${msg.attachmentType.uppercase()}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textColor
                                        )
                                    }
                                }

                                Text(
                                    text = msg.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = textColor
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = timeStr,
                                        fontSize = 10.sp,
                                        color = textColor.copy(alpha = 0.7f)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = if (msg.isRead) Icons.Filled.DoneAll else Icons.Filled.Done,
                                        contentDescription = null,
                                        modifier = Modifier.size(12.dp),
                                        tint = if (msg.isRead) Color(0xFF3B82F6) else textColor.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
