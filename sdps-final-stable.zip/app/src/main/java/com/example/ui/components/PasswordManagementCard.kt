package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.SchoolViewModel
import com.example.ui.theme.glassCardColors

@Composable
fun PasswordManagementCard(
    targetUser: User,
    currentUserRole: String,
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    SecureScreen()
    val context = LocalContext.current
    var showResetDialog by remember { mutableStateOf(false) }
    var showCustomPassDialog by remember { mutableStateOf(false) }
    var showFixDobDialog by remember { mutableStateOf(false) }

    var newCustomPassword by remember { mutableStateOf("") }
    var confirmCustomPassword by remember { mutableStateOf("") }
    var newDobInput by remember { mutableStateOf("") }
    var generatedTempPass by remember { mutableStateOf<String?>(null) }

    val effectiveStatus = targetUser.getEffectivePasswordStatus()
    val isPrincipal = currentUserRole.uppercase().trim() == "PRINCIPAL" || 
            viewModel.currentUser.value?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    val isOwnProfile = targetUser.userId.equals(viewModel.currentUser.value?.userId, ignoreCase = true) ||
            targetUser.email.equals(viewModel.currentUser.value?.email, ignoreCase = true)

    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = glassCardColors(),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "PASSWORD MANAGEMENT",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("User ID", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(targetUser.userId.ifBlank { "N/A" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Account Status", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(targetUser.accountStatus.ifBlank { "ACTIVE" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Password Status", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                
                val statusBg = when (effectiveStatus) {
                    "CUSTOM PASSWORD SET" -> Color(0xFFE8F5E9)
                    "INITIAL DOB PASSWORD" -> Color(0xFFFFF3E0)
                    "DOB VERIFICATION REQUIRED" -> Color(0xFFFFEBEE)
                    else -> Color(0xFFECEFF1)
                }
                val statusText = when (effectiveStatus) {
                    "CUSTOM PASSWORD SET" -> Color(0xFF2E7D32)
                    "INITIAL DOB PASSWORD" -> Color(0xFFE65100)
                    "DOB VERIFICATION REQUIRED" -> Color(0xFFC62828)
                    else -> Color(0xFF37474F)
                }

                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = effectiveStatus,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = statusText
                    )
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Last Password Change", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(targetUser.lastPasswordChange.ifBlank { "Never" }, style = MaterialTheme.typography.bodyMedium)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Last Password Action", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(targetUser.lastPasswordAction.ifBlank { "INITIAL_CREATION" }, style = MaterialTheme.typography.bodyMedium)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Changed By", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(targetUser.changedBy.ifBlank { "System" }, style = MaterialTheme.typography.bodyMedium)
            }

            // Only PRINCIPAL can manage credentials of other users.
            // Users can change their OWN password.
            if (isPrincipal) {
                Spacer(modifier = Modifier.height(4.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (effectiveStatus == "DOB VERIFICATION REQUIRED") {
                        Button(
                            onClick = { showFixDobDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f).testTag("fix_dob_button")
                        ) {
                            Icon(Icons.Filled.EditCalendar, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Verify DOB", fontSize = 12.sp)
                        }
                    } else {
                        OutlinedButton(
                            onClick = { showResetDialog = true },
                            modifier = Modifier.weight(1f).testTag("reset_to_dob_button")
                        ) {
                            Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset Password", fontSize = 12.sp)
                        }
                    }

                    Button(
                        onClick = { showCustomPassDialog = true },
                        modifier = Modifier.weight(1f).testTag("set_custom_password_button")
                    ) {
                        Icon(Icons.Filled.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Set Password", fontSize = 12.sp)
                    }
                }
            } else if (isOwnProfile) {
                Spacer(modifier = Modifier.height(4.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Button(
                    onClick = { showCustomPassDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("change_my_password_button")
                ) {
                    Icon(Icons.Filled.LockReset, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Change My Password", fontSize = 13.sp)
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset User Password", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select a password reset option for User ID: ${targetUser.userId} (${targetUser.name}):")
                    
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Option 1: Reset to DOB Password", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("Resets user password to registered DOB (${targetUser.dob.ifBlank { "DOB" }}).", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Option 2: Generate One-Time Temporary Password", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("Generates a new secure temporary password shown ONE TIME to admin.", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            },
            confirmButton = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            viewModel.adminGenerateTemporaryPassword(targetUser.userId) { success, msg, tempPass ->
                                if (success) {
                                    showResetDialog = false
                                    generatedTempPass = tempPass
                                } else {
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth().testTag("generate_temp_password_btn")
                    ) {
                        Icon(Icons.Filled.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Generate Temp Password", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.adminResetPasswordToDob(targetUser.userId) { success, msg ->
                                if (success) {
                                    showResetDialog = false
                                    Toast.makeText(context, "Password reset to DOB successfully!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("reset_to_dob_confirm_btn")
                    ) {
                        Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset to DOB", fontSize = 12.sp)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (generatedTempPass != null) {
        val tempPass = generatedTempPass!!
        val credentialsText = """
            S.D. PUBLIC SCHOOL - TEMPORARY ACCOUNT CREDENTIAL
            --------------------------------------------------
            User ID: ${targetUser.userId}
            User Name: ${targetUser.name}
            Temporary Password: $tempPass
            --------------------------------------------------
            Note: This temporary password is valid immediately. Please change your password upon login.
        """.trimIndent()

        AlertDialog(
            onDismissRequest = { generatedTempPass = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEMPORARY CREDENTIAL", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = Color(0xFFFFEBEE),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = Color(0xFFC62828), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Shown ONE TIME ONLY. Will not be stored or viewable again after closing.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC62828))
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("USER ID:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(targetUser.userId, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Text("TEMPORARY PASSWORD:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(tempPass, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.tertiary)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("User ID", targetUser.userId))
                                Toast.makeText(context, "User ID copied!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Copy User ID", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Temporary Password", tempPass))
                                Toast.makeText(context, "Temporary Password copied!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Copy Temp Pass", fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val shareIntent = android.content.Intent().apply {
                            action = android.content.Intent.ACTION_SEND
                            putExtra(android.content.Intent.EXTRA_TEXT, credentialsText)
                            type = "text/plain"
                        }
                        context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Temporary Credentials"))
                    }
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            },
            dismissButton = {
                TextButton(onClick = { generatedTempPass = null }) {
                    Text("Done")
                }
            }
        )
    }

    if (showCustomPassDialog) {
        AlertDialog(
            onDismissRequest = { showCustomPassDialog = false },
            title = { Text("Set Custom Password", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter a new custom password for User ID ${targetUser.userId}:", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = newCustomPassword,
                        onValueChange = { newCustomPassword = it },
                        label = { Text("New Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("admin_new_password_input")
                    )
                    OutlinedTextField(
                        value = confirmCustomPassword,
                        onValueChange = { confirmCustomPassword = it },
                        label = { Text("Confirm Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("admin_confirm_password_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCustomPassword.trim().length < 6) {
                            Toast.makeText(context, "Password must be at least 6 characters!", Toast.LENGTH_SHORT).show()
                        } else if (newCustomPassword.trim() != confirmCustomPassword.trim()) {
                            Toast.makeText(context, "Passwords do not match!", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.adminSetCustomPassword(targetUser.userId, newCustomPassword.trim()) { success, msg ->
                                if (success) {
                                    showCustomPassDialog = false
                                    newCustomPassword = ""
                                    confirmCustomPassword = ""
                                    Toast.makeText(context, "Custom password updated!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                ) {
                    Text("Save Password")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomPassDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showFixDobDialog) {
        AlertDialog(
            onDismissRequest = { showFixDobDialog = false },
            title = { Text("Fix / Verify Date of Birth", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter the verified Date of Birth for User ID ${targetUser.userId} (Format: DD-MM-YYYY):", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = newDobInput,
                        onValueChange = { newDobInput = it },
                        label = { Text("Date of Birth (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("admin_fix_dob_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newDobInput.trim().isBlank()) {
                            Toast.makeText(context, "Please enter a valid Date of Birth!", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.updateUserDob(targetUser.userId, newDobInput.trim()) { success, msg ->
                                if (success) {
                                    showFixDobDialog = false
                                    newDobInput = ""
                                    Toast.makeText(context, "DOB verified and updated!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                ) {
                    Text("Save & Activate DOB Password")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFixDobDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
