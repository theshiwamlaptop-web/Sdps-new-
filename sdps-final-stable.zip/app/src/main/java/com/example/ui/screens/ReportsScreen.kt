package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.*
import com.example.ui.SchoolViewModel
import com.example.ui.components.UserProfileAvatar
import com.example.ui.theme.*
import com.example.util.SchoolReportPdfHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: SchoolViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Real Data States from ViewModel
    val feesList by viewModel.feesState.collectAsState()
    val feeLedgerList by viewModel.feeLedgerState.collectAsState()
    val students by viewModel.studentsState.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    val attendanceList by viewModel.attendanceState.collectAsState()
    val teacherAttendanceList by viewModel.teacherAttendanceState.collectAsState()
    val notices by viewModel.noticesState.collectAsState()
    val homeworkList by viewModel.homeworkState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    var showReportCardDialog by remember { mutableStateOf(false) }
    var isExportingExecutivePdf by remember { mutableStateOf(false) }

    // Financial Metrics Calculation
    val totalCollected = if (feesList.isNotEmpty()) {
        feesList.sumOf { it.paidAmount }
    } else {
        feeLedgerList.sumOf { it.paidAmount }
    }
    val totalDues = if (feesList.isNotEmpty()) {
        feesList.sumOf { it.dueAmount }
    } else {
        feeLedgerList.sumOf { it.balance }
    }
    val totalBilled = totalCollected + totalDues
    val collectionRatePercent = if (totalBilled > 0) (totalCollected / totalBilled * 100.0) else 0.0
    val totalConcessions = feeLedgerList.sumOf { it.concession }

    val cashCollection = feeLedgerList.filter { it.paymentMode.contains("cash", ignoreCase = true) }.sumOf { it.paidAmount }
    val onlineCollection = feeLedgerList.filter { !it.paymentMode.contains("cash", ignoreCase = true) }.sumOf { it.paidAmount }

    // Attendance Metrics Calculation
    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val todayAttendance = attendanceList.filter { it.date == todayDateStr || it.date.isNotBlank() }

    val presentStudentsCount = if (todayAttendance.isNotEmpty()) {
        todayAttendance.count { it.status.equals("Present", ignoreCase = true) }
    } else {
        students.count { it.attendanceStatus.equals("Present", ignoreCase = true) }
    }
    val absentStudentsCount = if (todayAttendance.isNotEmpty()) {
        todayAttendance.count { it.status.equals("Absent", ignoreCase = true) }
    } else {
        students.count { it.attendanceStatus.equals("Absent", ignoreCase = true) }
    }
    val lateStudentsCount = if (todayAttendance.isNotEmpty()) {
        todayAttendance.count { it.status.equals("Late", ignoreCase = true) }
    } else 0
    val leaveStudentsCount = if (todayAttendance.isNotEmpty()) {
        todayAttendance.count { it.status.equals("Leave", ignoreCase = true) }
    } else 0

    val totalMarkedStudents = presentStudentsCount + absentStudentsCount + lateStudentsCount + leaveStudentsCount
    val studentAttendanceRate = if (totalMarkedStudents > 0) {
        (presentStudentsCount.toDouble() / totalMarkedStudents * 100.0)
    } else if (students.isNotEmpty()) {
        (presentStudentsCount.toDouble() / students.size * 100.0)
    } else 0.0

    val presentTeachersCount = if (teacherAttendanceList.isNotEmpty()) {
        teacherAttendanceList.count { it.status.equals("Present", ignoreCase = true) || it.status.equals("On Duty", ignoreCase = true) }
    } else {
        teachers.count { it.status.equals("ACTIVE", ignoreCase = true) }
    }
    val staffAttendanceRate = if (teachers.isNotEmpty()) {
        (presentTeachersCount.toDouble() / teachers.size * 100.0).coerceIn(0.0, 100.0)
    } else 100.0

    // Demographics & Strength Metrics
    val totalStudentsCount = students.size
    val activeStudentsCount = students.count { !it.isDeleted && !it.status.equals("Inactive", ignoreCase = true) }
    val boysCount = students.count { it.gender.equals("Male", ignoreCase = true) || it.gender.equals("Boy", ignoreCase = true) }
    val girlsCount = students.count { it.gender.equals("Female", ignoreCase = true) || it.gender.equals("Girl", ignoreCase = true) }
    val transportCount = students.count { it.hasTransport }

    val classStrengthMap = remember(students) {
        val allClasses = listOf(
            "Nursery", "LKG", "UKG",
            "Class 1", "Class 2", "Class 3", "Class 4", "Class 5",
            "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
        )
        allClasses.map { cls -> cls to students.count { it.className.equals(cls, ignoreCase = true) } }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Action Header
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
            colors = glassCardColors()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Institutional Analytics",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Real-time School KPI Insights & PDF Reports",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    isExportingExecutivePdf = true
                                    val summaryPdf = SchoolReportPdfHelper.generateAnalyticsSummaryPdf(
                                        context = context,
                                        totalStudents = totalStudentsCount,
                                        activeStudents = activeStudentsCount,
                                        totalTeachers = teachers.size,
                                        totalFeesBilled = totalBilled,
                                        totalFeesCollected = totalCollected,
                                        totalFeesDues = totalDues,
                                        collectionRate = collectionRatePercent,
                                        studentAttendancePercent = studentAttendanceRate,
                                        staffAttendancePercent = staffAttendanceRate,
                                        noticesCount = notices.size,
                                        homeworkCount = homeworkList.size,
                                        classDistribution = classStrengthMap
                                    )
                                    isExportingExecutivePdf = false
                                    if (summaryPdf != null) {
                                        Toast.makeText(context, "Executive Analytics Summary PDF generated!", Toast.LENGTH_SHORT).show()
                                        SchoolReportPdfHelper.openPdf(context, summaryPdf, "Open School Analytics Report")
                                    } else {
                                        Toast.makeText(context, "Failed to generate report PDF", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("export_analytics_pdf_btn")
                        ) {
                            if (isExportingExecutivePdf) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Executive PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Button(
                            onClick = { showReportCardDialog = true },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("open_report_card_creator_btn")
                        ) {
                            Icon(Icons.Filled.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Report Card", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Segmented Tabs
                val tabTitles = listOf("Executive", "Finance", "Attendance", "Demographics")
                val tabIcons = listOf(Icons.Filled.Dashboard, Icons.Filled.AccountBalanceWallet, Icons.Filled.FactCheck, Icons.Filled.People)
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(tabIcons[index], contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(title, fontSize = 12.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal)
                                }
                            },
                            modifier = Modifier.testTag("reports_tab_$index")
                        )
                    }
                }
            }
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                0 -> ExecutiveOverviewTab(
                    totalCollected = totalCollected,
                    totalDues = totalDues,
                    totalBilled = totalBilled,
                    collectionRate = collectionRatePercent,
                    studentAttendanceRate = studentAttendanceRate,
                    staffAttendanceRate = staffAttendanceRate,
                    totalStudents = totalStudentsCount,
                    totalFaculty = teachers.size,
                    activeNotices = notices.size,
                    onOpenReportCard = { showReportCardDialog = true }
                )
                1 -> FinancialsAnalyticsTab(
                    totalBilled = totalBilled,
                    totalCollected = totalCollected,
                    totalDues = totalDues,
                    collectionRate = collectionRatePercent,
                    totalConcessions = totalConcessions,
                    cashCollection = cashCollection,
                    onlineCollection = onlineCollection,
                    feesList = feesList,
                    feeLedgerList = feeLedgerList,
                    students = students
                )
                2 -> AttendanceAnalyticsTab(
                    studentAttendanceRate = studentAttendanceRate,
                    staffAttendanceRate = staffAttendanceRate,
                    presentStudents = presentStudentsCount,
                    absentStudents = absentStudentsCount,
                    lateStudents = lateStudentsCount,
                    leaveStudents = leaveStudentsCount,
                    totalMarked = totalMarkedStudents,
                    students = students,
                    attendanceList = todayAttendance,
                    teachers = teachers
                )
                3 -> DemographicsAnalyticsTab(
                    totalStudents = totalStudentsCount,
                    activeStudents = activeStudentsCount,
                    boysCount = boysCount,
                    girlsCount = girlsCount,
                    transportCount = transportCount,
                    classStrengthMap = classStrengthMap,
                    totalTeachers = teachers.size,
                    homeworkCount = homeworkList.size,
                    noticesCount = notices.size
                )
            }
        }
    }

    if (showReportCardDialog) {
        Dialog(
            onDismissRequest = { showReportCardDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                ReportCardCreatorDialog(
                    students = students,
                    currentUser = currentUser,
                    onDismiss = { showReportCardDialog = false }
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 1: EXECUTIVE OVERVIEW
// -------------------------------------------------------------
@Composable
private fun ExecutiveOverviewTab(
    totalCollected: Double,
    totalDues: Double,
    totalBilled: Double,
    collectionRate: Double,
    studentAttendanceRate: Double,
    staffAttendanceRate: Double,
    totalStudents: Int,
    totalFaculty: Int,
    activeNotices: Int,
    onOpenReportCard: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Stat Cards Grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnalyticsMetricCard(
                    title = "Revenue Collected",
                    value = "₹${"%,.0f".format(totalCollected)}",
                    subValue = "${"%.1f".format(collectionRate)}% Recovery",
                    icon = Icons.Filled.AccountBalanceWallet,
                    iconTint = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
                AnalyticsMetricCard(
                    title = "Outstanding Dues",
                    value = "₹${"%,.0f".format(totalDues)}",
                    subValue = "Pending across classes",
                    icon = Icons.Filled.MonetizationOn,
                    iconTint = Color(0xFFEF4444),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnalyticsMetricCard(
                    title = "Student Attendance",
                    value = "${"%.1f".format(studentAttendanceRate)}%",
                    subValue = "$totalStudents Enrolled",
                    icon = Icons.Filled.FactCheck,
                    iconTint = Color(0xFF3B82F6),
                    modifier = Modifier.weight(1f)
                )
                AnalyticsMetricCard(
                    title = "Faculty Strength",
                    value = "$totalFaculty Staff",
                    subValue = "${"%.1f".format(staffAttendanceRate)}% Daily Quotient",
                    icon = Icons.Filled.School,
                    iconTint = Color(0xFF8B5CF6),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Custom Canvas Chart: Revenue Allocation
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Institutional Revenue Partition",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Total: ₹${"%,.0f".format(totalBilled)}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                    ) {
                        val padding = 30f
                        val chartHeight = size.height - padding * 2
                        val chartWidth = size.width - padding * 2

                        // Base grid line
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.5f),
                            start = Offset(padding, size.height - padding),
                            end = Offset(size.width - padding, size.height - padding),
                            strokeWidth = 2f
                        )

                        if (totalBilled > 0) {
                            val collectedRatio = (totalCollected / totalBilled).toFloat().coerceIn(0.01f, 1f)
                            val duesRatio = (totalDues / totalBilled).toFloat().coerceIn(0.01f, 1f)

                            val barWidth = (chartWidth / 3).coerceAtMost(100f)

                            // Bar 1: Collected
                            val collectedHeight = (chartHeight * collectedRatio).coerceAtLeast(10f)
                            drawRoundRect(
                                color = Color(0xFF10B981),
                                topLeft = Offset(padding + chartWidth * 0.15f, size.height - padding - collectedHeight),
                                size = Size(barWidth, collectedHeight),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                            )

                            // Bar 2: Dues
                            val duesHeight = (chartHeight * duesRatio).coerceAtLeast(10f)
                            drawRoundRect(
                                color = Color(0xFFEF4444),
                                topLeft = Offset(padding + chartWidth * 0.55f, size.height - padding - duesHeight),
                                size = Size(barWidth, duesHeight),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(12.dp).background(Color(0xFF10B981), RoundedCornerShape(3.dp)))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Collected: ₹${"%,.0f".format(totalCollected)} (${"%.1f".format(collectionRate)}%)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(12.dp).background(Color(0xFFEF4444), RoundedCornerShape(3.dp)))
                            Spacer(modifier = Modifier.width(6.dp))
                            val duesPercent = if (totalBilled > 0) (totalDues / totalBilled * 100.0) else 0.0
                            Text("Outstanding: ₹${"%,.0f".format(totalDues)} (${"%.1f".format(duesPercent)}%)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Attendance & Operational KPIs Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Daily Operational Health", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    KPIProgressSegment(
                        title = "Student Attendance Ratio",
                        scorePercent = studentAttendanceRate.toInt(),
                        barColor = if (studentAttendanceRate >= 85) Color(0xFF10B981) else Color(0xFFF59E0B)
                    )
                    KPIProgressSegment(
                        title = "Staff Attendance Quotient",
                        scorePercent = staffAttendanceRate.toInt(),
                        barColor = Color(0xFF3B82F6)
                    )
                    KPIProgressSegment(
                        title = "Fee Collection Target Met",
                        scorePercent = collectionRate.toInt(),
                        barColor = if (collectionRate >= 75) Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                }
            }
        }

        // Quick Action Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Student Progress Report Cards",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Generate printable official PDF report cards with aggregate grades.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Button(
                        onClick = onOpenReportCard,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Create")
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: FINANCIALS & FEE LEDGER
// -------------------------------------------------------------
@Composable
private fun FinancialsAnalyticsTab(
    totalBilled: Double,
    totalCollected: Double,
    totalDues: Double,
    collectionRate: Double,
    totalConcessions: Double,
    cashCollection: Double,
    onlineCollection: Double,
    feesList: List<Fee>,
    feeLedgerList: List<FeeLedgerEntry>,
    students: List<Student>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Detailed Financial Metrics
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Fee Ledger Key Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        FinancialRowItem("Total Billed", "₹${"%,.2f".format(totalBilled)}", MaterialTheme.colorScheme.onSurface)
                        FinancialRowItem("Total Collected", "₹${"%,.2f".format(totalCollected)}", Color(0xFF10B981))
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        FinancialRowItem("Balance Dues", "₹${"%,.2f".format(totalDues)}", Color(0xFFEF4444))
                        FinancialRowItem("Concessions Granted", "₹${"%,.2f".format(totalConcessions)}", Color(0xFFF59E0B))
                    }
                }
            }
        }

        // Payment Channel Split
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Payment Channel Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    val totalChannel = (cashCollection + onlineCollection).coerceAtLeast(1.0)
                    val cashPercent = (cashCollection / totalChannel * 100.0).toInt()
                    val onlinePercent = (onlineCollection / totalChannel * 100.0).toInt()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cash Mode: ₹${"%,.0f".format(cashCollection)} ($cashPercent%)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Text("Online / UPI: ₹${"%,.0f".format(onlineCollection)} ($onlinePercent%)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .weight((cashCollection.toFloat() / totalChannel.toFloat()).coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFF3B82F6))
                        )
                        Box(
                            modifier = Modifier
                                .weight((onlineCollection.toFloat() / totalChannel.toFloat()).coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFF10B981))
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFF3B82F6), CircleShape))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cash Counter", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.width(20.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFF10B981), CircleShape))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Online / Bank / UPI", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // Class-wise Fee Status
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Class-wise Fee Collection Distribution", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    val studentMap = remember(students) { students.associateBy { it.studentId } }
                    val classFees = remember(feesList, feeLedgerList, students) {
                        val map = mutableMapOf<String, Pair<Double, Double>>() // class -> (paid, due)
                        feesList.forEach { f ->
                            val s = studentMap[f.studentId]
                            val cls = s?.className?.ifBlank { "Unassigned" } ?: "Unassigned"
                            val cur = map.getOrDefault(cls, Pair(0.0, 0.0))
                            map[cls] = Pair(cur.first + f.paidAmount, cur.second + f.dueAmount)
                        }
                        if (map.isEmpty()) {
                            feeLedgerList.forEach { l ->
                                val s = studentMap[l.studentId]
                                val cls = s?.className?.ifBlank { "Unassigned" } ?: "Unassigned"
                                val cur = map.getOrDefault(cls, Pair(0.0, 0.0))
                                map[cls] = Pair(cur.first + l.paidAmount, cur.second + l.balance)
                            }
                        }
                        map.toList().sortedByDescending { it.second.first + it.second.second }
                    }

                    if (classFees.isEmpty()) {
                        Text(
                            text = "No fee records recorded yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        classFees.take(8).forEach { (clsName, feeData) ->
                            val (paid, due) = feeData
                            val total = paid + due
                            val pct = if (total > 0) (paid / total * 100.0).toInt() else 0

                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(clsName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("Paid: ₹${"%,.0f".format(paid)} | Due: ₹${"%,.0f".format(due)} ($pct%)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                LinearProgressIndicator(
                                    progress = { if (total > 0) (paid / total).toFloat() else 0f },
                                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                                    color = if (pct >= 80) Color(0xFF10B981) else Color(0xFFF59E0B),
                                    trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FinancialRowItem(label: String, value: String, valueColor: Color) {
    Column {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

// -------------------------------------------------------------
// TAB 3: ATTENDANCE & DISCIPLINE
// -------------------------------------------------------------
@Composable
private fun AttendanceAnalyticsTab(
    studentAttendanceRate: Double,
    staffAttendanceRate: Double,
    presentStudents: Int,
    absentStudents: Int,
    lateStudents: Int,
    leaveStudents: Int,
    totalMarked: Int,
    students: List<Student>,
    attendanceList: List<Attendance>,
    teachers: List<Teacher>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Attendance Overview Cards
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Today's Student Attendance Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        AttendancePill("Present", "$presentStudents", Color(0xFF10B981))
                        AttendancePill("Absent", "$absentStudents", Color(0xFFEF4444))
                        AttendancePill("Late", "$lateStudents", Color(0xFFF59E0B))
                        AttendancePill("On Leave", "$leaveStudents", Color(0xFF8B5CF6))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    KPIProgressSegment(
                        title = "Overall Attendance Rate",
                        scorePercent = studentAttendanceRate.toInt(),
                        barColor = Color(0xFF10B981)
                    )
                }
            }
        }

        // Staff Attendance Quotient
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Faculty & Staff Attendance Quotient", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Faculty: ${teachers.size}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("Staff Attendance: ${"%.1f".format(staffAttendanceRate)}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${staffAttendanceRate.toInt()}%", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }

        // Class-wise Attendance Performance
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Class-wise Attendance Rates", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    val studentMap = remember(students) { students.groupBy { it.className } }
                    studentMap.forEach { (clsName, studentList) ->
                        if (clsName.isNotBlank()) {
                            val presentInClass = studentList.count { it.attendanceStatus.equals("Present", ignoreCase = true) }
                            val totalInClass = studentList.size
                            val pct = if (totalInClass > 0) (presentInClass.toDouble() / totalInClass * 100.0).toInt() else 0

                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(clsName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("$presentInClass/$totalInClass Present ($pct%)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                LinearProgressIndicator(
                                    progress = { if (totalInClass > 0) presentInClass.toFloat() / totalInClass else 0f },
                                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                                    color = if (pct >= 85) Color(0xFF10B981) else if (pct >= 70) Color(0xFF3B82F6) else Color(0xFFEF4444),
                                    trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AttendancePill(label: String, count: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(color.copy(alpha = 0.15f))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(count, fontWeight = FontWeight.ExtraBold, color = color, fontSize = 16.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
    }
}

// -------------------------------------------------------------
// TAB 4: DEMOGRAPHICS & OPERATIONS
// -------------------------------------------------------------
@Composable
private fun DemographicsAnalyticsTab(
    totalStudents: Int,
    activeStudents: Int,
    boysCount: Int,
    girlsCount: Int,
    transportCount: Int,
    classStrengthMap: List<Pair<String, Int>>,
    totalTeachers: Int,
    homeworkCount: Int,
    noticesCount: Int
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Enrolment & Status Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Enrollment & Student Demographics", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        FinancialRowItem("Total Enrolled", "$totalStudents Scholars", MaterialTheme.colorScheme.onSurface)
                        FinancialRowItem("Active Status", "$activeStudents Students", Color(0xFF10B981))
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Gender Ratio
                    val totalGender = (boysCount + girlsCount).coerceAtLeast(1)
                    val boysPercent = (boysCount.toDouble() / totalGender * 100.0).toInt()
                    val girlsPercent = (girlsCount.toDouble() / totalGender * 100.0).toInt()

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Boys: $boysCount ($boysPercent%)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF3B82F6))
                        Text("Girls: $girlsCount ($girlsPercent%)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFEC4899))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .weight((boysCount.toFloat() / totalGender).coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFF3B82F6))
                        )
                        Box(
                            modifier = Modifier
                                .weight((girlsCount.toFloat() / totalGender).coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFFEC4899))
                        )
                    }
                }
            }
        }

        // Transport & Logistics
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Transport & Logistics Enrollment", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    val transportPercent = if (totalStudents > 0) (transportCount.toDouble() / totalStudents * 100.0).toInt() else 0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("$transportCount Students enrolled in Bus Transport", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("$transportPercent% of total student body", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        Icon(Icons.Filled.DirectionsBus, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    }
                }
            }
        }

        // Class Strength Histogram
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Class-wise Strength Distribution", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    val maxStrength = (classStrengthMap.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)

                    classStrengthMap.forEach { (clsName, count) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(clsName, modifier = Modifier.width(70.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(16.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fraction = (count.toFloat() / maxStrength).coerceIn(0.02f, 1f))
                                        .fillMaxHeight()
                                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                                )
                            }
                            Text(
                                text = "$count",
                                modifier = Modifier.width(40.dp),
                                textAlign = TextAlign.End,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// REUSABLE KPI PROGRESS SEGMENT
// -------------------------------------------------------------
@Composable
fun KPIProgressSegment(title: String, scorePercent: Int, barColor: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
            Text("$scorePercent%", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = barColor)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (scorePercent / 100f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = barColor,
            trackColor = barColor.copy(alpha = 0.15f)
        )
    }
}

@Composable
private fun AnalyticsMetricCard(
    title: String,
    value: String,
    subValue: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        colors = glassCardColors(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(iconTint.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subValue, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// -------------------------------------------------------------
// REPORT CARD CREATOR & PDF GENERATOR DIALOG
// -------------------------------------------------------------
@Composable
fun ReportCardCreatorDialog(
    students: List<Student>,
    currentUser: User?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedStudentId by remember { mutableStateOf(students.firstOrNull()?.studentId ?: "") }
    var examTitle by remember { mutableStateOf("Annual Final Examination") }

    var scoreMath by remember { mutableStateOf("88") }
    var scoreScience by remember { mutableStateOf("92") }
    var scoreEnglish by remember { mutableStateOf("85") }
    var scoreSocial by remember { mutableStateOf("89") }
    var scoreCS by remember { mutableStateOf("94") }
    var scoreHindi by remember { mutableStateOf("86") }

    var remarksInput by remember { mutableStateOf("Excellent academic progression. Outstanding problem solving ability.") }

    var isGeneratingPdf by remember { mutableStateOf(false) }
    var generatedPdfFile by remember { mutableStateOf<java.io.File?>(null) }

    val correspondent = students.find { it.studentId == selectedStudentId }

    // Live Marks Calculation
    val math = scoreMath.toIntOrNull() ?: 0
    val science = scoreScience.toIntOrNull() ?: 0
    val english = scoreEnglish.toIntOrNull() ?: 0
    val social = scoreSocial.toIntOrNull() ?: 0
    val cs = scoreCS.toIntOrNull() ?: 0
    val hindi = scoreHindi.toIntOrNull() ?: 0

    val marksMap = mapOf(
        "Mathematics" to math,
        "Science" to science,
        "English" to english,
        "Social Studies" to social,
        "Computer Science / IT" to cs,
        "Hindi / Regional" to hindi
    )
    val totalMaxMarks = marksMap.size * 100
    val totalObtained = marksMap.values.sum()
    val percentage = if (totalMaxMarks > 0) (totalObtained.toDouble() / totalMaxMarks * 100.0) else 0.0

    val grade = when {
        percentage >= 90 -> "A+ (Outstanding)"
        percentage >= 80 -> "A (Excellent)"
        percentage >= 70 -> "B+ (Very Good)"
        percentage >= 60 -> "B (Good)"
        percentage >= 50 -> "C (Satisfactory)"
        percentage >= 40 -> "D (Pass)"
        else -> "E (Needs Improvement)"
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = glassCardColors()
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Generate Academic Report Card",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Scholar Selector
            var isDropdownOpen by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { isDropdownOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (correspondent != null) "${correspondent.name} (${correspondent.className})" else "Select Student",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                    }
                }

                DropdownMenu(
                    expanded = isDropdownOpen,
                    onDismissRequest = { isDropdownOpen = false }
                ) {
                    students.forEach { s ->
                        DropdownMenuItem(
                            text = { Text("${s.name} - ${s.className} (Roll ${s.rollNo.ifBlank { s.rollNumber.toString() }})") },
                            onClick = {
                                selectedStudentId = s.studentId
                                isDropdownOpen = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Assessment Title Input
            OutlinedTextField(
                value = examTitle,
                onValueChange = { examTitle = it },
                label = { Text("Assessment Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Subject Marks (Max: 100)",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = scoreMath, onValueChange = { scoreMath = it }, label = { Text("Math") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = scoreScience, onValueChange = { scoreScience = it }, label = { Text("Science") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = scoreEnglish, onValueChange = { scoreEnglish = it }, label = { Text("English") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = scoreSocial, onValueChange = { scoreSocial = it }, label = { Text("Social Sci") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = scoreCS, onValueChange = { scoreCS = it }, label = { Text("Computers") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = scoreHindi, onValueChange = { scoreHindi = it }, label = { Text("Hindi") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Live Performance Preview Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total: $totalObtained / $totalMaxMarks", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Grade: $grade", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Text("${"%.1f".format(percentage)}%", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = remarksInput,
                onValueChange = { remarksInput = it },
                label = { Text("Principal / Teacher Remarks") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (generatedPdfFile != null) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                SchoolReportPdfHelper.openPdf(context, generatedPdfFile!!, "Open Report Card PDF")
                            },
                            modifier = Modifier.weight(1f).testTag("open_generated_pdf_btn")
                        ) {
                            Icon(Icons.Filled.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Open PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                SchoolReportPdfHelper.sharePdf(
                                    context = context,
                                    pdfFile = generatedPdfFile!!,
                                    subject = "Report Card - ${correspondent?.name ?: "Student"}",
                                    body = "Attached is the official report card for ${correspondent?.name}."
                                )
                            },
                            modifier = Modifier.weight(1f).testTag("share_generated_pdf_btn")
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share PDF")
                        }
                    }
                    Text(
                        text = "Saved to: ${generatedPdfFile?.name}",
                        fontSize = 11.sp,
                        color = Color(0xFF10B981),
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Button(
                    onClick = {
                        val studentToGenerate = correspondent ?: students.firstOrNull()
                        if (studentToGenerate == null) {
                            Toast.makeText(context, "Please select a student first", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        scope.launch {
                            isGeneratingPdf = true
                            val file = SchoolReportPdfHelper.generateReportCardPdf(
                                context = context,
                                student = studentToGenerate,
                                examTitle = examTitle,
                                marksMap = marksMap,
                                totalMaxMarks = totalMaxMarks,
                                totalObtainedMarks = totalObtained,
                                percentage = percentage,
                                grade = grade,
                                remarks = remarksInput,
                                issuedBy = currentUser?.name ?: "Principal"
                            )
                            isGeneratingPdf = false
                            if (file != null) {
                                generatedPdfFile = file
                                Toast.makeText(context, "Report Card PDF generated successfully!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("build_pdf_report_btn"),
                    enabled = !isGeneratingPdf && students.isNotEmpty()
                ) {
                    if (isGeneratingPdf) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generating PDF Document...")
                    } else {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Generate & Download Official PDF", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                Text("Dismiss")
            }
        }
    }
}
