package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.ui.components.UserProfileAvatar
import com.example.ui.components.PasswordManagementCard
import com.example.data.model.Student
import com.example.data.model.User
import com.example.ui.SchoolViewModel
import com.example.ui.theme.glassCardColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentProfileScreen(
    student: Student,
    viewModel: SchoolViewModel,
    onBack: () -> Unit,
    canEdit: Boolean,
    onEdit: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Student Profile") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    if (canEdit) {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Filled.Edit, "Edit")
                        }
                    }
                    IconButton(onClick = { /* Export PDF */ }) {
                        Icon(Icons.Filled.Download, "Export PDF")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Header
            ProfileHeaderCard(student = student)

            // Info Cards
            var expandedSection by remember { mutableStateOf<String?>("Personal Info") }
            
            ExpandableProfileCard(
                title = "Personal Information",
                icon = Icons.Filled.Person,
                isExpanded = expandedSection == "Personal Info",
                onToggle = { expandedSection = if (expandedSection == "Personal Info") null else "Personal Info" }
            ) {
                InfoRow("Father's Name", student.fatherName.ifEmpty { "N/A" })
                InfoRow("Mother's Name", student.motherName.ifEmpty { "N/A" })
                InfoRow("Phone", student.phone.ifEmpty { "N/A" })
                InfoRow("Address", student.address.ifEmpty { "N/A" })
                InfoRow("DOB", student.DOB.ifEmpty { "N/A" })
                InfoRow("Aadhaar", student.aadhaarNo.ifEmpty { "N/A" })
            }
            
            ExpandableProfileCard(
                title = "Academic Information",
                icon = Icons.Filled.School,
                isExpanded = expandedSection == "Academic",
                onToggle = { expandedSection = if (expandedSection == "Academic") null else "Academic" }
            ) {
                InfoRow("Admission Date", student.dateOfAdmission)
                InfoRow("Status", student.status)
            }

            ExpandableProfileCard(
                title = "Fee Summary",
                icon = Icons.Filled.AccountBalanceWallet,
                isExpanded = expandedSection == "Fees",
                onToggle = { expandedSection = if (expandedSection == "Fees") null else "Fees" }
            ) {
                InfoRow("Fee Status", student.feeStatus)
                InfoRow("Admission Fee", "₹12000.0")
                InfoRow("Monthly Fee", "₹2000.0")
                InfoRow("Transport Fee", "₹${student.transportFee}")
                InfoRow("Exam Fee", "₹1500.0")
                InfoRow("Pending Amount", "₹0.0")
                InfoRow("Paid Amount", "₹15500.0")
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Make Quick Payment") }
                // Add more fee details
            }
            
            ExpandableProfileCard(
                title = "Transport Configuration",
                icon = Icons.Filled.DirectionsBus,
                isExpanded = expandedSection == "Transport",
                onToggle = { expandedSection = if (expandedSection == "Transport") null else "Transport" }
            ) {
                if (student.hasTransport) {
                    InfoRow("Slab", student.transportSlab)
                    InfoRow("Monthly Fee", "₹${student.transportFee}")
                } else {
                    Text("Transport not opted.", style = MaterialTheme.typography.bodyMedium)
                }
            }

            ExpandableProfileCard(
                title = "Assigned Books",
                icon = Icons.Filled.MenuBook,
                isExpanded = expandedSection == "Books",
                onToggle = { expandedSection = if (expandedSection == "Books") null else "Books" }
            ) {
                Text("No books assigned.", style = MaterialTheme.typography.bodyMedium)
            }
            
            ExpandableProfileCard(
                title = "Activity Timeline",
                icon = Icons.Filled.Timeline,
                isExpanded = expandedSection == "Timeline",
                onToggle = { expandedSection = if (expandedSection == "Timeline") null else "Timeline" }
            ) {
                TimelineItem("Profile Created", "System", "10 Apr 2024")
                TimelineItem("Fee Paid - April", "Admin", "15 Apr 2024")
            }

            val currentUser by viewModel.currentUser.collectAsState()
            val usersList by viewModel.usersState.collectAsState(initial = emptyList())
            val targetUserId = student.studentId.ifBlank { student.admissionNo }
            val targetUser = usersList.find { it.userId == targetUserId || it.userId == student.studentId || it.userId == student.admissionNo }
                ?: User(
                    userId = targetUserId,
                    name = student.name,
                    role = "STUDENT",
                    phone = student.phone,
                    dob = student.DOB,
                    passwordStatus = if (student.DOB.isBlank()) "DOB VERIFICATION REQUIRED" else "INITIAL DOB PASSWORD"
                )

            Spacer(modifier = Modifier.height(8.dp))
            PasswordManagementCard(
                targetUser = targetUser,
                currentUserRole = currentUser?.role ?: "",
                viewModel = viewModel
            )
        }
    }
}

@Composable
fun ProfileHeaderCard(student: Student) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            UserProfileAvatar(
                avatarUrl = student.photoUrl,
                size = 100.dp,
                fallbackIcon = Icons.Filled.Person,
                contentDescription = "${student.name} Profile Photo",
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                iconTint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = student.name,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${student.className} • Roll ${student.rollNo}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
            Text(
                text = "ID: ${student.studentId} • Adm: ${student.admissionNo}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun ExpandableProfileCard(
    title: String,
    icon: ImageVector,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = glassCardColors(),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = "Toggle",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    content()
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@Composable
fun TimelineItem(title: String, subtitle: String, date: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
            )
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(40.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(text = date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
