package com.example.ui.screens
import com.example.ui.components.SecureScreen
import android.net.Uri
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.automirrored.filled.*

import androidx.activity.compose.BackHandler
import androidx.compose.ui.input.nestedscroll.nestedScroll

import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch
import androidx.compose.ui.res.painterResource
import com.example.R

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.data.repository.findEffectiveFeeRate
import com.example.util.SchoolReportPdfHelper
import com.example.ui.components.UserProfileAvatar
import com.example.ui.SchoolViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// CENTRAL SCHOOL ACADEMIC CLASSES (Nursery to 10th Grade)
val SchoolClassesList = listOf(
    "Nursery", "LKG", "UKG", 
    "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
    "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
)

@Composable
fun getTeacherAssignedClass(viewModel: SchoolViewModel): String {
    val currentUser by viewModel.currentUser.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""
    if (roleStr == "TEACHER" || roleStr == "CLASS_TEACHER") {
        val teacher = teachers.find { it.teacherId == currentUser?.userId }
        if (teacher != null && teacher.classTeacherOf.isNotBlank()) {
            return teacher.classTeacherOf
        }
        if (teacher != null) {
            val matches = SchoolClassesList.filter { cl ->
                teacher.classesAssigned.contains(cl, ignoreCase = true)
            }
            if (matches.isNotEmpty()) return matches.first()
        }
        return "Class 9" // Default fallback for TC12/demo
    }
    return ""
}

@Composable
fun getTeacherAssignedSection(viewModel: SchoolViewModel): String {
    val currentUser by viewModel.currentUser.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""
    if (roleStr == "TEACHER" || roleStr == "CLASS_TEACHER") {
        val teacher = teachers.find { it.teacherId == currentUser?.userId }
        return "A" // Default fallback
    }
    return ""
}

// ENUM FOR MODULAR SYSTEM NAVIGATION
enum class AppScreen(val title: String) {
    SPLASH("Loading Session..."),
    LOGIN("Secure Login"),
    DASHBOARD("Smart Dashboard"),
    STUDENTS("Students Directory"),
    TEACHERS("Teachers Staff"),
    ATTENDANCE("Class Attendance"),
    FEES("Fees Management"),
    HOMEWORK("Class Homework"),
    NOTICES("Notices Board"),
    TIMETABLE("Weekly Schedules"),
    CHAT("Real-Time Messenger"),
    REPORTS("Reports & Analytics"),
    CALENDAR("School Calendar"),
    CLASSES("Academic Classes"),
    SETTINGS("Settings & Profile"),
    ADD_STUDENT("Register Student"),
    PRINCIPAL_ACTIVITY("Principal Activity Center"),
    CHAT_OVERSIGHT("School Chat Oversight")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainSchoolAppContainer(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isSessionChecking by viewModel.isSessionChecking.collectAsState()
    var currentScreen by remember { mutableStateOf(AppScreen.SPLASH) }
    val currentUser by viewModel.currentUser.collectAsState()
    val isFirebaseMode by viewModel.isFirebaseMode.collectAsState()
    var selectedStudentForFeeLedger by remember { mutableStateOf<Student?>(null) }

    // Observe navigationState for strict reactive role-based screen routing
    val navigationState by viewModel.navigationState.collectAsState()

    // Import UI states imports or reference properly: com.example.ui.NavigationTarget
    LaunchedEffect(navigationState) {
        when (navigationState) {
            com.example.ui.NavigationTarget.PRINCIPAL_DASHBOARD,
            com.example.ui.NavigationTarget.ADMIN_DASHBOARD,
            com.example.ui.NavigationTarget.TEACHER_DASHBOARD,
            com.example.ui.NavigationTarget.STUDENT_DASHBOARD -> {
                if (currentScreen == AppScreen.LOGIN || currentScreen == AppScreen.SPLASH) {
                    currentScreen = AppScreen.DASHBOARD
                    Toast.makeText(context, "Welcome back, ${currentUser?.name}!", Toast.LENGTH_SHORT).show()
                }
            }
            com.example.ui.NavigationTarget.LOGIN_SCREEN -> {
                currentScreen = AppScreen.LOGIN
            }
            com.example.ui.NavigationTarget.Idle -> {
                // Do nothing
            }
        }
    }

    // Secure Role-Based Access Control Guards & Sync
    LaunchedEffect(currentUser) {
        val user = currentUser
        if (user != null) {
            val role = user.role.uppercase().trim()
            if (role == "STUDENT") {
                val allowedScreens = listOf(
                    AppScreen.DASHBOARD, AppScreen.ATTENDANCE, AppScreen.FEES,
                    AppScreen.SETTINGS, AppScreen.CHAT, AppScreen.NOTICES,
                    AppScreen.TIMETABLE, AppScreen.HOMEWORK, AppScreen.CALENDAR
                )
                if (currentScreen !in allowedScreens) {
                    currentScreen = AppScreen.DASHBOARD
                }
            } else if (role == "CLASS_TEACHER" || role == "TEACHER") {
                val allowedScreens = listOf(
                    AppScreen.DASHBOARD, AppScreen.CLASSES, AppScreen.ATTENDANCE,
                    AppScreen.HOMEWORK, AppScreen.NOTICES, AppScreen.SETTINGS,
                    AppScreen.CHAT, AppScreen.TIMETABLE, AppScreen.CALENDAR,
                    AppScreen.STUDENTS, AppScreen.FEES, AppScreen.REPORTS
                )
                if (currentScreen !in allowedScreens) {
                    currentScreen = AppScreen.DASHBOARD
                }
            } else if (role == "PRINCIPAL" || user.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)) {
                val allowedScreens = listOf(
                    AppScreen.DASHBOARD, AppScreen.STUDENTS, AppScreen.TEACHERS,
                    AppScreen.ATTENDANCE, AppScreen.FEES, AppScreen.HOMEWORK,
                    AppScreen.NOTICES, AppScreen.TIMETABLE, AppScreen.CHAT,
                    AppScreen.REPORTS, AppScreen.CALENDAR, AppScreen.CLASSES,
                    AppScreen.SETTINGS, AppScreen.ADD_STUDENT,
                    AppScreen.PRINCIPAL_ACTIVITY, AppScreen.CHAT_OVERSIGHT
                )
                if (currentScreen !in allowedScreens) {
                    currentScreen = AppScreen.DASHBOARD
                }
            } else if (role == "ADMIN" || role == "HEAD_ADMIN") {
                val allowedScreens = listOf(
                    AppScreen.DASHBOARD, AppScreen.STUDENTS, AppScreen.TEACHERS,
                    AppScreen.ATTENDANCE, AppScreen.FEES, AppScreen.HOMEWORK,
                    AppScreen.NOTICES, AppScreen.TIMETABLE, AppScreen.CHAT,
                    AppScreen.REPORTS, AppScreen.CALENDAR, AppScreen.CLASSES,
                    AppScreen.SETTINGS, AppScreen.ADD_STUDENT
                )
                if (currentScreen !in allowedScreens) {
                    currentScreen = AppScreen.DASHBOARD
                }
            }
        } else {
            if (!isSessionChecking) {
                currentScreen = AppScreen.LOGIN
            }
        }
    }
    // Prevent the user from going back to Login/Splash if authenticated
    BackHandler(enabled = currentScreen != AppScreen.LOGIN) {
        if (currentScreen != AppScreen.DASHBOARD) {
            currentScreen = AppScreen.DASHBOARD
        } else {
            val activity = context as? android.app.Activity
            activity?.finish()
        }
    }

    if (isSessionChecking || currentScreen == AppScreen.SPLASH) {
        SplashScreen()
    } else {
        val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
        val isDashboardOrLogin = currentScreen == AppScreen.LOGIN || currentScreen == AppScreen.SPLASH || currentScreen == AppScreen.DASHBOARD
        Scaffold(
            modifier = modifier,
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                val screensWithoutMainTopBar = listOf(
                    AppScreen.LOGIN, AppScreen.SPLASH, AppScreen.DASHBOARD,
                    AppScreen.CHAT, AppScreen.ATTENDANCE, AppScreen.ADD_STUDENT,
                    AppScreen.PRINCIPAL_ACTIVITY, AppScreen.CHAT_OVERSIGHT
                )
                if (currentScreen !in screensWithoutMainTopBar) {
                    TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                        actionIconContentColor = MaterialTheme.colorScheme.onPrimary,
                        scrolledContainerColor = MaterialTheme.colorScheme.primary
                    ),
                    scrollBehavior = scrollBehavior,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (currentScreen == AppScreen.DASHBOARD) {
                                SchoolLogoImage(
                                    contentDescription = "Logo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                            Column {
                                Text(
                                    text = "S. D Public School",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                                Text(
                                    text = currentScreen.title,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                                )
                            )
                        }
                            }
                    },
                    navigationIcon = {
                        if (currentScreen != AppScreen.DASHBOARD) {
                            IconButton(
                                onClick = { currentScreen = AppScreen.DASHBOARD },
                                modifier = Modifier.testTag("back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to Dashboard"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Filled.School,
                                contentDescription = "School Logo",
                                modifier = Modifier.padding(start = 12.dp, end = 4.dp)
                            )
                        }
                    },
                    actions = {
                        // Connection toggler Indicator
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.15f))
                                .clickable {
                                    viewModel.toggleFirebaseMode()
                                    val mode = if (isFirebaseMode) "Firestore Live" else "Offline Sandbox"
                                    Toast.makeText(context, "Database Mode Switched: $mode", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isFirebaseMode) Color(0xFF10B981) else Color(0xFFF59E0B))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isFirebaseMode) "Cloud" else "Sandbox",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }

                        if (currentUser != null && currentScreen != AppScreen.SETTINGS) {
                            IconButton(
                                onClick = { currentScreen = AppScreen.SETTINGS },
                                modifier = Modifier.testTag("settings_top_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = "App Settings"
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                viewModel.logoutUser()
                                Toast.makeText(context, "Signed out securely", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = "Secure Log Out"
                            )
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (currentScreen != AppScreen.LOGIN && currentScreen != AppScreen.DASHBOARD) {
                // Persistent elegant quick access ribbon at the bottom of child modules
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    val items = listOf(
                        Triple(AppScreen.DASHBOARD, Icons.Filled.Dashboard, "Home"),
                        Triple(AppScreen.STUDENTS, Icons.Filled.People, "Students"),
                        Triple(AppScreen.ATTENDANCE, Icons.Filled.CheckCircle, "Attendance"),
                        Triple(AppScreen.FEES, Icons.Filled.AccountBalanceWallet, "Fees"),
                        Triple(AppScreen.CHAT, Icons.Filled.Chat, "Chat")
                    )
                    items.forEach { (screen, icon, label) ->
                        NavigationBarItem(
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(text = label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = currentScreen == screen,
                            onClick = { currentScreen = screen },
                            modifier = Modifier.testTag("nav_${label.lowercase(Locale.ROOT)}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.SPLASH -> SplashScreen()
                AppScreen.LOGIN -> PremiumLoginScreen(viewModel = viewModel)
                AppScreen.DASHBOARD -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigate = { currentScreen = it }
                )
                AppScreen.STUDENTS -> StudentManagementScreen(viewModel = viewModel, onNavigate = { currentScreen = it })
                AppScreen.TEACHERS -> TeacherManagementScreen(viewModel = viewModel)
                AppScreen.ATTENDANCE -> AttendanceManagementScreen(viewModel = viewModel)
                AppScreen.FEES -> FeesManagementScreen(viewModel = viewModel, onOpenFeeLedger = { selectedStudentForFeeLedger = it })
                AppScreen.HOMEWORK -> HomeworkScreen(viewModel = viewModel)
                AppScreen.NOTICES -> NoticeHubScreen(viewModel = viewModel)
                AppScreen.TIMETABLE -> TimetableScreen(viewModel = viewModel)
                AppScreen.CHAT -> ChatScreen(viewModel = viewModel)
                AppScreen.REPORTS -> ReportsScreen(viewModel = viewModel)
                AppScreen.CALENDAR -> SchoolCalendarScreen(viewModel = viewModel)
                AppScreen.CLASSES -> AcademicClassesScreen(
                    viewModel = viewModel, 
                    onNavigate = { currentScreen = it },
                    onOpenFeeLedger = { selectedStudentForFeeLedger = it }
                )
                AppScreen.ADD_STUDENT -> AddStudentScreen(
                    viewModel = viewModel,
                    onNavigate = { currentScreen = it }
                )
                AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                AppScreen.PRINCIPAL_ACTIVITY -> PrincipalActivityCenterScreen(
                    viewModel = viewModel,
                    onNavigate = { currentScreen = it }
                )
                AppScreen.CHAT_OVERSIGHT -> ChatOversightScreen(
                    viewModel = viewModel,
                    onNavigate = { currentScreen = it }
                )
            }

            if (selectedStudentForFeeLedger != null) {
                PupilsFeeLedgerSheet(
                    viewModel = viewModel,
                    student = selectedStudentForFeeLedger!!,
                    onDismiss = { selectedStudentForFeeLedger = null }
                )
            }
        }
    }
    }
}

@Composable
fun SplashScreen() {
    val scale = remember { androidx.compose.animation.core.Animatable(0.5f) }
    val alpha = remember { androidx.compose.animation.core.Animatable(0f) }
    
    LaunchedEffect(Unit) {
        launch {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.tween(durationMillis = 800, easing = androidx.compose.animation.core.FastOutSlowInEasing)
            )
        }
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = androidx.compose.animation.core.tween(durationMillis = 800)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050B14)), // Dark midnight background
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .graphicsLayer(scaleX = scale.value, scaleY = scale.value, alpha = alpha.value),
                contentAlignment = Alignment.Center
            ) {
                SchoolLogoImage(
                    contentDescription = "School Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "S.D. PUBLIC SCHOOL",
                style = MaterialTheme.typography.displaySmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            )
            Text(
                text = "Smart Management System",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.height(48.dp))
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}

// ==========================================
// 1. SECURE AUTHENTICATION SYSTEM
// ==========================================
// 4. TEACHER MANAGEMENT
// ==========================================
@Composable
fun TeacherManagementScreen(viewModel: SchoolViewModel) {
    SecureScreen()
    val teachers by viewModel.teachersState.collectAsState()
    val users by viewModel.usersState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val payrolls by viewModel.payrollsState.collectAsState()
    
    val isManagement = currentUser?.role in listOf("ADMIN", "HEAD_ADMIN", "PRINCIPAL")
    val isPrincipal = currentUser?.role?.uppercase()?.trim() == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    
    var selectedTeacherForProfile by remember { mutableStateOf<Teacher?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var enrolledTeacherDialogInfo by remember { mutableStateOf<Triple<String, String, String>?>(null) }

    var searchQuery by remember { mutableStateOf("") }
    val filteredTeachers = remember(teachers, searchQuery) {
        if (searchQuery.isBlank()) teachers
        else {
            teachers.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                it.subject.contains(searchQuery, ignoreCase = true) ||
                it.classesAssigned.contains(searchQuery, ignoreCase = true) ||
                it.teacherId.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    // Detail profile states
    var showClassChangeDialog by remember { mutableStateOf(false) }
    var selectedNewClassForChange by remember { mutableStateOf("") }
    
    var showTakeoverTeacherPrompt by remember { mutableStateOf(false) }
    var selectedTakeoverTeacher by remember { mutableStateOf<Teacher?>(null) }
    
    var showDeleteConfirmationDialog by remember { mutableStateOf(false) }

    var tId by remember { mutableStateOf("") }
    var tName by remember { mutableStateOf("") }
    var tSubject by remember { mutableStateOf("") }
    var tClasses by remember { mutableStateOf("") }
    var tPhone by remember { mutableStateOf("") }
    var tEmail by remember { mutableStateOf("") }
    var tDOB by remember { mutableStateOf("") }

    val context = LocalContext.current

    if (selectedTeacherForProfile != null) {
        val teacherObj = selectedTeacherForProfile!!
        // Instagram-Style Detailed Profile screen
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Top Navigation header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { selectedTeacherForProfile = null },
                    modifier = Modifier.testTag("profile_back_btn")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to teachers directory")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Teacher Profile", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // centered circular avatar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val matchingUser = users.find { it.userId == teacherObj.teacherId }
                    val resolvedRole = matchingUser?.role ?: "TEACHER"
                    val resolvedEmail = matchingUser?.email ?: teacherObj.email
                    val resolvedClassTeacher = teacherObj.classTeacherOf

                    // Avatar with Overlapping mini medal badge
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(102.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surface),
                                contentAlignment = Alignment.Center
                            ) {
                                if (teacherObj.photoUrl.isNotEmpty()) {
                                    coil.compose.AsyncImage(
                                        model = teacherObj.photoUrl,
                                        contentDescription = "Profile Photo",
                                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                       // error = coil.compose.rememberAsyncImagePainter(model = "https://images.unsplash.com/photo-1544717205-2782549b5136?w=150")
                                    )
                                } else {
                                    Text(
                                        text = teacherObj.name.split(" ").mapNotNull { it.firstOrNull() }.joinToString("").take(2).uppercase(),
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }
                            }
                        }

                        // Badge Overlap
                        val overlayDetails = getCredentialBadgeDetails(resolvedRole, resolvedEmail, resolvedClassTeacher)
                        if (overlayDetails != null) {
                            val overlayColor = overlayDetails.second
                            val overlayIcon = overlayDetails.third
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .offset(x = (4).dp, y = (4).dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(overlayColor, Color(0xFFF59E0B))))
                                    .padding(2.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = overlayIcon,
                                    contentDescription = "Avatar Badge Seal",
                                    tint = overlayColor,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(teacherObj.name, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold))
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    // Stylized badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (resolvedClassTeacher.isNotEmpty()) "CLASS TEACHER OF ${resolvedClassTeacher.uppercase()}" else "SUBJECT TEACHER",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    // Render dynamic Role Credential Badge Card right below
                    DynamicRoleCredentialBadge(
                        userRole = resolvedRole,
                        userEmail = resolvedEmail,
                        classTeacherOf = resolvedClassTeacher,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    
                    if (isPrincipal && resolvedRole != "CLASS_TEACHER") {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showClassChangeDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("promote_class_teacher_btn")
                        ) {
                            Icon(Icons.Filled.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Promote to Class Teacher")
                        }
                    } else if (resolvedRole == "CLASS_TEACHER") {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Class Teacher of $resolvedClassTeacher", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Biography stats list grid layout
            val isStudentViewer = currentUser?.role == "STUDENT"
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("More Information", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    if (!isStudentViewer) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("User Identifier (Login ID)", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            Text(teacherObj.teacherId, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Classroom Assigned", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(teacherObj.classesAssigned.ifBlank { "None" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Mobile Number", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(teacherObj.phone.ifBlank { "Available on Request" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    if (!isStudentViewer) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Email Address", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            Text(teacherObj.email, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Department / Subject Specialty", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(teacherObj.subject, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Academic Qualifications", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(teacherObj.qualification.ifBlank { "B.Ed, Graduate" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Teaching Experience", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(teacherObj.experience.ifBlank { "3 Years" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    if (!isStudentViewer) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Official Joining Date", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            Text(teacherObj.joiningDate.ifBlank { "2026-04-01" }, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Salary Management Subsection strictly visible only to Principal role
            if (isPrincipal) {
                val monthsList = listOf("April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March")
                var selectedMonthLedger by remember { mutableStateOf("May") }
                
                // Fetch dynamic payroll list
                val teacherId = teacherObj.teacherId
                val matchingPayrolls = payrolls.filter { it.teacherId == teacherId }
                
                // Cumulative calculations
                val totalPaidAmt = matchingPayrolls.filter { it.status == "Paid" }.sumOf { it.netSalary }
                val totalPendingAmt = matchingPayrolls.filter { it.status == "Pending" }.sumOf { it.netSalary }
                
                // Editing payroll state
                var showSalaryEditDialog by remember { mutableStateOf(false) }
                var editBasicSalary by remember { mutableStateOf("52500") }
                var editBonus by remember { mutableStateOf("1500") }
                var editAllowances by remember { mutableStateOf("3000") }
                var editDeductions by remember { mutableStateOf("2000") }
                var editAbsentDays by remember { mutableStateOf("0") }
                var editStatus by remember { mutableStateOf("Paid") }
                var editRefDetails by remember { mutableStateOf("Direct NEFT Ref #TXN938248") }
                var editRemarks by remember { mutableStateOf("Credited successfully.") }

                // Slip overlay state
                var showReceiptSlipDialog by remember { mutableStateOf(false) }
                
                // Active configuration
                val activePayroll = matchingPayrolls.find { it.month == selectedMonthLedger } ?: Payroll(
                    payrollId = "${teacherId}_$selectedMonthLedger",
                    teacherId = teacherId,
                    month = selectedMonthLedger,
                    basicSalary = 52500.0,
                    bonus = 1500.0,
                    allowances = 3000.0,
                    deductions = 2000.0,
                    netSalary = 55000.0,
                    status = if (selectedMonthLedger == "April" || selectedMonthLedger == "May") "Paid" else "Pending",
                    paymentDetails = "Direct NEFT Ref #TXN938248",
                    remarks = "Default projection"
                )

                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = glassCardColors()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Teacher Payroll & Salary Ledger", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                            OutlinedButton(
                                onClick = { showReceiptSlipDialog = true },
                                modifier = Modifier.testTag("btn_salary_slip")
                            ) {
                                Icon(Icons.Filled.Print, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Salary Slip", fontSize = 11.sp)
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        // Analytics overview card grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ElevatedCard(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFE8F5E9)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("FY Total Released", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                    Text("₹$totalPaidAmt", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                                }
                            }
                            ElevatedCard(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF3E0)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("FY Total Outstanding", fontSize = 10.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                                    Text("₹$totalPendingAmt", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Fiscal Monthly Ledger (Select Month)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Horizontally scrollable list of months
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(monthsList) { month ->
                                val currentRecord = matchingPayrolls.find { it.month == month }
                                val monthStatus = currentRecord?.status ?: (if (month == "April" || month == "May") "Paid" else "Pending")
                                val isSelected = month == selectedMonthLedger
                                val containerColor = if (isSelected) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                }
                                val textColor = if (isSelected) {
                                    MaterialTheme.colorScheme.onPrimary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                }

                                Surface(
                                    modifier = Modifier
                                        .clickable { selectedMonthLedger = month }
                                        .clip(RoundedCornerShape(20.dp)),
                                    color = containerColor,
                                    shape = RoundedCornerShape(20.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(if (monthStatus == "Paid") Color(0xFF4CAF50) else Color(0xFFFF9800))
                                        )
                                        Text(month, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = textColor)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Dynamic Month Ledger details
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.15f))
                                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.08f)), RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Ledger Month: $selectedMonthLedger", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Surface(
                                        color = if (activePayroll.status == "Paid") Color(0xFFE8F5E9) else Color(0xFFFFE0B2),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = activePayroll.status.uppercase(),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (activePayroll.status == "Paid") Color(0xFF2E7D32) else Color(0xFFE65100),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Basic Salary:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("₹${activePayroll.basicSalary}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Bonus Awarded:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("+ ₹${activePayroll.bonus}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF4CAF50))
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Allowances (HRA/Medical/Conveyance):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("+ ₹${activePayroll.allowances}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Deductions & Arrears (PF/Tax):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("- ₹${activePayroll.deductions}", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                                }
                                
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                                
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Net Salary Generated:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("₹${activePayroll.netSalary}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (activePayroll.status == "Paid") Color(0xFF2E7D32) else Color(0xFFD32F2F))
                                }
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Payment details: ${activePayroll.paymentDetails.ifBlank { "Unreleased ledger" }}",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Medium
                                )
                                if (activePayroll.remarks.isNotEmpty()) {
                                    Text(
                                        text = "Remarks: ${activePayroll.remarks}",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        style = androidx.compose.ui.text.TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                                    )
                                }

                                if (activePayroll.status == "Pending") {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFFFFEBEE))
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Filled.Warning, null, tint = Color(0xFFC62828), modifier = Modifier.size(14.dp))
                                        Text("DUE SALARY ALERT: Outstanding unpaid ledger detected for $selectedMonthLedger!", fontSize = 10.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                if (isPrincipal) {
                                Button(
                                    onClick = {
                                        editBasicSalary = activePayroll.basicSalary.toInt().toString()
                                        editBonus = activePayroll.bonus.toInt().toString()
                                        editAllowances = activePayroll.allowances.toInt().toString()
                                        editDeductions = activePayroll.deductions.toInt().toString()
                                        editAbsentDays = "0"
                                        editStatus = activePayroll.status
                                        editRefDetails = activePayroll.paymentDetails.ifBlank { "Direct NEFT Ref #TXN" + (100000..999999).random() }
                                        editRemarks = activePayroll.remarks.ifBlank { "Salary released successfully." }
                                        showSalaryEditDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Filled.EditNote, null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Release / Update Ledger", fontWeight = FontWeight.Bold)
                                }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Release Salary Input sheet Dialog
                if (showSalaryEditDialog) {
                    AlertDialog(
                        onDismissRequest = { showSalaryEditDialog = false },
                        title = {
                            Text(
                                "Manage $selectedMonthLedger Salary Ledger", 
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        },
                        text = {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "Smart attendance metrics & auto deductions are applied in real time as values change.",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )

                                OutlinedTextField(
                                    value = editBasicSalary,
                                    onValueChange = { editBasicSalary = it },
                                    label = { Text("Basic Salary (Base pay)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editBonus,
                                    onValueChange = { editBonus = it },
                                    label = { Text("Performance Bonus (₹)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editAllowances,
                                    onValueChange = { editAllowances = it },
                                    label = { Text("Allowances & HRA (₹)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editDeductions,
                                    onValueChange = { editDeductions = it },
                                    label = { Text("Standard Deductions (PF/Tax) (₹)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                // SMART ATTENDANCE-BASED DEDUCTIONS
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f))
                                        .padding(8.dp)
                                ) {
                                    Text("Smart Attendance deductions", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    OutlinedTextField(
                                        value = editAbsentDays,
                                        onValueChange = { editAbsentDays = it },
                                        label = { Text("Absent Days (Unpaid Leave)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    val basic = editBasicSalary.toDoubleOrNull() ?: 0.0
                                    val absDigits = editAbsentDays.toIntOrNull() ?: 0
                                    val calculatedLoss = (basic / 30.0) * absDigits
                                    if (calculatedLoss > 0) {
                                        Text(
                                            "Auto Deduction: - ₹${String.format("%.2f", calculatedLoss)} (loss of pay)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                }

                                // Status Dropdown
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Payment Status:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Button(
                                        onClick = { editStatus = "Paid" },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (editStatus == "Paid") Color(0xFF4CAF50) else Color.Gray)
                                    ) {
                                        Text("Paid")
                                    }
                                    Button(
                                        onClick = { editStatus = "Pending" },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (editStatus == "Pending") Color(0xFFFF9800) else Color.Gray)
                                    ) {
                                        Text("Pending")
                                    }
                                }

                                OutlinedTextField(
                                    value = editRefDetails,
                                    onValueChange = { editRefDetails = it },
                                    label = { Text("Payment Ref / Channel") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editRemarks,
                                    onValueChange = { editRemarks = it },
                                    label = { Text("Remarks") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                // Dynamic Live Estimation Preview
                                val basicVal = editBasicSalary.toDoubleOrNull() ?: 0.0
                                val bonusVal = editBonus.toDoubleOrNull() ?: 0.0
                                val allVal = editAllowances.toDoubleOrNull() ?: 0.0
                                val dedVal = editDeductions.toDoubleOrNull() ?: 0.0
                                val absDays = editAbsentDays.toIntOrNull() ?: 0
                                val absDeduction = (basicVal / 30.0) * absDays
                                val netVal = basicVal + bonusVal + allVal - dedVal - absDeduction

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("AUTO ESTIMATED NET PAYOUT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("₹${String.format("%.2f", netVal)}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val basicVal = editBasicSalary.toDoubleOrNull() ?: 0.0
                                    val bonusVal = editBonus.toDoubleOrNull() ?: 0.0
                                    val allVal = editAllowances.toDoubleOrNull() ?: 0.0
                                    val dedVal = editDeductions.toDoubleOrNull() ?: 0.0
                                    val absDays = editAbsentDays.toIntOrNull() ?: 0
                                    val absDeduction = (basicVal / 30.0) * absDays
                                    val netVal = basicVal + bonusVal + allVal - dedVal - absDeduction

                                    val finalPayroll = Payroll(
                                        payrollId = "${teacherId}_$selectedMonthLedger",
                                        teacherId = teacherId,
                                        month = selectedMonthLedger,
                                        basicSalary = basicVal,
                                        bonus = bonusVal,
                                        allowances = allVal,
                                        deductions = dedVal + absDeduction,
                                        netSalary = netVal,
                                        status = editStatus,
                                        paymentDetails = editRefDetails,
                                        remarks = editRemarks,
                                        lastUpdated = "2026-05-26"
                                    )
                                    viewModel.addOrUpdatePayroll(finalPayroll)
                                    showSalaryEditDialog = false
                                    Toast.makeText(context, "$selectedMonthLedger salary ledger released", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text("Release Ledger")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showSalaryEditDialog = false }) {
                                Text("Cancel")
                            }
                        }
                    )
                }

                // Printable Receipt Slip Template Dialog
                if (showReceiptSlipDialog) {
                    AlertDialog(
                        onDismissRequest = { showReceiptSlipDialog = false },
                        title = {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Print Salary Receipt Slip", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                IconButton(onClick = { showReceiptSlipDialog = false }) {
                                    Icon(Icons.Filled.Close, "Close slip")
                                }
                            }
                        },
                        text = {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(BorderStroke(2.dp, Color.Black), RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(16.dp)
                                        .verticalScroll(rememberScrollState()),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // Simulated Letterhead
                                    Text("SD ADARSH SENIOR SECONDARY SCHOOL", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                                    Text("Affiliated to CBSE, Session 2026-2027", fontSize = 11.sp, color = Color.Gray)
                                    Text("Main Campus, New Delhi, India", fontSize = 10.sp, color = Color.Gray)
                                    
                                    HorizontalDivider(color = Color.Black, modifier = Modifier.padding(vertical = 8.dp), thickness = 1.dp)
                                    
                                    Text("MONTHLY SALARY DISBURSEMENT RECEIPT SLIP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Employee Metadata Grid
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Employee Name:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text(teacherObj.name, fontSize = 11.sp, color = Color.Black)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Staff ID:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text(teacherObj.teacherId, fontSize = 11.sp, color = Color.Black)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Designation Role:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text(teacherObj.role.ifBlank { "Instructor" }, fontSize = 11.sp, color = Color.Black)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Payment Ledger Month:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text(selectedMonthLedger, fontSize = 11.sp, color = Color.Black)
                                        }
                                    }

                                    HorizontalDivider(color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))

                                    // Ledger Breakdown Sheet Layout
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Basic Monthly Base Salary:", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("₹${activePayroll.basicSalary}", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Performance Bonus released:", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("₹${activePayroll.bonus}", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("HRA & General Allowances:", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("₹${activePayroll.allowances}", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Taxes & PF Deductions (Smart):", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("- ₹${activePayroll.deductions}", fontSize = 11.sp, color = Color.Red, fontWeight = FontWeight.SemiBold)
                                        }
                                        
                                        HorizontalDivider(color = Color.Black, modifier = Modifier.padding(vertical = 6.dp))
                                        
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("CREDITED NET PAYOUT IN-HAND:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text("₹${activePayroll.netSalary}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    // Signature Seal Layout
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.Bottom
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .border(BorderStroke(1.dp, Color.LightGray))
                                                    .padding(4.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("SEAL", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.LightGray)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Authorized Stamp", fontSize = 9.sp, color = Color.Black)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("Principal Accounts Dept", fontSize = 9.sp, color = Color.Black)
                                            HorizontalDivider(color = Color.Black, modifier = Modifier.width(90.dp))
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Signed Signatory Official", fontSize = 8.sp, color = Color.Gray)
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text("N.B: Computer generated slip does not require manual signature.", fontSize = 8.sp, color = Color.Gray, modifier = Modifier.fillMaxWidth())
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    Toast.makeText(context, "Salary Receipt exported successfully to downloads space!", Toast.LENGTH_SHORT).show()
                                    showReceiptSlipDialog = false
                                }
                            ) {
                                Icon(Icons.Filled.Download, null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export receipt")
                            }
                        }
                    )
                }
            }

            // Command management actions card
            if (isPrincipal) {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Administrative Powers", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    
                    val matchingUser = users.find { it.userId == teacherObj.teacherId }
                    val resolvedRole = matchingUser?.role ?: teacherObj.role.ifBlank { "TEACHER" }
                    val isTargetAdmin = resolvedRole.uppercase().trim() == "ADMIN"
                    val isTargetPrincipal = resolvedRole.uppercase().trim() == "PRINCIPAL"

                    if (isTargetAdmin) {
                        // Option for Demote to Teacher
                        Button(
                            onClick = {
                                viewModel.demoteToTeacher(teacherObj.teacherId) { success ->
                                    if (success) {
                                        Toast.makeText(context, "Admin demoted to Teacher successfully!", Toast.LENGTH_LONG).show()
                                        selectedTeacherForProfile = teacherObj.copy(role = "TEACHER", classesAssigned = "", classTeacherOf = "")
                                    } else {
                                        Toast.makeText(context, "Demotion failed!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiary,
                                contentColor = MaterialTheme.colorScheme.onTertiary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("demote_to_teacher_btn")
                        ) {
                            Icon(Icons.Filled.PersonRemove, contentDescription = "Demote", modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Demote to Teacher", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold))
                        }
                    } else if (!isTargetPrincipal) {
                        // Option for Promote to Admin
                        Button(
                            onClick = {
                                viewModel.promoteToAdmin(teacherObj.teacherId) { success ->
                                    if (success) {
                                        Toast.makeText(context, "Teacher promoted to School Admin successfully!", Toast.LENGTH_LONG).show()
                                        selectedTeacherForProfile = teacherObj.copy(role = "ADMIN", classesAssigned = "", classTeacherOf = "")
                                    } else {
                                        Toast.makeText(context, "Promotion failed!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF3B82F6),
                                contentColor = Color(0xFFFFD700)
                            ),
                            border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFFF59E0B)))),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("promote_to_school_admin_btn")
                        ) {
                            Icon(Icons.Filled.Stars, contentDescription = "Crown Emblem", tint = Color(0xFFFFD700), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Promote to Admin", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold))
                        }
                    }

                    // Assign / Change Class Teacher button
                    Button(
                        onClick = {
                            selectedNewClassForChange = teacherObj.classesAssigned
                            showClassChangeDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("promote_or_change_class_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.SwapHoriz, "Class modify icon")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Assign / Change Class Teacher", fontWeight = FontWeight.Bold)
                    }

                    if (teacherObj.classTeacherOf.isNotBlank() || teacherObj.classesAssigned.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                viewModel.removeClassTeacher(teacherObj.teacherId) { success ->
                                    if (success) {
                                        Toast.makeText(context, "Class teacher designation removed.", Toast.LENGTH_SHORT).show()
                                        selectedTeacherForProfile = teacherObj.copy(classTeacherOf = "", classesAssigned = "")
                                    } else {
                                        Toast.makeText(context, "Failed to remove class teacher designation.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("remove_class_teacher_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.RemoveCircleOutline, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Remove Class Teacher Duty", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Password Management Component
                    val userForTeacher = users.find { it.userId == teacherObj.teacherId }
                    val teacherTargetUser = userForTeacher ?: com.example.data.model.User(
                        userId = teacherObj.teacherId,
                        name = teacherObj.name,
                        role = teacherObj.role.ifBlank { "TEACHER" },
                        email = teacherObj.email,
                        phone = teacherObj.phone,
                        dob = teacherObj.joiningDate,
                        passwordStatus = if (teacherObj.joiningDate.isBlank()) "DOB VERIFICATION REQUIRED" else "INITIAL DOB PASSWORD"
                    )

                    com.example.ui.components.PasswordManagementCard(
                        targetUser = teacherTargetUser,
                        currentUserRole = currentUser?.role ?: "",
                        viewModel = viewModel
                    )

                    // Permanent account deletion button
                    Button(
                        onClick = { showDeleteConfirmationDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("delete_teacher_perm_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.DeleteForever, "Remove worker icon")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete Account Permanently", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Sub-dialogs inside detail profile
        if (showClassChangeDialog) {
            val classOptions = listOf(
                "Nursery", "LKG", "UKG", 
                "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
            )
            var expandedClassDropdown by remember { mutableStateOf(false) }

            AlertDialog(
                onDismissRequest = { showClassChangeDialog = false },
                title = { Text("Assign / Promote Class Teacher", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Select assigned class for teacher \"${teacherObj.name}\":")
                        
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { expandedClassDropdown = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(selectedNewClassForChange.ifEmpty { "Select Class" }, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Filled.ArrowDropDown, null)
                            }
                            DropdownMenu(
                                expanded = expandedClassDropdown,
                                onDismissRequest = { expandedClassDropdown = false },
                                modifier = Modifier.fillMaxWidth(0.8f)
                            ) {
                                classOptions.forEach { cl ->
                                    DropdownMenuItem(
                                        text = { Text(cl) },
                                        onClick = {
                                            selectedNewClassForChange = cl
                                            expandedClassDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showClassChangeDialog = false
                            if (selectedNewClassForChange.isNotBlank()) {
                                viewModel.assignClassTeacher(teacherObj.teacherId, selectedNewClassForChange) { success ->
                                    if (success) {
                                        Toast.makeText(context, "Assigned as Class Teacher of $selectedNewClassForChange successfully!", Toast.LENGTH_LONG).show()
                                        selectedTeacherForProfile = teacherObj.copy(classTeacherOf = selectedNewClassForChange, classesAssigned = selectedNewClassForChange)
                                    } else {
                                        showTakeoverTeacherPrompt = true
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Please select a valid class.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Text("Confirm Assignment")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClassChangeDialog = false }) { Text("Cancel") }
                }
            )
        }

        if (showTakeoverTeacherPrompt) {
            val potentialTakeoverTeachers = teachers.filter { it.teacherId != teacherObj.teacherId }
            var expandedTakeoverMenu by remember { mutableStateOf(false) }

            AlertDialog(
                onDismissRequest = { showTakeoverTeacherPrompt = false },
                title = { Text("Class Takeover / Exchange", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Select replacement teacher for previous class \"${teacherObj.classesAssigned}\":",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { expandedTakeoverMenu = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(selectedTakeoverTeacher?.name ?: "Select available teacher", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Filled.ArrowDropDown, null)
                            }
                            DropdownMenu(
                                expanded = expandedTakeoverMenu,
                                onDismissRequest = { expandedTakeoverMenu = false },
                                modifier = Modifier.fillMaxWidth(0.8f)
                            ) {
                                potentialTakeoverTeachers.forEach { takeoverStaff ->
                                    DropdownMenuItem(
                                        text = { Text("${takeoverStaff.name} (Assigned: ${takeoverStaff.classesAssigned})") },
                                        onClick = {
                                            selectedTakeoverTeacher = takeoverStaff
                                            expandedTakeoverMenu = false
                                        }
                                    )
                                }
                            }
                        }
                        
                        Text(
                            text = "Note: Exchanging class assignment will update both teachers.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val takeoverStaff = selectedTakeoverTeacher
                            if (takeoverStaff == null) {
                                Toast.makeText(context, "Please select a replacement teacher!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val oldClass = teacherObj.classesAssigned
                            val newClass = selectedNewClassForChange

                            // Update current teacher classes
                            val currentTeacherUpdated = teacherObj.copy(classesAssigned = newClass, classTeacherOf = newClass)
                            viewModel.addOrUpdateTeacher(currentTeacherUpdated)
                            val curTeacherUser = users.find { it.userId == teacherObj.teacherId }
                            if (curTeacherUser != null) {
                                viewModel.addUser(curTeacherUser.copy(className = newClass))
                            }

                            // Update takeover teacher classes to old classroom
                            val takeoverTeacherUpdated = takeoverStaff.copy(classesAssigned = oldClass, classTeacherOf = oldClass)
                            viewModel.addOrUpdateTeacher(takeoverTeacherUpdated)
                            val takeoverUser = users.find { it.userId == takeoverStaff.teacherId }
                            if (takeoverUser != null) {
                                viewModel.addUser(takeoverUser.copy(className = oldClass))
                            }

                            selectedTeacherForProfile = currentTeacherUpdated
                            showTakeoverTeacherPrompt = false
                            selectedTakeoverTeacher = null
                            Toast.makeText(context, "Class assignment updated successfully!", Toast.LENGTH_LONG).show()
                        }
                    ) {
                        Text("Confirm Exchange")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { 
                        showTakeoverTeacherPrompt = false 
                        selectedTakeoverTeacher = null
                    }) { Text("Cancel") }
                }
            )
        }

        if (showDeleteConfirmationDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirmationDialog = false },
                title = { Text("Delete Account Permanently", fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        text = "Are you sure you want to permanently delete account for ${teacherObj.name}? This action cannot be undone.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val idToDelete = teacherObj.teacherId
                            val currentUserId = viewModel.currentUser.value?.userId ?: ""
                            val currentUserName = viewModel.currentUser.value?.name ?: "Admin"
                            val currentUserRole = viewModel.currentUser.value?.role?.uppercase() ?: ""
                            
                            if (currentUserRole == "PRINCIPAL" || currentUserRole == "HEAD_ADMIN") {
                                viewModel.deleteUserAccount(idToDelete)
                                viewModel.deleteTeacher(idToDelete)
                                selectedTeacherForProfile = null
                                showDeleteConfirmationDialog = false
                                Toast.makeText(context, "Teacher deleted permanently.", Toast.LENGTH_LONG).show()
                            } else if (currentUserRole == "ADMIN" || currentUserRole == "HEAD_ADMIN") {
                                viewModel.requestDeletion(
                                    targetId = idToDelete,
                                    targetType = "TEACHER",
                                    targetName = teacherObj.name,
                                    requesterName = currentUserName,
                                    requesterId = currentUserId
                                )
                                showDeleteConfirmationDialog = false
                                Toast.makeText(context, "Deletion request sent to Principal.", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Yes, Delete Permanently")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmationDialog = false }) { Text("No, Cancel") }
                }
            )
        }
        }

    } else {
        // Teachers block main directory view list
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp)
        ) {

            val tcConfig = LocalConfiguration.current
            val tcWidth = tcConfig.screenWidthDp
            val teacherCols = if (tcWidth >= 950) 3 else if (tcWidth >= 620) 2 else 1

            LazyVerticalGrid(
                columns = GridCells.Fixed(teacherCols),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Teachers Directory", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                                Text("Unique codes assigned to staff", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }

                            if (isPrincipal) {
                                Button(
                                    onClick = {
                                        tId = "T-${java.util.UUID.randomUUID().toString().replace("-", "").take(6).uppercase()}"
                                        tName = ""
                                        tSubject = ""
                                        tClasses = ""
                                        tPhone = ""
                                        tEmail = ""
                                        tDOB = ""
                                        showDialog = true
                                    },
                                    modifier = Modifier.testTag("add_teacher_btn"),
                                    enabled = isPrincipal
                                ) {
                                    Icon(Icons.Filled.Add, "Plus icon")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Staff")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search teachers by name, subject, classes...") },
                            leadingIcon = { Icon(Icons.Filled.Search, "Search Icon") },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("teacher_search")
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                if (filteredTeachers.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        EmptyStateLayout("No Teacher Records", "Add administrative/academic teachers here.")
                    }
                } else {
                    items(filteredTeachers) { teacher ->
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedTeacherForProfile = teacher },
                            colors = glassCardColors()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.secondaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = teacher.name.firstOrNull()?.toString() ?: "T",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(teacher.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    Text(
                                        text = if (teacher.classTeacherOf.isNotEmpty()) "CLASS TEACHER OF ${teacher.classTeacherOf.uppercase()}" else "SUBJECT TEACHER",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (teacher.classTeacherOf.isNotEmpty()) Color(0xFF10B981) else Color(0xFF94A3B8), 
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text("Department: ${teacher.subject}", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium))
                                    Text("Assigned: ${teacher.classesAssigned}", style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.primary))
                                    Text("Code: ${teacher.teacherId} | ${teacher.email}", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var selectedClassVal by remember { mutableStateOf("Class V") }
        var showTClassDropdown by remember { mutableStateOf(false) }

        var primarySubject by remember { mutableStateOf("") }
        var showPrimaryDropdown by remember { mutableStateOf(false) }

        val secondarySubjects = remember { mutableStateMapOf<String, Boolean>() }

        var tGender by remember { mutableStateOf("") }
        var isTGenderExpanded by remember { mutableStateOf(false) }
        var tPhotoUrl by remember { mutableStateOf("") }
        var tQualification by remember { mutableStateOf("B.Ed, Graduate") }
        var tExperience by remember { mutableStateOf("3 Years") }
        var tJoiningDate by remember { mutableStateOf(java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH))) }
        var tRole by remember { mutableStateOf("Teacher") }
        var showTRoleDropdown by remember { mutableStateOf(false) }

        val dynamicSubjects = remember(selectedClassVal) {
            val lists = when (selectedClassVal) {
                "Nursery", "LKG", "UKG" -> listOf("Basic Hindi", "Basic English", "Basic Maths", "Hindi", "English", "Maths")
                "Class I", "Class II", "Class III", "Class IV", "Class V" -> listOf("Hindi", "English", "Maths", "EVS", "Hindi Grammar", "English Grammar", "Sanskrit", "Urdu", "GK", "Computer")
                "Class VI", "Class VII", "Class VIII", "Class IX", "Class X" -> listOf("Hindi", "English", "Maths", "Science", "SST", "Hindi Grammar", "English Grammar", "Sanskrit", "Urdu", "GK", "Computer")
                else -> listOf("Hindi", "English", "Maths", "Science", "SST", "Computer")
            }
            primarySubject = lists.firstOrNull() ?: ""
            secondarySubjects.clear()
            lists.forEach { secondarySubjects[it] = false }
            lists
        }

        val isTNameValid = tName.trim().length >= 3
        val isTPhoneValid = tPhone.length == 10 && tPhone.all { it.isDigit() }
        val isTEmailValid = tEmail.trim().contains("@") && tEmail.trim().contains(".") && tEmail.trim().indexOf("@") < tEmail.trim().lastIndexOf(".")
        val isTPasswordValid = tDOB.trim().matches(Regex("""\d{2}-\d{2}-\d{4}"""))

        val isTeacherFormValid = isTNameValid && isTPhoneValid && isTEmailValid && isTPasswordValid

        var showSwapTeachersSection by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Instructor Registration Office", 
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), 
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "Hire and employ certified professional staff. Assign classrooms, class teacher roles, expert subject domains, and grant security clearances.", 
                                style = MaterialTheme.typography.bodySmall, 
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }

                    // CLASS TEACHER SWAP TRANS-DEMOTIONS SECTION (Expandable Accordion)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showSwapTeachersSection = !showSwapTeachersSection },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.SwapHoriz, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Class Teacher Fast-Swap & Trans-Demotions", 
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.ExtraBold),
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                                Icon(
                                    imageVector = if (showSwapTeachersSection) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                    contentDescription = "Toggle swap panel",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }

                            if (showSwapTeachersSection) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Selecting a teacher and clicking 'Execute' triggers a Firestore Transaction. The previous occupant of that designated class level is instantly stripped of designation and permissions.", 
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                var swapTeacherId by remember { mutableStateOf("") }
                                var swapClassName by remember { mutableStateOf("Class V") }
                                var showSwapTeacherDropdown by remember { mutableStateOf(false) }
                                var showSwapClassDropdown by remember { mutableStateOf(false) }

                                Spacer(modifier = Modifier.height(8.dp))

                                val isWideLayout = LocalConfiguration.current.screenWidthDp >= 600

                                if (isWideLayout) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(modifier = Modifier.weight(1f)) {
                                            val tLabel = teachers.find { it.teacherId == swapTeacherId }?.name ?: "Select Educator"
                                            OutlinedButton(
                                                onClick = { showSwapTeacherDropdown = true },
                                                modifier = Modifier.fillMaxWidth().testTag("assign_teacher_b_trigger")
                                            ) {
                                                Text(tLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            DropdownMenu(
                                                expanded = showSwapTeacherDropdown,
                                                onDismissRequest = { showSwapTeacherDropdown = false }
                                            ) {
                                                teachers.forEach { t ->
                                                    DropdownMenuItem(
                                                        text = { Text(t.name) },
                                                        onClick = {
                                                            swapTeacherId = t.teacherId
                                                            showSwapTeacherDropdown = false
                                                        }
                                                    )
                                                }
                                            }
                                        }

                                        Box(modifier = Modifier.weight(1f)) {
                                            OutlinedButton(
                                                onClick = { showSwapClassDropdown = true },
                                                modifier = Modifier.fillMaxWidth().testTag("assign_class_demote_trigger")
                                            ) {
                                                Text(swapClassName)
                                            }
                                            DropdownMenu(
                                                expanded = showSwapClassDropdown,
                                                onDismissRequest = { showSwapClassDropdown = false }
                                            ) {
                                                SchoolClassesList.forEach { cls ->
                                                    DropdownMenuItem(
                                                        text = { Text(cls) },
                                                        onClick = {
                                                            swapClassName = cls
                                                            showSwapClassDropdown = false
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        val tLabel = teachers.find { it.teacherId == swapTeacherId }?.name ?: "Select Educator"
                                        OutlinedButton(
                                            onClick = { showSwapTeacherDropdown = true },
                                            modifier = Modifier.fillMaxWidth().testTag("assign_teacher_b_trigger")
                                        ) {
                                            Text(tLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        DropdownMenu(
                                            expanded = showSwapTeacherDropdown,
                                            onDismissRequest = { showSwapTeacherDropdown = false }
                                        ) {
                                            teachers.forEach { t ->
                                                DropdownMenuItem(
                                                    text = { Text(t.name) },
                                                    onClick = {
                                                        swapTeacherId = t.teacherId
                                                        showSwapTeacherDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        OutlinedButton(
                                            onClick = { showSwapClassDropdown = true },
                                            modifier = Modifier.fillMaxWidth().testTag("assign_class_demote_trigger")
                                        ) {
                                            Text(swapClassName)
                                        }
                                        DropdownMenu(
                                            expanded = showSwapClassDropdown,
                                            onDismissRequest = { showSwapClassDropdown = false }
                                        ) {
                                            SchoolClassesList.forEach { cls ->
                                                DropdownMenuItem(
                                                    text = { Text(cls) },
                                                    onClick = {
                                                        swapClassName = cls
                                                        showSwapClassDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = {
                                        if (swapTeacherId.isEmpty()) {
                                            Toast.makeText(context, "Please select Teacher B!", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        viewModel.assignClassTeacher(swapTeacherId, swapClassName) { success ->
                                            if (success) {
                                                Toast.makeText(context, "Trans-demoted previous incumbent! Staff updated in Firestore.", Toast.LENGTH_LONG).show()
                                                selectedClassVal = swapClassName
                                            } else {
                                                Toast.makeText(context, "Assignment / demotion completed.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("execute_demotion_transaction_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Icon(Icons.Filled.SwapHoriz, "Swap")
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Execute Transaction Assignment", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Text(
                        text = "Educator Profile Credentials", 
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val isWideScreen = LocalConfiguration.current.screenWidthDp >= 600

                    if (isWideScreen) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = tName,
                                onValueChange = { tName = it.uppercase() },
                                label = { Text("Professional Full Name") },
                                isError = tName.isNotEmpty() && !isTNameValid,
                                leadingIcon = { Icon(Icons.Filled.Person, "Teacher Name") },
                                supportingText = {
                                    if (tName.isNotEmpty() && !isTNameValid) {
                                        Text("नाम कम से कम 3 अक्षरों का होना चाहिए!")
                                    }
                                },
                                modifier = Modifier.weight(1f).testTag("teacher_name_input")
                            )
                        @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
                        androidx.compose.material3.ExposedDropdownMenuBox(
                            expanded = isTGenderExpanded,
                            onExpandedChange = { isTGenderExpanded = it },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = tGender,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Gender") },
                                trailingIcon = { androidx.compose.material3.ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTGenderExpanded) },
                                colors = androidx.compose.material3.ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = isTGenderExpanded,
                                onDismissRequest = { isTGenderExpanded = false }
                            ) {
                                listOf("Male", "Female", "Other").forEach { g ->
                                    androidx.compose.material3.DropdownMenuItem(
                                        text = { Text(g) },
                                        onClick = { 
                                            tGender = g
                                            isTGenderExpanded = false 
                                        }
                                    )
                                }
                            }
                        }


                            OutlinedTextField(
                                value = tPhone,
                                onValueChange = { newValue ->
                                    if (newValue.all { it.isDigit() } && newValue.length <= 10) {
                                        tPhone = newValue
                                    }
                                },
                                label = { Text("Direct Phone (10-digit)") },
                                leadingIcon = { Icon(Icons.Filled.Phone, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                isError = tPhone.isNotEmpty() && !isTPhoneValid,
                                supportingText = {
                                    if (tPhone.isNotEmpty() && !isTPhoneValid) {
                                        Text("फोन नंबर केवल 10 अंकों का होना चाहिए!")
                                    }
                                },
                                modifier = Modifier.weight(1f).testTag("teacher_phone_input")
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(modifier = Modifier.weight(1.2f)) {
                                OutlinedTextField(
                                    value = selectedClassVal,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Appointed Class Level") },
                                    leadingIcon = { Icon(Icons.Filled.Class, null) },
                                    trailingIcon = { 
                                        IconButton(onClick = { showTClassDropdown = !showTClassDropdown }) {
                                            Icon(Icons.Filled.ArrowDropDown, "Open Dropdown")
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showTClassDropdown = true }
                                        .testTag("teacher_class_trigger")
                                )

                                DropdownMenu(
                                    expanded = showTClassDropdown,
                                    onDismissRequest = { showTClassDropdown = false },
                                    modifier = Modifier.testTag("teacher_class_menu")
                                ) {
                                    SchoolClassesList.forEach { opt ->
                                        DropdownMenuItem(
                                            text = { Text(opt) },
                                            onClick = {
                                                selectedClassVal = opt
                                                showTClassDropdown = false
                                            },
                                            modifier = Modifier.testTag("opt_tclass_$opt")
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = tEmail,
                                onValueChange = { tEmail = it },
                                label = { Text("Email Address") },
                                leadingIcon = { Icon(Icons.Filled.Email, null) },
                                isError = tEmail.isNotEmpty() && !isTEmailValid,
                                supportingText = {
                                    if (tEmail.isNotEmpty() && !isTEmailValid) {
                                        Text("कृपया सही ईमेल एड्रेस दर्ज करें!")
                                    }
                                },
                                modifier = Modifier.weight(1f).testTag("teacher_email_input")
                            )
                        }
                    } else {
                        OutlinedTextField(
                            value = tName,
                            onValueChange = { tName = it.uppercase() },
                            label = { Text("Professional Full Name") },
                            isError = tName.isNotEmpty() && !isTNameValid,
                            leadingIcon = { Icon(Icons.Filled.Person, "Teacher Name") },
                            supportingText = {
                                if (tName.isNotEmpty() && !isTNameValid) {
                                    Text("नाम कम से कम 3 अक्षरों का होना चाहिए!")
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("teacher_name_input")
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = selectedClassVal,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Appointed Class Level") },
                                leadingIcon = { Icon(Icons.Filled.Class, null) },
                                trailingIcon = { 
                                    IconButton(onClick = { showTClassDropdown = !showTClassDropdown }) {
                                        Icon(Icons.Filled.ArrowDropDown, "Open Dropdown")
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showTClassDropdown = true }
                                    .testTag("teacher_class_trigger")
                            )

                            DropdownMenu(
                                expanded = showTClassDropdown,
                                    onDismissRequest = { showTClassDropdown = false },
                                modifier = Modifier.testTag("teacher_class_menu")
                            ) {
                                SchoolClassesList.forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(opt) },
                                        onClick = {
                                            selectedClassVal = opt
                                            showTClassDropdown = false
                                        },
                                        modifier = Modifier.testTag("opt_tclass_$opt")
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        OutlinedTextField(
                            value = tEmail,
                            onValueChange = { tEmail = it },
                            label = { Text("Email Address") },
                            isError = tEmail.isNotEmpty() && !isTEmailValid,
                            supportingText = {
                                if (tEmail.isNotEmpty() && !isTEmailValid) {
                                    Text("कृपया सही ईमेल एड्रेस दर्ज करें!")
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("teacher_email_input")
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        OutlinedTextField(
                            value = tPhone,
                            onValueChange = { newValue ->
                                if (newValue.all { it.isDigit() } && newValue.length <= 10) {
                                    tPhone = newValue
                                }
                            },
                            label = { Text("Direct Phone (10-digit)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            isError = tPhone.isNotEmpty() && !isTPhoneValid,
                            supportingText = {
                                if (tPhone.isNotEmpty() && !isTPhoneValid) {
                                    Text("फोन नंबर केवल 10 अंकों का होना चाहिए!")
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("teacher_phone_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "Advanced Staff Credentials",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            
                            // Role Selection
                            Box(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = tRole,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Staff System Role") },
                                    leadingIcon = { Icon(Icons.Filled.Badge, null) },
                                    trailingIcon = { 
                                        IconButton(onClick = { showTRoleDropdown = !showTRoleDropdown }) {
                                            Icon(Icons.Filled.ArrowDropDown, null)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().clickable { showTRoleDropdown = true }
                                )
                                DropdownMenu(
                                    expanded = showTRoleDropdown,
                                    onDismissRequest = { showTRoleDropdown = false }
                                ) {
                                    listOf("Teacher", "Class Teacher", "Admin", "Principal").forEach { r ->
                                        DropdownMenuItem(
                                            text = { Text(r) },
                                            onClick = {
                                                tRole = r
                                                showTRoleDropdown = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Photo URL
                            OutlinedTextField(
                                value = tPhotoUrl,
                                onValueChange = { tPhotoUrl = it },
                                label = { Text("Photo URL (Direct link)") },
                                placeholder = { Text("https://example.com/photo.jpg") },
                                leadingIcon = { Icon(Icons.Filled.Link, null) },
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Qualification
                            OutlinedTextField(
                                value = tQualification,
                                onValueChange = { tQualification = it },
                                label = { Text("Qualifications & Degrees") },
                                leadingIcon = { Icon(Icons.Filled.School, null) },
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Experience & Joining Date
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = tExperience,
                                    onValueChange = { tExperience = it },
                                    label = { Text("Experience") },
                                    leadingIcon = { Icon(Icons.Filled.Work, null) },
                                    modifier = Modifier.weight(1f)
                                )

                                Box(modifier = Modifier.weight(1f)) {
                                    DynamicDatePicker(
                                        selectedDate = tJoiningDate,
                                        onDateSelected = { tJoiningDate = it },
                                        label = "Joining Date"
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // SUBJECT SELECTION MODULES
                    Text("Primary Expert Subject (Single Selection)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                    
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showPrimaryDropdown = !showPrimaryDropdown },
                            modifier = Modifier.fillMaxWidth().testTag("primary_subject_trigger")
                        ) {
                            Text(if (primarySubject.isEmpty()) "Select Primary Subject" else "Primary: $primarySubject", fontWeight = FontWeight.SemiBold)
                        }

                        DropdownMenu(
                            expanded = showPrimaryDropdown,
                            onDismissRequest = { showPrimaryDropdown = false },
                            modifier = Modifier.testTag("primary_subject_menu")
                        ) {
                            dynamicSubjects.forEach { sub ->
                                DropdownMenuItem(
                                    text = { Text(sub) },
                                    onClick = {
                                        primarySubject = sub
                                        showPrimaryDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Text("Secondary Support Subjects (Multi-Select Checkboxes)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.secondary)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            dynamicSubjects.forEach { item ->
                                val isChecked = secondarySubjects[item] ?: false
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { secondarySubjects[item] = !isChecked }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { secondarySubjects[item] = it },
                                        modifier = Modifier.testTag("checkbox_sub_$item")
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(item, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }

                    Box(modifier = Modifier.fillMaxWidth().testTag("teacher_dob_input")) {
                        DynamicDatePicker(
                            selectedDate = tDOB,
                            onDateSelected = { tDOB = it },
                            label = "Date of Birth (DD-MM-YYYY) *",
                            disableFutureDates = true,
                            pattern = "dd-MM-yyyy"
                        )
                    }

                    // STATIC PREVIEW COMPONENT
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Live Educator State Rules",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Assigned Class Level: $selectedClassVal", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("Primary Expert Subject: ${if (primarySubject.isEmpty()) "Not chosen" else primarySubject}", style = MaterialTheme.typography.bodyMedium)
                            val secondaryText = secondarySubjects.filter { it.value }.keys.joinToString(", ")
                            Text("Secondary Support Subjects: ${if (secondaryText.isEmpty()) "None selected" else secondaryText}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }

                    // Action Buttons Layout
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { showDialog = false },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Cancel", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = {
                                if (isTeacherFormValid) {
                                    val finalId = tId.trim().ifBlank { "T-" + System.currentTimeMillis().toString().takeLast(6) }
                                    val extraChecked = secondarySubjects.filter { it.value }.keys.joinToString(", ")

                                    val mappedUserRole = when (tRole) {
                                        "Class Teacher" -> "CLASS_TEACHER"
                                        "Admin" -> "ADMIN"
                                        "Principal" -> "PRINCIPAL"
                                        else -> "TEACHER"
                                    }

                                    val finalClassTeacherOf = if (tRole == "Class Teacher") selectedClassVal else ""

                                    val newTeacher = Teacher(
                                        teacherId = finalId,
                                        name = tName,
                                        subject = "$primarySubject (Primary)",
                                        classesAssigned = selectedClassVal,
                                        phone = tPhone,
                                        email = tEmail,
                                        classTeacherOf = finalClassTeacherOf,
                                        primarySubject = primarySubject,
                                        secondarySubjects = extraChecked,
                                        photoUrl = tPhotoUrl,
                                        qualification = tQualification,
                                        experience = tExperience,
                                        joiningDate = tJoiningDate,
                                        role = tRole
                                    )
                                    viewModel.addOrUpdateTeacher(newTeacher)

                                    val newUser = User(
                                        userId = finalId,
                                        uid = "",
                                        name = tName,
                                        role = mappedUserRole,
                                        roleCode = when (mappedUserRole) {
                                            "PRINCIPAL" -> "PR-01"
                                            "ADMIN" -> "AD-05"
                                            "CLASS_TEACHER" -> "CT-10"
                                            else -> "TC-12"
                                        },
                                        email = tEmail,
                                        passwordHash = viewModel.sha256Hex(tDOB.trim()),
                                        isFirstLogin = true,
                                        className = selectedClassVal
                                    )
                                    viewModel.addUser(newUser)

                                    if (mappedUserRole == "CLASS_TEACHER") {
                                        viewModel.assignClassTeacher(finalId, selectedClassVal)
                                    }

                                    showDialog = false
                                    enrolledTeacherDialogInfo = Triple(tName, finalId, tDOB.trim())
                                    Toast.makeText(context, "Staff successfully boarded!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = isTeacherFormValid,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("dialog_submit_teacher")
                        ) {
                            Icon(Icons.Filled.PersonAddAlt1, "Employ Icon")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Employ Educator", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (enrolledTeacherDialogInfo != null) {
        val (tNameText, tIdText, tempPasswordText) = enrolledTeacherDialogInfo!!
        AlertDialog(
            onDismissRequest = { enrolledTeacherDialogInfo = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LockPerson, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Staff Boarded Successfully!", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("The educator \"$tNameText\" has been registered in the database.", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(12.dp)
                    ) {
                        Column {
                            Text("STAFF SECURITY CREDENTIALS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Unique Login ID: $tIdText", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Password Code: $tempPasswordText", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Please hand over these credentials to the teacher so they can log in to update marks, assign homework, and submit daily attendances.", fontSize = 11.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                Button(onClick = { enrolledTeacherDialogInfo = null }) {
                    Text("OK, Copy Key")
                }
            }
        )
    }
}

// ==========================================
// 5. ATTENDANCE MANAGEMENT
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DynamicDatePicker(
    selectedDate: String,
    onDateSelected: (String) -> Unit,
    isReadOnly: Boolean = false,
    label: String = "Selected Date",
    disableFutureDates: Boolean = false,
    pattern: String = "dd-MM-yyyy"
) {
    var showDialog by remember { mutableStateOf(false) }
    
    val formatter = remember(pattern) { java.time.format.DateTimeFormatter.ofPattern(pattern, java.util.Locale.ENGLISH) }
    
    val initialDateMillis = try {
        java.time.LocalDate.parse(selectedDate, formatter).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
    } catch (e: Exception) {
        try {
            val fallbackFormatter = java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH)
            java.time.LocalDate.parse(selectedDate, fallbackFormatter).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
        } catch (e2: Exception) {
            try {
                java.time.LocalDate.parse(selectedDate).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
            } catch (e3: Exception) {
                System.currentTimeMillis()
            }
        }
    }

    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = initialDateMillis,
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                if (isReadOnly) return true
                if (disableFutureDates) return utcTimeMillis <= System.currentTimeMillis()
                return true
            }
            override fun isSelectableYear(year: Int): Boolean {
                return year in 1900..2100
            }
        }
    )

    val displayDate = try {
        java.time.LocalDate.parse(selectedDate, formatter).format(formatter)
    } catch (e: Exception) {
        try {
            val fallbackFormatter = java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH)
            java.time.LocalDate.parse(selectedDate, fallbackFormatter).format(formatter)
        } catch (e2: Exception) {
            try {
                java.time.LocalDate.parse(selectedDate).format(formatter)
            } catch (e3: Exception) {
                selectedDate.ifBlank { java.time.LocalDate.now().format(formatter) }
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = !isReadOnly) { showDialog = true },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(displayDate, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            if (!isReadOnly) {
                Icon(Icons.Filled.CalendarMonth, contentDescription = "Change Date", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }

    if (showDialog) {
        DatePickerDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        val date = java.time.Instant.ofEpochMilli(millis).atZone(java.time.ZoneOffset.UTC).toLocalDate()
                        onDateSelected(date.format(formatter))
                    }
                    showDialog = false
                }) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
@Composable
fun FeeComponentRow(title: String, amount: Double, icon: ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Medium)
        }
        Text("₹${"%,.0f".format(amount)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FeesManagementScreen(
    viewModel: SchoolViewModel,
    onOpenFeeLedger: (Student) -> Unit = {}
) {
    val feesList by viewModel.feesState.collectAsState()
    val students by viewModel.studentsState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val isStudent = currentUser?.role == "STUDENT"
    val myStudentId = currentUser?.userId ?: "S101"
    val myStudent = students.find { it.studentId == myStudentId }
    
    // We maintain activeStudentState for our double-stage fee navigation flow
    var activeStudentForLedger by remember { mutableStateOf<Student?>(null) }
    
    // Auto-lock STUDENT roles to their personalized profile immediately
    LaunchedEffect(isStudent, myStudent, students) {
        if (isStudent && myStudent != null && activeStudentForLedger == null) {
            activeStudentForLedger = myStudent
        }
    }

    if (activeStudentForLedger != null) {
        // STAGE 2: PREMIUM ERP STUDENT FEE LEDGER PORTAL
        StudentLedgerDetailView(
            viewModel = viewModel,
            student = activeStudentForLedger!!,
            isFromDialog = false,
            onBackClick = {
                if (!isStudent) {
                    activeStudentForLedger = null
                }
            }
        )
    } else {
        // STAGE 1: CLASS SELECTION & STUDENT LIST SCREEN
        var selectedClassFilter by remember { mutableStateOf("All Classes") }
        var searchQuery by remember { mutableStateOf("") }
        val context = LocalContext.current
        
        // Dynamic class extraction from database
        val classes = remember(students) {
            val dynamicClasses = students.map { it.className }.distinct().filter { it.isNotEmpty() }.sorted()
            listOf("All Classes") + dynamicClasses
        }

        var debouncedQuery by remember { mutableStateOf("") }
        LaunchedEffect(searchQuery) {
            kotlinx.coroutines.delay(300L)
            debouncedQuery = searchQuery
        }

        // Search algorithm for instant filtering
        val filteredStudentsByClassAndSearch = remember(students, selectedClassFilter, debouncedQuery) {
            students.filter { student ->
                val matchesClass = selectedClassFilter == "All Classes" || 
                    student.className.equals(selectedClassFilter, ignoreCase = true)
                val matchesSearch = debouncedQuery.isBlank() || 
                    student.name.contains(debouncedQuery, ignoreCase = true) || 
                    student.studentId.contains(debouncedQuery, ignoreCase = true) || 
                    student.admissionNo.contains(debouncedQuery, ignoreCase = true) ||
                    student.rollNo.contains(debouncedQuery, ignoreCase = true) ||
                    student.phone.contains(debouncedQuery, ignoreCase = true) ||
                    student.fatherName.contains(debouncedQuery, ignoreCase = true)
                matchesClass && matchesSearch
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // MODULE BAR: Material 3 Header & synchronization badge
            Surface(
                tonalElevation = 2.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "S.D. Public School - Fees",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Enterprise Finance & Revenue Module",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (currentUser?.role != "STUDENT" && currentUser?.role != "TEACHER" && currentUser?.role != "CLASS_TEACHER") {
                                Row(modifier = Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { Toast.makeText(context, "Exporting Due Students List to Excel...", Toast.LENGTH_SHORT).show() }, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("Export Excel", fontSize = 11.sp) }
                                    Button(onClick = { Toast.makeText(context, "Exporting Monthly Revenue Report to PDF...", Toast.LENGTH_SHORT).show() }, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))) { Text("Export PDF", fontSize = 11.sp) }
                                }
                            }
                        }
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50.dp))
                                .background(Color(0xFFDCFCE7))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ONLINE SYNC",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }
                    }
                }
            }

            // CLASS SELECTOR (Horizontal Row)
            Text(
                text = "Select Academic Class Filter",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(classes) { cl ->
                    val isSelected = selectedClassFilter == cl
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedClassFilter = cl },
                        label = { Text(cl) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            // INSTANT SEARCH BAR
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("student_fees_search"),
                placeholder = { Text("Search by student name or admission ID...") },
                leadingIcon = { Icon(Icons.Filled.Search, "Search Icon") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Clear, "Clear Icon")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                )
            )

            // STUDENT LIST (Vertical LazyColumn)
            Text(
                text = "Registered Scholars Directory (${filteredStudentsByClassAndSearch.size})",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (filteredStudentsByClassAndSearch.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No matching students found.", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                        .testTag("school_fees_student_list"),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredStudentsByClassAndSearch) { student ->
                        val fee = feesList.find { it.studentId == student.studentId }
                        val hasFee = fee != null
                        val dues = fee?.dueAmount ?: 0.0
                        val isPaid = hasFee && dues <= 0.0

                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    activeStudentForLedger = student
                                },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Avatar Photo / Profile Placeholder
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.secondaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val initials = student.name.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString("").uppercase()
                                    Text(
                                        text = initials.ifEmpty { "ST" },
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                // Student info
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = student.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Roll No: ${student.rollNo} | Adm No: ${student.admissionNo}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 4.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (student.className.uppercase().contains("CLASS")) student.className.uppercase() else "CLASS ${student.className.uppercase()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Premium Trailing balance status badge
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isPaid) Color(0xFFD1FAE5) else if (hasFee) Color(0xFFFEE2E2) else Color(0xFFE2E8F0)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = if (isPaid) "Fully Paid" else if (hasFee) "Dues: ₹${"%,.0f".format(dues)}" else "No Record",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (isPaid) Color(0xFF10B981) else if (hasFee) Color(0xFFEF4444) else Color(0xFF475569)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 7. HOMEWORK SYSTEM
// ==========================================
@Composable
fun HomeworkScreen(viewModel: SchoolViewModel) {
    val homework by viewModel.homeworkState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val teachersList by viewModel.teachersState.collectAsState()
    val students by viewModel.studentsState.collectAsState()
    val isAdminOrTeacher = currentUser?.role != "STUDENT"

    val homeworkFiltered = remember(homework, currentUser, students) {
        if (currentUser?.role == "STUDENT") {
            val myStudent = students.find { it.studentId == currentUser?.userId }
            if (myStudent != null) {
                homework.filter { hw ->
                    hw.className.lowercase(Locale.ROOT) == myStudent.className.lowercase(Locale.ROOT)
                }
            } else {
                homework
            }
        } else {
            homework
        }
    }

    var showHomeworkDialog by remember { mutableStateOf(false) }

    var hClass by remember { mutableStateOf("Class X") }
    var hSubject by remember { mutableStateOf("Mathematics") }
    var hDesc by remember { mutableStateOf("") }
    var hDue by remember { mutableStateOf("2026-05-28") }
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    val isUploadingAttachment by viewModel.isUploadingAttachment.collectAsState()

    val context = LocalContext.current

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedFileUri = uri
            var name = "worksheet_${System.currentTimeMillis()}.pdf"
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        name = cursor.getString(nameIndex)
                    }
                }
            } catch (e: Exception) {
                // Fallback to generated name
            }
            selectedFileName = name
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Assigned Tasks & Homework", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Text("Official cloud-synced worksheets & assignments", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }

            if (isAdminOrTeacher) {
                Button(onClick = { 
                    selectedFileUri = null
                    selectedFileName = ""
                    showHomeworkDialog = true 
                }) {
                    Icon(Icons.Filled.NoteAdd, "Add assignments icon")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Assign")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (homeworkFiltered.isEmpty()) {
            EmptyStateLayout("No Homework", "Great job! All classes have completed their assignments.")
        } else {
            val hwConfig = LocalConfiguration.current
            val hwWidth = hwConfig.screenWidthDp
            val hwCols = if (hwWidth >= 950) 3 else if (hwWidth >= 620) 2 else 1

            LazyVerticalGrid(
                columns = GridCells.Fixed(hwCols),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(homeworkFiltered) { hw ->
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = glassCardColors()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFFEF3C7)) // Amber tint
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(hw.className, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                                }
                                Text("Due: ${hw.dueDate}", fontSize = 11.sp, color = Color(0xFFEF4444), fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Subject: ${hw.subject}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(hw.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            
                            if (hw.fileUrl.isNotBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                val isCloudUrl = hw.fileUrl.startsWith("http://") || hw.fileUrl.startsWith("https://")
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(hw.fileUrl)).apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Open Homework Document"))
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Document URL: ${hw.fileUrl}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.PictureAsPdf,
                                            contentDescription = "PDF document",
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isCloudUrl) "Attached Worksheet / PDF" else hw.fileUrl,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = if (isCloudUrl) "Stored on Firebase Storage (Tap to open)" else "Attached file reference",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Filled.OpenInNew,
                                            contentDescription = "Open file",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            if (isAdminOrTeacher) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { viewModel.deleteHomework(hw.homeworkId) }) {
                                        Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Remove", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showHomeworkDialog) {
        var isHClassExpanded by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!isUploadingAttachment) showHomeworkDialog = false },
            title = { Text("Assign Homework Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = hClass,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target Class") },
                            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, "Select Class") },
                            modifier = Modifier.fillMaxWidth().clickable { isHClassExpanded = true }
                        )
                        DropdownMenu(
                            expanded = isHClassExpanded,
                            onDismissRequest = { isHClassExpanded = false }
                        ) {
                            SchoolClassesList.forEach { cl ->
                                DropdownMenuItem(
                                    text = { Text(cl) },
                                    onClick = {
                                        hClass = cl
                                        isHClassExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    OutlinedTextField(value = hSubject, onValueChange = { hSubject = it }, label = { Text("Subject (e.g. Physics)") })
                    DynamicDatePicker(selectedDate = hDue, onDateSelected = { hDue = it }, label = "Due Deadline")
                    OutlinedTextField(value = hDesc, onValueChange = { hDesc = it }, label = { Text("Assignment Details / Exercise Questions") }, maxLines = 4)
                    
                    Text("Attach Document Worksheet (Firebase Storage)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    
                    if (selectedFileUri != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.AttachFile, null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = selectedFileName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = { 
                                        selectedFileUri = null
                                        selectedFileName = ""
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Remove file", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = { filePickerLauncher.launch("*/*") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pick PDF / Worksheet File")
                        }
                    }

                    if (isUploadingAttachment) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Uploading attachment to cloud...", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !isUploadingAttachment,
                    onClick = {
                        if (hDesc.isBlank() || hSubject.isBlank()) {
                            Toast.makeText(context, "Kindly fill description and subject!", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.uploadHomeworkWithFile(
                                className = hClass,
                                subject = hSubject,
                                description = hDesc,
                                dueDate = hDue,
                                fileUri = selectedFileUri,
                                fileName = selectedFileName
                            ) { success, err ->
                                if (success) {
                                    showHomeworkDialog = false
                                    Toast.makeText(context, "Homework assigned and synced to cloud!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Error: ${err ?: "Failed"}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                ) {
                    Text(if (isUploadingAttachment) "Uploading..." else "Assign Task")
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isUploadingAttachment,
                    onClick = { showHomeworkDialog = false }
                ) { 
                    Text("Dismiss") 
                }
            }
        )
    }
}

// ==========================================
// 8. NOTICE / ANNOUNCEMENT SYSTEM
/*
fun NoticesScreen(viewModel: SchoolViewModel) {

    val notices by viewModel.noticesState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val teachersList by viewModel.teachersState.collectAsState()
    val students by viewModel.studentsState.collectAsState()
    val isAdminOrTeacher = currentUser?.role != "STUDENT"

    val noticesFiltered = remember(notices, currentUser, students) {
        if (currentUser?.role == "STUDENT") {
            val myStudent = students.find { it.studentId == currentUser?.userId }
            if (myStudent != null) {
                notices.filter { notice ->
                    notice.targetClass.lowercase(Locale.ROOT) == "all" ||
                    notice.targetClass.isBlank() ||
                    notice.targetClass.lowercase(Locale.ROOT) == myStudent.className.lowercase(Locale.ROOT)
                }
            } else {
                notices
            }
        } else {
            notices
        }
    }

    var showNoticeDialog by remember { mutableStateOf(false) }
    var selectedNoticeForDetail by remember { mutableStateOf<Notice?>(null) }

    var nTitle by remember { mutableStateOf("") }
    var nMessage by remember { mutableStateOf("") }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Notices & Alerts", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Text("Broadcast direct announcements immediately", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }

            if (isAdminOrTeacher) {
                Button(
                    onClick = { showNoticeDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Icon(Icons.Filled.Campaign, null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Broadcast")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (noticesFiltered.isEmpty()) {
            EmptyStateLayout("No announcements", "Institutional noticeboard is idle.")
        } else {
            val noticeConfig = LocalConfiguration.current
            val noticeWidth = noticeConfig.screenWidthDp
            val noticeCols = if (noticeWidth >= 950) 3 else if (noticeWidth >= 620) 2 else 1

            LazyVerticalGrid(
                columns = GridCells.Fixed(noticeCols),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(noticesFiltered) { notice ->
                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedNoticeForDetail = notice },
                        colors = glassCardColors()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = notice.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFFEF4444)),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(notice.date, fontSize = 11.sp, color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = notice.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Click to tap and read full details...",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            
                            if (isAdminOrTeacher) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { 
                                        viewModel.deleteNotice(notice.noticeId)
                                    }) {
                                        Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Remove notice", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNoticeDialog) {
        var nTargetClass by remember { mutableStateOf("All") }
        var nTargetClassExpanded by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showNoticeDialog = false },
            title = { Text("Publish Institutional Broadcast") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nTitle,
                        onValueChange = { nTitle = it },
                        label = { Text("Urgent title headline") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = nMessage,
                        onValueChange = { nMessage = it },
                        label = { Text("Broadcast message details") },
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Target Audience Class Filter", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = nTargetClass,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Class standard") },
                            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, "Dropdown") },
                            modifier = Modifier.fillMaxWidth().clickable { nTargetClassExpanded = true }
                        )
                        DropdownMenu(
                            expanded = nTargetClassExpanded,
                            onDismissRequest = { nTargetClassExpanded = false }
                        ) {
                            (listOf("All") + SchoolClassesList).forEach { cl ->
                                DropdownMenuItem(
                                    text = { Text(cl) },
                                    onClick = {
                                        nTargetClass = cl
                                        nTargetClassExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nTitle.isBlank() || nMessage.isBlank()) {
                            Toast.makeText(context, "Kindly write both Title & Message!", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.addNotice(
                                Notice(
                                    noticeId = "N_${(504..999).random()}",
                                    title = nTitle,
                                    message = nMessage,
                                    date = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH)),
                                    targetClass = nTargetClass
                                )
                            )
                            showNoticeDialog = false
                            Toast.makeText(context, if (nTargetClass == "All") "Digital push notice blasted to all students!" else "Digital push notice blasted to $nTargetClass!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Blast Notice")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNoticeDialog = false }) { Text("Close") }
            }
        )
    }

    if (selectedNoticeForDetail != null) {
        val notice = selectedNoticeForDetail!!
        AlertDialog(
            onDismissRequest = { selectedNoticeForDetail = null },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Campaign,
                        contentDescription = null,
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Notice Broadcast",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = notice.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("S. D Public School Office", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color.Gray)
                        Text(notice.date, fontSize = 11.sp, color = Color.Gray)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = notice.message,
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedNoticeForDetail = null }
                ) {
                    Text("Understood, Close")
                }
            }
        )
    }
}

*/

// ==========================================
// 9. TIMETABLE MODULE
// ==========================================
@Composable
fun TimetableScreen(viewModel: SchoolViewModel) {
    val timetables by viewModel.timetablesState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isAdmin = currentUser?.role in listOf("ADMIN", "HEAD_ADMIN", "PRINCIPAL")
    val isPrincipal = currentUser?.role?.uppercase()?.trim() == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    var selectedClassTab by remember { mutableStateOf("Class X") }

    var isEditState by remember { mutableStateOf(false) }
    var currentPeriodsString by remember { mutableStateOf("") }
    var conflictData by remember { mutableStateOf<com.example.data.util.TimetableConflictResult.Conflict?>(null) }
    var overrideReason by remember { mutableStateOf("") }
    val currentTable = timetables.find { it.className == selectedClassTab }

    LaunchedEffect(selectedClassTab, timetables) {
        currentPeriodsString = currentTable?.scheduleData ?: "Mon: Math (9:00), CS (10:00) | Tue: Phy (9:00), Art (10:00)"
    }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Academic timetable, select class:", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(10.dp))

        // Class Selection Filter
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SchoolClassesList.forEach { cl ->
                val active = selectedClassTab == cl
                Button(
                    onClick = { selectedClassTab = cl },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    )
                ) {
                    Text(cl, color = if (active) Color.White else MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = glassCardColors()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Current schedule - $selectedClassTab",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    if (isAdmin) IconButton(onClick = { isEditState = !isEditState }) {
                        Icon(
                            imageVector = if (isEditState) Icons.Filled.Save else Icons.Filled.EditNote,
                            contentDescription = "Edit schedules",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isEditState) {
                    OutlinedTextField(
                        value = currentPeriodsString,
                        onValueChange = { currentPeriodsString = it },
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        label = { Text("Edit class periods timeline") },
                        maxLines = 6
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            viewModel.saveTimetable(
                                timetable = Timetable(
                                    timetableId = currentTable?.timetableId ?: "TT_${(600..999).random()}",
                                    className = selectedClassTab,
                                    scheduleData = currentPeriodsString.trim()
                                ),
                                onConflict = { conflict ->
                                    conflictData = conflict
                                },
                                onSuccess = {
                                    isEditState = false
                                }
                            )
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Confirm Changes")
                    }
                } else {
                    // Prettier visual period parser
                    val dailyPeriods = currentPeriodsString.split("|")
                    if (dailyPeriods.isEmpty()) {
                        Text("No period slots registered for $selectedClassTab.")
                    } else {
                        dailyPeriods.forEach { daySlot ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.background)
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.primary)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = daySlot.split(":").firstOrNull()?.trim() ?: "Day",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = daySlot.split(":").getOrNull(1)?.trim() ?: daySlot,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Conflict Dialog
    conflictData?.let { conflict ->
        AlertDialog(
            onDismissRequest = { conflictData = null },
            title = { Text("Timetable Conflict Detected", color = MaterialTheme.colorScheme.error) },
            text = {
                Column {
                    Text(conflict.message)
                    if (isPrincipal) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("As Principal, you may override this conflict. Please provide a reason:", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = overrideReason,
                            onValueChange = { overrideReason = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Override Reason") }
                        )
                    }
                }
            },
            confirmButton = {
                if (isPrincipal) {
                    Button(
                        onClick = {
                            viewModel.saveTimetable(
                                timetable = Timetable(
                                    timetableId = currentTable?.timetableId ?: "TT_${(600..999).random()}",
                                    className = selectedClassTab,
                                    scheduleData = currentPeriodsString.trim()
                                ),
                                allowOverride = true,
                                overrideReason = overrideReason,
                                onSuccess = {
                                    isEditState = false
                                    conflictData = null
                                    overrideReason = ""
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Force Override")
                    }
                } else {
                    Button(onClick = { conflictData = null }) {
                        Text("OK")
                    }
                }
            },
            dismissButton = {
                if (isPrincipal) {
                    TextButton(onClick = { conflictData = null }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}

// ==========================================
// 10. REAL-TIME CHAT & REPORTS (MODULARIZED)
// ==========================================

// ==========================================
// 12. SCHOOL CALENDAR EVENTS & HOLIDAYS
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolCalendarScreen(viewModel: SchoolViewModel) {
    val events by viewModel.calendarEvents.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val role = currentUser?.role?.uppercase()?.trim() ?: ""
    val isManagement = role == "PRINCIPAL" || role == "ADMIN" || role == "HEAD_ADMIN"

    // Calendar state
    val todayCalendar = remember { Calendar.getInstance() }
    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(todayCalendar.time) }

    var displayedMonth by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedDate by rememberSaveable { mutableStateOf(todayDateStr) }
    var selectedCategoryFilter by rememberSaveable { mutableStateOf("All") }
    var showOnlySelectedDateEvents by rememberSaveable { mutableStateOf(false) }

    // Dialog state for Add/Edit event
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingEvent by remember { mutableStateOf<CalendarEvent?>(null) }

    // Delete confirmation dialog state
    var eventToDelete by remember { mutableStateOf<CalendarEvent?>(null) }

    // Helper formatting
    val monthYearFormat = remember { SimpleDateFormat("MMMM yyyy", Locale.ENGLISH) }
    val dayMonthYearFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH) }
    val currentMonthStr = remember(displayedMonth) { SimpleDateFormat("yyyy-MM", Locale.ENGLISH).format(displayedMonth.time) }

    // Events filtered for current month or selected date
    val monthEvents = remember(events, currentMonthStr) {
        events.filter { it.date.startsWith(currentMonthStr) }
    }

    val filteredEvents = remember(events, selectedDate, selectedCategoryFilter, showOnlySelectedDateEvents, currentMonthStr) {
        events.filter { ev ->
            val dateMatches = if (showOnlySelectedDateEvents) ev.date == selectedDate else ev.date.startsWith(currentMonthStr)
            val categoryMatches = if (selectedCategoryFilter == "All") true else ev.type.equals(selectedCategoryFilter, ignoreCase = true)
            dateMatches && categoryMatches
        }.sortedWith(compareBy({ it.date }, { it.time }))
    }

    Scaffold(
        topBar = {},
        floatingActionButton = {
            if (isManagement) {
                FloatingActionButton(
                    onClick = {
                        editingEvent = null
                        showAddEditDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_calendar_event_fab")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Add Calendar Event")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            item {
            // Header Title Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "School Calendar & Agenda",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Holidays, exams, deadlines & academic schedules",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (isManagement) {
                    Button(
                        onClick = {
                            editingEvent = null
                            showAddEditDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Event", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Month Navigation Card
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = glassCardColors()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Month & Year Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            displayedMonth = (displayedMonth.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Month")
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = monthYearFormat.format(displayedMonth.time),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            AssistChip(
                                onClick = {
                                    displayedMonth = Calendar.getInstance()
                                    selectedDate = todayDateStr
                                },
                                label = { Text("Today", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                leadingIcon = { Icon(Icons.Filled.Today, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }

                        IconButton(onClick = {
                            displayedMonth = (displayedMonth.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Month")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Calendar Day Header (Sun..Sat)
                    val dayNames = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        dayNames.forEach { dayName ->
                            Text(
                                text = dayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Calendar Month Days Grid
                    val daysInMonth = displayedMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
                    val firstDayOfWeek = (displayedMonth.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }.get(Calendar.DAY_OF_WEEK) // 1 = Sunday

                    var dayCounter = 1
                    for (row in 0..5) {
                        if (dayCounter > daysInMonth) break
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            for (col in 0..6) {
                                if ((row == 0 && col < firstDayOfWeek - 1) || dayCounter > daysInMonth) {
                                    Box(modifier = Modifier.weight(1f).aspectRatio(1.1f))
                                } else {
                                    val currentDay = dayCounter
                                    val cellDateCal = (displayedMonth.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, currentDay) }
                                    val cellDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(cellDateCal.time)
                                    val isSelected = cellDateStr == selectedDate
                                    val isToday = cellDateStr == todayDateStr
                                    
                                    val eventsOnDate = monthEvents.filter { it.date == cellDateStr }
                                    val hasEvent = eventsOnDate.isNotEmpty()
                                    val hasHoliday = eventsOnDate.any { it.type.equals("Holiday", ignoreCase = true) }
                                    val hasExam = eventsOnDate.any { it.type.equals("Exam", ignoreCase = true) }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1.1f)
                                            .padding(2.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                when {
                                                    isSelected -> MaterialTheme.colorScheme.primary
                                                    isToday -> MaterialTheme.colorScheme.primaryContainer
                                                    else -> Color.Transparent
                                                }
                                            )
                                            .border(
                                                width = if (isToday && !isSelected) 1.5.dp else 0.dp,
                                                color = if (isToday && !isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                selectedDate = cellDateStr
                                                showOnlySelectedDateEvents = true
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = currentDay.toString(),
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected || isToday) FontWeight.ExtraBold else FontWeight.Normal,
                                                color = when {
                                                    isSelected -> MaterialTheme.colorScheme.onPrimary
                                                    isToday -> MaterialTheme.colorScheme.onPrimaryContainer
                                                    else -> MaterialTheme.colorScheme.onSurface
                                                }
                                            )
                                            if (hasEvent) {
                                                Row(
                                                    horizontalArrangement = Arrangement.Center,
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(top = 2.dp)
                                                ) {
                                                    val dotColor = when {
                                                        hasHoliday -> Color(0xFFEF4444)
                                                        hasExam -> Color(0xFFF59E0B)
                                                        else -> Color(0xFF10B981)
                                                    }
                                                    Box(
                                                        modifier = Modifier
                                                            .size(5.dp)
                                                            .clip(CircleShape)
                                                            .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else dotColor)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    dayCounter++
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category Filter Row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val categories = listOf("All", "Holiday", "Exam", "School Event", "Fee Deadline", "Meeting", "Activity")
                items(categories) { category ->
                    FilterChip(
                        selected = selectedCategoryFilter == category,
                        onClick = { selectedCategoryFilter = category },
                        label = { Text(category, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Events List Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val headerText = if (showOnlySelectedDateEvents) {
                    try {
                        val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).parse(selectedDate)
                        if (parsed != null) "Events on ${dayMonthYearFormat.format(parsed)}" else "Events on $selectedDate"
                    } catch (e: Exception) {
                        "Events on $selectedDate"
                    }
                } else {
                    "All Agenda for ${monthYearFormat.format(displayedMonth.time)}"
                }

                Text(
                    text = headerText,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (showOnlySelectedDateEvents) {
                    TextButton(onClick = { showOnlySelectedDateEvents = false }) {
                        Text("Show Full Month", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            } // end header item

            // Events List
            if (filteredEvents.isEmpty()) {
                item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.EventAvailable,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (showOnlySelectedDateEvents) "No events scheduled for $selectedDate" else "No events found for this filter in ${monthYearFormat.format(displayedMonth.time)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        if (isManagement) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = {
                                    editingEvent = null
                                    showAddEditDialog = true
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Event for Date")
                            }
                        }
                    }
                }
                } // end empty-state item
            } else {
                items(filteredEvents, key = { it.id }) { ev ->
                        val categoryColor = when (ev.type.lowercase()) {
                            "holiday" -> Color(0xFFEF4444)
                            "exam" -> Color(0xFFF59E0B)
                            "school event" -> Color(0xFF10B981)
                            "fee deadline" -> Color(0xFF8B5CF6)
                            "meeting" -> Color(0xFF3B82F6)
                            "activity" -> Color(0xFFEC4899)
                            else -> MaterialTheme.colorScheme.primary
                        }

                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = glassCardColors()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(categoryColor.copy(alpha = 0.15f))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = ev.type,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = categoryColor
                                            )
                                        }
                                        if (ev.time.isNotBlank()) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = ev.time,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = ev.date,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        if (isManagement) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            IconButton(
                                                onClick = {
                                                    editingEvent = ev
                                                    showAddEditDialog = true
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Filled.Edit, contentDescription = "Edit Event", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                            }
                                            IconButton(
                                                onClick = { eventToDelete = ev },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Filled.Delete, contentDescription = "Delete Event", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = ev.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                if (ev.description.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = ev.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Audience: ${ev.targetClass}",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (ev.createdBy.isNotBlank()) {
                                        Text(
                                            text = "By: ${ev.createdBy}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
            }
        }
    }

    // Add/Edit Event Dialog
    if (showAddEditDialog) {
        var titleInput by remember { mutableStateOf(editingEvent?.title ?: "") }
        var descInput by remember { mutableStateOf(editingEvent?.description ?: "") }
        var dateInput by remember { mutableStateOf(editingEvent?.date ?: selectedDate) }
        var timeInput by remember { mutableStateOf(editingEvent?.time ?: "All Day") }
        var typeInput by remember { mutableStateOf(editingEvent?.type ?: "School Event") }
        var targetClassInput by remember { mutableStateOf(editingEvent?.targetClass ?: "All") }

        val typeOptions = listOf("School Event", "Holiday", "Exam", "Fee Deadline", "Meeting", "Activity", "Other")

        AlertDialog(
            onDismissRequest = { showAddEditDialog = false },
            title = {
                Text(if (editingEvent == null) "Create Calendar Event" else "Edit Calendar Event")
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Event Title *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dateInput,
                            onValueChange = { dateInput = it },
                            label = { Text("Date (yyyy-MM-dd)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = timeInput,
                            onValueChange = { timeInput = it },
                            label = { Text("Time (e.g. 09:00 AM)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Text("Category:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(typeOptions) { option ->
                            FilterChip(
                                selected = typeInput.equals(option, ignoreCase = true),
                                onClick = { typeInput = option },
                                label = { Text(option, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = targetClassInput,
                        onValueChange = { targetClassInput = it },
                        label = { Text("Target Class (e.g. All, Class 10)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val eventToSave = CalendarEvent(
                            id = editingEvent?.id ?: "",
                            date = dateInput.trim(),
                            title = titleInput.trim(),
                            description = descInput.trim(),
                            type = typeInput.trim(),
                            time = timeInput.trim(),
                            targetClass = targetClassInput.trim().ifEmpty { "All" },
                            createdBy = editingEvent?.createdBy ?: (currentUser?.name ?: "Management"),
                            createdAt = editingEvent?.createdAt ?: System.currentTimeMillis()
                        )
                        viewModel.saveCalendarEvent(eventToSave)
                        showAddEditDialog = false
                    },
                    enabled = titleInput.isNotBlank() && dateInput.isNotBlank()
                ) {
                    Text("Save Event")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEditDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (eventToDelete != null) {
        AlertDialog(
            onDismissRequest = { eventToDelete = null },
            title = { Text("Delete Event") },
            text = { Text("Are you sure you want to delete '${eventToDelete?.title}'? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        eventToDelete?.let { viewModel.deleteCalendarEvent(it.id) }
                        eventToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { eventToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// EXTRA FEATURE COMPONENT PLATES
// ==========================================

// A. HIGH-FIDELITY STUDENT ID CARD GENERATOR LAYOUT
@Composable
fun CardDetailItem(label: String, value: String) {
    Column {
        Text(label.uppercase(Locale.getDefault()), fontSize = 8.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
        Text(value, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

// EMPTY VISUAL CHANNELS PLATFORM PLATES
@Composable
fun EmptyStateLayout(
    title: String, 
    msg: String,
    icon: ImageVector = Icons.Filled.Inbox,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = Space16, horizontal = Space8),
        shape = RoundedCornerShape(CornerLargeRadius),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        tonalElevation = ElevationLevel1
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(Space24),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.height(Space12))
            Text(
                text = title, 
                fontWeight = FontWeight.Bold, 
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(Space4))
            Text(
                text = msg, 
                style = MaterialTheme.typography.bodySmall, 
                color = MaterialTheme.colorScheme.onSurfaceVariant, 
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onActionClick != null) {
                Spacer(modifier = Modifier.height(Space16))
                FilledTonalButton(
                    onClick = onActionClick,
                    shape = RoundedCornerShape(CornerMediumRadius)
                ) {
                    Text(actionLabel, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

// ==========================================
// 12. ACADEMIC CLASSES SYSTEM (ADVANCED)
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AcademicClassesScreen(
    viewModel: SchoolViewModel,
    onNavigate: (AppScreen) -> Unit,
    onOpenFeeLedger: (Student) -> Unit = {}
) {
    val students by viewModel.studentsState.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val teacherClass = getTeacherAssignedClass(viewModel)
    val teacherSection = getTeacherAssignedSection(viewModel)
    val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""
    val isTeacher = roleStr == "TEACHER" || roleStr == "CLASS_TEACHER"
    val isHeadAdmin = roleStr == "HEAD_ADMIN"
    val isAdmin = roleStr == "ADMIN" || isHeadAdmin
    val isPrincipal = roleStr == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    val isManagement = roleStr == "ADMIN" || roleStr == "HEAD_ADMIN" || roleStr == "PRINCIPAL"

    val selectedClassDetail by viewModel.selectedClassDetail.collectAsState()
    var selectedStudentDialog by remember { mutableStateOf<Student?>(null) }
    var selectedStudentForIDCard by remember { mutableStateOf<Student?>(null) }

    val context = LocalContext.current
    val currentClassDetail = selectedClassDetail

    if (currentClassDetail == null) {
        // LIST OF ALL CLASSES
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Text(
                    text = "Institutional Class standards",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Directory and registry of classes from Nursery to 10th grade",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            SchoolClassesList.forEach { className ->
                val enrolledInClass = students.filter { it.className.lowercase(Locale.ROOT) == className.lowercase(Locale.ROOT) }
                val enrolledCount = enrolledInClass.size
                val classTeacher = teachers.find { it.classesAssigned.contains(className, ignoreCase = true) }?.name ?: "Vacant / Not Assigned"
                
                val isMyAssignedClass = isTeacher && teacherClass.lowercase(Locale.ROOT) == className.lowercase(Locale.ROOT)
                val isClickable = !isTeacher || isMyAssignedClass

                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("class_card_${className.replace(" ", "_").lowercase(Locale.ROOT)}")
                        .alpha(if (isMyAssignedClass || !isTeacher) 1f else 0.55f)
                        .clickable {
                            if (isClickable) {
                                viewModel.setSelectedClassDetail(className)
                            } else {
                                Toast.makeText(context, "Access restricted to your teaching assignment: $teacherClass", Toast.LENGTH_LONG).show()
                            }
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = if (isMyAssignedClass) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isMyAssignedClass) Icons.Filled.Star else Icons.Filled.MeetingRoom,
                                    contentDescription = null,
                                    tint = if (isMyAssignedClass) Color(0xFFF59E0B) else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = className,
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            if (isMyAssignedClass) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFFEF3C7))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "CLASS TEACHER",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFF59E0B)
                                    )
                                }
                            } else if (isTeacher) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = "Locked Class icon",
                                    tint = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Class Teacher:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(classTeacher, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Enrolled strength:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("$enrolledCount Students", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            }
    } else {
        // SPECIFIC CLASS DETAIL DIRECTORY
        val currentClass = currentClassDetail
        
        val enrolledStudents = students.filter { it.className.equals(currentClass, true) }
        val enrolledCount = enrolledStudents.size

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isManagement) {
                    IconButton(onClick = { viewModel.setSelectedClassDetail(null) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Go back to classes")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Column {
                    Text(
                        text = currentClass,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
                    )
                    Text(
                        text = "Strength: $enrolledCount Students",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }

            // Options Bar (Admit Student & Track Attendance)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { 
                        viewModel.setStudentPrefill(currentClass)
                        onNavigate(AppScreen.ADD_STUDENT) 
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Admit Student", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        viewModel.setAttendanceFilters(currentClass, "2026-05-22")
                        onNavigate(AppScreen.ATTENDANCE)
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Icon(Icons.Filled.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Track Attendance", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (enrolledStudents.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    EmptyStateLayout(
                        title = "No Students Enrolled",
                        msg = "Admit a new scholar to get started in $currentClass."
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(enrolledStudents) { student ->
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStudentDialog = student },
                            shape = RoundedCornerShape(10.dp),
                            colors = glassCardColors()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                               ) {
                                    Text(
                                        text = student.name.take(2).uppercase(Locale.ROOT),
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                               }

                               Spacer(modifier = Modifier.width(12.dp))

                               Column(modifier = Modifier.weight(1f)) {
                                   Text(student.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                   Text("Roll No: ${student.rollNo}    |    Adm No: ${student.admissionNo}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                   Text("Father's Name: ${student.fatherName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                               }
                               
                               IconButton(onClick = { selectedStudentForIDCard = student }) {
                                   Icon(Icons.Filled.Badge, "Student ID Badge", tint = MaterialTheme.colorScheme.secondary)
                               }
                               IconButton(onClick = { onOpenFeeLedger(student) }) {
                                   Icon(Icons.Filled.Receipt, "Pupils Fee Ledger Registry", tint = Color(0xFF10B981))
                               }
                            }
                        }
                    }
                }
            }
        }



        if (selectedStudentForIDCard != null) {
            val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""
            StudentIDCardLayout(
                student = selectedStudentForIDCard!!,
                onDismiss = { selectedStudentForIDCard = null },
                showUserId = (roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN")
            )
        }

        if (selectedStudentDialog != null) {
            val currentStudent = selectedStudentDialog!!
            val studentFee = viewModel.feesState.collectAsState().value.find { it.studentId == currentStudent.studentId }
            val studentAttendance = viewModel.attendanceState.collectAsState().value.filter { it.studentId == currentStudent.studentId }
            Dialog(
                onDismissRequest = { selectedStudentDialog = null },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .heightIn(max = (LocalConfiguration.current.screenHeightDp * 0.9).dp)
                ) {
                    StudentDetailDialogLayout(
                        student = currentStudent,
                        fee = studentFee,
                        attendance = studentAttendance,
                        onDismiss = { selectedStudentDialog = null },
                        canEdit = isManagement || (isTeacher && currentStudent.className.equals(teacherClass, ignoreCase = true)),
                        onSave = { updated -> viewModel.updateStudent(updated); selectedStudentDialog = updated },
                        onOpenFeeLedger = {
                            onOpenFeeLedger(currentStudent)
                            selectedStudentDialog = null
                        }
                    )
                }
            }
        }


    }
}

@Composable
fun FirstLoginPasswordChangeDialog(
    viewModel: SchoolViewModel,
    userId: String,
    onSuccessChanged: () -> Unit
) {
    var oldPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = { /* Force change - cannot dismiss */ },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Setup New Secure Password", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Welcome to S. D Public School Portal! Crucially, because you are logging in with a temporary workspace credential, you MUST setup a custom password now to protect your privacy.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Your password is encrypted locally using industrial SHA-256 standard and hidden from all school authorities, teachers, and admins.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("New Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth().testTag("new_password_input")
                )
                
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("Confirm New Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth().testTag("confirm_password_input")
                )

                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.isBlank()) {
                        errorMessage = "Password cannot be empty!"
                    } else if (newPassword != confirmPassword) {
                        errorMessage = "Passwords do not match!"
                    } else if (newPassword.length < 6) {
                        errorMessage = "Password must be at least 6 characters long!"
                    } else {
                        isSubmitting = true
                        errorMessage = null
                        viewModel.changePassword(
                            userId = userId,
                            oldPassword = oldPassword,
                            newPassword = newPassword,
                            onSuccess = {
                                isSubmitting = false
                                Toast.makeText(context, "Password configured and encrypted securely!", Toast.LENGTH_LONG).show()
                                onSuccessChanged()
                            },
                            onFailure = { err ->
                                isSubmitting = false
                                errorMessage = err
                            }
                        )
                    }
                },
                modifier = Modifier.testTag("apply_password_change_button"),
                enabled = !isSubmitting
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text("Apply & Sign In")
                }
            }
        }
    )
}

@Composable
fun PupilsFeeLedgerSheet(
    viewModel: SchoolViewModel,
    student: Student,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .clip(RoundedCornerShape(16.dp)),
            color = MaterialTheme.colorScheme.background
        ) {
            StudentLedgerDetailView(
                viewModel = viewModel,
                student = student,
                isFromDialog = true,
                onBackClick = onDismiss
            )
        }
    }
}

@Composable
fun StudentLedgerDetailView(
    viewModel: SchoolViewModel,
    student: Student,
    isFromDialog: Boolean = false,
    onBackClick: () -> Unit
) {
    var selectedMonths by remember { mutableStateOf(emptySet<String>()) }
    val context = LocalContext.current
    val academicMonths = listOf("April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March")
    
    // Monthly ledger entries state collected reactive flow
    val dbEntries by viewModel.getFeeLedgerForStudentFlow(student.studentId).collectAsState(initial = emptyList())
    val currentUser by viewModel.currentUser.collectAsState()
    val isStudent = currentUser?.role == "STUDENT"
    val isReadOnly = isStudent || currentUser?.role == "TEACHER" || currentUser?.role == "CLASS_TEACHER"
    val isPrincipal = currentUser?.role?.uppercase()?.trim() == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    
    val feeConfig by viewModel.feeConfig.collectAsState()
    val feeRates by viewModel.feeRates.collectAsState()
    val feeEventCharges by viewModel.feeEventCharges.collectAsState()

    fun transportFeeTypeFor(slab: String): String = when (slab) {
        "0-5 km" -> "TRANSPORT_0_5"
        "5-10 km" -> "TRANSPORT_5_10"
        "10-15 km" -> "TRANSPORT_10_15"
        else -> ""
    }

    fun transportFallbackFor(slab: String): Double = when (slab) {
        "0-5 km" -> feeConfig.transportSlab1
        "5-10 km" -> feeConfig.transportSlab2
        "10-15 km" -> feeConfig.transportSlab3
        else -> 0.0
    }

    // Builds a not-yet-persisted (virtual) entry for a month with no saved record yet,
    // using whichever rate was effective for THAT month — falls back to the old flat
    // FeeConfig only if the Principal hasn't set a rate in the new module for it yet.
    fun buildVirtualEntry(m: String): FeeLedgerEntry {
        val tuition = findEffectiveFeeRate(feeRates, student.className, "TUITION", m).let { if (it > 0) it else feeConfig.tuitionFee }
        val admission = if (m == "April") findEffectiveFeeRate(feeRates, "ALL", "ADMISSION", m).let { if (it > 0) it else feeConfig.admissionFee } else 0.0
        val game = findEffectiveFeeRate(feeRates, "ALL", "GAME", m).let { if (it > 0) it else feeConfig.gameFee }
        val exam = if (m == "September" || m == "March") findEffectiveFeeRate(feeRates, "ALL", "EXAM", m).let { if (it > 0) it else feeConfig.examFee } else 0.0
        val transport = if (student.hasTransport) {
            val tType = transportFeeTypeFor(student.transportSlab)
            findEffectiveFeeRate(feeRates, "ALL", tType, m).let { if (it > 0) it else transportFallbackFor(student.transportSlab) }
        } else 0.0
        val eventsForMonth = feeEventCharges.filter { it.month == m && (it.className == student.className || it.className == "ALL") }
        val eventTotal = eventsForMonth.sumOf { it.amount }
        val eventDetails = eventsForMonth.joinToString("|") { "${it.label}:${it.amount}" }
        return FeeLedgerEntry(
            entryId = "${student.studentId}_$m",
            studentId = student.studentId,
            month = m,
            admissionFee = admission,
            tuitionFee = tuition,
            gameFee = game,
            examFee = exam,
            transportFee = transport,
            eventChargeDetails = eventDetails,
            eventFeeTotal = eventTotal
        )
    }

    // Arrears forwarding and Net payable calculations. Only months that were actually paid
    // (or otherwise explicitly saved) come from dbEntries — everything else is computed live
    // above, so a Principal rate change reaches every not-yet-paid month automatically.
    val calculatedLedger = remember(dbEntries, student.studentId, feeConfig, feeRates, feeEventCharges) {
        val today = java.time.LocalDate.now()
        val todayMonthName = academicMonths.getOrElse(
            // java.time.Month is JAN=1..DEC=12; map that to our April-start academic list.
            (today.monthValue - 4 + 12) % 12
        ) { "April" }
        val currentIdx = academicMonths.indexOf(todayMonthName)
        val daysInCurrentMonth = today.lengthOfMonth()

        val sorted = academicMonths.map { mName ->
            dbEntries.find { it.month == mName } ?: buildVirtualEntry(mName)
        }

        var runningArrear = 0.0
        sorted.map { entry ->
            val mIdx = academicMonths.indexOf(entry.month)
            val baseDue = entry.admissionFee + entry.tuitionFee + entry.gameFee + entry.examFee + entry.transportFee + entry.eventFeeTotal
            val isSettled = entry.paidAmount >= baseDue && baseDue > 0

            val autoLateFee = when {
                isSettled -> 0.0
                mIdx > currentIdx -> 0.0 // future month — hasn't started yet
                mIdx < currentIdx -> 150.0 // fully elapsed and still unpaid — capped
                else -> { // this is the current, ongoing month
                    val lastThreeStart = daysInCurrentMonth - 2
                    if (today.dayOfMonth >= lastThreeStart) {
                        val lateDays = (today.dayOfMonth - lastThreeStart + 1).coerceIn(1, 3)
                        (lateDays * 50).toDouble()
                    } else 0.0
                }
            }
            val effectiveLateFee = if (entry.lateFee > 0) entry.lateFee else autoLateFee

            val totalPayable = baseDue + runningArrear + effectiveLateFee - entry.concession
            val balance = totalPayable - entry.paidAmount
            val updated = entry.copy(
                arrear = runningArrear,
                lateFee = effectiveLateFee,
                totalPayable = totalPayable,
                balance = balance
            )
            runningArrear = balance
            updated
        }
    }

    var selectedEntryForEdit by remember { mutableStateOf<FeeLedgerEntry?>(null) }
    var selectedEntryForReceipt by remember { mutableStateOf<FeeLedgerEntry?>(null) }
    var entryForEventBreakdown by remember { mutableStateOf<FeeLedgerEntry?>(null) }
    var showMultiMonthCollectionDialog by remember { mutableStateOf(false) }
    var activeTabSubIndex by remember { mutableStateOf(0) } // 0: Monthly Fee Ledger, 1: Transport, 2: Books, 3: Payment History, 4: Receipts, 5: Remarks

    // Grand totals
    val annualBilled = calculatedLedger.sumOf { it.totalPayable - it.arrear }
    val annualPaid = calculatedLedger.sumOf { it.paidAmount }
    val currentDues = calculatedLedger.lastOrNull()?.balance ?: 0.0
    val lastPaymentEntry = calculatedLedger.filter { it.paidAmount > 0 }.lastOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. TOP ACTIONS SUB-HEADER
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Return to Stage 1 list button (hidden if role is student, since they must stay in portal)
                if (!isStudent || isFromDialog) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .testTag("back_to_students_btn")
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to list View"
                        )
                    }
                } else {
                    Box(modifier = Modifier.size(1.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!isStudent) {
                        IconButton(
                            onClick = {
                                viewModel.sendFeeReminderNotification(student, currentDues)
                                Toast.makeText(context, "Fee Dues Reminder Sent to ${student.name}'s parent!", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        ) {
                            Icon(Icons.Filled.NotificationsActive, "Send Reminder", tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    // Add Payment (only PRINCIPAL/ADMIN/etc., readOnly locks this)
                    if (!isReadOnly) {
                        Button(
                            onClick = {
                                showMultiMonthCollectionDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("collect_payment_btn")
                        ) {
                            Icon(Icons.Filled.Add, "Add Payment Icon")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Collect Fee", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. STUDENT PROFILE INFO CARD
        item {
            ElevatedCard(
                colors = glassCardColors(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Editable Photo Placeholder
                        Box {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Person,
                                    contentDescription = student.name,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                            
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .align(Alignment.BottomEnd)
                                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                    .clickable {
                                        Toast.makeText(context, "Photo uploader/camera feature pending active API sync for ${student.name}.", Toast.LENGTH_SHORT).show()
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.EditNote,
                                    contentDescription = "Edit Photo Icon",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }

                        // Text details
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = student.name,
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFDCFCE7))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "ACTIVE",
                                        fontSize = 9.sp,
                                        color = Color(0xFF10B981),
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                            Text(
                                text = "Admission ID: ${student.admissionNo}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(14.dp))

                    // 2-Column Responsive Grid details
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val isWide = maxWidth >= 600.dp
                        if (isWide) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ProfileInfoRow("Class:", student.className)
                                    ProfileInfoRow("Roll Number:", student.rollNo)
                                    ProfileInfoRow("Admission Date:", student.dateOfAdmission)
                                }
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ProfileInfoRow("Father's Name:", student.fatherName)
                                    ProfileInfoRow("Mother's Name:", student.motherName)
                                    ProfileInfoRow("Phone Number:", student.phone)
                                }
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                ProfileInfoRow("Class:", student.className)
                                ProfileInfoRow("Roll Number:", student.rollNo)
                                ProfileInfoRow("Admission Date:", student.dateOfAdmission)
                                ProfileInfoRow("Father's Name:", student.fatherName)
                                ProfileInfoRow("Mother's Name:", student.motherName)
                                ProfileInfoRow("Phone Number:", student.phone)
                            }
                        }
                    }
                }
            }
        }

        // 3. FEE METRIC SUMMARY ROW
        item {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val isWide = maxWidth >= 600.dp
                if (isWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SummaryStatCard(label = "Total Billed Fee", amount = annualBilled, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        SummaryStatCard(label = "Total Paid", amount = annualPaid, color = Color(0xFF10B981), modifier = Modifier.weight(1f))
                        SummaryStatCard(label = "Total Outstanding", amount = currentDues, color = Color(0xFFEF4444), modifier = Modifier.weight(1f))
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SummaryStatCard(label = "Total Billed Fee", amount = annualBilled, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                            SummaryStatCard(label = "Total Paid", amount = annualPaid, color = Color(0xFF10B981), modifier = Modifier.weight(1f))
                        }
                        SummaryStatCard(label = "Total Outstanding (Dues)", amount = currentDues, color = Color(0xFFEF4444), modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }

        // 3.5. LAST PAYMENT STATS SECONDARY ROW
        item {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "LAST TRANSACTION DETAILS", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(2.dp))
                        if (lastPaymentEntry != null) {
                            Text(
                                text = "Amount: ₹${"%,.0f".format(lastPaymentEntry.paidAmount)} | Date: ${lastPaymentEntry.paymentDate.ifBlank { "N/A" }}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            Text(text = "No recorded transacted ledger logs on file yet.", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    val statusText = when {
                        currentDues <= 0 -> "FULLY PAID"
                        annualPaid > 0 -> "PARTIALLY PAID"
                        else -> "PENDING DUES"
                    }
                    val statusColorBg = when {
                        currentDues <= 0 -> Color(0xFFD1FAE5)
                        annualPaid > 0 -> Color(0xFFFEF3C7)
                        else -> Color(0xFFFEE2E2)
                    }
                    val statusColorTxt = when {
                        currentDues <= 0 -> Color(0xFF10B981)
                        annualPaid > 0 -> Color(0xFFF59E0B)
                        else -> Color(0xFFEF4444)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(statusColorBg)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = statusText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = statusColorTxt
                        )
                    }
                }
            }
        }

        // 4. TAB CONTENT - MONTHLY FEE LEDGER / DETAILS
        item {
            ScrollableTabRow(
                selectedTabIndex = activeTabSubIndex,
                containerColor = Color.Transparent,
                edgePadding = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                val tabLabels = listOf("Monthly Fee Ledger", "Transport", "Books", "Payment History", "Receipts", "Remarks")
                tabLabels.forEachIndexed { idx, title ->
                    Tab(
                        selected = activeTabSubIndex == idx,
                        onClick = { activeTabSubIndex = idx },
                        text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    )
                }
            }
        }

        // ACTIVE TAB INNER CONTENT DISPLAY
        item {
            when (activeTabSubIndex) {
                0 -> {
                    ElevatedCard(
                        colors = glassCardColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text("Monthly Fee Engine", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            MonthlyFeeEngine(
                                academicMonths = academicMonths,
                                calculatedLedger = calculatedLedger,
                                selectedMonths = selectedMonths,
                                onMonthSelected = { month ->
                                    selectedMonths = if (selectedMonths.contains(month)) selectedMonths - month else selectedMonths + month
                                }
                            )
                            if (selectedMonths.isNotEmpty() && !isReadOnly) {
                                Button(
                                    onClick = { showMultiMonthCollectionDialog = true },
                                    modifier = Modifier.fillMaxWidth().height(50.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Filled.Payment, "Proceed to Payment")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Proceed to Collect ${selectedMonths.size} Month(s)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                            }
                            
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)
                            
                            Text(
                                text = "Detailed Ledger Sheet (Swipe horizontally)",
                                fontSize = 12.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.SemiBold
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                    .clip(RoundedCornerShape(8.dp))
                            ) {
                                Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    Column {
                                        Row(
                                            modifier = Modifier
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .padding(vertical = 10.dp)
                                        ) {
                                            TableCell("MONTH", 85, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            TableCell("ADMISSION", 80, fontWeight = FontWeight.Bold)
                                            TableCell("TUITION", 75, fontWeight = FontWeight.Bold)
                                            TableCell("GAME", 70, fontWeight = FontWeight.Bold)
                                            TableCell("EXAM", 70, fontWeight = FontWeight.Bold)
                                            TableCell("TRANSPORT", 80, fontWeight = FontWeight.Bold)
                                            TableCell("EVENT", 80, fontWeight = FontWeight.Bold)
                                            TableCell("LATE FEE", 80, fontWeight = FontWeight.Bold)
                                            TableCell("DISCOUNT", 80, fontWeight = FontWeight.Bold)
                                            TableCell("ARREAR", 80, fontWeight = FontWeight.Bold)
                                            TableCell("NET PAYABLE", 100, fontWeight = FontWeight.Bold)
                                            TableCell("PAID", 100, fontWeight = FontWeight.Bold)
                                            TableCell("BALANCE", 100, fontWeight = FontWeight.Bold)
                                            TableCell("DATE", 80, fontWeight = FontWeight.Bold)
                                            TableCell("RECEIPT", 110, fontWeight = FontWeight.Bold)
                                            TableCell("ACTIONS", 110, fontWeight = FontWeight.Bold)
                                        }
                                        calculatedLedger.forEach { entry ->
                                            val isPaid = entry.paidAmount >= entry.totalPayable && entry.totalPayable > 0
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                                    .background(if (isPaid) Color(0xFFF0FDF4) else Color.Transparent)
                                                    .padding(vertical = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                TableCell(entry.month, 85, fontWeight = FontWeight.Bold)
                                                TableCell("₹${"%.0f".format(entry.admissionFee)}", 80)
                                                TableCell("₹${"%.0f".format(entry.tuitionFee)}", 75)
                                                TableCell("₹${"%.0f".format(entry.gameFee)}", 70)
                                                TableCell("₹${"%.0f".format(entry.examFee)}", 70)
                                                TableCell("₹${"%.0f".format(entry.transportFee)}", 80)
                                                Box(
                                                    modifier = Modifier
                                                        .width(80.dp)
                                                        .padding(horizontal = 8.dp)
                                                        .then(
                                                            if (entry.eventFeeTotal > 0) Modifier.clickable { entryForEventBreakdown = entry }
                                                            else Modifier
                                                        ),
                                                    contentAlignment = Alignment.CenterStart
                                                ) {
                                                    Text(
                                                        text = "₹${"%.0f".format(entry.eventFeeTotal)}",
                                                        fontSize = 11.sp,
                                                        color = if (entry.eventFeeTotal > 0) MaterialTheme.colorScheme.primary else Color.Unspecified,
                                                        fontWeight = if (entry.eventFeeTotal > 0) FontWeight.Bold else FontWeight.Normal,
                                                        textDecoration = if (entry.eventFeeTotal > 0) TextDecoration.Underline else null
                                                    )
                                                }
                                                TableCell("₹${"%.0f".format(entry.lateFee)}", 80, color = Color(0xFFDC2626))
                                                TableCell("-₹${"%.0f".format(entry.concession)}", 80, color = Color(0xFFF59E0B))
                                                TableCell("₹${"%.0f".format(entry.arrear)}", 80, color = Color(0xFFDC2626))
                                                TableCell("₹${"%.0f".format(entry.totalPayable)}", 100, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                                TableCell("₹${"%.0f".format(entry.paidAmount)}", 100, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                                TableCell("₹${"%.0f".format(entry.balance)}", 100, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                                                TableCell(entry.paymentDate.ifBlank { "-" }, 80)
                                                TableCell(entry.receiptNo.ifBlank { "-" }, 110)
                                                Box(modifier = Modifier.width(110.dp), contentAlignment = Alignment.Center) {
                                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        if (!isReadOnly && !isPaid) {
                                                            IconButton(
                                                                onClick = { selectedEntryForEdit = entry },
                                                                modifier = Modifier.size(24.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                                                            ) {
                                                                Icon(Icons.Filled.Edit, "Edit entry", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                                            }
                                                        }
                                                        if (entry.paidAmount > 0) {
                                                            IconButton(
                                                                onClick = { selectedEntryForReceipt = entry },
                                                                modifier = Modifier.size(24.dp).background(Color(0xFFD1FAE5), CircleShape)
                                                            ) {
                                                                Icon(Icons.Filled.Receipt, "Print PDF receipt", tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        val sumAdmission = calculatedLedger.sumOf { it.admissionFee }
                                        val sumTuition = calculatedLedger.sumOf { it.tuitionFee }
                                        val sumGame = calculatedLedger.sumOf { it.gameFee }
                                        val sumExam = calculatedLedger.sumOf { it.examFee }
                                        val sumTransport = calculatedLedger.sumOf { it.transportFee }
                                        val sumLate = calculatedLedger.sumOf { it.lateFee }
                                        val sumConcession = calculatedLedger.sumOf { it.concession }
                                        val sumPayable = calculatedLedger.sumOf { it.totalPayable }
                                        val sumPaid = calculatedLedger.sumOf { it.paidAmount }
                                        val sumBalance = calculatedLedger.sumOf { it.balance }
                                        Row(
                                            modifier = Modifier
                                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                                                .padding(vertical = 10.dp)
                                        ) {
                                            TableCell("GRAND TOTAL", 85, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            TableCell("₹${sumAdmission.toInt()}", 80, fontWeight = FontWeight.Bold)
                                            TableCell("₹${sumTuition.toInt()}", 75, fontWeight = FontWeight.Bold)
                                            TableCell("₹${sumGame.toInt()}", 70, fontWeight = FontWeight.Bold)
                                            TableCell("₹${sumExam.toInt()}", 70, fontWeight = FontWeight.Bold)
                                            TableCell("₹${sumTransport.toInt()}", 80, fontWeight = FontWeight.Bold)
                                            TableCell("₹${sumLate.toInt()}", 80, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                                            TableCell("-₹${sumConcession.toInt()}", 80, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                                            TableCell("-", 80, fontWeight = FontWeight.Bold)
                                            TableCell("₹${sumPayable.toInt()}", 100, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                            TableCell("₹${sumPaid.toInt()}", 100, fontWeight = FontWeight.ExtraBold, color = Color(0xFF10B981))
                                            TableCell("₹${sumBalance.toInt()}", 100, fontWeight = FontWeight.ExtraBold, color = Color(0xFFEF4444))
                                            TableCell("-", 80)
                                            TableCell("VERIFIED", 110, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                            TableCell("-", 110)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    TransportManagementSection(student = student, viewModel = viewModel, currentUserRole = currentUser?.role ?: "STUDENT")
                }

                2 -> {
                    BookDistributionSection(student = student, viewModel = viewModel, currentUserRole = currentUser?.role ?: "STUDENT")
                }

                3 -> {
                    ElevatedCard(
                        colors = glassCardColors(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Audit Trail Logs & Payment Ledger Timeline", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val timelineEntries = calculatedLedger.filter { it.paidAmount > 0 }
                            if (timelineEntries.isEmpty()) {
                                Text("No payment ledger payments detected for this student account currently.", fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, color = Color.Gray, fontSize = 12.sp)
                            } else {
                                timelineEntries.forEachIndexed { i, item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box(
                                                modifier = Modifier
                                                    .size(12.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFF10B981))
                                            )
                                            if (i < timelineEntries.size - 1) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(2.dp)
                                                        .height(40.dp)
                                                        .background(Color.LightGray)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text("${item.month} Payment Settled", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                            Text("Collected Collection: ₹${"%,.0f".format(item.paidAmount)} via ${if (item.receiptNo.isNotEmpty()) "Receipt " + item.receiptNo else "Cash Book"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Timestamp: ${item.paymentDate.ifBlank { "N/A" }}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    val paidForReceipts = calculatedLedger.filter { it.paidAmount > 0 }
                    if (paidForReceipts.isEmpty()) {
                        ElevatedCard(
                            colors = glassCardColors(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Box(modifier = Modifier.padding(16.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text("No payment receipts available. Please record an entry using the collect button.", fontSize = 12.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            paidForReceipts.forEach { entry ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("RECEIPT: ${entry.receiptNo.ifBlank { "REC_ONLINE_" + entry.month.uppercase() }}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                                            Text("Date: ${entry.paymentDate.ifBlank { "N/A" }}", fontSize = 11.sp, color = Color.Gray)
                                        }
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)
                                        ReceiptRow("Month Name", entry.month)
                                        ReceiptRow("Scholar Roll", student.rollNo)
                                        ReceiptRow("Billed Amount", "₹${entry.totalPayable.toInt()}")
                                        ReceiptRow("Paid Amount", "₹${entry.paidAmount.toInt()}")
                                        ReceiptRow("Remaining", "₹${entry.balance.toInt()}")
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = { selectedEntryForReceipt = entry },
                                            modifier = Modifier.align(Alignment.End),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                        ) {
                                            Icon(Icons.Filled.Print, "Invoice", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Launch Digital Receipt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                5 -> {
                    ElevatedCard(
                        colors = glassCardColors(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Official Administrative Ledger Remarks & Audit Comments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val remarksWithRecords = calculatedLedger.filter { it.remarks.isNotEmpty() }
                            if (remarksWithRecords.isEmpty()) {
                                Text("No custom administrative remarks logged on this ledger yet. Edit an item to log remarks.", fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, color = Color.Gray)
                            } else {
                                remarksWithRecords.forEach { record ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("Month: ${record.month}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                            Text("Remarks: \"${record.remarks}\"", style = MaterialTheme.typography.bodyMedium, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!isReadOnly) {
            item {
                ElevatedCard(
                    colors = glassCardColors(),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "INSTANT ACCOUNT QUICK OPERATIONS",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        BoxWithConstraints {
                            val isPhone = maxWidth < 480.dp
                            val columnsCount = if (isPhone) 2 else 3
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(columnsCount),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.height(if (isPhone) 160.dp else 115.dp),
                                userScrollEnabled = false
                            ) {
                                item {
                                    QuickActionButton(title = "Add Payment", icon = Icons.Filled.Payment, tint = Color(0xFFEAF9F1), textTint = Color(0xFF10B981)) {
                                        val firstDue = calculatedLedger.find { it.balance > 0 }
                                        if (firstDue != null) {
                                            selectedEntryForEdit = firstDue
                                        } else {
                                            Toast.makeText(context, "All bills cleared for this student!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                item {
                                    QuickActionButton(title = "Add Fine", icon = Icons.Filled.Add, tint = Color(0xFFFEF2F2), textTint = Color(0xFFEF4444)) {
                                        val firstDue = calculatedLedger.find { it.balance > 0 }
                                        if (firstDue != null) {
                                            selectedEntryForEdit = firstDue.copy(lateFee = 200.0, remarks = "Late fee adjustment")
                                        } else {
                                            Toast.makeText(context, "No outstanding months found to fine!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                item {
                                    QuickActionButton(title = "Add Discount", icon = Icons.Filled.EditNote, tint = Color(0xFFEFF6FF), textTint = Color(0xFF3B82F6)) {
                                        val firstDue = calculatedLedger.find { it.balance > 0 }
                                        if (firstDue != null) {
                                            selectedEntryForEdit = firstDue.copy(concession = 200.0, remarks = "Concession applied")
                                        } else {
                                            Toast.makeText(context, "No outstanding months found to discount!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                item {
                                    QuickActionButton(title = "Gen Receipt", icon = Icons.Filled.Receipt, tint = Color(0xFFFFFBEB), textTint = Color(0xFFF59E0B)) {
                                        if (lastPaymentEntry != null) {
                                            selectedEntryForReceipt = lastPaymentEntry
                                        } else {
                                            Toast.makeText(context, "No payment history recorded to generate receipt!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                item {
                                    QuickActionButton(title = "Statement", icon = Icons.Filled.Download, tint = Color(0xFFF3E8FF), textTint = Color(0xFFA855F7)) {
                                        Toast.makeText(context, "Downloading computerized fee statement ledger PDF...", Toast.LENGTH_LONG).show()
                                        viewModel.logAudit("Downloaded Fee Statement", "-", "Student: ${student.studentId}")
                                    }
                                }
                                item {
                                    QuickActionButton(title = "Send Reminder", icon = Icons.Filled.NotificationsActive, tint = Color(0xFFFCE7F3), textTint = Color(0xFFEC4899)) {
                                        viewModel.logAudit("Dispatched Automatic Fee Reminders", "-", "Student: ${student.studentId}")
                                        Toast.makeText(context, "SMS Alert reminder successfully dispatched to ${student.fatherName}'s mobile (${student.phone})!", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            ElevatedCard(
                colors = glassCardColors(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text("ACCOUNTS ANALYTICS GAUGE", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        val totalMonths = 12
                        val paidMonths = calculatedLedger.count { it.paidAmount >= it.totalPayable && it.totalPayable > 0 }
                        val partialMonths = calculatedLedger.count { it.paidAmount > 0 && it.paidAmount < it.totalPayable }
                        val pendingMonths = totalMonths - paidMonths - partialMonths

                        Text("• Total Months: $totalMonths", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text("• Fully Paid Months: $paidMonths", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        Text("• Partially Paid: $partialMonths", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold)
                        Text("• Pending Months: $pendingMonths", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                    }

                    val percentPaid = if (annualBilled > 0) ((annualPaid / annualBilled) * 100).toInt() else 0
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(80.dp)
                            ) {
                                CircularProgressIndicator(
                                    progress = { percentPaid / 100f },
                                    color = Color(0xFF10B981),
                                    trackColor = Color.LightGray.copy(alpha = 0.25f),
                                    strokeWidth = 9.dp,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Text(
                                    text = "$percentPaid%",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF10B981)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Total Paid ratio", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        }
                    }
                }
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFEFF6FF))
                    .border(BorderStroke(1.dp, Color(0xFF3B82F6).copy(alpha = 0.25f)), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, "Disclaimer Info Icon", tint = Color(0xFF3B82F6), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "All amounts are in Indian Rupees (₹). Click on Edit details log to override dynamic concession adjustments or late fees overrides.",
                        fontSize = 11.sp,
                        color = Color(0xFF3B82F6),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    if (selectedEntryForEdit != null) {
        val original = selectedEntryForEdit!!
        var eReceipt by remember { mutableStateOf(original.receiptNo.ifBlank { "REC-${System.currentTimeMillis()}" }) }
        var eDate by remember { mutableStateOf(original.paymentDate.ifBlank { java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH)) }) }
        var eAdmission by remember { mutableStateOf(original.admissionFee.toInt().toString()) }
        var eTuition by remember { mutableStateOf(original.tuitionFee.toInt().toString()) }
        var eGame by remember { mutableStateOf(original.gameFee.toInt().toString()) }
        var eExam by remember { mutableStateOf(original.examFee.toInt().toString()) }
        var eTransport by remember { mutableStateOf(original.transportFee.toInt().toString()) }
        var eLateFee by remember { mutableStateOf(original.lateFee.toInt().toString()) }
        var eConcession by remember { mutableStateOf(original.concession.toInt().toString()) }
        var ePaidAmount by remember { mutableStateOf(original.paidAmount.toInt().toString()) }
        var ePaymentMode by remember { mutableStateOf(original.paymentMode) }
        var eRemarks by remember { mutableStateOf(original.remarks) }
        
        var editError by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }
        
        val admVal = eAdmission.toDoubleOrNull() ?: 0.0
        val tuiVal = eTuition.toDoubleOrNull() ?: 0.0
        val gameVal = eGame.toDoubleOrNull() ?: 0.0
        val examVal = eExam.toDoubleOrNull() ?: 0.0
        val transVal = eTransport.toDoubleOrNull() ?: 0.0
        val lateVal = eLateFee.toDoubleOrNull() ?: 0.0
        val concessionVal = eConcession.toDoubleOrNull() ?: 0.0
        val paidVal = ePaidAmount.toDoubleOrNull() ?: 0.0
        
        val totalFee = admVal + tuiVal + gameVal + examVal + transVal + lateVal - concessionVal
        val remainingBalance = totalFee - paidVal

        Dialog(
            onDismissRequest = { if(!isSaving) selectedEntryForEdit = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(24.dp)),
                color = MaterialTheme.colorScheme.background,
                tonalElevation = 6.dp
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Process Payment - ${original.month}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { if(!isSaving) selectedEntryForEdit = null }) {
                            Icon(Icons.Filled.Close, "Close", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Student Profile Card
                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(),
                            colors = glassCardColors(),
                            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(student.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("Class: ${student.className} | Roll No: ${student.rollNo}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Admission No: ${student.admissionNo}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        // Payment Details Grid
                        Text("Fee Components", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        
                        // Using custom layout for chips/cards for fees
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(value = eAdmission, onValueChange = { if (isPrincipal) eAdmission = it }, readOnly = !isPrincipal, label = { Text("Admission") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                            OutlinedTextField(value = eTuition, onValueChange = { if (isPrincipal) eTuition = it }, readOnly = !isPrincipal, label = { Text("Tuition") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                        }
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(value = eExam, onValueChange = { if (isPrincipal) eExam = it }, readOnly = !isPrincipal, label = { Text("Exam Fee") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                            OutlinedTextField(value = eGame, onValueChange = { if (isPrincipal) eGame = it }, readOnly = !isPrincipal, label = { Text("Game") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                        }
                        
                        OutlinedTextField(value = eTransport, onValueChange = { if (isPrincipal) eTransport = it }, readOnly = !isPrincipal, label = { Text("Transport Fee") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                        
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        
                        Text("Adjustments & Concessions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(value = eLateFee, onValueChange = { eLateFee = it }, label = { Text("Late Fee") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                            OutlinedTextField(value = eConcession, onValueChange = { eConcession = it }, label = { Text("Discount") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                        }
                        OutlinedTextField(value = eRemarks, onValueChange = { eRemarks = it }, label = { Text("Remarks (Mandatory if adjustments made)") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                        
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        
                        Text("Payment Collection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        OutlinedTextField(value = ePaidAmount, onValueChange = { ePaidAmount = it }, label = { Text("Amount Paid Now") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), leadingIcon = { Text("₹", modifier = Modifier.padding(start=12.dp)) })
                        OutlinedTextField(value = ePaymentMode, onValueChange = { ePaymentMode = it }, label = { Text("Mode (Cash/UPI/Bank)") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), leadingIcon = { Icon(Icons.Filled.AccountBalanceWallet, null) })
                        OutlinedTextField(value = eReceipt, onValueChange = { eReceipt = it }, label = { Text("Receipt No.") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                        
                        if (editError != null) {
                            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(editError!!, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                    
                    // Footer (Totals & Action)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shadowElevation = 8.dp
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Fee", style = MaterialTheme.typography.bodyMedium)
                                Text("₹${"%,.0f".format(totalFee)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Paid Amount", style = MaterialTheme.typography.bodyMedium)
                                Text("- ₹${"%,.0f".format(paidVal)}", style = MaterialTheme.typography.bodyLarge, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Remaining Balance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("₹${"%,.0f".format(remainingBalance)}", style = MaterialTheme.typography.titleLarge, color = if(remainingBalance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold)
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Button(
                                onClick = {
                                    if ((lateVal > 0.0 || concessionVal > 0.0) && eRemarks.isBlank()) {
                                        editError = "Remarks explanation is MANDATORY when introducing Late Fee overrides or Concession Discounts!"
                                    } else {
                                        isSaving = true
                                        val updated = original.copy(
                                            receiptNo = eReceipt.trim(),
                                            paymentDate = eDate.trim(),
                                            admissionFee = admVal,
                                            tuitionFee = tuiVal,
                                            gameFee = gameVal,
                                            examFee = examVal,
                                            transportFee = transVal,
                                            lateFee = lateVal,
                                            concession = concessionVal,
                                            paidAmount = paidVal,
                                            remarks = eRemarks.trim(), paymentMode = ePaymentMode.trim()
                                        )
                                        viewModel.saveFeeLedgerEntry(updated)
                                        
                                        val studentFeeIndex = viewModel.feesState.value.find { it.studentId == student.studentId }
                                        val currentPaidAccumulated = calculatedLedger.sumOf { if (it.month == original.month) updated.paidAmount else it.paidAmount }
                                        val currentBilledAccumulated = calculatedLedger.sumOf { 
                                            val currentMonthEntry = if (it.month == original.month) updated else it
                                            currentMonthEntry.admissionFee + currentMonthEntry.tuitionFee + currentMonthEntry.gameFee + currentMonthEntry.examFee + currentMonthEntry.transportFee + currentMonthEntry.lateFee - currentMonthEntry.concession
                                        }
                                        
                                        val indexToSave = studentFeeIndex ?: Fee(
                                            feeId = "F_${student.studentId}",
                                            studentId = student.studentId
                                        )
                                        viewModel.addOrUpdateFee(
                                            indexToSave.copy(
                                                totalFee = currentBilledAccumulated,
                                                paidAmount = currentPaidAccumulated,
                                                dueAmount = maxOf(0.0, currentBilledAccumulated - currentPaidAccumulated),
                                                paymentDate = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH))
                                            )
                                        )
                                        
                                        selectedEntryForEdit = null
                                        Toast.makeText(context, "Payment Processed Successfully!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(56.dp),
                                shape = RoundedCornerShape(16.dp),
                                enabled = !isSaving
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                                } else {
                                    Icon(Icons.Filled.CheckCircle, "Save")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Confirm Payment", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

if (entryForEventBreakdown != null) {
    val entry = entryForEventBreakdown!!
    AlertDialog(
        onDismissRequest = { entryForEventBreakdown = null },
        title = { Text("${entry.month} — What this ₹${"%.0f".format(entry.eventFeeTotal)} is for", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (entry.eventChargeDetails.isBlank()) {
                    Text("No details available.", color = Color.Gray)
                } else {
                    entry.eventChargeDetails.split("|").forEach { item ->
                        val parts = item.split(":")
                        if (parts.size == 2) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(parts[0], fontSize = 13.sp)
                                Text("₹${parts[1].toDoubleOrNull()?.let { "%.0f".format(it) } ?: parts[1]}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { entryForEventBreakdown = null }) { Text("Close") }
        }
    )
}

if (selectedEntryForReceipt != null) {
val entry = selectedEntryForReceipt!!
AlertDialog(
onDismissRequest = { selectedEntryForReceipt = null },
title = {
Row(verticalAlignment = Alignment.CenterVertically) {
Icon(Icons.Filled.Verified, "Success Receipt", tint = Color(0xFF10B981))
Spacer(modifier = Modifier.width(8.dp))
Text("Digital Fee Receipt Generated", fontWeight = FontWeight.Bold)
}
},
text = {
ElevatedCard(
colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
modifier = Modifier
.fillMaxWidth()
.wrapContentHeight()
.border(1.dp, Color.LightGray, RoundedCornerShape(12.dp))
) {
Column(
modifier = Modifier.padding(16.dp),
horizontalAlignment = Alignment.CenterHorizontally
) {
Text("S. D PUBLIC SCHOOL", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF3B82F6))
Text("Karol Bagh, New Delhi-110005", fontSize = 10.sp, color = Color.Gray)
Spacer(modifier = Modifier.height(10.dp))

HorizontalDivider(color = Color.LightGray)
Spacer(modifier = Modifier.height(8.dp))

ReceiptRow("Admission Number", student.admissionNo)
ReceiptRow("Pupil's Name", student.name)
ReceiptRow("Aadhaar Number", student.aadhaarNo)
ReceiptRow("Class", student.className)
ReceiptRow("Payment Month", entry.month)
ReceiptRow("Receipt Number", entry.receiptNo.ifBlank { "REC-${(10024..99999).random()}" })
ReceiptRow("Payment Date", entry.paymentDate.ifBlank { "N/A" })
ReceiptRow("Payment Mode", entry.paymentMode)

Spacer(modifier = Modifier.height(8.dp))
HorizontalDivider(color = Color.LightGray)
Spacer(modifier = Modifier.height(8.dp))

Text("FEE BREAKDOWN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B82F6), modifier = Modifier.align(Alignment.Start))
Spacer(modifier = Modifier.height(4.dp))

FeeItemRow("Admission Fee", entry.admissionFee)
FeeItemRow("Tuition Fee", entry.tuitionFee)
FeeItemRow("Game Fee", entry.gameFee)
FeeItemRow("Exam Fee", entry.examFee)
FeeItemRow("Transport Fee", entry.transportFee)
FeeItemRow("Late Fee Charged", entry.lateFee)
FeeItemRow("Concession Discount", -entry.concession, isNegative = true)
FeeItemRow("Arrears Forwarded", entry.arrear)

Spacer(modifier = Modifier.height(6.dp))
HorizontalDivider(color = Color.LightGray)
Spacer(modifier = Modifier.height(6.dp))

Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
Text("TOTAL PACK PAYABLE", fontWeight = FontWeight.ExtraBold, color = Color.Black, fontSize = 12.sp)
Text("₹${entry.totalPayable.toInt()}", fontWeight = FontWeight.ExtraBold, color = Color.Black, fontSize = 12.sp)
}
Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
Text("AMOUNT COLLECTED", fontWeight = FontWeight.ExtraBold, color = Color(0xFF10B981), fontSize = 12.sp)
Text("₹${entry.paidAmount.toInt()}", fontWeight = FontWeight.ExtraBold, color = Color(0xFF10B981), fontSize = 12.sp)
}
Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
Text("REMAINING BALANCE", fontWeight = FontWeight.ExtraBold, color = Color(0xFFEF4444), fontSize = 12.sp)
Text("₹${entry.balance.toInt()}", fontWeight = FontWeight.ExtraBold, color = Color(0xFFEF4444), fontSize = 12.sp)
}

Spacer(modifier = Modifier.height(12.dp))
Text(
text = "Status: ${if (entry.paidAmount >= entry.totalPayable && entry.totalPayable > 0) "FULLY PAID / TRANSACTED" else "PARTIALLY CLEAR / DUES PENDING"}",
fontWeight = FontWeight.Bold,
color = if (entry.paidAmount >= entry.totalPayable && entry.totalPayable > 0) Color(0xFF10B981) else Color(0xFFEF4444),
fontSize = 11.sp
)
Spacer(modifier = Modifier.height(8.dp))
Text("This is an official system generated computerized statement of transacted finances and does not require a physical ink signature.", fontSize = 9.sp, color = Color.Gray, textAlign = TextAlign.Center)
}
}
},
confirmButton = {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(
            onClick = {
                val receiptNo = entry.receiptNo.ifBlank { "REC-${System.currentTimeMillis().toString().takeLast(6)}" }
                val file = com.example.util.PaymentReceiptPdfHelper.generateReceiptPdf(
                    context = context,
                    student = student,
                    entries = listOf(entry),
                    paymentMode = entry.paymentMode,
                    transactionRef = "REF-${System.currentTimeMillis().toString().takeLast(6)}",
                    receiptNo = receiptNo,
                    totalPaidAmount = entry.paidAmount,
                    collectedBy = currentUser?.name ?: "School Admin"
                )
                if (file != null) {
                    com.example.util.PaymentReceiptPdfHelper.openReceiptPdf(context, file)
                } else {
                    Toast.makeText(context, "Failed to generate PDF receipt", Toast.LENGTH_SHORT).show()
                }
                selectedEntryForReceipt = null
            }
        ) {
            Icon(Icons.Filled.PictureAsPdf, null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Open PDF")
        }
        Button(
            onClick = {
                val receiptNo = entry.receiptNo.ifBlank { "REC-${System.currentTimeMillis().toString().takeLast(6)}" }
                val file = com.example.util.PaymentReceiptPdfHelper.generateReceiptPdf(
                    context = context,
                    student = student,
                    entries = listOf(entry),
                    paymentMode = entry.paymentMode,
                    transactionRef = "REF-${System.currentTimeMillis().toString().takeLast(6)}",
                    receiptNo = receiptNo,
                    totalPaidAmount = entry.paidAmount,
                    collectedBy = currentUser?.name ?: "School Admin"
                )
                if (file != null) {
                    com.example.util.PaymentReceiptPdfHelper.shareReceiptPdf(context, file)
                } else {
                    Toast.makeText(context, "Failed to generate PDF receipt", Toast.LENGTH_SHORT).show()
                }
                selectedEntryForReceipt = null
            }
        ) {
            Icon(Icons.Filled.Share, null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Share PDF")
        }
    }
},
dismissButton = {
    TextButton(onClick = { selectedEntryForReceipt = null }) { Text("Dismiss") }
}
)
}

    if (showMultiMonthCollectionDialog) {
        MultiMonthPaymentCollectionDialog(
            student = student,
            calculatedLedger = calculatedLedger,
            currentUserRole = currentUser?.role ?: "STUDENT",
            initialSelectedMonths = selectedMonths,
            onDismiss = { showMultiMonthCollectionDialog = false },
            onConfirmPayment = { selectedMonths, paymentMode, transactionRef, totalPaidNow, remarks, receiptNo ->
                var remainingToDistribute = totalPaidNow
                val updatedEntries = mutableListOf<FeeLedgerEntry>()

                selectedMonths.forEach { monthName ->
                    val existing = calculatedLedger.find { it.month.equals(monthName, ignoreCase = true) }
                    if (existing != null) {
                        val neededForThisMonth = maxOf(0.0, existing.totalPayable - existing.paidAmount)
                        val allocated = if (remainingToDistribute >= neededForThisMonth) neededForThisMonth else remainingToDistribute
                        val newPaid = existing.paidAmount + allocated
                        remainingToDistribute = (remainingToDistribute - allocated).coerceAtLeast(0.0)

                        val updatedEntry = existing.copy(
                            paidAmount = newPaid,
                            paymentMode = paymentMode,
                            paymentDate = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH)),
                            receiptNo = if (existing.receiptNo.isBlank()) receiptNo else existing.receiptNo,
                            remarks = if (remarks.isNotBlank()) remarks else existing.remarks
                        )
                        viewModel.saveFeeLedgerEntry(updatedEntry)
                        updatedEntries.add(updatedEntry)
                    }
                }

                viewModel.feesState.value.find { it.studentId == student.studentId }?.let { currentFee ->
                    val newFeePaid = currentFee.paidAmount + totalPaidNow
                    val newDue = (currentFee.totalFee - newFeePaid).coerceAtLeast(0.0)
                    val newStatus = if (newDue <= 0) "Paid" else "Partial"
                    val updatedFee = currentFee.copy(
                        paidAmount = newFeePaid,
                        dueAmount = newDue,
                        status = newStatus,
                        paymentDate = java.time.LocalDate.now().toString(),
                        paymentMode = paymentMode
                    )
                    viewModel.addOrUpdateFee(updatedFee)
                }

                val generatedFile = com.example.util.PaymentReceiptPdfHelper.generateReceiptPdf(
                    context = context,
                    student = student,
                    entries = if (updatedEntries.isNotEmpty()) updatedEntries else calculatedLedger.filter { selectedMonths.contains(it.month) },
                    paymentMode = paymentMode,
                    transactionRef = transactionRef,
                    receiptNo = receiptNo,
                    totalPaidAmount = totalPaidNow,
                    collectedBy = currentUser?.name ?: "School Admin"
                )

                showMultiMonthCollectionDialog = false
                if (generatedFile != null) {
                    com.example.util.PaymentReceiptPdfHelper.openReceiptPdf(context, generatedFile)
                }
                Toast.makeText(context, "Payment recorded and PDF Receipt generated!", Toast.LENGTH_LONG).show()
            }
        )
    }
}

@Composable
fun ProfileInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun QuickActionButton(title: String, icon: ImageVector, tint: Color, textTint: Color, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onClick() },
        colors = CardDefaults.elevatedCardColors(containerColor = tint),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = textTint, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = textTint, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun MetadataItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
        Text(text = value.ifBlank { "N/A" }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SummaryStatCard(label: String, amount: Double, color: Color, modifier: Modifier = Modifier) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = color.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label.uppercase(Locale.getDefault()), fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Text("₹${"%,.0f".format(amount)}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
fun TableHeaderCell(text: String, widthDp: Int) {
    Box(
        modifier = Modifier
            .width(widthDp.dp)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text = text, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun TableCell(
    text: String,
    widthDp: Int,
    fontWeight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip
) {
    Box(
        modifier = Modifier
            .width(widthDp.dp)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text = text, fontWeight = fontWeight, fontSize = 11.sp, color = color, maxLines = 1, overflow = overflow)
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = Color.DarkGray)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
    }
}

@Composable
fun FeeItemRow(label: String, amount: Double, isNegative: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 10.sp, color = Color.Gray)
        val prefix = if (isNegative) "-" else ""
        Text("${prefix}₹${Math.abs(amount).toInt()}", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = if (isNegative) Color(0xFFF59E0B) else Color.DarkGray)
    }
}

@Composable
fun FirstLoginPasswordChangeScreen(
    viewModel: SchoolViewModel,
    userId: String,
    onSuccessChanged: () -> Unit
) {
    var oldPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
            .systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 480.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    
                    Text(
                        text = "Initialize Secure Password",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        textAlign = TextAlign.Center
                    )
                    
                    Text(
                        text = "Welcome to S. D Public School Portal! Crucially, because you are logging in with a temporary workspace credential, you MUST setup a custom password now to protect your privacy and secure school records.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center
                    )
                    
                    Text(
                        text = "Your password is encrypted locally using industrial SHA-256 standard and hidden from all school authorities, teachers, and admins.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                    
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    
                    OutlinedTextField(
                        value = oldPassword,
                        onValueChange = { oldPassword = it },
                        label = { Text("Current Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("New Secure Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_password_input")
                    )
                    
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("Confirm New Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_password_input")
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Button(
                        onClick = {
                            val trimmedNew = newPassword.trim()
                            val trimmedConfirm = confirmPassword.trim()
                            if (trimmedNew.isBlank()) {
                                errorMessage = "Password cannot be empty!"
                            } else if (trimmedNew != trimmedConfirm) {
                                errorMessage = "Passwords do not match!"
                            } else if (trimmedNew.length < 6) {
                                errorMessage = "Password must be at least 6 characters long!"
                            } else {
                                isSubmitting = true
                                errorMessage = null
                                viewModel.changePassword(
                                    userId = userId,
                                    oldPassword = oldPassword,
                                    newPassword = trimmedNew,
                                    onSuccess = {
                                        isSubmitting = false
                                        Toast.makeText(context, "Password configured and encrypted securely!", Toast.LENGTH_LONG).show()
                                        onSuccessChanged()
                                    },
                                    onFailure = { err ->
                                        isSubmitting = false
                                        errorMessage = err
                                    }
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("apply_password_change_button"),
                        enabled = !isSubmitting,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Text(
                                "Save Password & Sign In",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// UNIFIED REGISTRATION & ADMISSION HUB WITH DYNAMIC LOGIC & TRANSACTIONS
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedRegistrationScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentRegistrationTab(viewModel: SchoolViewModel) {
    val context = LocalContext.current
    val students by viewModel.studentsState.collectAsState()

    // Form inputs state
    var name by remember { mutableStateOf("") }
    var selectedClass by remember { mutableStateOf("Nursery") }
    var rollNoVal by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("Male") }
    var sFather by remember { mutableStateOf("") }
    var sMother by remember { mutableStateOf("") }
    var sGuardian by remember { mutableStateOf("") }
    var sPhone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var admissionDate by remember { mutableStateOf(java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMMM yyyy", java.util.Locale.ENGLISH))) }
    var status by remember { mutableStateOf("Active") }
    var linkedSiblings by remember { mutableStateOf("") }
    
    var showClassDropdown by remember { mutableStateOf(false) }
    var showGenderDropdown by remember { mutableStateOf(false) }
    var showStatusDropdown by remember { mutableStateOf(false) }

    // Fee, Transport, and Book configuration state
    var tuitionFeeText by remember { mutableStateOf("1000") }
    var admissionFeeText by remember { mutableStateOf("2000") }
    var bookFeeText by remember { mutableStateOf("1500") }
    var hasTransport by remember { mutableStateOf(false) }
    var transportSlab by remember { mutableStateOf("0-5 km") } // "0-5 km", "5-10 km", "10-15 km"
    var assignBooksPackage by remember { mutableStateOf(true) }

    var newlyRegisteredStudent by remember { mutableStateOf<Student?>(null) }

    if (newlyRegisteredStudent != null) {
        com.example.ui.screens.NewStudentCredentialDialog(
            student = newlyRegisteredStudent!!,
            onDismiss = { newlyRegisteredStudent = null }
        )
    }

    val calculatedTransportFee = if (hasTransport) {
        when (transportSlab) {
            "0-5 km" -> 500.0
            "5-10 km" -> 1000.0
            "10-15 km" -> 1500.0
            else -> 500.0
        }
    } else 0.0

    val classOptions = listOf(
        "Nursery", "LKG", "UKG", 
        "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
        "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Scholar Admission Office", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                }
                Text("Admit a new student with complete fee, transport, and book configurations. All records save instantly to Firestore & Room.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }
        }

        // Student Form Card
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = glassCardColors(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Student Credentials", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                // Name Input
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Student Full Name") },
                    leadingIcon = { Icon(Icons.Filled.Person, "Name") },
                    modifier = Modifier.fillMaxWidth().testTag("student_name_input")
                )

                // Drop-down for Class (Manual entry disallowed)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = selectedClass,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Assigned Class") },
                        leadingIcon = { Icon(Icons.Filled.Class, "Class Selection") },
                        trailingIcon = { 
                            IconButton(onClick = { showClassDropdown = !showClassDropdown }) {
                                Icon(Icons.Filled.ArrowDropDown, "Open Dropdown")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showClassDropdown = true }
                            .testTag("student_class_trigger")
                    )

                    DropdownMenu(
                        expanded = showClassDropdown,
                        onDismissRequest = { showClassDropdown = false },
                        modifier = Modifier.testTag("student_class_menu")
                    ) {
                        classOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    selectedClass = opt
                                    showClassDropdown = false
                                },
                                modifier = Modifier.testTag("opt_class_$opt")
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = rollNoVal,
                    onValueChange = { rollNoVal = it },
                    label = { Text("Roll Number") },
                    modifier = Modifier.fillMaxWidth().testTag("student_roll_input")
                )

                OutlinedTextField(
                    value = sFather,
                    onValueChange = { sFather = it },
                    label = { Text("Father's Name") },
                    modifier = Modifier.fillMaxWidth().testTag("student_father_input")
                )

                OutlinedTextField(
                    value = sPhone,
                    onValueChange = { sPhone = it },
                    label = { Text("Contact Phone") },
                    modifier = Modifier.fillMaxWidth().testTag("student_phone_input")
                )
                DynamicDatePicker(selectedDate = dob, onDateSelected = { dob = it }, label = "Date of Birth")
                DynamicDatePicker(selectedDate = admissionDate, onDateSelected = { admissionDate = it }, label = "Date of Admission")

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Monthly Fee & Transport Configuration Section
                Text("Fee & Transport Configuration", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = tuitionFeeText,
                        onValueChange = { tuitionFeeText = it },
                        label = { Text("Monthly Tuition Fee (₹)") },
                        leadingIcon = { Icon(Icons.Filled.Payments, null) },
                        modifier = Modifier.weight(1f).testTag("tuition_fee_input")
                    )

                    OutlinedTextField(
                        value = admissionFeeText,
                        onValueChange = { admissionFeeText = it },
                        label = { Text("Admission Fee (₹)") },
                        leadingIcon = { Icon(Icons.Filled.ReceiptLong, null) },
                        modifier = Modifier.weight(1f).testTag("admission_fee_input")
                    )
                }

                // Transport Facility Selection
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.DirectionsBus, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Transport Required?", fontWeight = FontWeight.Bold)
                            }
                            Switch(
                                checked = hasTransport,
                                onCheckedChange = { hasTransport = it },
                                modifier = Modifier.testTag("transport_toggle")
                            )
                        }

                        if (hasTransport) {
                            Text("Select Distance Slab:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("0-5 km", "5-10 km", "10-15 km").forEach { slab ->
                                    FilterChip(
                                        selected = transportSlab == slab,
                                        onClick = { transportSlab = slab },
                                        label = { Text(slab, fontSize = 12.sp) },
                                        modifier = Modifier.weight(1f).testTag("slab_$slab")
                                    )
                                }
                            }
                            Text(
                                text = "Calculated Transport Fee: ₹${calculatedTransportFee.toInt()}/month",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Book Assignment Option
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Assign Class Books Package", fontWeight = FontWeight.Bold)
                                Text("Includes curriculum book bundle (₹${bookFeeText.toDoubleOrNull()?.toInt() ?: 1500})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Checkbox(
                            checked = assignBooksPackage,
                            onCheckedChange = { assignBooksPackage = it },
                            modifier = Modifier.testTag("book_package_toggle")
                        )
                    }
                }

                // SUBMIT BUTTON
                Button(
                    onClick = {
                        if (name.trim().isEmpty()) {
                            Toast.makeText(context, "Please enter student name!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (dob.trim().isEmpty()) {
                            Toast.makeText(context, "Date of Birth (DD-MM-YYYY) is required for admission & initial login!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val cleanRoll = rollNoVal.toIntOrNull() ?: 1
                        val cleanId = "STID_${selectedClass.replace(" ", "").uppercase()}_${String.format("%02d", cleanRoll)}"
                        val monthlyTuition = tuitionFeeText.toDoubleOrNull() ?: 1000.0
                        val initialAdmissionFee = admissionFeeText.toDoubleOrNull() ?: 2000.0
                        val initialBookFee = if (assignBooksPackage) (bookFeeText.toDoubleOrNull() ?: 1500.0) else 0.0

                        val newStudent = Student(
                            studentId = cleanId,
                            id = cleanId,
                            name = name,
                            className = selectedClass,
                            rollNo = rollNoVal,
                            DOB = dob,
                            dateOfAdmission = admissionDate,
                            fatherName = sFather,
                            motherName = "Co-Guardian",
                            phone = sPhone,
                            address = "Residential Area",
                            admissionNo = "ADM_${cleanId}",
                            rollNumber = cleanRoll,
                            attendanceStatus = "Present",
                            feeStatus = "Pending",
                            role = "STUDENT",
                            hasTransport = hasTransport,
                            transportSlab = if (hasTransport) transportSlab else "0-5 km",
                            transportFee = calculatedTransportFee
                        )

                        viewModel.addOrUpdateStudent(newStudent, isEdit = false)
                        viewModel.initializeStudentFeeAndLedger(
                            student = newStudent,
                            monthlyTuitionFee = monthlyTuition,
                            admissionFee = initialAdmissionFee,
                            bookFee = initialBookFee,
                            monthlyTransportFee = calculatedTransportFee
                        )

                        Toast.makeText(context, "Student $name registered & initial fee structure created!", Toast.LENGTH_LONG).show()
                        newlyRegisteredStudent = newStudent

                        // Clear inputs
                        name = ""
                        rollNoVal = ""
                        sFather = ""
                        sPhone = ""
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_student_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.PersonAdd, "Admit")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Register & Save to Firestore", fontWeight = FontWeight.Bold)
                }
            }
        }

        // DYNAMIC PREVIEW CARD
        OutlinedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Live Student State Preview",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onTertiaryContainer
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Name: ${if (name.isEmpty()) "Pending Entry" else name}", style = MaterialTheme.typography.bodyMedium)
                    Text("Class: $selectedClass", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
            }
        }

        // LIVE SEEDED SCHOLARS DIRECTORY
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Seeded Students (Pre-Seeded)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            val classFilterStudents = students.filter { it.className.lowercase(Locale.ROOT) == selectedClass.lowercase(Locale.ROOT) }

            if (classFilterStudents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No students currently loaded in $selectedClass. Select Class above to view.", style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Class: $selectedClass - Active Scholars (${classFilterStudents.size})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        classFilterStudents.take(15).forEach { stud ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${stud.rollNo}. ${stud.name}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (stud.feeStatus == "Paid") Color(0xFFD1FAE5) else Color(0xFFFEE2E2))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(stud.feeStatus, fontSize = 10.sp, color = if (stud.feeStatus == "Paid") Color(0xFF10B981) else Color(0xFFEF4444))
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherAndDemotionRegistrationTab(viewModel: SchoolViewModel) {
    val context = LocalContext.current
    val teachers by viewModel.teachersState.collectAsState()

    // Form inputs state
    var tName by remember { mutableStateOf("") }
    var tGender by remember { mutableStateOf("") }
    var isTGenderExpanded by remember { mutableStateOf(false) }
    var selectedClassVal by remember { mutableStateOf("Class 5") }
    var tPhone by remember { mutableStateOf("") }
    var tEmail by remember { mutableStateOf("") }
    var tDOB by remember { mutableStateOf("") }
    var showTClassDropdown by remember { mutableStateOf(false) }

    // Subject states
    var primarySubject by remember { mutableStateOf("") }
    val secondarySubjects = remember { mutableStateMapOf<String, Boolean>() }

    val classOptions = listOf(
        "Nursery", "LKG", "UKG", 
        "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
        "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
    )

    // Dynamic subject lists helper
    val selectableSubjects = remember(selectedClassVal) {
        val lists = when (selectedClassVal) {
            "Nursery", "LKG", "UKG" -> listOf("Basic Hindi", "Basic English", "Basic Maths", "Hindi", "English", "Maths")
            "Class 1", "Class 2", "Class 3", "Class 4", "Class 5" -> listOf("Hindi", "English", "Maths", "EVS", "Hindi Grammar", "English Grammar", "Sanskrit", "Urdu", "GK", "Computer")
            "Class 6", "Class 7", "Class 8", "Class 9", "Class 10" -> listOf("Hindi", "English", "Maths", "Science", "SST", "Hindi Grammar", "English Grammar", "Sanskrit", "Urdu", "GK", "Computer")
            else -> emptyList()
        }
        // Sync primary subject and clear checkboxes when subject lists shift
        primarySubject = lists.firstOrNull() ?: ""
        secondarySubjects.clear()
        lists.forEach { secondarySubjects[it] = false }
        lists
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // AUTOMATIC CLASS TEACHER DEMOTION INTERFACE
        OutlinedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LockOpen, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Automated Class Teacher Assignment & Trans-Demotions", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onErrorContainer)
                }
                Text("Selecting a teacher and clicking 'Execute' triggers a Firestore Transaction. The previous Class Teacher is instantly stripped of designation, and boundaries revoked.", style = MaterialTheme.typography.bodySmall)

                var targetTeacherId by remember { mutableStateOf("") }
                var targetClassName by remember { mutableStateOf("Class 5") }
                var showDemoteTeacherDropdown by remember { mutableStateOf(false) }
                var showDemoteClassDropdown by remember { mutableStateOf(false) }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Teacher Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        val activeSelectorLabel = teachers.find { it.teacherId == targetTeacherId }?.name ?: "Select staff B"
                        OutlinedButton(
                            onClick = { showDemoteTeacherDropdown = true },
                            modifier = Modifier.fillMaxWidth().testTag("assign_teacher_b_trigger")
                        ) {
                            Text(activeSelectorLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }

                        DropdownMenu(
                            expanded = showDemoteTeacherDropdown,
                            onDismissRequest = { showDemoteTeacherDropdown = false },
                            modifier = Modifier.testTag("demote_teacher_menu")
                        ) {
                            teachers.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t.name) },
                                    onClick = {
                                        targetTeacherId = t.teacherId
                                        showDemoteTeacherDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Class Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { showDemoteClassDropdown = true },
                            modifier = Modifier.fillMaxWidth().testTag("assign_class_demote_trigger")
                        ) {
                            Text(targetClassName)
                        }

                        DropdownMenu(
                            expanded = showDemoteClassDropdown,
                            onDismissRequest = { showDemoteClassDropdown = false },
                            modifier = Modifier.testTag("demote_class_menu")
                        ) {
                            classOptions.forEach { cls ->
                                DropdownMenuItem(
                                    text = { Text(cls) },
                                    onClick = {
                                        targetClassName = cls
                                        showDemoteClassDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        if (targetTeacherId.isEmpty()) {
                            Toast.makeText(context, "Please select Teacher B!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.assignClassTeacher(targetTeacherId, targetClassName) { success ->
                            if (success) {
                                Toast.makeText(context, "Trans-demoted previous incumbent! Staff updated in Firestore.", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Assignment / demotion completed.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("execute_demotion_transaction_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Filled.SwapHoriz, "Swap")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Execute Transaction Assignment", fontWeight = FontWeight.Bold)
                }
            }
        }

        // REGISTRATION FORM
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = glassCardColors(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Instructor Registration Form", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                // Name Input
                OutlinedTextField(
                    value = tName,
                    onValueChange = { tName = it.uppercase() },
                    label = { Text("Teacher Name") },
                    leadingIcon = { Icon(Icons.Filled.Person, "Name") },
                    modifier = Modifier.fillMaxWidth().testTag("teacher_name_input")
                )
                @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
                androidx.compose.material3.ExposedDropdownMenuBox(
                    expanded = isTGenderExpanded,
                    onExpandedChange = { isTGenderExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = tGender,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Gender") },
                        trailingIcon = { androidx.compose.material3.ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTGenderExpanded) },
                        colors = androidx.compose.material3.ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isTGenderExpanded,
                        onDismissRequest = { isTGenderExpanded = false }
                    ) {
                        listOf("Male", "Female", "Other").forEach { g ->
                            androidx.compose.material3.DropdownMenuItem(
                                text = { Text(g) },
                                onClick = { 
                                    tGender = g
                                    isTGenderExpanded = false 
                                }
                            )
                        }
                    }
                }

                // Drop-down for Class Selector
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = selectedClassVal,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Appointed Class Level") },
                        leadingIcon = { Icon(Icons.Filled.Class, "Class Selection") },
                        trailingIcon = { 
                            IconButton(onClick = { showTClassDropdown = !showTClassDropdown }) {
                                Icon(Icons.Filled.ArrowDropDown, "Open Dropdown")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showTClassDropdown = true }
                            .testTag("teacher_class_trigger")
                    )

                    DropdownMenu(
                        expanded = showTClassDropdown,
                        onDismissRequest = { showTClassDropdown = false },
                        modifier = Modifier.testTag("teacher_class_menu")
                    ) {
                        classOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    selectedClassVal = opt
                                    showTClassDropdown = false
                                },
                                modifier = Modifier.testTag("opt_tclass_$opt")
                            )
                        }
                    }
                }

                // PRIMARY SUBJECT SELECTOR (Radio Dropdown / Selector)
                Text("1. Primary Expert Subject (Single Selection)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                var showPrimaryDropdown by remember { mutableStateOf(false) }
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { showPrimaryDropdown = !showPrimaryDropdown },
                        modifier = Modifier.fillMaxWidth().testTag("primary_subject_trigger")
                    ) {
                        Text(if (primarySubject.isEmpty()) "Select Primary Subject" else "Primary: $primarySubject", fontWeight = FontWeight.SemiBold)
                    }

                    DropdownMenu(
                        expanded = showPrimaryDropdown,
                        onDismissRequest = { showPrimaryDropdown = false },
                        modifier = Modifier.testTag("primary_subject_menu")
                    ) {
                        selectableSubjects.forEach { sub ->
                            DropdownMenuItem(
                                text = { Text(sub) },
                                onClick = {
                                    primarySubject = sub
                                    showPrimaryDropdown = false
                                }
                            )
                        }
                    }
                }

                // SECONDARY SUBJECT COMPONENT (Checkbox Interface)
                Text("2. Secondary Support Subjects (Multi-Select Checkbox)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.secondary)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        selectableSubjects.forEach { item ->
                            val isChecked = secondarySubjects[item] ?: false
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { secondarySubjects[item] = !isChecked }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { secondarySubjects[item] = it },
                                    modifier = Modifier.testTag("checkbox_sub_$item")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(item, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = tPhone,
                    onValueChange = { tPhone = it },
                    label = { Text("Phone Number") },
                    modifier = Modifier.fillMaxWidth().testTag("teacher_phone_input")
                )

                OutlinedTextField(
                    value = tEmail,
                    onValueChange = { tEmail = it },
                    label = { Text("Corporate Email Address") },
                    modifier = Modifier.fillMaxWidth().testTag("teacher_email_input")
                )

                OutlinedTextField(
                    value = tDOB,
                    onValueChange = { tDOB = it },
                    label = { Text("Date of Birth (DD-MM-YYYY)") },
                    modifier = Modifier.fillMaxWidth().testTag("teacher_dob_input")
                )

                Button(
                    onClick = {
                        if (tName.trim().isEmpty()) {
                            Toast.makeText(context, "Teacher Name cannot be empty!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val cleanDOB = tDOB.trim()
                        if (cleanDOB.isEmpty()) {
                            Toast.makeText(context, "Date of Birth (DD-MM-YYYY) is required for initial password setup!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val finalId = "T-${System.currentTimeMillis().toString().takeLast(6)}"
                        val extraChecked = secondarySubjects.filter { it.value }.keys.joinToString(", ")

                        val finalEmail = if (tEmail.contains("@")) tEmail else "$finalId@sdps.com"
                        val newTeacher = Teacher(
                            teacherId = finalId,
                            name = tName,
                            subject = "$primarySubject (Primary)",
                            classesAssigned = selectedClassVal,
                            phone = tPhone,
                            email = finalEmail,
                            classTeacherOf = "",
                            primarySubject = primarySubject,
                            secondarySubjects = extraChecked,
                            joiningDate = cleanDOB
                        )

                        viewModel.addOrUpdateTeacher(newTeacher)
                        
                        val newUser = com.example.data.model.User(
                            userId = finalId,
                            uid = "",
                            name = tName,
                            role = "TEACHER",
                            roleCode = "TC-12",
                            email = finalEmail,
                            phone = tPhone,
                            passwordHash = viewModel.sha256Hex(cleanDOB),
                            isFirstLogin = true,
                            className = selectedClassVal,
                            dob = cleanDOB
                        )
                        viewModel.addUser(newUser) { success, message ->
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            if (success) {
                                // Reset only after the Firestore user document was confirmed.
                                tName = ""
                                tPhone = ""
                                tEmail = ""
                                tDOB = ""
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("submit_teacher_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.PersonAddAlt1, "Add", modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Register & Save to Firestore", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
            }
        }

        // DESIGN PREVIEW COMPONENT
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Live Teacher State Preview Rules",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Assigned Class Level: $selectedClassVal", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text("Primary Expert Subject: ${if (primarySubject.isEmpty()) "Not chosen" else primarySubject}", style = MaterialTheme.typography.bodyMedium)
                val secondaryText = secondarySubjects.filter { it.value }.keys.joinToString(", ")
                Text("Secondary Support Subjects: ${if (secondaryText.isEmpty()) "None selected" else secondaryText}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

// Dynamic Credential Badge Details Helper
fun getCredentialBadgeDetails(userRole: String, userEmail: String, classTeacherOf: String): Triple<Boolean, Color, ImageVector>? {
    val role = userRole.uppercase().trim()
    val isPrincipal = (userEmail.equals("theshiwamlaptop@gmail.com", ignoreCase = true) && role == "PRINCIPAL") || role == "PRINCIPAL"
    val isHeadAdmin = role == "HEAD_ADMIN"
    val isClassTeacher = (role == "TEACHER" || role == "CLASS_TEACHER") && classTeacherOf.isNotEmpty()
    val isAdmin = role == "ADMIN"
    
    if (!isPrincipal && !isHeadAdmin && !isClassTeacher && !isAdmin) return null
    
    val badgeColor = if (isPrincipal) Color(0xFFFFD700) else if (isHeadAdmin) Color(0xFFF59E0B) else if (isClassTeacher) Color(0xFFC0C0C0) else Color(0xFF3B82F6)
    val emblemIcon = if (isPrincipal) Icons.Filled.Stars else if (isHeadAdmin) Icons.Filled.Shield else if (isClassTeacher) Icons.Filled.School else Icons.Filled.AdminPanelSettings
    
    return Triple(true, badgeColor, emblemIcon)
}

@Composable
fun DynamicRoleCredentialBadge(
    userRole: String,
    userEmail: String,
    classTeacherOf: String,
    modifier: Modifier = Modifier
) {
    val badgeDetails = getCredentialBadgeDetails(userRole, userEmail, classTeacherOf) ?: return
    val badgeColor = badgeDetails.second
    val emblemIcon = badgeDetails.third

    val role = userRole.uppercase().trim()
    val isPrincipal = (userEmail.equals("theshiwamlaptop@gmail.com", ignoreCase = true) && role == "PRINCIPAL") || role == "PRINCIPAL"
    val isHeadAdmin = role == "HEAD_ADMIN"
    val isClassTeacher = (role == "TEACHER" || role == "CLASS_TEACHER") && classTeacherOf.isNotEmpty()

    val badgeTitle = when {
        isPrincipal -> "PRINCIPAL Of The School"
        isHeadAdmin -> "HEAD ADMIN Of The School"
        isClassTeacher -> "Class Teacher"
        else -> "ADMIN Of The School"
    }

    val overlayText = when {
        isPrincipal -> "PRINCIPAL Of The School - CHIEF EXECUTIVE & ACADEMIC HEAD"
        isHeadAdmin -> "HEAD ADMIN Of The School - SENIOR OPERATIONS LEAD"
        isClassTeacher -> "CLASS TEACHER Of Class: $classTeacherOf - CERTIFIED EDUCATOR"
        else -> "ADMIN Of The School - OPERATIONS COORDINATOR"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("dynamic_credential_badge_${userRole.lowercase()}"),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(2.dp, Brush.sweepGradient(listOf(badgeColor, Color(0xFFF59E0B), badgeColor))),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)) // Deep Space Slate navy black
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(badgeColor, Color(0xFF78350F), badgeColor)
                        )
                    )
                    .padding(2.5.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF3B82F6)), // Royal blue insert
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(3.dp)
                        .clip(CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(
                        imageVector = emblemIcon,
                        contentDescription = "Badge Emblem Icon",
                        tint = badgeColor,
                        modifier = Modifier
                            .size(28.dp)
                            .align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = badgeTitle.uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp
                        ),
                        color = badgeColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Filled.Verified,
                        contentDescription = "Verified Status",
                        tint = badgeColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = overlayText,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White.copy(alpha = 0.9f)
                )
            }
        }
    }
}

@Composable
fun SmartNotificationFeed(
    viewModel: SchoolViewModel,
    currentUser: User?,
    modifier: Modifier = Modifier
) {
    val rawNotifications by viewModel.notificationsState.collectAsState()
    
    val userRole = currentUser?.role?.uppercase()?.trim() ?: ""
    val userId = currentUser?.userId ?: ""
    val userEmail = currentUser?.email ?: ""
    
    val myNotifications = remember(rawNotifications, userRole, userId, userEmail) {
        rawNotifications.filter { notif ->
            if (userRole == "PRINCIPAL" || userRole == "HEAD_ADMIN") {
                (notif.userId == "PRINCIPAL" || notif.userId == "HEAD_ADMIN")
            } else {
                notif.userId == userId || notif.userId == userEmail
            }
        }
    }
    
    if (myNotifications.isNotEmpty()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.95f)
            ),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Notifications,
                        contentDescription = "Notification Alerts",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Real-Time System Alerts",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.weight(1f)
                    )
                    if (myNotifications.size > 1) {
                        Text(
                            text = "${myNotifications.size} Alerts",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                
                myNotifications.take(3).forEach { alert ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val icon = when (alert.type) {
                            "APPROVAL_PENDING", "DELETE_REQUEST" -> Icons.Filled.HourglassEmpty
                            "APPROVED" -> Icons.Filled.CheckCircle
                            "REJECTED" -> Icons.Filled.Close
                            else -> Icons.Filled.Info
                        }
                        val tint = when (alert.type) {
                            "APPROVAL_PENDING", "DELETE_REQUEST" -> Color(0xFFF59E0B)
                            "APPROVED" -> Color(0xFF10B981)
                            "REJECTED" -> Color(0xFFEF4444)
                            else -> MaterialTheme.colorScheme.primary
                        }
                        
                        Icon(
                            imageVector = icon,
                            contentDescription = alert.type,
                            tint = tint,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = alert.title,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = alert.message,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { viewModel.deleteNotification(alert.notificationId) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Dismiss",
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrincipalApprovalQueueCard(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val pendingStudents by viewModel.pendingApprovalStudentsState.collectAsState()
    var selectedStudentForReject by remember { mutableStateOf<Student?>(null) }
    var rejectionRemarks by remember { mutableStateOf("") }
    
    if (pendingStudents.isNotEmpty()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Stars,
                        contentDescription = "Approval Center",
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Scholar Admission Approval Center",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Review and evaluate pending registrations submitted by staff administrators and class teachers.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                pendingStudents.forEach { student ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Face,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = student.name,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFFEF3C7))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "PENDING",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row {
                                    Text("Class: ", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    Text(student.className, style = MaterialTheme.typography.bodySmall)
                                }
                                Row {
                                    Text("Admission No: ", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    Text(student.admissionNo, style = MaterialTheme.typography.bodySmall)
                                }
                                Row {
                                    Text("Guardian: ", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    Text(student.fatherName, style = MaterialTheme.typography.bodySmall)
                                }
                                Row {
                                    Text("Submitted By: ", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    Text("${student.submittedByRole} (at ${student.submittedAt})", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.approveStudentAdmission(student) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("approve_btn_${student.studentId}"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.Check, contentDescription = "Approve", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                
                                OutlinedButton(
                                    onClick = { selectedStudentForReject = student; rejectionRemarks = "" },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("reject_btn_${student.studentId}"),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                    border = BorderStroke(1.dp, Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Reject", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    selectedStudentForReject?.let { target ->
        AlertDialog(
            onDismissRequest = { selectedStudentForReject = null },
            title = { Text("Enter Rejection Remarks") },
            text = {
                Column {
                    Text("Provide a reason/remarks for rejecting the admission of ${target.name}.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectionRemarks,
                        onValueChange = { rejectionRemarks = it },
                        modifier = Modifier.fillMaxWidth().testTag("rejection_remarks_field"),
                        placeholder = { Text("e.g. Incomplete verification logs") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.rejectStudentAdmission(target, rejectionRemarks.ifBlank { "Incomplete Document Submission Details" })
                        selectedStudentForReject = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Reject Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedStudentForReject = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==========================================
// NEW PRODUCTION PAYMENT & ERP MODULE COMPONENTS
// ==========================================

@Composable
fun MultiMonthPaymentCollectionDialog(
    student: Student,
    calculatedLedger: List<FeeLedgerEntry>,
    currentUserRole: String,
    initialSelectedMonths: Set<String>,
    onDismiss: () -> Unit,
    onConfirmPayment: (selectedMonths: List<String>, paymentMode: String, transactionRef: String, totalPaidNow: Double, remarks: String, receiptNo: String) -> Unit
) {
    val context = LocalContext.current
    val academicMonths = listOf("April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March")
    
    // Default selection: first unpaid month if available
    val firstUnpaid = calculatedLedger.find { it.balance > 0 }?.month
    var selectedMonths by remember { mutableStateOf(initialSelectedMonths.ifEmpty { if (firstUnpaid != null) setOf(firstUnpaid) else emptySet() }) }
    
    var paymentMode by remember { mutableStateOf("Cash") } // "Cash" or "UPI"
    var transactionRef by remember { mutableStateOf("") }
    var receiptNo by remember { mutableStateOf("REC-${System.currentTimeMillis().toString().takeLast(6)}") }
    var concessionText by remember { mutableStateOf("0") }
    var lateFeeText by remember { mutableStateOf("0") }
    var remarksText by remember { mutableStateOf("") }
    var customPaidAmountText by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val selectedEntries = calculatedLedger.filter { selectedMonths.contains(it.month) }
    val selectedBaseTotal = selectedEntries.sumOf { maxOf(0.0, it.totalPayable - it.paidAmount) }
    
    val concessionVal = concessionText.toDoubleOrNull() ?: 0.0
    val lateVal = lateFeeText.toDoubleOrNull() ?: 0.0
    val calculatedNetPayable = maxOf(0.0, selectedBaseTotal + lateVal - concessionVal)
    
    val totalPaidNow = if (customPaidAmountText.isNotBlank()) (customPaidAmountText.toDoubleOrNull() ?: calculatedNetPayable) else calculatedNetPayable

    // Grand totals for overall student account
    val totalBilledAnnual = calculatedLedger.sumOf { it.totalPayable - it.arrear }
    val totalPaidAnnual = calculatedLedger.sumOf { it.paidAmount }
    val totalPendingAnnual = maxOf(0.0, totalBilledAnnual - totalPaidAnnual)

    Dialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Payments, "Fee Collection", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Monthly Fee Collection",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = { if (!isSaving) onDismiss() }) {
                        Icon(Icons.Filled.Close, "Close", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // 1. Student Details Top Card
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = glassCardColors(),
                        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Person, contentDescription = student.name, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(student.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("Class: ${student.className} | Roll No: ${student.rollNo}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Admission No: ${student.admissionNo.ifBlank { "N/A" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            
                            val statusText = if (totalPendingAnnual <= 0) "FULLY PAID" else if (totalPaidAnnual > 0) "PARTIAL" else "DUES PENDING"
                            val statusBg = if (totalPendingAnnual <= 0) Color(0xFFD1FAE5) else if (totalPaidAnnual > 0) Color(0xFFFEF3C7) else Color(0xFFFEE2E2)
                            val statusTxt = if (totalPendingAnnual <= 0) Color(0xFF10B981) else if (totalPaidAnnual > 0) Color(0xFFF59E0B) else Color(0xFFEF4444)
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(statusBg)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(statusText, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = statusTxt)
                            }
                        }
                    }

                    // 2. Monthly Fee Collection Cards / Chips
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Select Months to Collect", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${selectedMonths.size} month(s) selected", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }

                        // 12 Months Grid (Selectable cards)
                        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                            val isPhone = maxWidth < 480.dp
                            val colCount = if (isPhone) 3 else 4
                            val chunkedMonths = academicMonths.chunked(colCount)

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                chunkedMonths.forEach { rowMonths ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        rowMonths.forEach { monthName ->
                                            val entry = calculatedLedger.find { it.month == monthName }
                                            val isPaid = entry != null && entry.paidAmount >= entry.totalPayable && entry.totalPayable > 0
                                            val isSelected = selectedMonths.contains(monthName)
                                            val remainingForMonth = entry?.balance ?: 1000.0

                                            val cardBg = when {
                                                isPaid -> Color(0xFFE6F4EA) // Green disabled
                                                isSelected -> MaterialTheme.colorScheme.primaryContainer
                                                else -> MaterialTheme.colorScheme.surface
                                            }
                                            val cardBorderColor = when {
                                                isPaid -> Color(0xFF34A853)
                                                isSelected -> MaterialTheme.colorScheme.primary
                                                else -> MaterialTheme.colorScheme.outlineVariant
                                            }

                                            Card(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(68.dp)
                                                    .border(
                                                        width = if (isSelected || isPaid) 2.dp else 1.dp,
                                                        color = cardBorderColor,
                                                        shape = RoundedCornerShape(12.dp)
                                                    )
                                                    .clickable(enabled = !isPaid) {
                                                        selectedMonths = if (isSelected) {
                                                            selectedMonths - monthName
                                                        } else {
                                                            selectedMonths + monthName
                                                        }
                                                    },
                                                colors = CardDefaults.cardColors(containerColor = cardBg),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .padding(6.dp),
                                                    verticalArrangement = Arrangement.SpaceBetween,
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        monthName,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp,
                                                        color = if (isPaid) Color(0xFF34A853) else MaterialTheme.colorScheme.onSurface
                                                    )

                                                    if (isPaid) {
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF34A853), modifier = Modifier.size(12.dp))
                                                            Spacer(modifier = Modifier.width(2.dp))
                                                            Text("PAID", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF34A853))
                                                        }
                                                    } else {
                                                        Text(
                                                            "₹${"%.0f".format(remainingForMonth)}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        // Fill empty slots if last row has fewer items
                                        repeat(colCount - rowMonths.size) {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. Fee Summary Metrics Box
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("FEE SUMMARY METRICS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Annual Billed Fee:", style = MaterialTheme.typography.bodySmall)
                                Text("₹${"%,.0f".format(totalBilledAnnual)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Paid So Far:", style = MaterialTheme.typography.bodySmall)
                                Text("₹${"%,.0f".format(totalPaidAnnual)}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Outstanding Dues:", style = MaterialTheme.typography.bodySmall)
                                Text("₹${"%,.0f".format(totalPendingAnnual)}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), thickness = 0.5.dp)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Selected Months Total:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("₹${"%,.0f".format(selectedBaseTotal)}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    // 4. Concession / Fine Adjustments & Payment Details
                    Text("Payment & Adjustment Options", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = lateFeeText,
                            onValueChange = { lateFeeText = it },
                            label = { Text("Late Fee / Fine") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            leadingIcon = { Text("₹", modifier = Modifier.padding(start = 12.dp)) }
                        )
                        OutlinedTextField(
                            value = concessionText,
                            onValueChange = { concessionText = it },
                            label = { Text("Concession Discount") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            leadingIcon = { Text("₹", modifier = Modifier.padding(start = 12.dp)) }
                        )
                    }

                    OutlinedTextField(
                        value = remarksText,
                        onValueChange = { remarksText = it },
                        label = { Text("Remarks (Mandatory for discounts/fines)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        placeholder = { Text("e.g. Approved sibling discount by Principal") }
                    )

                    Text("Payment Method", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FilterChip(
                            selected = paymentMode == "Cash",
                            onClick = { paymentMode = "Cash" },
                            label = { Text("Cash Payment") },
                            leadingIcon = { Icon(Icons.Filled.Payments, null) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = paymentMode == "UPI",
                            onClick = { paymentMode = "UPI" },
                            label = { Text("UPI / Online Transfer") },
                            leadingIcon = { Icon(Icons.Filled.AccountBalanceWallet, null) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (paymentMode == "UPI") {
                        OutlinedTextField(
                            value = transactionRef,
                            onValueChange = { transactionRef = it },
                            label = { Text("UPI Transaction Ref / UTR ID") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            placeholder = { Text("e.g. UTR-982183120") }
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = customPaidAmountText,
                            onValueChange = { customPaidAmountText = it },
                            label = { Text("Amount Paid Now") },
                            placeholder = { Text("₹${"%.0f".format(calculatedNetPayable)}") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            leadingIcon = { Text("₹", modifier = Modifier.padding(start = 12.dp)) }
                        )
                        OutlinedTextField(
                            value = receiptNo,
                            onValueChange = { receiptNo = it },
                            label = { Text("Receipt No.") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    if (errorMessage != null) {
                        Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(errorMessage!!, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Footer Actions
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .imePadding(),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shadowElevation = 8.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Net Payable Amount:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("₹${"%,.0f".format(totalPaidNow)}", style = MaterialTheme.typography.headlineSmall, color = Color(0xFF10B981), fontWeight = FontWeight.ExtraBold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (selectedMonths.isEmpty()) {
                                    errorMessage = "Please select at least one unpaid month to collect fee!"
                                } else if ((concessionVal > 0.0 || lateVal > 0.0) && remarksText.isBlank()) {
                                    errorMessage = "Remarks explanation is mandatory when introducing Concession Discount or Late Fine!"
                                } else if (paymentMode == "UPI" && transactionRef.isBlank()) {
                                    errorMessage = "Please enter UPI Transaction / UTR reference ID for record keeping."
                                } else {
                                    isSaving = true
                                    errorMessage = null
                                    onConfirmPayment(
                                        selectedMonths.toList(),
                                        paymentMode,
                                        transactionRef,
                                        totalPaidNow,
                                        remarksText,
                                        receiptNo
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            enabled = !isSaving
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                            } else {
                                Icon(Icons.Filled.CheckCircle, "Confirm Fee Payment")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Process Fee & Issue PDF Receipt", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransportManagementSection(
    student: Student,
    viewModel: SchoolViewModel,
    currentUserRole: String
) {
    val context = LocalContext.current
    var hasTransport by remember { mutableStateOf(student.hasTransport) }
    var slab by remember { mutableStateOf(student.transportSlab.ifBlank { "0-5 km" }) }
    var transportFeeText by remember { mutableStateOf(student.transportFee.toInt().toString()) }
    var startDate by remember { mutableStateOf(student.transportStartDate.ifBlank { java.time.LocalDate.now().toString() }) }
    var endDate by remember { mutableStateOf(student.transportEndDate) }
    var isSaving by remember { mutableStateOf(false) }

    val isPrincipal = currentUserRole == "PRINCIPAL" || viewModel.currentUser.value?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    val isAdmin = currentUserRole == "ADMIN" || currentUserRole == "HEAD_ADMIN" || isPrincipal

    ElevatedCard(
        colors = glassCardColors(),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DirectionsBus, "Transport", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Transport Service Module", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                Switch(
                    checked = hasTransport,
                    onCheckedChange = { 
                        if (isAdmin) {
                            hasTransport = it
                        } else {
                            Toast.makeText(context, "Only Admin or Principal can assign/remove transport services.", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            HorizontalDivider(thickness = 0.5.dp)

            if (hasTransport) {
                Text("Distance Slab & Billing Rates", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)

                val slabs = listOf("0-5 km" to 500, "5-10 km" to 700, "10-15 km" to 900)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    slabs.forEach { (slabName, defaultRate) ->
                        val isSelected = slab == slabName
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (isAdmin) {
                                    slab = slabName
                                    if (!isPrincipal) {
                                        transportFeeText = defaultRate.toString()
                                    }
                                }
                            },
                            label = { Text("$slabName (₹$defaultRate)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (isPrincipal) {
                    OutlinedTextField(
                        value = transportFeeText,
                        onValueChange = { if (isPrincipal) transportFeeText = it },
                        readOnly = !isPrincipal,
                        label = { Text("Monthly Fee Rate (Editable by Principal)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        leadingIcon = { Text("₹", modifier = Modifier.padding(start = 12.dp)) }
                    )
                } else {
                    Text(
                        text = "Monthly Transport Rate: ₹$transportFeeText",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("Start Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        readOnly = !isAdmin
                    )
                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("End Date (Optional)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        readOnly = !isAdmin
                    )
                }

                // 20th Day Cutoff Billing Rule Notice
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("📜 Transport Billing Enforcement Rule:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            "• Enabling service on or before the 20th charges for the current month onwards.\n" +
                            "• Enabling service after the 20th starts charging from the next month onwards.\n" +
                            "• Disabling on or before 20th stops charges from current month.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (isAdmin) {
                    Button(
                        onClick = {
                            isSaving = true
                            val feeVal = transportFeeText.toDoubleOrNull() ?: 500.0
                            viewModel.updateStudent(student.copy(hasTransport = true, transportSlab = slab))
                            isSaving = false
                            Toast.makeText(context, "Transport Settings Updated Successfully!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Save, "Save Transport Settings")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Transport Configuration", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text(
                    "Transport service is currently INACTIVE for this student.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
                if (isAdmin) {
                    Button(
                        onClick = {
                            viewModel.updateStudent(student.copy(hasTransport = false, transportSlab = "None"))
                            Toast.makeText(context, "Transport Service Removed.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Confirm Transport Removal")
                    }
                }
            }
        }
    }
}

@Composable
fun BookDistributionSection(
    student: Student,
    viewModel: SchoolViewModel,
    currentUserRole: String
) {
    val context = LocalContext.current
    val allClassBooks by viewModel.classBooksState.collectAsState()
    val allIssuedBooks by viewModel.issuedBooksState.collectAsState()

    val classBooksForStudent = allClassBooks.filter { it.className.equals(student.className, ignoreCase = true) }
    val issuedBooksForStudent = allIssuedBooks.filter { it.studentId == student.studentId }

    var showIssueDialog by remember { mutableStateOf(false) }
    var selectedBookToIssue by remember { mutableStateOf<ClassBook?>(null) }
    var issueDateText by remember { mutableStateOf(java.time.LocalDate.now().toString()) }

    val isAdminOrPrincipal = currentUserRole == "ADMIN" || currentUserRole == "PRINCIPAL" || currentUserRole == "HEAD_ADMIN"
    val isPrincipalOnly = currentUserRole == "PRINCIPAL" || viewModel.currentUser.value?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Class Books Catalog
        ElevatedCard(
            colors = glassCardColors(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MenuBook, "Book Catalog", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Class Books Catalog (${student.className})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    if (isAdminOrPrincipal) {
                        Button(
                            onClick = { showIssueDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Filled.Add, "Issue Book", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Issue Book", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                HorizontalDivider(thickness = 0.5.dp)

                if (classBooksForStudent.isEmpty()) {
                    Text("No registered book list found for class ${student.className}.", fontSize = 12.sp, color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                } else {
                    classBooksForStudent.forEach { book ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(book.bookName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Subject: ${book.subject} | Author: ${book.author}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("₹${"%.0f".format(book.price)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }

        // Issued Books Log
        ElevatedCard(
            colors = glassCardColors(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LibraryBooks, "Issued Books", tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Issued Books History (${issuedBooksForStudent.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(thickness = 0.5.dp)

                if (issuedBooksForStudent.isEmpty()) {
                    Text("No books currently issued to this student.", fontSize = 12.sp, color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                } else {
                    issuedBooksForStudent.forEach { issued ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(issued.bookName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF10B981))
                                    Text("Issued Date: ${issued.issueDate} | By: ${issued.issuedBy}", fontSize = 11.sp, color = Color(0xFF15803D))
                                }

                                if (isPrincipalOnly) {
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteIssuedBook(issued.issueId)
                                            Toast.makeText(context, "Issued book record removed by Principal.", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Filled.Delete, "Return/Remove Book", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showIssueDialog) {
        val currentUser by viewModel.currentUser.collectAsState()
        AlertDialog(
            onDismissRequest = { showIssueDialog = false },
            title = { Text("Issue Book to ${student.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select a book from ${student.className} catalog:")
                    
                    if (classBooksForStudent.isEmpty()) {
                        Text("No books registered for this class.", color = Color.Red, fontSize = 12.sp)
                    } else {
                        classBooksForStudent.forEach { b ->
                            FilterChip(
                                selected = selectedBookToIssue?.bookId == b.bookId,
                                onClick = { selectedBookToIssue = b },
                                label = { Text("${b.bookName} (${b.subject})") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    OutlinedTextField(
                        value = issueDateText,
                        onValueChange = { issueDateText = it },
                        label = { Text("Issue Date") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val book = selectedBookToIssue
                        if (book != null) {
                            val issued = IssuedBook(
                                issueId = UUID.randomUUID().toString(),
                                studentId = student.studentId,
                                studentName = student.name,
                                className = student.className,
                                bookName = book.bookName,
                                issueDate = issueDateText,
                                issuedBy = currentUser?.name ?: "Admin",
                                status = "Issued"
                            )
                            viewModel.issueBook(issued)
                            showIssueDialog = false
                            Toast.makeText(context, "Book '${book.bookName}' Issued Successfully!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Please select a book to issue.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = selectedBookToIssue != null
                ) {
                    Text("Confirm Issue")
                }
            },
            dismissButton = {
                TextButton(onClick = { showIssueDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SchoolLogoImage(
    modifier: Modifier = Modifier,
    contentDescription: String = "School Logo",
    contentScale: ContentScale = ContentScale.Fit
) {
    val context = LocalContext.current
    val isDrawableAvailable = remember {
        try {
            androidx.core.content.ContextCompat.getDrawable(context, R.drawable.app_logo) != null
        } catch (e: Throwable) {
            false
        }
    }

    if (isDrawableAvailable) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = contentDescription,
            contentScale = contentScale,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier
                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.School,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(4.dp)
            )
        }
    }
}
