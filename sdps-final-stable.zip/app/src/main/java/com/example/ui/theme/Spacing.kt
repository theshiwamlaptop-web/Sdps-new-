package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class Spacing(
    val none: Dp = 0.dp,
    val space2: Dp = 2.dp,
    val space4: Dp = 4.dp,
    val space6: Dp = 6.dp,
    val space8: Dp = 8.dp,
    val space10: Dp = 10.dp,
    val space12: Dp = 12.dp,
    val space14: Dp = 14.dp,
    val space16: Dp = 16.dp,
    val space20: Dp = 20.dp,
    val space24: Dp = 24.dp,
    val space32: Dp = 32.dp,
    val space40: Dp = 40.dp,
    val space48: Dp = 48.dp,
    val space56: Dp = 56.dp,
    val space64: Dp = 64.dp
)

val LocalSpacing = staticCompositionLocalOf { Spacing() }

val AppSpacing: Spacing
    @Composable
    @ReadOnlyComposable
    get() = LocalSpacing.current

// Global constants for quick direct references
val Space2 = 2.dp
val Space4 = 4.dp
val Space6 = 6.dp
val Space8 = 8.dp
val Space10 = 10.dp
val Space12 = 12.dp
val Space14 = 14.dp
val Space16 = 16.dp
val Space20 = 20.dp
val Space24 = 24.dp
val Space32 = 32.dp
val Space40 = 40.dp
val Space48 = 48.dp
val Space56 = 56.dp
val Space64 = 64.dp
