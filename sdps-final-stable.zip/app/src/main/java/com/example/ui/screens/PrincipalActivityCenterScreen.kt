package com.example.ui.screens

import com.example.ui.components.SecureScreen
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.ui.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.*
import com.example.ui.theme.glassCardColors

enum class ActivityTab(val label: String, val icon: ImageVector) {
    AUDIT_STREAM("Audit Stream", Icons.Filled.History),
    NOTIFICATIONS_APPROVALS("Approvals & Alerts", Icons.Filled.NotificationsActive),
    SECURITY_ACCESS("Security & Auth", Icons.Filled.Security),
    FINANCE_ACADEMICS("Fees & Operations", Icons.Filled.AccountBalance)
}

enum class AuditCategory(val displayName: String) {
    ALL("All Events"),
    SECURITY("Security & Auth"),
    STUDENTS("Students"),
    TEACHERS("Teachers & Staff"),
    FEES("Fees & Finance"),
    ATTENDANCE("Attendance"),
    ACADEMICS("Academics & Timetable"),
    CALENDAR_NOTICES("Calendar & Notices"),
    LIBRARY("Library & Books"),
    CHAT("Chat Oversight")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalActivityCenterScreen(
    viewModel: SchoolViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    SecureScreen()
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogsState.collectAsStateWithLifecycle()
    val notifications by viewModel.notificationsState.collectAsStateWithLifecycle()

    val userRole = currentUser?.role?.uppercase()?.trim() ?: ""
    val isAuthorized = userRole == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)

    if (!isAuthorized) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = glassCardColors()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Access Denied",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Restricted Access",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = "The Principal Activity Center is restricted to Principal and School Management.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { onNavigate(AppScreen.DASHBOARD) },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text("Return to Dashboard")
                    }
                }
            }
        }
        return
    }

    var selectedTab by rememberSaveable { mutableStateOf(ActivityTab.AUDIT_STREAM) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategoryFilter by rememberSaveable { mutableStateOf(AuditCategory.ALL) }
    var selectedAuditDetail by remember { mutableStateOf<AuditLog?>(null) }

    val pendingApprovalsCount = remember(notifications) {
        notifications.count { it.type == "DELETE_REQUEST" || it.type == "APPROVAL_PENDING" }
    }

    val securityAuditCount = remember(auditLogs) {
        auditLogs.count { isSecurityLog(it.action) }
    }

    val todayAuditCount = remember(auditLogs) {
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        auditLogs.count { it.timestamp >= todayStart }
    }

    // Filter audit logs based on tab, category, and search query
    val filteredLogs = remember(auditLogs, selectedTab, selectedCategoryFilter, searchQuery) {
        var list = auditLogs.sortedByDescending { it.timestamp }

        when (selectedTab) {
            ActivityTab.SECURITY_ACCESS -> {
                list = list.filter { isSecurityLog(it.action) }
            }
            ActivityTab.FINANCE_ACADEMICS -> {
                list = list.filter { isFinanceOrAcademicLog(it.action) }
            }
            else -> {
                if (selectedCategoryFilter != AuditCategory.ALL) {
                    list = list.filter { getCategoryForLog(it.action) == selectedCategoryFilter }
                }
            }
        }

        if (searchQuery.isNotBlank()) {
            val query = searchQuery.trim().lowercase()
            list = list.filter {
                it.action.lowercase().contains(query) ||
                it.userName.lowercase().contains(query) ||
                it.userId.lowercase().contains(query) ||
                it.oldValue.lowercase().contains(query) ||
                it.newValue.lowercase().contains(query)
            }
        }

        list
    }

    // Filtered notifications
    val filteredNotifications = remember(notifications, searchQuery) {
        var list = notifications.sortedByDescending { it.timestamp }
        if (searchQuery.isNotBlank()) {
            val query = searchQuery.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(query) ||
                it.message.lowercase().contains(query) ||
                it.type.lowercase().contains(query)
            }
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Principal Activity Center",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Comprehensive Audit Stream & Action Center",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { onNavigate(AppScreen.DASHBOARD) },
                        modifier = Modifier.testTag("activity_center_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Dashboard")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.forceSync()
                            Toast.makeText(context, "Refreshing audit trail & synchronizing cloud...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("activity_center_refresh_btn")
                    ) {
                        Icon(Icons.Filled.Sync, contentDescription = "Sync Data")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Metrics Summary Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActivityStatChip(
                    label = "Total Logs",
                    value = "${auditLogs.size}",
                    icon = Icons.Filled.ListAlt,
                    color = MaterialTheme.colorScheme.primary
                )
                ActivityStatChip(
                    label = "Today's Events",
                    value = "$todayAuditCount",
                    icon = Icons.Filled.Today,
                    color = Color(0xFF0284C7)
                )
                ActivityStatChip(
                    label = "Pending Approvals",
                    value = "$pendingApprovalsCount",
                    icon = Icons.Filled.PendingActions,
                    color = if (pendingApprovalsCount > 0) Color(0xFFEF4444) else Color(0xFF10B981)
                )
                ActivityStatChip(
                    label = "Security / Auth",
                    value = "$securityAuditCount",
                    icon = Icons.Filled.Security,
                    color = Color(0xFFF59E0B)
                )
            }

            // Tab Selection
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                edgePadding = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                ActivityTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    Tab(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = tab.label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                                if (tab == ActivityTab.NOTIFICATIONS_APPROVALS && pendingApprovalsCount > 0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.error)
                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "$pendingApprovalsCount",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
            }

            // Search Bar & Filter Strip
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by user, action code, or keyword...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("activity_search_input")
                )

                // Category chips (visible on ALL AUDIT STREAM tab)
                if (selectedTab == ActivityTab.AUDIT_STREAM) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AuditCategory.values().forEach { cat ->
                            FilterChip(
                                selected = selectedCategoryFilter == cat,
                                onClick = { selectedCategoryFilter = cat },
                                label = { Text(cat.displayName, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }
            }

            // Tab Content
            when (selectedTab) {
                ActivityTab.NOTIFICATIONS_APPROVALS -> {
                    NotificationsAndApprovalsView(
                        notifications = filteredNotifications,
                        viewModel = viewModel,
                        currentUser = currentUser
                    )
                }
                else -> {
                    AuditLogsListView(
                        logs = filteredLogs,
                        onLogClick = { selectedAuditDetail = it }
                    )
                }
            }
        }
    }

    // Detail Dialog
    if (selectedAuditDetail != null) {
        AuditDetailDialog(
            log = selectedAuditDetail!!,
            onDismiss = { selectedAuditDetail = null }
        )
    }
}

@Composable
fun ActivityStatChip(
    label: String,
    value: String,
    icon: ImageVector,
    color: Color
) {
    ElevatedCard(
        shape = RoundedCornerShape(12.dp),
        colors = glassCardColors(),
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Column {
                Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = color)
                Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun AuditLogsListView(
    logs: List<AuditLog>,
    onLogClick: (AuditLog) -> Unit
) {
    if (logs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.History,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Text(
                    text = "No audit log records found",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "System events and administrative actions will appear here automatically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    } else {
        // Group logs by Date Header (Today, Yesterday, Earlier this week, Older)
        val groupedLogs = remember(logs) {
            val now = Calendar.getInstance()
            val todayStart = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis

            val yesterdayStart = todayStart - (24 * 60 * 60 * 1000L)
            val weekStart = todayStart - (7 * 24 * 60 * 60 * 1000L)

            logs.groupBy { log ->
                when {
                    log.timestamp >= todayStart -> "Today"
                    log.timestamp >= yesterdayStart -> "Yesterday"
                    log.timestamp >= weekStart -> "Earlier This Week"
                    else -> "Older Records"
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            groupedLogs.forEach { (timeHeader, logGroup) ->
                item {
                    Text(
                        text = timeHeader,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }

                items(logGroup, key = { it.logId }) { log ->
                    AuditLogItemCard(log = log, onClick = { onLogClick(log) })
                }
            }
        }
    }
}

@Composable
fun AuditLogItemCard(
    log: AuditLog,
    onClick: () -> Unit
) {
    val category = getCategoryForLog(log.action)
    val categoryColor = getCategoryColor(category)
    val formattedTime = remember(log.timestamp) {
        val date = Date(log.timestamp)
        SimpleDateFormat("hh:mm a • dd MMM yyyy", Locale.getDefault()).format(date)
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("audit_card_${log.logId}"),
        shape = RoundedCornerShape(12.dp),
        colors = glassCardColors()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(categoryColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = formatActionTitle(log.action),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = categoryColor
                    )
                }

                Text(
                    text = formattedTime,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Actor & Description
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${log.userName} (${log.userId})",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Details line
            if (log.newValue.isNotBlank() || log.oldValue.isNotBlank()) {
                val detailText = when {
                    log.oldValue.isNotBlank() && log.newValue.isNotBlank() -> "${log.oldValue} ➔ ${log.newValue}"
                    log.newValue.isNotBlank() -> log.newValue
                    else -> log.oldValue
                }
                Text(
                    text = detailText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun NotificationsAndApprovalsView(
    notifications: List<AppNotification>,
    viewModel: SchoolViewModel,
    currentUser: com.example.data.model.User?
) {
    val context = LocalContext.current

    if (notifications.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.NotificationsNone,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Text(
                    text = "No notifications or pending approvals",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(notifications, key = { it.notificationId }) { notif ->
                NotificationApprovalCard(
                    notification = notif,
                    onApprove = {
                        viewModel.approveDeletion(
                            notification = notif,
                            principalName = currentUser?.name ?: "Principal",
                            principalId = currentUser?.userId ?: "PRIN001"
                        )
                        Toast.makeText(context, "Request Approved Successfully.", Toast.LENGTH_SHORT).show()
                    },
                    onReject = {
                        viewModel.rejectDeletion(
                            notification = notif,
                            principalName = currentUser?.name ?: "Principal",
                            principalId = currentUser?.userId ?: "PRIN001"
                        )
                        Toast.makeText(context, "Request Rejected.", Toast.LENGTH_SHORT).show()
                    },
                    onMarkRead = {
                        viewModel.markNotificationAsRead(notif.notificationId)
                    },
                    onDelete = {
                        viewModel.deleteNotification(notif.notificationId)
                        Toast.makeText(context, "Notification removed.", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
fun NotificationApprovalCard(
    notification: AppNotification,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onMarkRead: () -> Unit,
    onDelete: () -> Unit
) {
    val isPendingApproval = notification.type == "DELETE_REQUEST" || notification.type == "APPROVAL_PENDING"
    val formattedTime = remember(notification.timestamp) {
        SimpleDateFormat("hh:mm a • dd MMM yyyy", Locale.getDefault()).format(Date(notification.timestamp))
    }

    val typeColor = when (notification.type) {
        "DELETE_REQUEST" -> Color(0xFFEF4444)
        "APPROVAL_PENDING" -> Color(0xFFF59E0B)
        "APPROVED" -> Color(0xFF10B981)
        "REJECTED" -> Color(0xFF6B7280)
        "FEE_REMINDER" -> Color(0xFF0284C7)
        else -> MaterialTheme.colorScheme.primary
    }

    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (!notification.isRead) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(typeColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = notification.type.replace("_", " "),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = typeColor
                    )
                }

                Text(
                    text = formattedTime,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = notification.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = notification.message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Action Buttons for Pending Approvals
            if (isPendingApproval) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), thickness = 0.5.dp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.weight(1f).testTag("approve_btn_${notification.notificationId}"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                        modifier = Modifier.weight(1f).testTag("reject_btn_${notification.notificationId}"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!notification.isRead) {
                        TextButton(onClick = onMarkRead) {
                            Text("Mark as Read", fontSize = 11.sp)
                        }
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete notification", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditDetailDialog(
    log: AuditLog,
    onDismiss: () -> Unit
) {
    val category = getCategoryForLog(log.action)
    val categoryColor = getCategoryColor(category)
    val formattedDate = SimpleDateFormat("EEEE, dd MMMM yyyy • hh:mm:ss a", Locale.getDefault()).format(Date(log.timestamp))

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(categoryColor.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = category.displayName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = categoryColor
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Text(
                    text = formatActionTitle(log.action),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                HorizontalDivider(thickness = 0.5.dp)

                AuditDetailRow(label = "Action Code:", value = log.action)
                AuditDetailRow(label = "Performed By:", value = "${log.userName} (${log.userId})")
                AuditDetailRow(label = "Exact Timestamp:", value = formattedDate)
                AuditDetailRow(label = "Log Unique ID:", value = log.logId)

                if (log.oldValue.isNotBlank()) {
                    AuditDetailRow(label = "Previous State / Target:", value = log.oldValue)
                }

                if (log.newValue.isNotBlank()) {
                    AuditDetailRow(label = "New Value / Action Details:", value = log.newValue)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Close Details")
                }
            }
        }
    }
}

@Composable
fun AuditDetailRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
    }
}

// Helpers
fun getCategoryForLog(action: String): AuditCategory {
    val upper = action.uppercase()
    return when {
        upper.contains("LOGIN") || upper.contains("LOGOUT") || upper.contains("PASSWORD") || upper.contains("ROLE") || upper.contains("DOB") || upper.contains("USER") || upper.contains("SECURITY") -> AuditCategory.SECURITY
        upper.contains("STUDENT") -> AuditCategory.STUDENTS
        upper.contains("TEACHER") || upper.contains("STAFF") || upper.contains("PAYROLL") -> AuditCategory.TEACHERS
        upper.contains("FEE") || upper.contains("LEDGER") || upper.contains("PAYMENT") -> AuditCategory.FEES
        upper.contains("ATTENDANCE") -> AuditCategory.ATTENDANCE
        upper.contains("TIMETABLE") || upper.contains("HOMEWORK") || upper.contains("CLASS") -> AuditCategory.ACADEMICS
        upper.contains("CALENDAR") || upper.contains("NOTICE") || upper.contains("EVENT") -> AuditCategory.CALENDAR_NOTICES
        upper.contains("BOOK") || upper.contains("LIBRARY") -> AuditCategory.LIBRARY
        upper.contains("CHAT") -> AuditCategory.CHAT
        else -> AuditCategory.ALL
    }
}

fun getCategoryColor(category: AuditCategory): Color {
    return when (category) {
        AuditCategory.SECURITY -> Color(0xFFF59E0B)
        AuditCategory.STUDENTS -> Color(0xFF0284C7)
        AuditCategory.TEACHERS -> Color(0xFF8B5CF6)
        AuditCategory.FEES -> Color(0xFF10B981)
        AuditCategory.ATTENDANCE -> Color(0xFFEC4899)
        AuditCategory.ACADEMICS -> Color(0xFF6366F1)
        AuditCategory.CALENDAR_NOTICES -> Color(0xFF14B8A6)
        AuditCategory.LIBRARY -> Color(0xFFD97706)
        AuditCategory.CHAT -> Color(0xFF3B82F6)
        AuditCategory.ALL -> Color(0xFF64748B)
    }
}

fun formatActionTitle(action: String): String {
    return action.replace("_", " ").split(" ")
        .joinToString(" ") { word -> word.lowercase().replaceFirstChar { it.uppercase() } }
}

fun isSecurityLog(action: String): Boolean {
    val u = action.uppercase()
    return u.contains("LOGIN") || u.contains("PASSWORD") || u.contains("ROLE") || u.contains("DOB") || u.contains("USER") || u.contains("SECURITY") || u.contains("DELETE_APPROVED") || u.contains("DELETE_REJECTED")
}

fun isFinanceOrAcademicLog(action: String): Boolean {
    val u = action.uppercase()
    return u.contains("FEE") || u.contains("LEDGER") || u.contains("PAYMENT") || u.contains("TIMETABLE") || u.contains("HOMEWORK") || u.contains("ATTENDANCE")
}
