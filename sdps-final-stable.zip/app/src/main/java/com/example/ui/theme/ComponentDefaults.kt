package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Android-Native Translucent Glass Surface Modifier.
 * Approximates Apple-style glassmorphism: a translucent tinted surface, a soft light-catching
 * border, and a gentle floating shadow. True background blur needs Android 12+ RenderEffect,
 * so this relies on translucency + shadow instead — it looks right on every Android version.
 */
@Composable
fun Modifier.premiumGlassSurface(
    shape: Shape = ShapeMedium,
    backgroundColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f),
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
    borderWidth: Dp = 1.dp,
    elevation: Dp = 10.dp
): Modifier = this
    .shadow(elevation = elevation, shape = shape, ambientColor = Color.Black.copy(alpha = 0.15f), spotColor = Color.Black.copy(alpha = 0.20f))
    .clip(shape)
    .background(backgroundColor)
    .border(width = borderWidth, color = borderColor, shape = shape)

/**
 * Shared frosted-glass card colors. Used by cards across the app so the translucent
 * look is defined in exactly one place and can be tuned globally from here.
 */
@Composable
fun glassCardColors(): androidx.compose.material3.CardColors =
    androidx.compose.material3.CardDefaults.elevatedCardColors(
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)
    )

/**
 * Premium Card Background Container Modifier
 */
@Composable
fun Modifier.premiumCardBackground(
    shape: Shape = ShapeMedium,
    backgroundColor: Color = MaterialTheme.colorScheme.surface
): Modifier = this
    .shadow(elevation = 6.dp, shape = shape, ambientColor = Color.Black.copy(alpha = 0.10f), spotColor = Color.Black.copy(alpha = 0.14f))
    .clip(shape)
    .background(backgroundColor)
    .border(
        width = 1.dp,
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
        shape = shape
    )
