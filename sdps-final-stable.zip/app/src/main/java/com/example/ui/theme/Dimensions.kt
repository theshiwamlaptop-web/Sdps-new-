package com.example.ui.theme

import androidx.compose.ui.unit.dp

// Icon Sizes
val IconSizeXS = 14.dp
val IconSizeSmall = 16.dp
val IconSizeMedium = 20.dp
val IconSizeDefault = 24.dp
val IconSizeLarge = 28.dp
val IconSizeXL = 32.dp
val IconSizeXXL = 40.dp
val IconSizeHero = 48.dp

// Touch Targets & Components
val MinTouchTargetSize = 48.dp
val ButtonHeightDefault = 48.dp
val ButtonHeightSmall = 36.dp
val CardHeaderIconBoxSize = 40.dp
val AvatarSizeSmall = 32.dp
val AvatarSizeMedium = 40.dp
val AvatarSizeLarge = 56.dp
val AvatarSizeXL = 72.dp
