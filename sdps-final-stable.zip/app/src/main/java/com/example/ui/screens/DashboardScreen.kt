package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Diversity3
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.platform.testTag
import com.example.ui.components.UserProfileAvatar
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.ui.SchoolViewModel
import com.example.ui.components.DashboardCard
import com.example.ui.components.SearchTextField
import com.example.ui.components.StatisticCard
import com.example.ui.theme.CornerLargeRadius
import com.example.ui.theme.CornerMediumRadius
import com.example.ui.theme.ElevationLevel1
import com.example.ui.theme.IconSizeMedium
import com.example.ui.theme.Space12
import com.example.ui.theme.Space16
import com.example.ui.theme.Space24
import com.example.ui.theme.Space4
import com.example.ui.theme.Space8
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SchoolViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val students by viewModel.studentsState.collectAsState()
    val attendanceList by viewModel.attendanceState.collectAsState()
    val feesList by viewModel.feesState.collectAsState()
    val notices by viewModel.noticesState.collectAsState()

    val totalStudentsCount = students.size
    val lastNotice = notices.firstOrNull()?.title ?: "No new announcements available"

    val presentCount = attendanceList.count { it.status == "Present" }
    val todayAttendanceText = if (attendanceList.isNotEmpty()) {
        val rate = (presentCount.toDouble() / attendanceList.size * 100).toInt()
        "$rate%"
    } else {
        "N/A"
    }

    val totalRevenue = feesList.sumOf { it.paidAmount }
    val totalRevenueText = if (feesList.isNotEmpty()) {
        "₹${totalRevenue}"
    } else {
        "₹0"
    }

    var searchQuery by remember { mutableStateOf("") }
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(rememberTopAppBarState())
    val roleStr = currentUser?.role?.uppercase()?.trim() ?: ""

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        val currentDate = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())
                        Text(
                            text = currentDate,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Good Morning, ${currentUser?.name?.split(" ")?.firstOrNull() ?: "User"}",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    Box(
                        modifier = Modifier.padding(horizontal = Space16),
                        contentAlignment = Alignment.Center
                    ) {
                        UserProfileAvatar(
                            avatarUrl = currentUser?.avatarUrl,
                            size = 40.dp,
                            contentDescription = "User Profile & Settings",
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            iconTint = MaterialTheme.colorScheme.primary,
                            onClick = { onNavigate(AppScreen.SETTINGS) },
                            modifier = Modifier.testTag("dashboard_profile_avatar")
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigate(AppScreen.NOTICES) }) {
                        Icon(
                            imageVector = Icons.Filled.Notifications,
                            contentDescription = "Notifications"
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentPadding = PaddingValues(Space16),
            verticalArrangement = Arrangement.spacedBy(Space24)
        ) {
            item {
                SearchTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = "Search students, teachers, or notices..."
                )
            }

            // Sync Status
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(CornerMediumRadius))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .clickable {
                            viewModel.forceSync()
                            Toast.makeText(context, "Syncing data...", Toast.LENGTH_SHORT).show()
                        }
                        .padding(Space16),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.CloudDone,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(Space16))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Cloud Sync Status",
                            style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Text(
                            text = "Connected to Firebase",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }

            // Quick Actions based on Role
            item {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = Space12)
                )

                val quickActions = mutableListOf<Triple<String, ImageVector, AppScreen>>()
                val isPrincipal = roleStr == "PRINCIPAL" || currentUser?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
                when {
                    isPrincipal -> {
                        quickActions.addAll(
                            listOf(
                                Triple("Students", Icons.Filled.People, AppScreen.STUDENTS),
                                Triple("Teachers", Icons.Filled.School, AppScreen.TEACHERS),
                                Triple("Attendance", Icons.Filled.FactCheck, AppScreen.ATTENDANCE),
                                Triple("Fees", Icons.Filled.MonetizationOn, AppScreen.FEES),
                                Triple("Activity Center", Icons.Filled.History, AppScreen.PRINCIPAL_ACTIVITY),
                                Triple("Chat Oversight", Icons.Filled.Policy, AppScreen.CHAT_OVERSIGHT),
                                Triple("Classes", Icons.Filled.AutoStories, AppScreen.CLASSES),
                                Triple("Reports", Icons.Filled.Assignment, AppScreen.REPORTS),
                                Triple("Chat", Icons.Filled.Chat, AppScreen.CHAT),
                                Triple("Notices", Icons.Filled.Campaign, AppScreen.NOTICES),
                                Triple("Calendar", Icons.Filled.Event, AppScreen.CALENDAR)
                            )
                        )
                    }
                    roleStr in listOf("HEAD_ADMIN", "ADMIN") -> {
                        quickActions.addAll(
                            listOf(
                                Triple("Students", Icons.Filled.People, AppScreen.STUDENTS),
                                Triple("Teachers", Icons.Filled.School, AppScreen.TEACHERS),
                                Triple("Attendance", Icons.Filled.FactCheck, AppScreen.ATTENDANCE),
                                Triple("Fees", Icons.Filled.MonetizationOn, AppScreen.FEES),
                                Triple("Classes", Icons.Filled.AutoStories, AppScreen.CLASSES),
                                Triple("Reports", Icons.Filled.Assignment, AppScreen.REPORTS),
                                Triple("Chat", Icons.Filled.Chat, AppScreen.CHAT),
                                Triple("Notices", Icons.Filled.Campaign, AppScreen.NOTICES),
                                Triple("Calendar", Icons.Filled.Event, AppScreen.CALENDAR)
                            )
                        )
                    }
                    roleStr in listOf("TEACHER", "CLASS_TEACHER") -> {
                        quickActions.addAll(
                            listOf(
                                Triple("My Students", Icons.Filled.People, AppScreen.STUDENTS),
                                Triple("Take Attendance", Icons.Filled.FactCheck, AppScreen.ATTENDANCE),
                                Triple("Homework", Icons.Filled.AutoStories, AppScreen.HOMEWORK),
                                Triple("Fee Status", Icons.Filled.MonetizationOn, AppScreen.FEES),
                                Triple("Reports", Icons.Filled.Assignment, AppScreen.REPORTS),
                                Triple("Chat", Icons.Filled.Chat, AppScreen.CHAT),
                                Triple("Timetable", Icons.Filled.Schedule, AppScreen.TIMETABLE),
                                Triple("Notices", Icons.Filled.Campaign, AppScreen.NOTICES),
                                Triple("Calendar", Icons.Filled.Event, AppScreen.CALENDAR)
                            )
                        )
                    }
                    roleStr == "STUDENT" -> {
                        quickActions.addAll(
                            listOf(
                                Triple("My Attendance", Icons.Filled.FactCheck, AppScreen.ATTENDANCE),
                                Triple("My Fees", Icons.Filled.MonetizationOn, AppScreen.FEES),
                                Triple("Homework", Icons.Filled.AutoStories, AppScreen.HOMEWORK),
                                Triple("Chat", Icons.Filled.Chat, AppScreen.CHAT),
                                Triple("Timetable", Icons.Filled.Schedule, AppScreen.TIMETABLE)
                            )
                        )
                    }
                }

                val rowCount = (quickActions.size + 2) / 3
                Column(verticalArrangement = Arrangement.spacedBy(Space12)) {
                    for (i in 0 until rowCount) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(Space12)
                        ) {
                            for (j in 0 until 3) {
                                val index = i * 3 + j
                                if (index < quickActions.size) {
                                    val action = quickActions[index]
                                    DashboardCard(
                                        label = action.first,
                                        icon = action.second,
                                        tint = MaterialTheme.colorScheme.primary,
                                        onClick = { onNavigate(action.third) },
                                        modifier = Modifier.weight(1f)
                                    )
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                // Principal-only: direct shortcuts into the settings sub-sections that used to
                // be buried behind Profile -> ERP Panel -> tab navigation.
                if (isPrincipal) {
                    Spacer(modifier = Modifier.height(Space16))
                    Text(
                        text = "Admin Controls",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(bottom = Space12)
                    )
                    val adminShortcuts = listOf(
                        Triple("Security Roles", Icons.Filled.AdminPanelSettings, 0),
                        Triple("Class Assignment", Icons.Filled.Diversity3, 1),
                        Triple("Fee & School Setup", Icons.Filled.Settings, 2),
                        Triple("Security Audits", Icons.Filled.Shield, 3)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(Space12)) {
                        val shortcutRowCount = (adminShortcuts.size + 1) / 2
                        for (i in 0 until shortcutRowCount) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(Space12)
                            ) {
                                for (j in 0 until 2) {
                                    val index = i * 2 + j
                                    if (index < adminShortcuts.size) {
                                        val shortcut = adminShortcuts[index]
                                        DashboardCard(
                                            label = shortcut.first,
                                            icon = shortcut.second,
                                            tint = MaterialTheme.colorScheme.secondary,
                                            onClick = {
                                                viewModel.requestedSettingsTab = shortcut.third
                                                onNavigate(AppScreen.SETTINGS)
                                            },
                                            modifier = Modifier.weight(1f)
                                        )
                                    } else {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Statistics based on Role
            if (roleStr in listOf("PRINCIPAL", "ADMIN", "HEAD_ADMIN", "TEACHER", "CLASS_TEACHER")) {
                item {
                    Text(
                        text = "Overview",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(bottom = Space12)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(Space12)
                    ) {
                        StatisticCard(
                            title = "Students",
                            value = "$totalStudentsCount",
                            subLabel = "Total Enrolled",
                            icon = Icons.Filled.School,
                            iconTint = Color(0xFF0EA5E9),
                            modifier = Modifier.weight(1f)
                        )
                        StatisticCard(
                            title = "Attendance",
                            value = todayAttendanceText,
                            subLabel = "$presentCount Present Today",
                            icon = Icons.Filled.CheckCircle,
                            iconTint = Color(0xFF10B981),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    
                    if (roleStr in listOf("PRINCIPAL", "ADMIN", "HEAD_ADMIN")) {
                        Spacer(modifier = Modifier.height(Space12))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(Space12)
                        ) {
                            StatisticCard(
                                title = "Revenue",
                                value = totalRevenueText,
                                subLabel = "Collected Today",
                                icon = Icons.Filled.AccountBalanceWallet,
                                iconTint = Color(0xFFF59E0B),
                                modifier = Modifier.weight(1f)
                            )
                            StatisticCard(
                                title = "Notices",
                                value = "${notices.size}",
                                subLabel = "Active Announcements",
                                icon = Icons.Filled.Campaign,
                                iconTint = Color(0xFF8B5CF6),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Recent Notices
            if (notices.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Latest Announcement",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "View All",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.clickable { onNavigate(AppScreen.NOTICES) }
                        )
                    }
                    Spacer(modifier = Modifier.height(Space12))
                    val notice = notices.firstOrNull()
                    if (notice != null) {
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate(AppScreen.NOTICES) },
                            shape = RoundedCornerShape(CornerLargeRadius),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            elevation = CardDefaults.elevatedCardElevation(defaultElevation = ElevationLevel1)
                        ) {
                            Column(modifier = Modifier.padding(Space16)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Campaign,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(Space8))
                                    Text(
                                        text = notice.title,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(modifier = Modifier.height(Space8))
                                Text(
                                    text = notice.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
