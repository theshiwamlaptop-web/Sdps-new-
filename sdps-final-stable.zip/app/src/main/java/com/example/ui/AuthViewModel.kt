package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.SchoolApplication
import com.example.data.model.User
import com.example.data.repository.SchoolRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel @JvmOverloads constructor(
    private val repository: SchoolRepository = SchoolApplication.instance.repository
) : ViewModel() {

    private val _currentUser = repository.currentUserFlow
    val currentUser: StateFlow<User?> = _currentUser

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    fun loginUser(userId: String, role: String, fullName: String, passwordHash: String) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            val result = repository.login(userId, role, fullName, passwordHash)
            _isAuthenticating.value = false
            if (!result.isSuccess) {
                _loginError.value = result.exceptionOrNull()?.message ?: "लॉगिन विफल!"
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }
}
