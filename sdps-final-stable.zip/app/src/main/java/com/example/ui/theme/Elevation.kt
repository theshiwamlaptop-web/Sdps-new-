package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class Elevation(
    val level0: Dp = 0.dp,
    val level1: Dp = 1.dp,
    val level2: Dp = 3.dp,
    val level3: Dp = 6.dp,
    val level4: Dp = 10.dp,
    val level5: Dp = 16.dp
)

val LocalElevation = staticCompositionLocalOf { Elevation() }

val AppElevation: Elevation
    @Composable
    @ReadOnlyComposable
    get() = LocalElevation.current

// Direct constants
val ElevationLevel0 = 0.dp
val ElevationLevel1 = 1.dp
val ElevationLevel2 = 3.dp
val ElevationLevel3 = 6.dp
val ElevationLevel4 = 10.dp
val ElevationLevel5 = 16.dp
