package com.example.ui.theme

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween

// Standard Animation Durations (ms)
const val DurationInstant = 0
const val DurationVeryFast = 100
const val DurationFast = 180
const val DurationNormal = 250
const val DurationMedium = 350
const val DurationSlow = 500

// Standard Animation Specs
val SpecFastOutSlowIn = tween<Float>(
    durationMillis = DurationNormal,
    easing = FastOutSlowInEasing
)

val SpecLinearOutSlowIn = tween<Float>(
    durationMillis = DurationNormal,
    easing = LinearOutSlowInEasing
)

// Spring Physics Specs
val SpecSpringGentle = spring<Float>(
    dampingRatio = Spring.DampingRatioLowBouncy,
    stiffness = Spring.StiffnessMediumLow
)

val SpecSpringSnappy = spring<Float>(
    dampingRatio = Spring.DampingRatioNoBouncy,
    stiffness = Spring.StiffnessMedium
)

val SpecSpringBouncy = spring<Float>(
    dampingRatio = Spring.DampingRatioMediumBouncy,
    stiffness = Spring.StiffnessLow
)
