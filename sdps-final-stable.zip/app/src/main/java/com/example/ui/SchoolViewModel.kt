package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.SchoolApplication
import com.example.data.model.*
import com.example.data.repository.SchoolRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import java.util.UUID

enum class NavigationTarget {
    Idle,
    PRINCIPAL_DASHBOARD,
    ADMIN_DASHBOARD,
    TEACHER_DASHBOARD,
    STUDENT_DASHBOARD,
    LOGIN_SCREEN
}

class SchoolViewModel @JvmOverloads constructor(
    private val repository: SchoolRepository = SchoolApplication.instance.repository
) : ViewModel() {

    private val _navigationState = MutableStateFlow<NavigationTarget>(NavigationTarget.Idle)
    val navigationState = _navigationState.asStateFlow()

    private val _isSessionChecking = MutableStateFlow(true)
    val isSessionChecking = _isSessionChecking.asStateFlow()
    
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage = _toastMessage.asStateFlow()

    // Lets a Dashboard quick-action button send the Principal straight to a specific
    // Settings sub-tab (0=Security Roles, 1=Classes Assign, 2=School Setup, 3=Security Audits)
    // instead of always landing on tab 0 and having to navigate manually.
    var requestedSettingsTab: Int = 0

    // Lets screens show a real reason when a list is empty (cloud read denied / offline /
    // not authenticated) instead of a misleading "no records found" message.
    val syncStatus: StateFlow<com.example.data.repository.CloudSyncStatus> =
        repository.syncStatusFlow
    
    fun clearToast() { _toastMessage.value = null }
    fun applyDefaultPassword(userId: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            val result = (repository as com.example.data.repository.SchoolRepository).applyDefaultPassword(userId)
            if (result.isSuccess) onSuccess() else onFailure(result.exceptionOrNull()?.message ?: "Failed")
        }
    }

    fun verifyResetDetails(userId: String, dob: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            val result = (repository as com.example.data.repository.SchoolRepository).verifyResetDetails(userId, dob)
            if (result.isSuccess) onSuccess() else onFailure(result.exceptionOrNull()?.message ?: "Verification failed")
        }
    }

    fun resetPasswordWithDob(userId: String, newPassword: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            val result = (repository as com.example.data.repository.SchoolRepository).resetPasswordWithDob(userId, newPassword)
            if (result.isSuccess) onSuccess() else onFailure(result.exceptionOrNull()?.message ?: "Failed to reset password")
        }
    }



    // Backend Connection
    val isFirebaseMode = repository.isFirebaseModeFlow

    fun forceSync() {
        repository.forceSync()
    }

    // Auth State
    val currentUser = repository.currentUserFlow
    private val _loginError = MutableStateFlow<String?>(null)
    val loginError = _loginError.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating = _isAuthenticating.asStateFlow()

    // Students
    private val _studentSearchQuery = MutableStateFlow("")
    val studentSearchQuery = _studentSearchQuery.asStateFlow()

    // Default to "" (treated as "All classes" by every screen that reads this) so the
    // student list isn't silently pre-filtered to one class the first time it opens.
    // It was previously "Nursery" — if a school had zero Nursery students, the Principal
    // saw "No Students Found" even with hundreds of real students in other classes.
    private val _prefillClass = MutableStateFlow("")
    val prefillClass = _prefillClass.asStateFlow()
    
    private val _editingStudent = MutableStateFlow<Student?>(null)
    val editingStudent = _editingStudent.asStateFlow()
    fun setEditingStudent(student: Student?) {
        _editingStudent.value = student
    }

    private val _selectedClassDetail = MutableStateFlow<String?>(null)
    val selectedClassDetail = _selectedClassDetail.asStateFlow()
    

    fun setStudentPrefill(className: String) {
        _prefillClass.value = className
    }

    fun setSelectedClassDetail(className: String?) {
        _selectedClassDetail.value = className
    }

    val studentsState: StateFlow<List<Student>> = combine(repository.getAllStudents(), repository.currentUserFlow, repository.getAllTeachers()) { rawList, user, teachers ->
        // isDeleted is the one always-reliable exclusion signal. status also has one
        // legitimate, intentional use in this app: a teacher-submitted student sits as
        // PENDING_APPROVAL until a Principal approves it, and a REJECTED one should stay
        // out of the main list too — so those two are explicitly excluded here. Anything
        // else (Active, blank, or an unexpected value from an older record) is treated as
        // visible, instead of requiring an exact "Active" match that silently hid any
        // record whose status wasn't spelled exactly that way.
        val list = rawList.filter { !it.isDeleted && it.status != "PENDING_APPROVAL" && it.status != "REJECTED" }
         
if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
            val teacher = teachers.find { it.teacherId == user.userId }
            if (teacher != null && teacher.classTeacherOf.isNotBlank()) {
                val assignedClass = teacher.classTeacherOf.trim()
                list.filter { it.className.equals(assignedClass, ignoreCase = true) }
            } else if (teacher != null && teacher.classesAssigned.isNotBlank()) {
                // Find matching class from assigned string
                val classesList = listOf("Nursery", "LKG", "UKG", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10")
                val matched = classesList.find { teacher.classesAssigned.contains(it, ignoreCase = true) } ?: "Class 9"
                list.filter { it.className.equals(matched, ignoreCase = true) }
            } else {
                list // fallback if no specific assignments
            }
        } else {
            list
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredStudentsState = combine(studentsState, studentSearchQuery) { list, query ->
        if (query.isBlank()) list
        else {
            list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.className.contains(query, ignoreCase = true) ||
                it.rollNo.contains(query, ignoreCase = true) ||
                it.admissionNo.contains(query, ignoreCase = true)
            }
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Teachers
    val teachersState: StateFlow<List<Teacher>> = repository.getAllTeachers()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Payrolls
    val payrollsState: StateFlow<List<Payroll>> = repository.getAllPayrolls()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Attendance

    val leaveRequestsState: StateFlow<List<LeaveRequest>> = repository.getAllLeaveRequests()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun saveLeaveRequest(request: LeaveRequest) {
        viewModelScope.launch {
            repository.saveLeaveRequest(request)
        }
    }

    fun deleteLeaveRequest(requestId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            // Simple security: only management can delete leave requests completely
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized."
                return@launch
            }
            repository.deleteLeaveRequest(requestId)
        }
    }
    val attendanceState: StateFlow<List<Attendance>> = combine(repository.getAllAttendance(), repository.currentUserFlow, repository.getAllTeachers()) { list, user, teachers ->
         
if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
             val teacher = teachers.find { it.teacherId == user.userId }
             if (teacher != null && teacher.classTeacherOf.isNotBlank()) {
                 val assignedClass = teacher.classTeacherOf.trim()
                 list.filter { it.className.equals(assignedClass, ignoreCase = true) }
             } else {
                 list
             }
        } else {
            list
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedClassForAttendance = MutableStateFlow("Class X")
    val selectedClassForAttendance = _selectedClassForAttendance.asStateFlow()

    private val _selectedDateForAttendance = MutableStateFlow("2026-05-22")
    val selectedDateForAttendance = _selectedDateForAttendance.asStateFlow()

    val currentClassAttendance = combine(
        selectedClassForAttendance,
        selectedDateForAttendance,
        repository.currentUserFlow,
        repository.getAllTeachers()
    ) { className, date, user, teachers ->
        val targetClass =  
if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
            val teacher = teachers.find { it.teacherId == user.userId }
            if (teacher != null && teacher.classTeacherOf.isNotBlank()) teacher.classTeacherOf.trim() else className
        } else {
            className
        }
        
        Pair(targetClass, date)
    }.flatMapLatest { (targetClass, date) ->
        repository.getAttendanceForClassAndDate(targetClass, date)
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Fees (Filtered for teachers based on their classroom students only)
    val feesState: StateFlow<List<Fee>> = combine(repository.getAllFees(), repository.currentUserFlow, repository.getAllStudents(), repository.getAllTeachers()) { fees, user, students, teachers ->
         
if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
            val teacher = teachers.find { it.teacherId == user.userId }
            val assignedClass = teacher?.classTeacherOf?.trim() ?: ""
            val classStudents = students.filter { 
                it.className.equals(assignedClass, ignoreCase = true)
            }.map { it.studentId }.toSet()
            fees.filter { classStudents.contains(it.studentId) }
        } else {
            fees
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Homework
    val homeworkState: StateFlow<List<Homework>> = repository.getAllHomework()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notices
    val noticesState: StateFlow<List<Notice>> = repository.getAllNotices()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // S.D. Public School Smart Admission workflow
    val pendingApprovalStudentsState: StateFlow<List<Student>> = repository.getAllStudents().map { list ->
        list.filter { it.status == "PENDING_APPROVAL" && !it.isDeleted }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notificationsState: StateFlow<List<AppNotification>> = repository.getAllNotifications()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Timetables
    val timetablesState: StateFlow<List<Timetable>> = repository.getAllTimetables()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Chats
    val chatsState: StateFlow<List<ChatMessage>> = repository.getAllChats()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Chat Selected Recipient ID
    private val _activeChatUserId = MutableStateFlow<String?>(null)
    val activeChatUserId = _activeChatUserId.asStateFlow()

    // Extra Features
    // Calendar events connected to Room + Firestore repository
    val calendarEvents: StateFlow<List<CalendarEvent>> = repository.getAllCalendarEvents()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveCalendarEvent(event: CalendarEvent) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only school management can add or update calendar events."
                return@launch
            }
            if (event.title.isBlank()) {
                _toastMessage.value = "Event title cannot be empty."
                return@launch
            }
            val eventToSave = if (event.id.isBlank()) event.copy(id = "CAL_" + java.util.UUID.randomUUID().toString().take(8)) else event
            val result = repository.saveCalendarEvent(eventToSave)
            if (result.isSuccess) {
                _toastMessage.value = "Calendar event saved successfully!"
                logAudit("SAVE_CALENDAR_EVENT", eventToSave.id, "Saved event: ${eventToSave.title}")
            } else {
                _toastMessage.value = "Failed to save calendar event: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun deleteCalendarEvent(eventId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only school management can delete calendar events."
                return@launch
            }
            val result = repository.deleteCalendarEvent(eventId)
            if (result.isSuccess) {
                _toastMessage.value = "Calendar event deleted."
                logAudit("DELETE_CALENDAR_EVENT", eventId, "Deleted calendar event")
            } else {
                _toastMessage.value = "Failed to delete calendar event: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    val usersState: StateFlow<List<User>> = repository.getAllUsers()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val feeLedgerState: StateFlow<List<FeeLedgerEntry>> = combine(repository.getAllFeeLedgerEntries(), repository.currentUserFlow, repository.getAllStudents()) { ledgers, user, students ->
         
if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
            val assignedClass = user.className.trim()
            val classStudents = students.filter { it.className.equals(assignedClass, ignoreCase = true) }.map { it.studentId }.toSet()
            ledgers.filter { classStudents.contains(it.studentId) }
        } else {
            ledgers
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Audit Logs
    val auditLogsState: StateFlow<List<AuditLog>> = repository.getAllAuditLogs()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Teacher Attendance
    val teacherAttendanceState: StateFlow<List<TeacherAttendance>> = repository.getAllTeacherAttendance()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Class Books & Issued Books
    val classBooksState: StateFlow<List<ClassBook>> = repository.getAllClassBooks()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val issuedBooksState: StateFlow<List<IssuedBook>> = repository.getAllIssuedBooks()
        .flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun logAudit(action: String, oldValue: String, newValue: String) {
        val u = currentUser.value
        val log = AuditLog(
            logId = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            userId = u?.userId ?: "SYSTEM",
            userName = u?.name ?: "Unknown User",
            action = action,
            oldValue = oldValue,
            newValue = newValue
        )
        viewModelScope.launch {
            repository.addAuditLog(log)
        }
    }

    fun addTeacherAttendance(attendance: TeacherAttendance) {
        viewModelScope.launch {
            repository.addTeacherAttendance(attendance)
        }
    }

    fun getAttendanceForTeacher(teacherId: String): Flow<List<TeacherAttendance>> {
        return repository.getAttendanceForTeacher(teacherId)
    }

    // Setup functions
    fun toggleFirebaseMode() {
        repository.toggleFirebaseMode(!isFirebaseMode.value)
    }

    fun updateNavigationTargetForUser(user: User?) {
        if (user != null) {
            val roleStr = user.role.uppercase().trim()
            when (roleStr) {
                "PRINCIPAL" -> _navigationState.value = NavigationTarget.PRINCIPAL_DASHBOARD
                "ADMIN" -> _navigationState.value = NavigationTarget.ADMIN_DASHBOARD
                "CLASS_TEACHER", "TEACHER" -> _navigationState.value = NavigationTarget.TEACHER_DASHBOARD
                "STUDENT" -> _navigationState.value = NavigationTarget.STUDENT_DASHBOARD
                else -> {
                    // role completely missing, malformed, or null in the database document
                    _loginError.value = "सर्वर त्रुटि: सुरक्षा कारणों से सत्र रीसेट किया गया है।"
                    _navigationState.value = NavigationTarget.LOGIN_SCREEN
                    logoutUser()
                }
            }
        } else {
            _navigationState.value = NavigationTarget.LOGIN_SCREEN
        }
    }

    fun loginUser(userId: String, role: String, fullname: String, password: String) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            val result = repository.login(userId, role, fullname, password)
            _isAuthenticating.value = false
            if (result.isSuccess) {
                val user = result.getOrNull()
                updateNavigationTargetForUser(user)
            } else {
                _loginError.value = result.exceptionOrNull()?.message ?: "Login Failed"
                _navigationState.value = NavigationTarget.LOGIN_SCREEN
            }
        }
    }

    fun startPhoneVerification(
        phone: String, 
        activity: android.app.Activity,
        onCodeSent: (String) -> Unit,
        onVerificationFailed: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            try {
                // 1. Resolve phone and extract linked email / role
                val resolvedUser = repository.findUserByPhone(phone)
                if (resolvedUser == null) {
                    _isAuthenticating.value = false
                    val err = "यह फोन नंबर पंजीकृत नहीं है!"
                    onVerificationFailed(err)
                    _loginError.value = err
                    return@launch
                }
                
                // 2. Emulator fallback or Real Firebase phone auth
                if (isEmulator()) {
                    kotlinx.coroutines.delay(1500)
                    _isAuthenticating.value = false
                    onCodeSent("simulated_verification_id")
                    return@launch
                }

                val options = com.google.firebase.auth.PhoneAuthOptions.newBuilder(com.google.firebase.auth.FirebaseAuth.getInstance())
                    .setPhoneNumber("+91$phone")
                    .setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
                    .setActivity(activity)
                    .setCallbacks(object : com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                            // Auto-retrieval
                        }
                        override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                            _isAuthenticating.value = false
                            onVerificationFailed(e.message ?: "सत्यापन विफल।")
                        }
                        override fun onCodeSent(verificationId: String, token: com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken) {
                            _isAuthenticating.value = false
                            onCodeSent(verificationId)
                        }
                    }).build()
                com.google.firebase.auth.PhoneAuthProvider.verifyPhoneNumber(options)
            } catch (e: Exception) {
                _isAuthenticating.value = false
                onVerificationFailed(e.message ?: "त्रुटि उत्पन्न हुई।")
            }
        }
    }

    fun verifyOtpAndLogin(
        verificationId: String,
        otpCode: String,
        phone: String
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            try {
                val resolvedUser = repository.findUserByPhone(phone)
                if (resolvedUser == null) {
                    _isAuthenticating.value = false
                    _loginError.value = "यह फोन नंबर पंजीकृत नहीं है!"
                    return@launch
                }

                if (verificationId == "simulated_verification_id") {
                    kotlinx.coroutines.delay(1000)
                    _isAuthenticating.value = false
                    updateNavigationTargetForUser(resolvedUser)
                    return@launch
                }

                val credential = com.google.firebase.auth.PhoneAuthProvider.getCredential(verificationId, otpCode)
                val result = repository.loginWithCredential(credential, resolvedUser)
                _isAuthenticating.value = false
                if (result.isSuccess) {
                    val user = result.getOrNull()
                    updateNavigationTargetForUser(user)
                } else {
                    _loginError.value = result.exceptionOrNull()?.message ?: "अमान्य OTP कोड!"
                }
            } catch (e: Exception) {
                _isAuthenticating.value = false
                _loginError.value = e.message ?: "सत्यापन त्रुटि।"
            }
        }
    }

    fun sendPasswordReset(destination: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            try {
                val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
                val clean = destination.trim()
                if (clean.contains("@")) {
                    auth.sendPasswordResetEmail(clean).await()
                    onSuccess()
                } else {
                    val phoneDigits = clean.filter { it.isDigit() }
                    if (phoneDigits.length != 10) {
                        throw Exception("कृपया 10 अंकों का मान्य फ़ोन नंबर दर्ज करें!")
                    }
                    val user = repository.findUserByPhone(phoneDigits)
                    if (user == null || user.email.isEmpty()) {
                        throw Exception("यह फ़ोन नंबर किसी भी उपयोगकर्ता से लिंक नहीं है!")
                    }
                    auth.sendPasswordResetEmail(user.email).await()
                    onSuccess()
                }
            } catch (e: Exception) {
                android.util.Log.e("SchoolViewModel", "Password reset failed", e)
                onFailure(e.localizedMessage ?: e.message ?: "पासवर्ड रीसेट लिंक भेजने में त्रुटि!")
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    fun updateUserRole(userId: String, newRole: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val uList = usersState.value
                val targetUser = uList.find { it.userId == userId }
                if (targetUser != null) {
                    val updatedUser = targetUser.copy(
                        role = newRole,
                        roleCode = when (newRole.uppercase().trim()) {
                            "PRINCIPAL" -> "HA-99"
                            "ADMIN" -> "AD-55"
                            "CLASS_TEACHER", "TEACHER" -> "TC-12"
                            else -> "ST-01"
                        }
                    )
                    val result = repository.updateUserProfile(updatedUser)
                    if (result.isSuccess) {
                        onSuccess()
                    } else {
                        onFailure(result.exceptionOrNull()?.message ?: "भूमिका अपडेट करने में विफल!")
                    }
                } else {
                    onFailure("उपयोगकर्ता नहीं मिला!")
                }
            } catch (e: Exception) {
                onFailure(e.message ?: "भूमिका अपडेट करने में विफल!")
            }
        }
    }

    fun sha256Hex(input: String): String {
        return try {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(input.toByteArray(kotlin.text.Charsets.UTF_8))
            hash.fold("") { str, it -> str + "%02x".format(it) }
        } catch (e: Exception) {
            input
        }
    }

    fun changePassword(userId: String, oldPassword: String?, newPassword: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.changePassword(userId, oldPassword, newPassword)
            if (result.isSuccess) {
                onSuccess()
            } else {
                onFailure(result.exceptionOrNull()?.message ?: "Failed to change password")
            }
        }
    }

    fun addUser(user: User, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            val result = repository.addUser(user)
            if (result.isSuccess) {
                val message = "${user.name} was saved to Firebase."
                _toastMessage.value = message
                onResult(true, message)
            } else {
                val message = "Firebase user save failed: ${result.exceptionOrNull()?.message ?: "unknown error"}"
                _toastMessage.value = message
                onResult(false, message)
            }
        }
    }

    fun getFeeLedgerForStudentFlow(studentId: String): Flow<List<FeeLedgerEntry>> {
        return repository.getFeeLedgerForStudentFlow(studentId)
    }

    fun saveFeeLedgerEntries(entries: List<FeeLedgerEntry>) {
        val user = currentUser.value
        if (user != null && (user.role == "TEACHER" || user.role == "CLASS_TEACHER")) return
        viewModelScope.launch {
            repository.saveFeeLedgerEntries(entries)
        }
    }

    fun saveFeeLedgerEntry(entry: FeeLedgerEntry) {
        val user = currentUser.value
        if (user != null && (user.role == "TEACHER" || user.role == "CLASS_TEACHER")) return
        viewModelScope.launch {
            repository.saveFeeLedgerEntry(entry)
            logAudit("FEE_UPDATED", "", "Fee ledger updated for student ${entry.studentId}, Month: ${entry.month}")
        }
    }

    fun logoutUser() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun updateUserProfile(user: User) {
        viewModelScope.launch {
            repository.updateUserProfile(user)
        }
    }

    fun isCurrentUserPrincipal(): Boolean {
        val user = repository.currentUserFlow.value
        val role = user?.role?.uppercase()?.trim() ?: ""
        return role == "PRINCIPAL" || user?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    }

    fun deleteUserAccount(userId: String, onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can delete user accounts."
                onComplete(false)
                return@launch
            }
            val res = repository.deleteUserAccount(userId)
            onComplete(res.isSuccess)
        }
    }

    fun updateUserDob(targetUserId: String, newDob: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            val user = currentUser.value
            if (!isCurrentUserPrincipal()) {
                val err = "Unauthorized: Only the Principal can verify or update user Date of Birth."
                _toastMessage.value = err
                onResult(false, err)
                return@launch
            }
            val requesterId = user?.userId ?: "theshiwamlaptop@gmail.com"
            val result = repository.updateUserDob(targetUserId, newDob, requesterId)
            if (result.isSuccess) {
                _toastMessage.value = "Date of Birth updated successfully!"
                onResult(true, "Date of Birth updated successfully!")
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Failed to update Date of Birth."
                _toastMessage.value = errorMsg
                onResult(false, errorMsg)
            }
        }
    }

    fun adminSetCustomPassword(targetUserId: String, newPassword: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            val user = currentUser.value
            val isPrincipal = isCurrentUserPrincipal()
            val isSelf = targetUserId.equals(user?.userId, ignoreCase = true) ||
                    targetUserId.equals(user?.email, ignoreCase = true)
            if (!isPrincipal && !isSelf) {
                val err = "Unauthorized: Only the Principal can set custom passwords for other users."
                _toastMessage.value = err
                onResult(false, err)
                return@launch
            }
            val adminId = user?.userId ?: "theshiwamlaptop@gmail.com"
            val result = repository.adminSetCustomPassword(targetUserId, newPassword, adminId)
            if (result.isSuccess) {
                _toastMessage.value = "Custom password updated for $targetUserId!"
                onResult(true, "Custom password updated successfully!")
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to set custom password"
                _toastMessage.value = err
                onResult(false, err)
            }
        }
    }

    fun adminResetPasswordToDob(targetUserId: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            val user = currentUser.value
            if (!isCurrentUserPrincipal()) {
                val err = "Unauthorized: Only the Principal can reset passwords to Date of Birth."
                _toastMessage.value = err
                onResult(false, err)
                return@launch
            }
            val adminId = user?.userId ?: "theshiwamlaptop@gmail.com"
            val result = repository.adminResetPasswordToDob(targetUserId, adminId)
            if (result.isSuccess) {
                _toastMessage.value = "Password reset to DOB for $targetUserId!"
                onResult(true, "Password reset to DOB!")
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to reset password to DOB"
                _toastMessage.value = err
                onResult(false, err)
            }
        }
    }

    fun adminGenerateTemporaryPassword(targetUserId: String, onResult: (Boolean, String, String) -> Unit = { _, _, _ -> }) {
        viewModelScope.launch {
            val user = currentUser.value
            if (!isCurrentUserPrincipal()) {
                val err = "Unauthorized: Only the Principal can generate temporary passwords."
                _toastMessage.value = err
                onResult(false, err, "")
                return@launch
            }
            val adminId = user?.userId ?: "theshiwamlaptop@gmail.com"
            val result = repository.adminGenerateTemporaryPassword(targetUserId, adminId)
            if (result.isSuccess) {
                val tempPass = result.getOrNull() ?: ""
                _toastMessage.value = "Temporary password generated for $targetUserId!"
                onResult(true, "Temporary password generated!", tempPass)
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to generate temporary password"
                _toastMessage.value = err
                onResult(false, err, "")
            }
        }
    }

    // STUDENT OPERATIONS
    fun updateStudent(student: Student) {
        viewModelScope.launch {
            val user = repository.currentUserFlow.value
            val role = user?.role?.uppercase()?.trim() ?: ""
            val isManagement = role == "PRINCIPAL" || role == "HEAD_ADMIN" || role == "ADMIN"
            val isPrincipal = isCurrentUserPrincipal()

            // Look up existing student to detect DOB alterations
            val existingList = studentsState.value
            val existingStudent = existingList.find { it.studentId == student.studentId }
            
            var studentToSave = student
            if (existingStudent != null && existingStudent.DOB.isNotBlank() && existingStudent.DOB != student.DOB) {
                if (!isManagement) {
                    _toastMessage.value = "Unauthorized: Only Administrators and Principal can edit Date of Birth."
                    studentToSave = student.copy(DOB = existingStudent.DOB)
                } else {
                    logAudit("DOB_CHANGED", "Target: ${student.studentId}, Old DOB: ${existingStudent.DOB}", "New DOB: ${student.DOB}")
                }
            }

            if (!isManagement) {
                if (role == "TEACHER" || role == "CLASS_TEACHER") {
                     val teacherInfo = repository.getAllTeachers().firstOrNull()?.find { it.teacherId == user?.userId }
                     val teacherClass = teacherInfo?.classesAssigned ?: ""
                     if (!student.className.equals(teacherClass, ignoreCase = true)) {
                         _toastMessage.value = "Unauthorized: You can only edit your own class students."
                         return@launch
                     }
                } else {
                     _toastMessage.value = "Unauthorized: You do not have permission to edit students."
                     return@launch
                }
            }
            repository.updateStudent(studentToSave)
            
            val log = com.example.data.model.AuditLog(
                logId = java.util.UUID.randomUUID().toString(),
                timestamp = System.currentTimeMillis(),
                userId = currentUser.value?.userId ?: "System",
                userName = currentUser.value?.name ?: "System",
                action = "Updated Student ${studentToSave.studentId} - ${studentToSave.name}"
            )
            repository.addAuditLog(log)
        }
    }

    fun addOrUpdateStudent(student: Student, isEdit: Boolean = false) {
        viewModelScope.launch {
            val user = repository.currentUserFlow.value
            val currentRole = user?.role?.uppercase()?.trim() ?: ""
            val currentUserName = user?.name ?: "Staff Member"
            val currentUserId = user?.userId ?: "STAFF"
            val isManagement = currentRole == "PRINCIPAL" || currentRole == "HEAD_ADMIN" || currentRole == "ADMIN"

            var studentToSave = student
            if (isEdit) {
                val existingList = studentsState.value
                val existingStudent = existingList.find { it.studentId == student.studentId }
                if (existingStudent != null && existingStudent.DOB.isNotBlank() && existingStudent.DOB != student.DOB) {
                    if (!isManagement) {
                        _toastMessage.value = "Unauthorized: Date of Birth change restricted to Administrators."
                        studentToSave = student.copy(DOB = existingStudent.DOB)
                    } else {
                        logAudit("DOB_CHANGED", "Target: ${student.studentId}, Old DOB: ${existingStudent.DOB}", "New DOB: ${student.DOB}")
                    }
                }
            } else {
                val existsLocally = repository.checkStudentExists(student.studentId)
                if (existsLocally) {
                    _toastMessage.value = "Validation Error: Student ID ${student.studentId} already exists in database. Please generate a unique ID."
                    return@launch
                }
            }
            android.util.Log.d("SchoolViewModel", "Adding student: ${studentToSave.name}")

            val updatedStudent = if (studentToSave.status == "PENDING_APPROVAL" || studentToSave.status == "REJECTED" || studentToSave.status.uppercase() == "ACTIVE") {
                studentToSave
            } else {
                if (isManagement) {
                    studentToSave.copy(
                        status = "ACTIVE",
                        approvedBy = currentUserName,
                        approvedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
                        submittedBy = currentUserName,
                        submittedByRole = currentRole,
                        submittedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                    )
                } else {
                    studentToSave.copy(
                        status = "PENDING_APPROVAL",
                        submittedBy = currentUserId,
                        submittedByRole = currentRole,
                        submittedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                    )
                }
            }

            val result = repository.addStudent(updatedStudent)
            if (result.isFailure) {
                // If it fails (e.g. Firebase rules or network), we can optionally surface this to UI
                android.util.Log.e("SchoolViewModel", "Failed to add/update student", result.exceptionOrNull())
                _toastMessage.value = "Failed to save to cloud: ${result.exceptionOrNull()?.message}"
            } else {
                _toastMessage.value = "Saved successfully!"
            }

            // Dynamic Real-time notification to Principal
            if (updatedStudent.status == "PENDING_APPROVAL" && student.status != "PENDING_APPROVAL") {
                val notifId = java.util.UUID.randomUUID().toString()
                repository.addNotification(
                    AppNotification(
                        notificationId = notifId,
                        userId = "PRINCIPAL",
                        title = "New Admission Request",
                        message = "New student admission request pending approval: ${updatedStudent.name} (${updatedStudent.className}).",
                        timestamp = System.currentTimeMillis(),
                        isRead = false,
                        type = "APPROVAL_PENDING"
                    )
                )
            }
        }
    }

    fun initializeStudentFeeAndLedger(
        student: Student,
        monthlyTuitionFee: Double,
        admissionFee: Double,
        bookFee: Double,
        monthlyTransportFee: Double
    ) {
        viewModelScope.launch {
            val totalAnnualFee = (monthlyTuitionFee * 12) + admissionFee + bookFee + (monthlyTransportFee * 12)
            val initialFee = Fee(
                feeId = "F_${student.studentId}",
                studentId = student.studentId,
                totalFee = totalAnnualFee,
                paidAmount = 0.0,
                dueAmount = totalAnnualFee,
                paymentDate = "",
                paymentMode = "Pending",
                status = "Due",
                tuitionFee = monthlyTuitionFee * 12,
                bookFee = bookFee,
                dressFee = 0.0,
                examFee = 0.0,
                transportFee = monthlyTransportFee * 12,
                otherFee = admissionFee
            )
            repository.addFee(initialFee)

            // NOTE: Per-month FeeLedgerEntry rows are intentionally NOT pre-created here anymore.
            // They are computed live (using the effective fee-rate history for each month) when
            // the student's fee screen is opened, and only get persisted once actually paid.
            // Pre-freezing all 12 months here used to permanently lock in the admission-time
            // rate, so a later Principal rate change could never reach this student.
        }
    }

    fun approveStudentAdmission(student: Student) {
        viewModelScope.launch {
            val user = repository.currentUserFlow.value
            val currentPrincipalName = user?.name ?: "Principal"
            val currentPrincipalId = user?.userId ?: "PRINCIPAL"

            val updated = student.copy(
                status = "ACTIVE",
                approvedBy = currentPrincipalName,
                approvedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            )
            repository.addStudent(updated)

            // Audit Trail
            repository.addAuditLog(
                AuditLog(
                    logId = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    userId = currentPrincipalId,
                    userName = currentPrincipalName,
                    action = "Approved Admission: ${student.name}",
                    oldValue = "PENDING_APPROVAL",
                    newValue = "ACTIVE"
                )
            )

            // Notify submitter
            if (student.submittedBy.isNotBlank()) {
                repository.addNotification(
                    AppNotification(
                        notificationId = java.util.UUID.randomUUID().toString(),
                        userId = student.submittedBy,
                        title = "Student Admission Approved",
                        message = "Principal has approved student ${student.name}'s admission request into ${student.className}.",
                        timestamp = System.currentTimeMillis(),
                        isRead = false,
                        type = "APPROVED"
                    )
                )
            }
        }
    }

    fun rejectStudentAdmission(student: Student, remarks: String) {
        viewModelScope.launch {
            val user = repository.currentUserFlow.value
            val currentPrincipalName = user?.name ?: "Principal"
            val currentPrincipalId = user?.userId ?: "PRINCIPAL"

            val updated = student.copy(
                status = "REJECTED",
                rejectionReason = remarks,
                approvedBy = currentPrincipalName,
                approvedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            )
            repository.addStudent(updated)

            // Audit Trail
            repository.addAuditLog(
                AuditLog(
                    logId = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    userId = currentPrincipalId,
                    userName = currentPrincipalName,
                    action = "Rejected Admission: ${student.name}",
                    oldValue = "PENDING_APPROVAL",
                    newValue = "REJECTED ($remarks)"
                )
            )

            // Notify submitter
            if (student.submittedBy.isNotBlank()) {
                repository.addNotification(
                    AppNotification(
                        notificationId = java.util.UUID.randomUUID().toString(),
                        userId = student.submittedBy,
                        title = "Student Admission Rejected",
                        message = "Principal has rejected student ${student.name}'s admission request. Code: $remarks",
                        timestamp = System.currentTimeMillis(),
                        isRead = false,
                        type = "REJECTED"
                    )
                )
            }
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch {
            val user = repository.currentUserFlow.value
            val role = user?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only management can delete students."
                return@launch
            }
            val currentUserName = user?.name ?: "Authorized Staff"
            val currentUserId = user?.userId ?: "STAFF"

            val students = repository.getAllStudents().firstOrNull() ?: emptyList()
            val target = students.find { it.studentId == studentId }
            if (target != null) {
                val updated = target.copy(
                    isDeleted = true,
                    deletedBy = currentUserName,
                    deletedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                )
                repository.addStudent(updated)

                repository.addAuditLog(
                    AuditLog(
                        logId = java.util.UUID.randomUUID().toString(),
                        timestamp = System.currentTimeMillis(),
                        userId = currentUserId,
                        userName = currentUserName,
                        action = "Deleted Student ${target.name} (${target.className})",
                        oldValue = "ACTIVE",
                        newValue = "DELETED"
                    )
                )
            }
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch {
            repository.deleteNotification(id)
        }
    }

    fun setStudentSearchQuery(query: String) {
        _studentSearchQuery.value = query
    }

    // TEACHER OPERATIONS
    fun addOrUpdateTeacher(teacher: Teacher) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only management can modify teachers."
                return@launch
            }
            repository.addTeacher(teacher)
        }
    }

    fun deleteTeacher(teacherId: String) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can delete teachers."
                return@launch
            }
            repository.deleteTeacher(teacherId)
        }
    }

    // PAYROLL OPERATIONS
    fun addOrUpdatePayroll(payroll: Payroll) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can modify payroll."
                return@launch
            }
            repository.addOrUpdatePayroll(payroll)
        }
    }

    fun savePayrolls(payrolls: List<Payroll>) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can modify payroll."
                return@launch
            }
            repository.savePayrolls(payrolls)
        }
    }

    fun deletePayrollsByTeacher(teacherId: String) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can delete payrolls."
                return@launch
            }
            repository.deletePayrollsByTeacher(teacherId)
        }
    }

    // ATTENDANCE OPERATIONS
    fun setAttendanceFilters(className: String, date: String) {
        _selectedClassForAttendance.value = className
        _selectedDateForAttendance.value = date
    }

    fun isAttendanceEditable(recordDate: String, userRole: String): Boolean {
        val role = userRole.uppercase().trim()
        val user = repository.currentUserFlow.value
        val isPrincipal = role == "PRINCIPAL" || user?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
        if (isPrincipal) return true
        if (role in listOf("HEAD_ADMIN", "ADMIN", "TEACHER", "CLASS_TEACHER")) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            return recordDate == today
        }
        return false
    }

    fun saveAttendance(attendanceList: List<Attendance>, onComplete: ((Boolean, String) -> Unit)? = null) {
        viewModelScope.launch {
            if (attendanceList.isEmpty()) {
                onComplete?.invoke(true, "No records to save")
                return@launch
            }

            val user = repository.currentUserFlow.value
            val role = user?.role?.uppercase()?.trim() ?: ""
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val targetDate = attendanceList.firstOrNull()?.date ?: today
            val targetClass = attendanceList.firstOrNull()?.className ?: ""
            val isPrincipal = role == "PRINCIPAL" || user?.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)

            // Time Lock & Permission Enforcement at Action Layer
            if (!isPrincipal) {
                val hasPastOrFuture = attendanceList.any { it.date != today }
                if (hasPastOrFuture) {
                    val msg = "Attendance editing is locked for past dates. Only the Principal can override historical attendance."
                    _toastMessage.value = msg
                    onComplete?.invoke(false, msg)
                    return@launch
                }
            }

            if (role == "TEACHER" || role == "CLASS_TEACHER") {
                // Verify teacher is assigned to this class
                val teacherList = repository.getAllTeachers().firstOrNull() ?: emptyList()
                val teacher = teacherList.find { it.teacherId == user?.userId }
                if (teacher != null && teacher.classTeacherOf.isNotBlank()) {
                    val assignedClass = teacher.classTeacherOf.trim()
                    val isMismatch = attendanceList.any { 
                        !it.className.equals(assignedClass, ignoreCase = true) && 
                        !teacher.classesAssigned.contains(it.className, ignoreCase = true)
                    }
                    if (isMismatch) {
                        val msg = "Unauthorized: You can only record attendance for your assigned class ($assignedClass)."
                        _toastMessage.value = msg
                        onComplete?.invoke(false, msg)
                        return@launch
                    }
                }
            } else if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                val msg = "Unauthorized: Only teachers and administrators can mark attendance."
                _toastMessage.value = msg
                onComplete?.invoke(false, msg)
                return@launch
            }

            val isPrincipalOverride = isPrincipal && (targetDate < today)

            // Prevent duplicate records: query existing attendance for the class and date
            val existingAttendance = repository.getAttendanceForClassAndDate(targetClass, targetDate).firstOrNull() ?: emptyList()
            val existingMap = existingAttendance.associateBy { it.studentId }

            val recordsToPersist = attendanceList.map { rec ->
                val existing = existingMap[rec.studentId]
                if (existing != null) {
                    rec.copy(
                        attendanceId = existing.attendanceId,
                        markedByTeacherId = if (role == "TEACHER" || role == "CLASS_TEACHER") (user?.userId ?: "") else existing.markedByTeacherId,
                        markedByTeacherName = if (role == "TEACHER" || role == "CLASS_TEACHER") (user?.name ?: "") else existing.markedByTeacherName,
                        date = existing.date,
                        timestamp = System.currentTimeMillis()
                    )
                } else {
                    rec.copy(
                        attendanceId = if (rec.attendanceId.isBlank()) UUID.randomUUID().toString() else rec.attendanceId,
                        markedByTeacherId = user?.userId ?: "",
                        markedByTeacherName = user?.name ?: "",
                        date = targetDate,
                        timestamp = System.currentTimeMillis()
                    )
                }
            }

            val result = repository.markAttendance(recordsToPersist)
            if (result.isSuccess) {
                if (isPrincipalOverride) {
                    val log = AuditLog(
                        logId = UUID.randomUUID().toString(),
                        timestamp = System.currentTimeMillis(),
                        userId = user?.userId ?: "PRINCIPAL",
                        userName = user?.name ?: "Principal",
                        action = "OVERRIDE_ATTENDANCE_EDIT",
                        oldValue = "LOCKED_ATTENDANCE ($targetDate, $targetClass)",
                        newValue = "UPDATED_BY_OVERRIDE (${recordsToPersist.size} records)"
                    )
                    repository.addAuditLog(log)
                }
                _toastMessage.value = if (isPrincipalOverride) "Attendance updated via Principal Override (Audited)" else "Attendance saved successfully"
                onComplete?.invoke(true, "Success")
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to save attendance"
                _toastMessage.value = "Failed to sync attendance: $err"
                onComplete?.invoke(false, err)
            }
        }
    }

    // FEES OPERATIONS
    fun addOrUpdateFee(fee: Fee) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only management can modify fees."
                return@launch
            }
            repository.addFee(fee)
        }
    }

    fun deleteFee(feeId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only management can delete fees."
                return@launch
            }
            repository.deleteFee(feeId)
        }
    }

    // HOMEWORK OPERATIONS
    val isUploadingAttachment = MutableStateFlow(false)

    fun uploadHomework(homework: Homework) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") return@launch
            repository.addHomework(homework)
        }
    }

    fun uploadHomeworkWithFile(
        className: String,
        subject: String,
        description: String,
        dueDate: String,
        fileUri: android.net.Uri?,
        fileName: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") {
                onComplete(false, "Unauthorized: Students cannot assign homework.")
                return@launch
            }

            val hwId = "HW_${System.currentTimeMillis()}_${(100..999).random()}"
            var finalFileUrl = ""

            if (fileUri != null) {
                isUploadingAttachment.value = true
                val uploadResult = repository.uploadHomeworkAttachment(fileUri, className, hwId, fileName)
                isUploadingAttachment.value = false

                if (uploadResult.isSuccess) {
                    finalFileUrl = uploadResult.getOrNull() ?: ""
                } else {
                    val errMsg = uploadResult.exceptionOrNull()?.message ?: "Upload failed"
                    _toastMessage.value = "File upload failed: $errMsg"
                    onComplete(false, errMsg)
                    return@launch
                }
            }

            val homework = Homework(
                homeworkId = hwId,
                className = className,
                subject = subject,
                description = description,
                dueDate = dueDate,
                fileUrl = finalFileUrl
            )
            val result = repository.addHomework(homework)
            if (result.isSuccess) {
                onComplete(true, null)
            } else {
                onComplete(false, result.exceptionOrNull()?.message)
            }
        }
    }

    fun deleteHomework(homeworkId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") return@launch
            repository.deleteHomework(homeworkId)
        }
    }

    // NOTICE OPERATIONS
    fun addNotice(notice: Notice) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") return@launch
            repository.addNotice(notice)
        }
    }

    fun deleteNotice(noticeId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") return@launch
            repository.deleteNotice(noticeId)
        }
    }

    // TIMETABLE OPERATIONS
    fun checkTimetableConflicts(timetable: Timetable): com.example.data.util.TimetableConflictResult {
        return com.example.data.util.TimetableConflictManager.validateTimetable(
            targetTimetable = timetable,
            allTimetables = timetablesState.value,
            knownTeachers = teachersState.value
        )
    }

    fun saveTimetable(
        timetable: Timetable,
        allowOverride: Boolean = false,
        overrideReason: String = "",
        onConflict: ((com.example.data.util.TimetableConflictResult.Conflict) -> Unit)? = null,
        onSuccess: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL" && role != "HEAD_ADMIN" && role != "ADMIN") {
                _toastMessage.value = "Unauthorized: Only management can modify timetables."
                return@launch
            }

            val conflictCheck = checkTimetableConflicts(timetable)
            if (conflictCheck is com.example.data.util.TimetableConflictResult.Conflict && !allowOverride) {
                _toastMessage.value = conflictCheck.message
                onConflict?.invoke(conflictCheck)
                return@launch
            }

            val res = repository.saveTimetable(timetable, allowOverride = allowOverride, overrideReason = overrideReason)
            if (res.isSuccess) {
                _toastMessage.value = if (allowOverride) "Timetable saved with Principal Override." else "Academic schedule saved successfully."
                onSuccess?.invoke()
            } else {
                _toastMessage.value = res.exceptionOrNull()?.message ?: "Failed to save timetable"
            }
        }
    }

    // CHAT OPERATIONS
    private var lastSendTimestamp = 0L

    fun setActiveChatRecipient(userId: String) {
        _activeChatUserId.value = userId.ifBlank { null }
        if (userId.isNotBlank()) {
            markChatMessagesAsRead(userId)
        }
    }

    fun markChatMessagesAsRead(senderId: String) {
        val currentU = currentUser.value ?: return
        if (senderId.isBlank()) return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.markMessagesAsRead(senderId = senderId, receiverId = currentU.userId)
        }
    }

    fun sendChatMessage(messageContent: String, replyToMessageId: String = "") {
        val currentU = currentUser.value ?: return
        val receiverU = activeChatUserId.value ?: return
        val trimmed = messageContent.trim()
        if (trimmed.isBlank()) return
        if (trimmed.length > 2000) {
            _toastMessage.value = "Message too long (max 2000 characters)"
            return
        }

        // Debounce fast double taps (300ms)
        val now = System.currentTimeMillis()
        if (now - lastSendTimestamp < 300) return
        lastSendTimestamp = now

        // Role-based recipient restriction:
        // Students can only message Teachers, Admins, or Principals
        val role = currentU.role.uppercase().trim()
        if (role == "STUDENT") {
            val isTeacher = teachersState.value.any { it.teacherId == receiverU }
            val isStaff = usersState.value.any { it.userId == receiverU && (it.role.uppercase() in listOf("TEACHER", "ADMIN", "HEAD_ADMIN", "PRINCIPAL", "CLASS_TEACHER")) }
            if (!isTeacher && !isStaff) {
                _toastMessage.value = "Students are only permitted to message teachers and administration."
                return
            }
        }

        val newMessage = ChatMessage(
            messageId = UUID.randomUUID().toString(),
            senderId = currentU.userId,
            receiverId = receiverU,
            message = trimmed,
            timestamp = now,
            isRead = false,
            status = "sent",
            replyToMessageId = replyToMessageId
        )

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.sendMessage(newMessage)
        }
    }

    fun sendChatMessageWithAttachment(
        messageContent: String,
        attachmentUri: android.net.Uri?,
        attachmentType: String,
        fileName: String,
        replyToMessageId: String = "",
        onComplete: (Boolean, String?) -> Unit = { _, _ -> }
    ) {
        val currentU = currentUser.value ?: return
        val receiverU = activeChatUserId.value ?: return
        val trimmed = messageContent.trim()

        val role = currentU.role.uppercase().trim()
        if (role == "STUDENT") {
            val isTeacher = teachersState.value.any { it.teacherId == receiverU }
            val isStaff = usersState.value.any { it.userId == receiverU && (it.role.uppercase() in listOf("TEACHER", "ADMIN", "HEAD_ADMIN", "PRINCIPAL", "CLASS_TEACHER")) }
            if (!isTeacher && !isStaff) {
                _toastMessage.value = "Students are only permitted to message teachers and administration."
                onComplete(false, "Recipient not permitted")
                return
            }
        }

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val msgId = UUID.randomUUID().toString()
            val convId = if (currentU.userId < receiverU) "${currentU.userId}_${receiverU}" else "${receiverU}_${currentU.userId}"
            var finalMsgText = trimmed
            var finalType = attachmentType

            if (attachmentUri != null) {
                val uploadResult = repository.uploadChatAttachment(attachmentUri, convId, msgId, fileName)
                if (uploadResult.isSuccess) {
                    val downloadUrl = uploadResult.getOrNull() ?: ""
                    finalMsgText = if (trimmed.isBlank()) downloadUrl else "$trimmed\n$downloadUrl"
                    if (finalType.isBlank()) {
                        finalType = if (fileName.endsWith(".pdf", true)) "pdf" else "image"
                    }
                } else {
                    val errMsg = uploadResult.exceptionOrNull()?.message ?: "Attachment upload failed"
                    _toastMessage.value = "Attachment failed: $errMsg"
                    onComplete(false, errMsg)
                    return@launch
                }
            }

            if (finalMsgText.isBlank() && finalType.isBlank()) return@launch

            val now = System.currentTimeMillis()
            val newMessage = ChatMessage(
                messageId = msgId,
                senderId = currentU.userId,
                receiverId = receiverU,
                message = finalMsgText,
                timestamp = now,
                isRead = false,
                status = "sent",
                attachmentType = finalType,
                replyToMessageId = replyToMessageId
            )
            val res = repository.sendMessage(newMessage)
            onComplete(res.isSuccess, res.exceptionOrNull()?.message)
        }
    }

    fun deleteChatMessage(messageId: String) {
        if (messageId.isBlank()) return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.deleteChatMessage(messageId)
        }
    }

    // New Architect Features
    
    fun removeClassTeacher(teacherId: String, onComplete: (Boolean) -> Unit = {}) {
        val user = repository.currentUserFlow.value
        val userId = user?.userId ?: "System"
        val userName = user?.name ?: "System"
        viewModelScope.launch {
            val res = repository.removeClassTeacher(teacherId, userId, userName)
            onComplete(res.isSuccess)
        }
    }

    fun assignClassTeacher(teacherBId: String, className: String, onComplete: (Boolean) -> Unit = {}) {
        val user = repository.currentUserFlow.value
        val userId = user?.userId ?: "System"
        val userName = user?.name ?: "System"
        viewModelScope.launch {
            val res = repository.assignClassTeacher(teacherBId, className, userId, userName)
            onComplete(res.isSuccess)
        }
    }

    fun seed10StudentsPerClass(onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.seed10StudentsPerClass()
            onComplete(res.isSuccess)
        }
    }

    fun requestDeletion(targetId: String, targetType: String, targetName: String, requesterName: String, requesterId: String) {
        viewModelScope.launch {
            val notifId = "DELREQ_${targetType}_${targetId}_${System.currentTimeMillis()}"
            val message = "Admin:\n" + requesterName + "\nRequested deletion of:\n" + targetType + ":\n" + targetName + "\nID:\n" + targetId
            val notification = com.example.data.model.AppNotification(
                notificationId = notifId,
                userId = "PRINCIPAL",
                title = "Deletion Request",
                message = message,
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "DELETE_REQUEST"
            )
            repository.addNotification(notification)
            
            repository.addAuditLog(
                com.example.data.model.AuditLog(
                    logId = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    userId = requesterId,
                    userName = requesterName,
                    action = "DELETE_REQUEST",
                    oldValue = targetType,
                    
                    newValue = "Requested deletion for $targetName - ID: $targetId"
                )
            )
        }
    }

    fun approveDeletion(notification: com.example.data.model.AppNotification, principalName: String, principalId: String) {
        viewModelScope.launch {
            val parts = notification.notificationId.split("_")
            if (parts.size >= 3) {
                val targetType = parts[1]
                val targetId = parts[2]
                
                if (targetType == "STUDENT") {
                    deleteStudent(targetId)
                } else if (targetType == "TEACHER") {
                    deleteTeacher(targetId)
                }
                deleteUserAccount(targetId)
                
                repository.addAuditLog(
                    com.example.data.model.AuditLog(
                        logId = java.util.UUID.randomUUID().toString(),
                        timestamp = System.currentTimeMillis(),
                        userId = principalId,
                        userName = principalName,
                        action = "DELETE_APPROVED",
                        oldValue = targetType,
                        
                        newValue = "Approved deletion requested by Admin - ID: $targetId"
                    )
                )
            }
            
            val updated = notification.copy(type = "APPROVED", title = "Deletion Approved", isRead = true)
            repository.addNotification(updated)
        }
    }

    fun rejectDeletion(notification: com.example.data.model.AppNotification, principalName: String, principalId: String) {
        viewModelScope.launch {
            val parts = notification.notificationId.split("_")
            if (parts.size >= 3) {
                val targetType = parts[1]
                val targetId = parts[2]
                
                repository.addAuditLog(
                    com.example.data.model.AuditLog(
                        logId = java.util.UUID.randomUUID().toString(),
                        timestamp = System.currentTimeMillis(),
                        userId = principalId,
                        userName = principalName,
                        action = "DELETE_REJECTED",
                        oldValue = targetType,
                        
                        newValue = "Rejected deletion request - ID: $targetId"
                    )
                )
            }
            
            val updated = notification.copy(type = "REJECTED", title = "Deletion Rejected", isRead = true)
            repository.addNotification(updated)
        }
    }

    fun promoteToAdmin(teacherId: String, onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can promote teachers to Admin."
                onComplete(false)
                return@launch
            }
            val res = repository.promoteToAdmin(teacherId)
            if (res.isSuccess) {
                logAudit("ROLE_CHANGED", "TEACHER", "Promoted $teacherId to ADMIN")
            }
            onComplete(res.isSuccess)
        }
    }

    fun demoteToTeacher(adminTeacherId: String, onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            if (!isCurrentUserPrincipal()) {
                _toastMessage.value = "Unauthorized: Only the Principal can demote staff."
                onComplete(false)
                return@launch
            }
            val res = repository.demoteToTeacher(adminTeacherId)
            if (res.isSuccess) {
                logAudit("ROLE_CHANGED", "ADMIN", "Demoted $adminTeacherId to TEACHER")
            }
            onComplete(res.isSuccess)
        }
    }

    // BOOK DISTRIBUTION OPERATIONS
    fun getClassBooksForClassFlow(className: String): Flow<List<ClassBook>> {
        return repository.getClassBooksForClass(className)
    }

    fun saveClassBook(book: ClassBook) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") { _toastMessage.value = "Unauthorized"; return@launch }
            repository.saveClassBook(book)
            logAudit("SAVE_CLASS_BOOK", "", "${book.className} - ${book.bookName}")
        }
    }

    fun deleteClassBook(bookId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") { _toastMessage.value = "Unauthorized"; return@launch }
            if (role == "STUDENT" || role == "PARENT") {
                _toastMessage.value = "Unauthorized"
                return@launch
            }
            repository.deleteClassBook(bookId)
            logAudit("DELETE_CLASS_BOOK", bookId, "Deleted book")
        }
    }

    fun getIssuedBooksForStudentFlow(studentId: String): Flow<List<IssuedBook>> {
        return repository.getIssuedBooksForStudent(studentId)
    }

    fun issueBook(issuedBook: IssuedBook) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT") { _toastMessage.value = "Unauthorized"; return@launch }
            repository.issueBook(issuedBook)
            logAudit("ISSUE_BOOK", "", "Issued ${issuedBook.bookName} to student ${issuedBook.studentId}")
        }
    }

    fun deleteIssuedBook(issueId: String) {
        viewModelScope.launch { 
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT" || role == "PARENT") {
                _toastMessage.value = "Unauthorized"
                return@launch
            }
            repository.deleteIssuedBook(issueId) 
        }
    }
    fun sendFeeReminderNotification(student: Student, dueAmount: Double) {
        viewModelScope.launch {
            val sender = currentUser.value
            val notification = AppNotification(
                notificationId = UUID.randomUUID().toString(),
                userId = student.studentId,
                title = "Fee Payment Reminder",
                message = "Dear Parent/Student, pending dues of ₹${"%,.0f".format(dueAmount)} are recorded for ${student.name} (${student.className}). Kindly settle at the earliest.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "FEE_REMINDER"
            )
            repository.addNotification(notification)
            logAudit("SEND_FEE_REMINDER", "", "Sent reminder to ${student.name} for ₹$dueAmount")
        }
    }

    fun logChatOversightAccess(viewerUserId: String, viewerUserName: String, participantAName: String, participantBName: String) {
        viewModelScope.launch {
            val log = AuditLog(
                logId = UUID.randomUUID().toString(),
                timestamp = System.currentTimeMillis(),
                userId = viewerUserId,
                userName = viewerUserName,
                action = "CHAT_OVERSIGHT_VIEW",
                oldValue = "",
                newValue = "Administrative inspection of conversation between $participantAName and $participantBName"
            )
            repository.addAuditLog(log)
        }
    }

    private fun seedSampleClassBooks() {
        viewModelScope.launch {
            val existing = repository.getAllClassBooks().firstOrNull() ?: emptyList()
            if (existing.isEmpty()) {
                val sampleBooks = listOf(
                    ClassBook(UUID.randomUUID().toString(), "Nursery", "Fun with Alphabets", "S.D. Press", "English", 250.0),
                    ClassBook(UUID.randomUUID().toString(), "Nursery", "Picture Rhymes & Songs", "S.D. Press", "General", 200.0),
                    ClassBook(UUID.randomUUID().toString(), "KG", "Junior English Practice", "S.D. Press", "English", 300.0),
                    ClassBook(UUID.randomUUID().toString(), "KG", "Number Magic 1-100", "S.D. Press", "Mathematics", 280.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 1", "Marigold English Reader 1", "NCERT", "English", 350.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 1", "Math Magic Book 1", "NCERT", "Mathematics", 320.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 1", "Rimjhim Hindi 1", "NCERT", "Hindi", 310.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 5", "Honeyhone English Reader 5", "NCERT", "English", 420.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 5", "Environmental Studies 5", "NCERT", "EVS", 450.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 10", "First Flight English 10", "NCERT", "English", 500.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 10", "Mathematics Text Book 10", "NCERT", "Mathematics", 550.0),
                    ClassBook(UUID.randomUUID().toString(), "Class 10", "Science Text Book 10", "NCERT", "Science", 580.0)
                )
                sampleBooks.forEach { repository.saveClassBook(it) }
            }
        }
    }

    init {
        seedSampleClassBooks()
        viewModelScope.launch {
            try {
                repository.auditAndMigrateAccounts()
            } catch (e: Exception) {}
        }
        viewModelScope.launch {
            try {
                repository.seed10StudentsPerClass()
            } catch (e: Exception) {}
        }
        viewModelScope.launch {
            try {
                repository.performSchoolStructureMigration()
            } catch (e: Exception) {}
        }
        viewModelScope.launch {
            _isSessionChecking.value = true
            try {
                val restored = repository.checkAndRestoreSession()
                updateNavigationTargetForUser(restored)
            } catch (e: Exception) {
                _loginError.value = e.message ?: "Error"
                repository.logout()
                _navigationState.value = NavigationTarget.LOGIN_SCREEN
            } finally {
                _isSessionChecking.value = false
            }
        }
        viewModelScope.launch {
            repository.currentUserFlow.collect { user -> 
                 if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
                    _selectedClassForAttendance.value = user.className.trim()
                }
            }
        }
    }
    private val _feeConfig = MutableStateFlow(loadFeeConfig())
    val feeConfig = _feeConfig.asStateFlow()

    private fun loadFeeConfig(): com.example.data.model.FeeConfig {
        val prefs = com.example.SchoolApplication.instance.getSharedPreferences("school_config", android.content.Context.MODE_PRIVATE)
        return com.example.data.model.FeeConfig(
            admissionFee = prefs.getFloat("admissionFee", 2000f).toDouble(),
            tuitionFee = prefs.getFloat("tuitionFee", 1000f).toDouble(),
            gameFee = prefs.getFloat("gameFee", 150f).toDouble(),
            examFee = prefs.getFloat("examFee", 500f).toDouble(),
            transportSlab1 = prefs.getFloat("transportSlab1", 400f).toDouble(),
            transportSlab2 = prefs.getFloat("transportSlab2", 800f).toDouble(),
            transportSlab3 = prefs.getFloat("transportSlab3", 1200f).toDouble()
        )
    }

    fun saveFeeConfig(config: com.example.data.model.FeeConfig) {
        val prefs = com.example.SchoolApplication.instance.getSharedPreferences("school_config", android.content.Context.MODE_PRIVATE)
        prefs.edit().apply {
            putFloat("admissionFee", config.admissionFee.toFloat())
            putFloat("tuitionFee", config.tuitionFee.toFloat())
            putFloat("gameFee", config.gameFee.toFloat())
            putFloat("examFee", config.examFee.toFloat())
            putFloat("transportSlab1", config.transportSlab1.toFloat())
            putFloat("transportSlab2", config.transportSlab2.toFloat())
            putFloat("transportSlab3", config.transportSlab3.toFloat())
        }.apply()
        _feeConfig.value = config
    }

    // New effective-dated, class-wise fee rates (replaces the flat FeeConfig going forward).
    val feeRates: StateFlow<List<com.example.data.model.FeeRateHistory>> =
        repository.getAllFeeRatesFlow().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setFeeRate(className: String, feeType: String, amount: Double, effectiveFromMonth: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL") {
                _toastMessage.value = "Unauthorized: Only the Principal can change fee rates."
                return@launch
            }
            val userId = repository.currentUserFlow.value?.userId ?: ""
            repository.setFeeRate(className, feeType, amount, effectiveFromMonth, userId)
        }
    }

    val feeEventCharges: StateFlow<List<com.example.data.model.FeeEventCharge>> =
        repository.getAllFeeEventChargesFlow().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addFeeEventCharge(className: String, month: String, label: String, amount: Double) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role != "PRINCIPAL") {
                _toastMessage.value = "Unauthorized: Only the Principal can add event charges."
                return@launch
            }
            val userId = repository.currentUserFlow.value?.userId ?: ""
            repository.addFeeEventCharge(className, month, label, amount, userId)
        }
    }

    private fun isEmulator(): Boolean {
        val buildModel = android.os.Build.MODEL.lowercase()
        val buildProduct = android.os.Build.PRODUCT.lowercase()
        val buildHardware = android.os.Build.HARDWARE.lowercase()
        return (android.os.Build.FINGERPRINT.startsWith("generic")
                || android.os.Build.FINGERPRINT.startsWith("unknown")
                || buildModel.contains("google_sdk")
                || buildModel.contains("emulator")
                || buildModel.contains("android sdk built for x86")
                || buildModel.contains("cuttlefish")
                || android.os.Build.MANUFACTURER.contains("Genymotion")
                || (android.os.Build.BRAND.startsWith("generic") && android.os.Build.DEVICE.startsWith("generic"))
                || buildProduct == "google_sdk"
                || buildProduct.contains("sdk_gphone")
                || buildProduct.contains("aosp_cf")
                || buildHardware.contains("goldfish")
                || buildHardware.contains("ranchu")
                || buildHardware.contains("cutf_cvm"))
    }
}
