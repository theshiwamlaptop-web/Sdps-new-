package com.example.ui.screens
import androidx.compose.material.icons.automirrored.filled.*
import com.example.ui.components.PasswordManagementCard
import com.example.ui.components.SecureScreen

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.SchoolViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// Preserved Avatars map for stunning Material 3 Profiles
@Composable
fun getAvatarIcon(avatar: String): ImageVector {
    return when (avatar) {
        "avatar_graduate" -> Icons.Filled.School
        "avatar_scholar" -> Icons.Filled.MenuBook
        "avatar_gamer" -> Icons.Filled.SportsEsports
        "avatar_teacher" -> Icons.Filled.Person
        "avatar_athlete" -> Icons.Filled.SportsBaseball
        "avatar_scientist" -> Icons.Filled.Science
        else -> Icons.Filled.Face
    }
}

val PredefinedSchoolAvatars = listOf(
    "avatar_graduate" to "Graduate Caps",
    "avatar_scholar" to "Academic Scholar",
    "avatar_gamer" to "Sports Gamer",
    "avatar_teacher" to "Staff Instructor",
    "avatar_athlete" to "Active Athlete",
    "avatar_scientist" to "Young Scientist"
)

@Composable
fun SettingsScreen(viewModel: SchoolViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: My Profile, 1: Administrative Controls
    
    val context = LocalContext.current
    val user = currentUser
    if (user == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Please login to access settings panel.", fontWeight = FontWeight.Bold)
        }
        return
    }

    val role = user.role

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Headers to split Profile adjustments from role tools cleanly
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.PersonOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("My Profile", fontWeight = FontWeight.Bold)
                } },
                            modifier = Modifier.testTag("settings_tab_profile")
            )
            
            val controlTabTitle = when (role) {
                "PRINCIPAL" -> "Principal ERP Panel"
                "HEAD_ADMIN", "ADMIN" -> "Staff Controls"
                "TEACHER" -> "Classroom Tools"
                else -> "My Student Portal"
            }
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(controlTabTitle, fontWeight = FontWeight.Bold)
                } },
                            modifier = Modifier.testTag("settings_tab_erp")
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            if (selectedTab == 0) {
                ProfileSettingsTab(viewModel = viewModel, user = user)
            } else {
                when (role) {
                    "PRINCIPAL" -> PrincipalERPPanel(viewModel = viewModel, principal = user)
                    "HEAD_ADMIN", "ADMIN" -> AdminERPPanel(viewModel = viewModel)
                    "TEACHER" -> TeacherERPPanel(viewModel = viewModel, teacherUser = user)
                    else -> StudentERPPanel(viewModel = viewModel, studentUser = user)
                }
            }
        }
    }
}

// ==========================================
// CORE PROFILE SETTINGS FOR ALL ROLES
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsTab(viewModel: SchoolViewModel, user: User) {
    val context = LocalContext.current
    val usersList by viewModel.usersState.collectAsState(initial = emptyList())
    val teachersList by viewModel.teachersState.collectAsState(initial = emptyList())
    
    // Principal capability: can select other users to view/delete
    var selectedUser by remember(user) { mutableStateOf(user) }
    
    // Active dropdown expansion state for selecting other users
    var isUserSelectorExpanded by remember { mutableStateOf(false) }
    
    var nameInput by remember(selectedUser) { mutableStateOf(selectedUser.name) }
    var emailInput by remember(selectedUser) { mutableStateOf(selectedUser.email) }
    var phoneInput by remember(selectedUser) { mutableStateOf(selectedUser.phone) }
    
    
    var isSavingProfile by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showDobDatePicker by remember { mutableStateOf(false) }
    val dobDatePickerState = rememberDatePickerState()

    val viewerRole = user.role.uppercase().trim()
    val isViewerPrincipal = viewerRole == "PRINCIPAL" || user.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    val isViewerAdmin = viewerRole == "ADMIN" || viewerRole == "HEAD_ADMIN"
    val isTargetPrincipal = selectedUser.role.uppercase().trim() == "PRINCIPAL" || selectedUser.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
    val isTargetAdmin = selectedUser.role.uppercase().trim() == "ADMIN"
    val isViewingSelf = selectedUser.userId == user.userId

    val canEditTargetDob = when {
        isViewerPrincipal -> true
        isViewerAdmin -> !isViewingSelf && !isTargetPrincipal && !isTargetAdmin
        else -> false
    }

    if (showDobDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDobDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        dobDatePickerState.selectedDateMillis?.let { millis ->
                            val cal = java.util.Calendar.getInstance().apply { timeInMillis = millis }
                            if (cal.timeInMillis > System.currentTimeMillis()) {
                                Toast.makeText(context, "Invalid DOB. Cannot be in the future.", Toast.LENGTH_SHORT).show()
                            } else {
                                val sdf = java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.ENGLISH)
                                val formattedDob = sdf.format(cal.time)
                                viewModel.updateUserDob(selectedUser.userId, formattedDob) { success, msg ->
                                    if (success) {
                                        selectedUser = selectedUser.copy(dob = formattedDob)
                                        showDobDatePicker = false
                                    } else {
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                    }
                ) {
                    Text("Save DOB")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDobDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = dobDatePickerState)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Principal User Selector (only visible if the login user is principal)
        if (isViewerPrincipal) {
            item {
                ElevatedCard(
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Principal Dashboard: Profile Inspector",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Select any institutional record below to inspect their full Instagram-Style Bio, modify, or permanently delete them from the cloud database server.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        Box(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            OutlinedButton(
                                onClick = { isUserSelectorExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("profile_inspector_selector"),
                                colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${selectedUser.name} (${selectedUser.role} - ID: ${selectedUser.userId})",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Icon(imageVector = Icons.Filled.ArrowDropDown, contentDescription = null)
                                }
                            }
                            
                            DropdownMenu(
                                expanded = isUserSelectorExpanded,
                                onDismissRequest = { isUserSelectorExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("My Profile (Principal Account)", fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        selectedUser = user
                                        isUserSelectorExpanded = false
                                    }
                                )
                                usersList.filter { it.userId != user.userId }.forEach { usr ->
                                    DropdownMenuItem(
                                        text = { Text("${usr.name} [${usr.role}] (${usr.userId})") },
                                        onClick = {
                                            selectedUser = usr
                                            isUserSelectorExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
            }
        }
        }

        // Instagram-Style Profile Header Card
        item {
            ElevatedCard(
                colors = glassCardColors(),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val matchingTeacher = teachersList.find { it.teacherId == selectedUser.userId }
                    val resolvedClassTeacher = matchingTeacher?.classTeacherOf ?: if (selectedUser.role == "CLASS_TEACHER") selectedUser.className else ""

                    // Avatar badge circle with dynamic glowing ring border and overlapping badge overlay
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.sweepGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.tertiary,
                                            MaterialTheme.colorScheme.secondary,
                                            MaterialTheme.colorScheme.primary
                                        )
                                    )
                                )
                                .padding(4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = getAvatarIcon(selectedUser.avatarUrl),
                                    contentDescription = "Profile Avatar",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(60.dp)
                                )
                            }
                        }

                        // Centered Overlap Badge with Gold/Silver border
                        val isPrincipal = selectedUser.role.uppercase() == "PRINCIPAL" || selectedUser.email == "theshiwamlaptop@gmail.com"
                        val isHeadAdmin = selectedUser.role.uppercase() == "HEAD_ADMIN"
                        val isClassTeacher = selectedUser.role.uppercase() == "CLASS_TEACHER" || (selectedUser.role.uppercase() == "TEACHER" && resolvedClassTeacher.isNotEmpty())
                        val isAdmin = selectedUser.role.uppercase() == "ADMIN"

                        val badgeDetails = when {
                            isPrincipal -> Triple("Principal Verified", Color(0xFFFEF08A), Icons.Filled.WorkspacePremium)
                            isHeadAdmin -> Triple("Head Admin Verified", Color(0xFFFDE68A), Icons.Filled.Shield)
                            isClassTeacher -> Triple("Class Teacher Verified", Color(0xFF38BDF8), Icons.Filled.School)
                            isAdmin -> Triple("System Admin Verified", Color(0xFFFCA5A5), Icons.Filled.Shield)
                            else -> null
                        }

                        if (badgeDetails != null) {
                            val (label, tintColor, badgeIcon) = badgeDetails
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .offset(x = (4).dp, y = (4).dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(tintColor, Color(0xFFF59E0B))))
                                    .padding(2.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0F172A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = badgeIcon,
                                    contentDescription = label,
                                    tint = tintColor,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Full Name in Bold
                    Text(
                        text = selectedUser.name.uppercase(),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Stylized Profile Role Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(
                                when (selectedUser.role.uppercase()) {
                                    "PRINCIPAL" -> MaterialTheme.colorScheme.errorContainer
                                    "ADMIN" -> MaterialTheme.colorScheme.primaryContainer
                                    "TEACHER", "CLASS_TEACHER" -> MaterialTheme.colorScheme.secondaryContainer
                                    else -> MaterialTheme.colorScheme.tertiaryContainer
                                }
                            )
                            .padding(horizontal = 14.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = when (selectedUser.role.uppercase()) {
                                "PRINCIPAL" -> "👑 PRINCIPAL"
                                "ADMIN" -> "💼 ADMINISTRATOR"
                                "TEACHER", "CLASS_TEACHER" -> {
                                    if (resolvedClassTeacher.isNotEmpty()) "📐 CLASS TEACHER OF ${resolvedClassTeacher.uppercase()}"
                                    else "📐 SUBJECT TEACHER"
                                }
                                else -> "🎓 SCHOLAR"
                            }
,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (selectedUser.role.uppercase()) {
                                "PRINCIPAL" -> MaterialTheme.colorScheme.onErrorContainer
                                "ADMIN" -> MaterialTheme.colorScheme.onPrimaryContainer
                                "TEACHER", "CLASS_TEACHER" -> MaterialTheme.colorScheme.onSecondaryContainer
                                else -> MaterialTheme.colorScheme.onTertiaryContainer
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Divider line
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))

                    Spacer(modifier = Modifier.height(16.dp))

                    // Instagram-Style "Bio" Grid Layout items
                    InstagramBioRow(label = "User Account ID", valStr = selectedUser.userId, icon = Icons.Filled.AccountBox)
                    InstagramBioRow(label = "Contact Number", valStr = selectedUser.phone.ifEmpty { "Not Provided" }, icon = Icons.Filled.Phone)
                    InstagramBioRow(label = "Email Address", valStr = selectedUser.email.ifEmpty { "Not Provided" }, icon = Icons.Filled.Email)
                    InstagramBioRow(label = "Campus Address", valStr = "S.D.P.S. Campus Sector 4, New Delhi", icon = Icons.Filled.LocationOn)
                    InstagramBioRowWithAction(
                        label = "Date of Birth (DOB)",
                        valStr = selectedUser.dob.ifEmpty { "Not Provided" },
                        icon = Icons.Filled.Cake,
                        canEdit = canEditTargetDob,
                        onEditClick = { showDobDatePicker = true }
                    )
                }
            }
        }

        // Customizable Choices for Own Profile Only
        if (selectedUser.userId == user.userId) {
            item {
                ElevatedCard(
                    colors = glassCardColors(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Customize Scholar Avatar",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // horizontal scroll profiles selection list
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            PredefinedSchoolAvatars.forEach { (avatarKey, avatarLabel) ->
                                val isSelected = user.avatarUrl == avatarKey
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.LightGray.copy(alpha = 0.2f))
                                        .border(
                                            2.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable {
                                            val updated = user.copy(avatarUrl = avatarKey)
                                            viewModel.updateUserProfile(updated)
                                            viewModel.logAudit(
                                                "Changed Avatar Icon",
                                                user.avatarUrl,
                                                avatarKey
                                            )
                                            Toast.makeText(context, "Avatar changed to $avatarLabel!", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = getAvatarIcon(avatarKey),
                                            contentDescription = avatarLabel,
                                            tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Text(text = avatarLabel.split(" ").last(), fontSize = 9.sp, color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray, fontWeight = FontWeight.SemiBold)
                                    }
}
}
}
}
}
}
        // Contact details update (Only for own profile)
            item {
                ElevatedCard(
                    colors = glassCardColors(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Contact Details",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.secondary
                        )

                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Display Name") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Filled.AccountCircle, null) },
                            modifier = Modifier.fillMaxWidth().testTag("profile_settings_name")
                        )

                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email Contact") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Filled.Email, null) },
                            modifier = Modifier.fillMaxWidth().testTag("profile_settings_email"),
                            enabled = user.role != "STUDENT"
                        )

                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it },
                            label = { Text("Phone Number") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Filled.Phone, null) },
                            modifier = Modifier.fillMaxWidth().testTag("profile_settings_phone"),
                            enabled = user.role != "STUDENT"
                        )

                        Button(
                            onClick = {
                                if (nameInput.trim().isBlank()) {
                                    Toast.makeText(context, "Name cannot be empty!", Toast.LENGTH_SHORT).show()
                                } else {
                                    isSavingProfile = true
                                    val oldValueStr = "Name:${user.name}, email:${user.email}, phone:${user.phone}"
                                    val newRecord = user.copy(
                                        name = nameInput.trim(),
                                        email = emailInput.trim(),
                                        phone = phoneInput.trim()
                                    )
                                    viewModel.updateUserProfile(newRecord)
                                    viewModel.logAudit(
                                        "Updated Profile Details",
                                        oldValueStr,
                                        "Name:${newRecord.name}, email:${newRecord.email}, phone:${newRecord.phone}"
                                    )
                                    isSavingProfile = false
                                    Toast.makeText(context, "Profile details saved successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("profile_settings_save_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isSavingProfile) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            } else {
                                Text("Save Profile Changes", fontWeight = FontWeight.Bold)
                            }
}
}
}
}


            item {
                PasswordManagementCard(
                    targetUser = selectedUser,
                    currentUserRole = user.role,
                    viewModel = viewModel
                )
            }
        // Theme Preferences (Only for own profile)
            item {
                ElevatedCard(
                    colors = glassCardColors(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("App Theme Mode", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text("Choose manual coloration schemes.", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("SYSTEM" to "System", "LIGHT" to "Light", "DARK" to "DarkTheme").forEach { (themeKey, themeLabel) ->
                                val isSelected = user.themePreference == themeKey
                                OutlinedButton(
                                    onClick = {
                                        val updated = user.copy(themePreference = themeKey)
                                        viewModel.updateUserProfile(updated)
                                        viewModel.logAudit("Changed Theme Mode", user.themePreference, themeKey)
                                        Toast.makeText(context, "$themeLabel theme selected!", Toast.LENGTH_SHORT).show()
                                    }
,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                    ),
                                    border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_btn_$themeKey")
                                ) {
                                    Text(themeLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray)
                                }
}
}
}
}
}
        // Alert Toggles (Only for own profile)
            item {
                ElevatedCard(
                    colors = glassCardColors(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Alert Preferences", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)

                        NotificationToggleItem(
                            title = "Mute All Announcements",
                            description = "Silence standard calendar announcements.",
                            checked = user.enableMuteNotifications,
                            onCheckedChange = {
                                viewModel.updateUserProfile(user.copy(enableMuteNotifications = it))
                            }
                        )
                        
                        NotificationToggleItem(
                            title = "Homework Deadline Alerts",
                            description = "Get alerted when subjects post homework tasks.",
                            checked = user.enableHomeworkAlerts,
                            onCheckedChange = {
                                viewModel.updateUserProfile(user.copy(enableHomeworkAlerts = it))
                            }
                        )

                        NotificationToggleItem(
                            title = "Fee Reminder Notifications",
                            description = "Get billing ledger status payment links.",
                            checked = user.enableFeeAlerts,
                            onCheckedChange = {
                                viewModel.updateUserProfile(user.copy(enableFeeAlerts = it))
                            }
                        )

                        NotificationToggleItem(
                            title = "Attendance Daily Reports",
                            description = "Receive instant reports of absent triggers.",
                            checked = user.enableAttendanceAlerts,
                            onCheckedChange = {
                                viewModel.updateUserProfile(user.copy(enableAttendanceAlerts = it))
                            }
                        )
                    }
            }
        }
}
        // Principal permanent deletion capability (Visible ONLY to the Principal)
        if (isViewerPrincipal) {
            val principalsCount = usersList.count { it.role.uppercase() == "PRINCIPAL" }
            val canDeleteThisUser = if (selectedUser.userId == user.userId) principalsCount > 1 else true
            if (canDeleteThisUser) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { showDeleteConfirmDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("delete_permanently_button")
                ) {
                    Icon(imageVector = Icons.Filled.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedUser.userId == user.userId) "🚨 Delete Principal Account Permanently" else "🚨 Delete This Account Permanently",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        }

        // Standard Secure logout hook (For all users, on their own profile view)
        if (selectedUser.userId == user.userId) {
            item {
                Button(
                    onClick = {
                        viewModel.logoutUser()
                        Toast.makeText(context, "Logged out of portal securely.", Toast.LENGTH_SHORT).show()
                    }
,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("settings_logout_btn")
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Secure Log Out Connection", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    // Stylized Fail-Safe Deletion Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            containerColor = MaterialTheme.colorScheme.errorContainer,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Filled.Warning, contentDescription = "Warning", tint = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.size(28.dp))
                    Text("खाता हमेशा के लिए हटाएं?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                }
            },
            text = {
                Text(
                    text = "क्या आप सच में इस अकाउंट (${selectedUser.name}) को परमानेंटली डिलीट करना चाहते हैं? हटाने के बाद यह डेटा वापस नहीं मिलेगा।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        val idToDelete = selectedUser.userId
                        viewModel.deleteUserAccount(idToDelete) { success ->
                            if (success) {
                                viewModel.logAudit("PRINCIPAL PERMANENT DELETION", "Deleted User account secure record id: $idToDelete", "SUCCESS")
                                Toast.makeText(context, "Account permanently removed from system!", Toast.LENGTH_LONG).show()
                                
                                // Reset Principal inspector selected user back to principal
                                if (idToDelete != user.userId) {
                                    selectedUser = user
                                }
                            } else {
                                Toast.makeText(context, "Deletions failed. Please try again.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onError),
                    modifier = Modifier.testTag("dialog_confirm_delete_btn")
                ) {
                    Text("YES (Delete)", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteConfirmDialog = false },
                            modifier = Modifier.testTag("dialog_dismiss_delete_btn")
                ) {
                    Text("NO (Cancel)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        )
    }
    


}

@Composable
fun NotificationToggleItem(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
            Text(description, fontSize = 10.sp, color = Color.Gray)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.scaleModifier(0.85f)
        )
    }
}

@Composable
fun InstagramBioRow(label: String, valStr: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Column {
            Text(label, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Text(valStr, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun InstagramBioRowWithAction(
    label: String,
    valStr: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    canEdit: Boolean,
    onEditClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(label, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    if (!canEdit) {
                        Text("(Official Record - Read Only)", fontSize = 9.sp, color = Color.Gray)
                    }
                }
                Text(valStr, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (canEdit) {
            IconButton(
                onClick = onEditClick,
                modifier = Modifier.size(32.dp).testTag("edit_dob_btn")
            ) {
                Icon(
                    imageVector = Icons.Filled.EditCalendar,
                    contentDescription = "Edit Date of Birth",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        } else {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = "Locked Record",
                tint = MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier.size(16.dp).padding(end = 4.dp)
            )
        }
    }
}

// Helper to scale switch down a tiny bit visually
fun Modifier.scaleModifier(scale: Float): Modifier = this

// ==========================================
// PRINCIPAL / HEAD ADMIN ERP CONTROL INTERFACE
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalERPPanel(viewModel: SchoolViewModel, principal: User) {
    SecureScreen()
    val context = LocalContext.current
    val users by viewModel.usersState.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    val auditLogs by viewModel.auditLogsState.collectAsState()
    val notices by viewModel.noticesState.collectAsState()
    
    var subSectionTab by remember { mutableStateOf(viewModel.requestedSettingsTab) } // 0: User Roles, 1: Teachers & Classes, 2: School Config, 3: Audits & Logs
    
    // Configurations Edit State
    var schoolName by remember { mutableStateOf("S. D Public School") }
    var clockInThreshold by remember { mutableStateOf("08:30 AM") }
    
    val feeConfig by viewModel.feeConfig.collectAsState()
    var baseAdmission by remember(feeConfig) { mutableStateOf(feeConfig.admissionFee.toString()) }
    var monthlyTuition by remember(feeConfig) { mutableStateOf(feeConfig.tuitionFee.toString()) }
    var sportsFund by remember(feeConfig) { mutableStateOf(feeConfig.gameFee.toString()) }
    var examFee by remember(feeConfig) { mutableStateOf(feeConfig.examFee.toString()) }
    var transport0to5 by remember(feeConfig) { mutableStateOf(feeConfig.transportSlab1.toString()) }
    var transport5to10 by remember(feeConfig) { mutableStateOf(feeConfig.transportSlab2.toString()) }
    var transport10to15 by remember(feeConfig) { mutableStateOf(feeConfig.transportSlab3.toString()) }

    // --- New: Class-wise Fee Rate & Event Charge management state ---
    val academicClassList = listOf("Nursery", "LKG", "UKG", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10")
    val academicMonthList = listOf("April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March")
    val feeTypeOptions = listOf(
        "TUITION" to "Tuition Fee",
        "ADMISSION" to "Admission Fee",
        "EXAM" to "Exam Fee",
        "GAME" to "Game/Sports Fee",
        "TRANSPORT_0_5" to "Transport 0-5 km",
        "TRANSPORT_5_10" to "Transport 5-10 km",
        "TRANSPORT_10_15" to "Transport 10-15 km"
    )
    var rateClassScope by remember { mutableStateOf("ALL") } // "ALL" or a specific class
    var rateClassExpanded by remember { mutableStateOf(false) }
    var rateFeeType by remember { mutableStateOf("TUITION") }
    var rateFeeTypeExpanded by remember { mutableStateOf(false) }
    var rateMonth by remember { mutableStateOf("April") }
    var rateMonthExpanded by remember { mutableStateOf(false) }
    var rateAmountInput by remember { mutableStateOf("") }
    val feeRatesList by viewModel.feeRates.collectAsState()

    var eventClassScope by remember { mutableStateOf("ALL") }
    var eventClassExpanded by remember { mutableStateOf(false) }
    var eventMonth by remember { mutableStateOf("April") }
    var eventMonthExpanded by remember { mutableStateOf(false) }
    var eventLabelInput by remember { mutableStateOf("") }
    var eventAmountInput by remember { mutableStateOf("") }
    val feeEventChargesList by viewModel.feeEventCharges.collectAsState()
    // --- End new state ---

    
    // Dialog triggers
    var showAssignTeacherDialog by remember { mutableStateOf(false) }
    var selectedTeacherForClassAssign by remember { mutableStateOf<Teacher?>(null) }
    var classesTextForAssign by remember { mutableStateOf("") }
    var subjectTextForAssign by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryTabRow(
            selectedTabIndex = subSectionTab,
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
        ) {
            listOf("Security Roles", "Classes Assign", "School Setup", "Security Audits").forEachIndexed { idx, label ->
                Tab(
                    selected = subSectionTab == idx,
                    onClick = { subSectionTab = idx },
                    text = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (subSectionTab) {
                0 -> { // SECURITY ROLES SECURITY MANAGEMENT SYSTEM
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Portal Access Directory", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Count: ${users.size}", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        }

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(users) { usr ->
                                val isSelf = usr.userId == principal.userId
                                ElevatedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = glassCardColors()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(usr.name.ifBlank { usr.email.substringBefore("@").ifBlank { usr.userId } }, fontWeight = FontWeight.Bold)
                                                if (isSelf) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Box(modifier = Modifier.background(Color(0xFFE0F2FE)).padding(horizontal = 4.dp, vertical = 2.dp)) {
                                                        Text("SELF", fontSize = 8.sp, color = Color(0xFF0284C7), fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                            Text("ID Code: ${usr.userId} | Email: ${usr.email}", fontSize = 11.sp, color = Color.Gray)
                                            Text("Auth Level: ${usr.role} (${usr.roleCode})", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            val isMasterPrincipal = principal.role == "PRINCIPAL" || principal.email.equals("theshiwamlaptop@gmail.com", ignoreCase = true)
                                            
                                            // Access promotion dropdown (Principal only)
                                            if (!isSelf && isMasterPrincipal) {
                                                val rolesList = listOf("HEAD_ADMIN", "ADMIN", "TEACHER", "STUDENT")
                                                IconButton(
                                                    onClick = {
                                                        val currentIndex = rolesList.indexOf(usr.role)
                                                        val nextIndex = (currentIndex + 1) % rolesList.size
                                                        val nextRole = rolesList[nextIndex]
                                                        val updatedRoleCode = when (nextRole) {
                                                             "HEAD_ADMIN" -> "HA-99"
                                                             "ADMIN" -> "AD-55"
                                                             "TEACHER" -> "TC-12"
                                                             else -> "ST-01"
                                                         }
                                                         val promotedUser = usr.copy(role = nextRole, roleCode = updatedRoleCode)
                                                         viewModel.addUser(promotedUser)
                                                         viewModel.logAudit(
                                                             "Modified User Access Level",
                                                             "Role: ${usr.role}, Code: ${usr.roleCode}",
                                                             "Role: $nextRole, Code: $updatedRoleCode"
                                                         )
                                                         Toast.makeText(context, "Role level updated for ${usr.name} to $nextRole!", Toast.LENGTH_SHORT).show()
                                                     },
                                                     modifier = Modifier.size(28.dp).testTag("toggle_role_${usr.userId}")
                                                 ) {
                                                     Icon(imageVector = Icons.Filled.GroupWork, contentDescription = "Toggle Role Access", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                                 }
                                             }
                                         }
                                    }
                                }
                            }
                        }

                        // Locked Ownership Transfer Section
                        ElevatedCard(
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("🔒 Enterprise Ownership Transfer", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.error)
                                Text("Instantly demote your principal level session and register another trusted administrator successor as the absolute Principal/Root Owner.", fontSize = 11.sp)
                                
                                var showTransferDialog by remember { mutableStateOf(false) }
                                var targetUserForTransfer by remember { mutableStateOf<User?>(null) }
                                
                                var dropdownExpanded by remember { mutableStateOf(false) }
                                Box {
                                    OutlinedButton(onClick = { dropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("ownership_transfer_selector")) {
                                        Text(targetUserForTransfer?.let { "${it.name} (${it.role})" } ?: "Select Successor Owner")
                                    }
                                    DropdownMenu(expanded = dropdownExpanded, onDismissRequest = { dropdownExpanded = false }) {
                                        users.filter { it.userId != principal.userId && it.role != "PRINCIPAL" }.forEach { otherUsr ->
                                            DropdownMenuItem(
                                                text = { Text("${otherUsr.name} (${otherUsr.role})") },
                                                onClick = {
                                                    targetUserForTransfer = otherUsr
                                                    dropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                                
                                Button(
                                    onClick = { showTransferDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth().testTag("ownership_transfer_submit"),
                                    enabled = targetUserForTransfer != null
                                ) {
                                    Text("Transfer Principal Ownership Securely", fontWeight = FontWeight.Bold)
                                }
                                
                                if (showTransferDialog && targetUserForTransfer != null) {
                                    AlertDialog(
                                        onDismissRequest = { showTransferDialog = false },
                                        title = { Text("WARN: CRYPTOGRAPHIC OWNER DEMOTION", fontWeight = FontWeight.Bold) },
                                        text = { Text("Are you absolutely sure you want to transfer owners? You will automatically be demoted to Administrator and lose write ownership claims.") },
                                        confirmButton = {
                                            Button(
                                                onClick = {
                                                    showTransferDialog = false
                                                    val oldPrincipal = principal.copy(role = "ADMIN", roleCode = "AD-55")
                                                    val newPrincipal = targetUserForTransfer!!.copy(role = "PRINCIPAL", roleCode = "PR-100")
                                                    viewModel.addUser(oldPrincipal)
                                                    viewModel.addUser(newPrincipal)
                                                    viewModel.logAudit("OWNERSHIP TRANSFER COMPLETE", "Demoted self to ADMIN. Promoted ${newPrincipal.name}", "SUCCESS")
                                                    Toast.makeText(context, "Ownership transferred! Demoting principal session... Please log in again.", Toast.LENGTH_LONG).show()
                                                    targetUserForTransfer = null
                                                }
,
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                                modifier = Modifier.testTag("confirm_ownership_transfer_btn")
                                            ) {
                                                Text("YES, CONFIRM TRANSFER")
                                            }
                                        }
,
                                        dismissButton = {
                                            TextButton(onClick = { showTransferDialog = false }) { Text("CANCEL") }
                                        }
                                    )
                                }
                    }
                            }
                        }
                        }
                1 -> { // CLASSES COMPREHENSIVE ASSIGNMENT
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Class Teacher Assignments & Portfolios", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Principal can instantly assign classes and subjects to appropriate teachers.", fontSize = 11.sp, color = Color.Gray)

                        // Live Faculty Status Monitor Panel
                        ElevatedCard(
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                                Text("📡 Live Faculty Status Monitor", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    val totalFaculty = teachers.size
                                    val assignedFaculty = teachers.filter { it.classesAssigned.isNotBlank() }.size
                                    
                                    Column {
                                        Text("Total Educators: $totalFaculty", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("Portfolio Assigned: $assignedFaculty", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Duty Active Status: PRESENT", fontSize = 11.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                        Text("Daily Logs Tracked: $totalFaculty Archives", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(teachers) { tec ->
                                ElevatedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = glassCardColors()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(imageVector = Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(tec.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            }
                                            IconButton(
                                                onClick = {
                                                    selectedTeacherForClassAssign = tec
                                                    classesTextForAssign = tec.classesAssigned
                                                    subjectTextForAssign = tec.subject
                                                    showAssignTeacherDialog = true
                                                },
                            modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(imageVector = Icons.Filled.EditCalendar, contentDescription = "Edit Class Assigns", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Assigned Subject: ${tec.subject}", fontSize = 12.sp, color = Color.Gray)
                                        
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 6.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "PORTFOLIO: ${tec.classesAssigned.ifBlank { "Unassigned" }}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                2 -> { // SCHOOL CONFIGURATION CONFIG CODES
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("School Setup & Threshold Configuration", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                        // Live Notice Board Broadcast Segment
                        ElevatedCard(
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("📢 Broadcast Live Notice Board Announcement", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodyMedium)
                                
                                var noticeTitleInput by remember { mutableStateOf("") }
                                var noticeDescInput by remember { mutableStateOf("") }
                                
                                OutlinedTextField(
                                    value = noticeTitleInput,
                                    onValueChange = { noticeTitleInput = it },
                                    label = { Text("Notice Title", fontSize = 12.sp) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("notice_title_input")
                                )
                                OutlinedTextField(
                                    value = noticeDescInput,
                                    onValueChange = { noticeDescInput = it },
                                    label = { Text("Announcement Body Context", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("notice_desc_input")
                                )
                                
                                Button(
                                    onClick = {
                                        if (noticeTitleInput.isBlank() || noticeDescInput.isBlank()) {
                                            Toast.makeText(context, "Title and description details cannot be blank!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            val formatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
                                            val dateStr = formatter.format(java.util.Date())
                                            val newNotice = Notice(
                                                noticeId = java.util.UUID.randomUUID().toString(),
                                                title = noticeTitleInput,
                                                description = noticeDescInput,
                                                createdAt = java.util.Date().time,
                                                targetClass = "All"
                                            )
                                            viewModel.addNotice(newNotice)
                                            viewModel.logAudit("BROADCAST LIVE NOTICE", noticeTitleInput, "INFO")
                                            Toast.makeText(context, "Notice live broadcast active!", Toast.LENGTH_SHORT).show()
                                            noticeTitleInput = ""
                                            noticeDescInput = ""
                                        }
                                    }
,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                    modifier = Modifier.fillMaxWidth().testTag("notice_broadcast_btn")
                                ) {
                                    Text("📢 Broadcast Absolute Notice", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = schoolName,
                            onValueChange = { schoolName = it },
                            label = { Text("School Facility Title") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clockInThreshold,
                            onValueChange = { clockInThreshold = it },
                            label = { Text("Teacher Morning Punch Clock-In Threshold (Normal)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        ElevatedCard(
                            colors = glassCardColors(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Manage ERP Default Base Fee Formulas", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("Set base values computed during traditional ledgers registration starting April.", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = baseAdmission, onValueChange = { baseAdmission = it }, label = { Text("Admission Fee") },
                            modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = monthlyTuition, onValueChange = { monthlyTuition = it }, label = { Text("Monthly Tuition") },
                            modifier = Modifier.weight(1f))
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = sportsFund, onValueChange = { sportsFund = it }, label = { Text("Game/Sports Fee") },
                            modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = examFee, onValueChange = { examFee = it }, label = { Text("Exam Fee") },
                            modifier = Modifier.weight(1f))
                                }
                                Text("Transport Slabs", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = transport0to5, onValueChange = { transport0to5 = it }, label = { Text("0-5 km") },
                            modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = transport5to10, onValueChange = { transport5to10 = it }, label = { Text("5-10 km") },
                            modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = transport10to15, onValueChange = { transport10to15 = it }, label = { Text("10-15 km") },
                            modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        Button(
                            onClick = {
                                val newConfig = com.example.data.model.FeeConfig(
                                    admissionFee = baseAdmission.toDoubleOrNull() ?: 0.0,
                                    tuitionFee = monthlyTuition.toDoubleOrNull() ?: 0.0,
                                    gameFee = sportsFund.toDoubleOrNull() ?: 0.0,
                                    examFee = examFee.toDoubleOrNull() ?: 0.0,
                                    transportSlab1 = transport0to5.toDoubleOrNull() ?: 0.0,
                                    transportSlab2 = transport5to10.toDoubleOrNull() ?: 0.0,
                                    transportSlab3 = transport10to15.toDoubleOrNull() ?: 0.0
                                )
                                viewModel.saveFeeConfig(newConfig)
                                viewModel.logAudit(
                                    "Adjusted Facility Wide Setup Settings",
                                    "SchoolName: S. D Public School",
                                    "SchoolName: $schoolName, clockInThreshold: $clockInThreshold, fees updated"
                                )
                                Toast.makeText(context, "School Wide Parameters Saved Successfully!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Save Facility Setup Configuration", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        // ---------- NEW: Class-wise, effective-dated Fee Rate Management ----------
                        ElevatedCard(
                            colors = glassCardColors(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Set Class-wise Fee Rate", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("A change here applies only from the selected month onward. Earlier months always keep whatever rate was active then.", fontSize = 11.sp, color = Color.Gray)

                                // Class selector
                                Box {
                                    OutlinedButton(onClick = { rateClassExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (rateClassScope == "ALL") "All Classes" else rateClassScope, modifier = Modifier.weight(1f))
                                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(expanded = rateClassExpanded, onDismissRequest = { rateClassExpanded = false }, modifier = Modifier.fillMaxWidth(0.9f)) {
                                        DropdownMenuItem(text = { Text("All Classes") }, onClick = { rateClassScope = "ALL"; rateClassExpanded = false })
                                        academicClassList.forEach { cls ->
                                            DropdownMenuItem(text = { Text(cls) }, onClick = { rateClassScope = cls; rateClassExpanded = false })
                                        }
                                    }
                                }

                                // Fee type selector
                                Box {
                                    OutlinedButton(onClick = { rateFeeTypeExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text(feeTypeOptions.find { it.first == rateFeeType }?.second ?: rateFeeType, modifier = Modifier.weight(1f))
                                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(expanded = rateFeeTypeExpanded, onDismissRequest = { rateFeeTypeExpanded = false }, modifier = Modifier.fillMaxWidth(0.9f)) {
                                        feeTypeOptions.forEach { (code, label) ->
                                            DropdownMenuItem(text = { Text(label) }, onClick = { rateFeeType = code; rateFeeTypeExpanded = false })
                                        }
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        OutlinedButton(onClick = { rateMonthExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                            Text(rateMonth)
                                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                                        }
                                        DropdownMenu(expanded = rateMonthExpanded, onDismissRequest = { rateMonthExpanded = false }) {
                                            academicMonthList.forEach { m ->
                                                DropdownMenuItem(text = { Text(m) }, onClick = { rateMonth = m; rateMonthExpanded = false })
                                            }
                                        }
                                    }
                                    OutlinedTextField(
                                        value = rateAmountInput,
                                        onValueChange = { rateAmountInput = it },
                                        label = { Text("Amount (₹)") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Button(
                                    onClick = {
                                        val amt = rateAmountInput.toDoubleOrNull()
                                        if (amt == null || amt < 0) {
                                            Toast.makeText(context, "Enter a valid amount", Toast.LENGTH_SHORT).show()
                                        } else {
                                            viewModel.setFeeRate(rateClassScope, rateFeeType, amt, rateMonth)
                                            Toast.makeText(context, "Rate set: ${feeTypeOptions.find { it.first == rateFeeType }?.second} for $rateClassScope = ₹$amt from $rateMonth", Toast.LENGTH_LONG).show()
                                            rateAmountInput = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(44.dp)
                                ) {
                                    Text("Apply Rate From $rateMonth", fontWeight = FontWeight.Bold)
                                }

                                if (feeRatesList.isNotEmpty()) {
                                    Text("Recent rate changes", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                    feeRatesList.sortedByDescending { it.setAt }.take(6).forEach { r ->
                                        Text(
                                            "${feeTypeOptions.find { it.first == r.feeType }?.second ?: r.feeType} • ${r.className} • ₹${r.amount} from ${r.effectiveFromMonth}",
                                            fontSize = 11.sp, color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // ---------- NEW: One-time Event Charges ----------
                        ElevatedCard(
                            colors = glassCardColors(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Add One-Time Event Charge", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("Adds an extra charge to the selected class (or all classes) for just that one month. Students will see the label you enter here.", fontSize = 11.sp, color = Color.Gray)

                                Box {
                                    OutlinedButton(onClick = { eventClassExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (eventClassScope == "ALL") "All Classes" else eventClassScope, modifier = Modifier.weight(1f))
                                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(expanded = eventClassExpanded, onDismissRequest = { eventClassExpanded = false }, modifier = Modifier.fillMaxWidth(0.9f)) {
                                        DropdownMenuItem(text = { Text("All Classes") }, onClick = { eventClassScope = "ALL"; eventClassExpanded = false })
                                        academicClassList.forEach { cls ->
                                            DropdownMenuItem(text = { Text(cls) }, onClick = { eventClassScope = cls; eventClassExpanded = false })
                                        }
                                    }
                                }

                                Box {
                                    OutlinedButton(onClick = { eventMonthExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text(eventMonth)
                                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(expanded = eventMonthExpanded, onDismissRequest = { eventMonthExpanded = false }) {
                                        academicMonthList.forEach { m ->
                                            DropdownMenuItem(text = { Text(m) }, onClick = { eventMonth = m; eventMonthExpanded = false })
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = eventLabelInput,
                                    onValueChange = { eventLabelInput = it },
                                    label = { Text("What is this charge for? (e.g. Sports Day Fee)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = eventAmountInput,
                                    onValueChange = { eventAmountInput = it },
                                    label = { Text("Amount (₹)") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = {
                                        val amt = eventAmountInput.toDoubleOrNull()
                                        if (eventLabelInput.isBlank()) {
                                            Toast.makeText(context, "Enter what this charge is for", Toast.LENGTH_SHORT).show()
                                        } else if (amt == null || amt <= 0) {
                                            Toast.makeText(context, "Enter a valid amount", Toast.LENGTH_SHORT).show()
                                        } else {
                                            viewModel.addFeeEventCharge(eventClassScope, eventMonth, eventLabelInput.trim(), amt)
                                            Toast.makeText(context, "Added: $eventLabelInput (₹$amt) for $eventClassScope in $eventMonth", Toast.LENGTH_LONG).show()
                                            eventLabelInput = ""
                                            eventAmountInput = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(44.dp)
                                ) {
                                    Text("Add Event Charge", fontWeight = FontWeight.Bold)
                                }

                                if (feeEventChargesList.isNotEmpty()) {
                                    Text("Recent event charges", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                    feeEventChargesList.sortedByDescending { it.createdAt }.take(6).forEach { ev ->
                                        Text("${ev.label} • ${ev.className} • ₹${ev.amount} • ${ev.month}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> { // COMPREHENSIVE SECURITY AUDITS LOG
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Security Auditing Intelligence Timeline", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("View detailed cryptographic activity logs. Restricted access: Principal Only.", fontSize = 11.sp, color = Color.Gray)

                        // Complete School Analytics Grid Overview Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.Group, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text("Accounts", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                Text("${users.size}", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Text("Notices", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                                Text("${notices.size}", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f))
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                Text("Audited", fontSize = 10.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                                Text("${auditLogs.size}", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            }
                        }

                        if (auditLogs.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No recent log registry files available.", fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, color = Color.Gray)
                            }
                            } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(auditLogs) { log ->
                                    ElevatedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(log.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(
                                                    text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(log.timestamp)),
                                                    fontSize = 10.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                            Text("Staff ID: ${log.userId}", fontSize = 11.sp, color = Color.Gray)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Action: ${log.action}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                            
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Column {
                                                Text("Old Value: ${log.oldValue}", fontSize = 10.sp, color = Color.Gray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text("New Value: ${log.newValue}", fontSize = 10.sp, color = Color(0xFF10B981), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
            
        
    

    if (showAssignTeacherDialog && selectedTeacherForClassAssign != null) {
        val teacherObj = selectedTeacherForClassAssign!!
        AlertDialog(
            onDismissRequest = { showAssignTeacherDialog = false },
            title = { Text("Configure Teacher Portfolio", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Reassign subjects and classes portfolio for Mrs/Mr: ${teacherObj.name}", fontSize = 12.sp)

                    OutlinedTextField(
                        value = subjectTextForAssign,
                        onValueChange = { subjectTextForAssign = it },
                        label = { Text("Instructing Subjects") },
                            modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = classesTextForAssign,
                        onValueChange = { classesTextForAssign = it },
                        label = { Text("Classes Portfolio (e.g. Class X - Sec A)") },
                            modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = teacherObj.copy(
                            subject = subjectTextForAssign.trim(),
                            classesAssigned = classesTextForAssign.trim()
                        )
                        viewModel.addOrUpdateTeacher(updated)
                        viewModel.logAudit(
                            "Updated Teacher Portfolio",
                            "Subject: ${teacherObj.subject}, Classes: ${teacherObj.classesAssigned}",
                            "Subject: ${updated.subject}, Classes: ${updated.classesAssigned}"
                        )
                        showAssignTeacherDialog = false
                        Toast.makeText(context, "Teacher Portfolio configured!", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Save Portfolio")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAssignTeacherDialog = false }) { Text("Cancel") }
            }
        )
    }


// ==========================================
}
    }
}
}
}
// ADMIN STAFF CONTROL PANEL (LIMITED ERP)
// ==========================================
@Composable
fun AdminERPPanel(viewModel: SchoolViewModel) {
    val students by viewModel.studentsState.collectAsState()
    val teachers by viewModel.teachersState.collectAsState()
    val notices by viewModel.noticesState.collectAsState()
    
    var showAddNoticeDialog by remember { mutableStateOf(false) }
    var noteTitle by remember { mutableStateOf("") }
    var noteMessage by remember { mutableStateOf("") }
    
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Staff ERP Operational Dashboard", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("Administrative roles are privileged with Notice Board posting and direct Student rosters monitoring.", fontSize = 11.sp, color = Color.Gray)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ElevatedCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Total Students", fontSize = 10.sp, color = Color.Gray)
                    Text("${students.size} Enrolled", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
            ElevatedCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Total Staff", fontSize = 10.sp, color = Color.Gray)
                    Text("${teachers.size} Instructors", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Recent Notices Posted", fontWeight = FontWeight.Bold)
            Button(
                onClick = { showAddNoticeDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(imageVector = Icons.Filled.AddAlert, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Broadcast Notice", fontSize = 12.sp)
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(notices) { nc ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(nc.title, fontWeight = FontWeight.Bold)
                            Text(SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(nc.createdAt)), fontSize = 10.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(nc.description, fontSize = 12.sp, lineHeight = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Target: ${nc.targetClass}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
            }
        }
    }

    if (showAddNoticeDialog) {
        AlertDialog(
            onDismissRequest = { showAddNoticeDialog = false },
            title = { Text("Publish New Notice Notice") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = noteTitle,
                        onValueChange = { noteTitle = it },
                        label = { Text("Notice Header Title") },
                            modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = noteMessage,
                        onValueChange = { noteMessage = it },
                        label = { Text("Notice Announcement Message") },
                            modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noteTitle.trim().isBlank() || noteMessage.trim().isBlank()) {
                            Toast.makeText(context, "Fill out both notice fields!", Toast.LENGTH_SHORT).show()
                        } else {
                            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                            val notice = Notice(
                                noticeId = UUID.randomUUID().toString(),
                                title = noteTitle.trim(),
                                description = noteMessage.trim(),
                                createdAt = Date().time,
                                targetClass = "All"
                            )
                            viewModel.addNotice(notice)
                            viewModel.logAudit("Posted Notice Bulletin", "-", notice.title)
                            showAddNoticeDialog = false
                            noteTitle = ""
                            noteMessage = ""
                            Toast.makeText(context, "Notice published successfully!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Publish notice")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNoticeDialog = false }) { Text("Cancel") }
            }
        )
    }
}
}

// ==========================================
// CLASS TEACHER ERP PANEL
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherERPPanel(viewModel: SchoolViewModel, teacherUser: User) {
    val context = LocalContext.current
    val students by viewModel.studentsState.collectAsState()
    val homework by viewModel.homeworkState.collectAsState()
    
    val assignedClass = "Class X" // Default assigned class for TC-12 staff
    
    val classStudents = remember(students) {
        students.filter { it.className.contains(assignedClass, ignoreCase = true) }
    }

    // Punch hours log attendance
    val historicAttendance by viewModel.teacherAttendanceState.collectAsState()
    val myAttendance = remember(historicAttendance, teacherUser.userId) {
        historicAttendance.filter { it.teacherId == teacherUser.userId }
    }

    var showHomeworkDialog by remember { mutableStateOf(false) }
    var hwSubject by remember { mutableStateOf("Mathematics") }
    var hwDescription by remember { mutableStateOf("") }
    var hwDueDate by remember { mutableStateOf("2026-05-28") }

    var localCheckInRemarks by remember { mutableStateOf("") }

    var activeTeacherSectionTab by remember { mutableStateOf(0) } // 0: Attendance, 1: Classroom Homework, 2: Student Remarks

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryTabRow(selectedTabIndex = activeTeacherSectionTab) {
            listOf("Duty Punching", "Class Homework", "Student Remind").forEachIndexed { index, label ->
                Tab(
                    selected = activeTeacherSectionTab == index,
                    onClick = { activeTeacherSectionTab = index },
                    text = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (activeTeacherSectionTab) {
                0 -> { // TEACHER ATTENDANCE CLOCK-IN CLOCK-OUT SYSTEM
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Clock-In / Clock-Out punch hours card", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        
                        ElevatedCard(
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Clock-In Duty Punch Portal", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                OutlinedTextField(
                                    value = localCheckInRemarks,
                                    onValueChange = { localCheckInRemarks = it },
                                    label = { Text("Special duty check-in remarks") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    // Clock-In Present
                                    Button(
                                        onClick = {
                                            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                                            val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                                            val att = TeacherAttendance(
                                                attendanceId = "${teacherUser.userId}_$today",
                                                teacherId = teacherUser.userId,
                                                teacherName = teacherUser.name,
                                                date = today,
                                                checkInTime = timeStr,
                                                checkOutTime = "N/A",
                                                status = "Present",
                                                remarks = localCheckInRemarks.ifBlank { "Regular Duty Shift" }
                                            )
                                            viewModel.addTeacherAttendance(att)
                                            viewModel.logAudit("Teacher Checked-In (Present)", "-", today)
                                            Toast.makeText(context, "Checked In (Present) successfully at $timeStr!", Toast.LENGTH_SHORT).show()
                                        },
                            modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Text("Clock In", fontSize = 11.sp)
                                    }

                                    // Clock-In On Duty (OD)
                                    Button(
                                        onClick = {
                                            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                                            val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                                            val att = TeacherAttendance(
                                                attendanceId = "${teacherUser.userId}_$today",
                                                teacherId = teacherUser.userId,
                                                teacherName = teacherUser.name,
                                                date = today,
                                                checkInTime = timeStr,
                                                checkOutTime = "N/A",
                                                status = "On Duty",
                                                remarks = localCheckInRemarks.ifBlank { "External Examination Auditor Duty" }
                                            )
                                            viewModel.addTeacherAttendance(att)
                                            viewModel.logAudit("Teacher Checked-In (On Duty)", "-", today)
                                            Toast.makeText(context, "Logged Check-in (On Duty) at $timeStr!", Toast.LENGTH_SHORT).show()
                                        },
                            modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                    ) {
                                        Text("On Duty (OD)", fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("My Duty logs History", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)

                        if (myAttendance.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No historical clock registers archived.", fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, color = Color.Gray)
                            }
                            } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(myAttendance) { ta ->
                                    val isOD = ta.status == "On Duty"
                                    ElevatedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.elevatedCardColors(
                                            containerColor = if (isOD) Color(0xFFEFF6FF) else Color(0xFFECFDF5)
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text("Date: ${ta.date}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text("Recorded Punch: ${ta.checkInTime} to ${ta.checkOutTime}", fontSize = 11.sp, color = Color.Gray)
                                                Text("Shift Remarks: ${ta.remarks}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isOD) Color(0xFF3B82F6) else Color(0xFF10B981))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text(ta.status, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                1 -> { // CLASSROOM HOMEWORK MANAGEMENT
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Classes Homework Assigned", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Button(onClick = { showHomeworkDialog = true }) {
                                Icon(Icons.Filled.Add, null)
                                Text("Assign Tasks")
                            }
                        }

                        val classHomework = homework.filter { it.className == assignedClass }
                        if (classHomework.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No recent homework files configured for assignment.", color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                            }
                            } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(classHomework) { hw ->
                                    ElevatedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = glassCardColors()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Subject: ${hw.subject}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                IconButton(
                                                    onClick = {
                                                        viewModel.deleteHomework(hw.homeworkId)
                                                        viewModel.logAudit("Deleted Homework Task", hw.subject, "-")
                                                        Toast.makeText(context, "Task deleted", Toast.LENGTH_SHORT).show()
                                                    },
                            modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete homework", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(hw.description, fontSize = 12.sp, lineHeight = 16.sp)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("Due Submission Date: ${hw.dueDate}", fontSize = 10.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                2 -> { // STUDENT DUES REMINDER LEDGER FOR ACTIVE LESSON
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Class Student Dues Reminders", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Send automated fee billing alerts right to classroom students profiles.", fontSize = 11.sp, color = Color.Gray)

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(classStudents) { std ->
                                ElevatedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = glassCardColors()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(std.name, fontWeight = FontWeight.Bold)
                                            Text("ID: ${std.studentId} | Roll: ${std.rollNo}", fontSize = 11.sp, color = Color.Gray)
                                            Text("Contact: ${std.phone}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.logAudit(
                                                    "Issued Student Dues Reminder Alert",
                                                    "-",
                                                    "Recipient ID: ${std.studentId}"
                                                )
                                                Toast.makeText(context, "Automated fee reminder dispatch complete to ${std.name}!", Toast.LENGTH_SHORT).show()
                                            }
,
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.Filled.ChatBubble, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Remind", fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
            }
        }
    }
    }

    if (showHomeworkDialog) {
        AlertDialog(
            onDismissRequest = { showHomeworkDialog = false },
            title = { Text("Post Subject Homework") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hwSubject,
                        onValueChange = { hwSubject = it },
                        label = { Text("Instructing Subject") },
                            modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = hwDescription,
                        onValueChange = { hwDescription = it },
                        label = { Text("Problem Description & Instructions") },
                            modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = hwDueDate,
                        onValueChange = { hwDueDate = it },
                        label = { Text("Submission Date (YYYY-MM-DD)") },
                            modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (hwDescription.trim().isBlank()) {
                            Toast.makeText(context, "Fill description tasks!", Toast.LENGTH_SHORT).show()
                        } else {
                            val newHw = Homework(
                                homeworkId = UUID.randomUUID().toString(),
                                className = assignedClass,
                                subject = hwSubject.trim(),
                                description = hwDescription.trim(),
                                dueDate = hwDueDate.trim()
                            )
                            viewModel.uploadHomework(newHw)
                            viewModel.logAudit("Posted Subject Homework", "-", newHw.subject)
                            showHomeworkDialog = false
                            hwDescription = ""
                            Toast.makeText(context, "Subject Homework Posted successfully!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Publish Task")
                }
            },
            dismissButton = {
                TextButton(onClick = { showHomeworkDialog = false }) { Text("Cancel") }
            }
        )
    }
}
    


// ==========================================
// STUDENT PERSONAL ERP DETAIL SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentERPPanel(viewModel: SchoolViewModel, studentUser: User) {
    val students by viewModel.studentsState.collectAsState()
    val homework by viewModel.homeworkState.collectAsState()
    val notices by viewModel.noticesState.collectAsState()
    
    val myStudentId = studentUser.userId
    val myStudent = remember(students, myStudentId) {
        students.find { it.studentId == myStudentId }
    }

    val studentClass = myStudent?.className ?: "Class X"

    var activeStudentSecTab by remember { mutableStateOf(0) } // 0: Homework Tasks, 1: Bulletins Board, 2: Academy Status

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryTabRow(selectedTabIndex = activeStudentSecTab) {
            listOf("My Homework", "Notice Board", "Academy Particulars").forEachIndexed { index, label ->
                Tab(
                    selected = activeStudentSecTab == index,
                    onClick = { activeStudentSecTab = index },
                    text = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (activeStudentSecTab) {
                0 -> { // STUDENT HOMEWORK FEED
                    val matchedHomework = homework.filter { it.className == studentClass }
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("My Homework Agenda ($studentClass)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        
                        if (matchedHomework.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Looking clean! No active homework deadlines recorded.", color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                            }
                            } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(matchedHomework) { hw ->
                                    ElevatedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = glassCardColors()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Subject: ${hw.subject}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Box(modifier = Modifier.background(Color(0xFFFEF2F2)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                    Text("DUE", fontSize = 9.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(hw.description, fontSize = 12.sp, lineHeight = 16.sp)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("Timeline: Complete prior to ${hw.dueDate}", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                1 -> { // NOTICES TIMELINE FEED FOR STUDENTS
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Facility Notices Timeline Board", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                        if (notices.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No official bulletins files uploaded.", color = Color.Gray)
                            }
                            } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(notices) { nc ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text(nc.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                                Text(SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(nc.createdAt)), fontSize = 10.sp, color = Color.Gray)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(nc.description, fontSize = 12.sp, lineHeight = 16.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                2 -> { // ACADEMY PARTICULARS METADATA FOR STUDENT PORTALS
                    val details = myStudent
                    if (details == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Aadhaar files and pupil particulars not fully synchronized. Please contact administration desk.", color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    } else {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text("Official Scholar Registry Card", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                            ElevatedCard {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StudentMetadataRow("Scholar Name", details.name)
                                    StudentMetadataRow("Facility Roll Number", details.rollNo)
                                    StudentMetadataRow("Academic Class", details.className)
                                    StudentMetadataRow("Admission Register ID", details.admissionNo)
                                    StudentMetadataRow("Date of Admission", details.dateOfAdmission)
                                    StudentMetadataRow("Father's Name", details.fatherName)
                                    StudentMetadataRow("Mother's Name", details.motherName)
                                    StudentMetadataRow("Aadhaar Unique Identifier", details.aadhaarNo)
                                    StudentMetadataRow("District Zone", details.district)
                                    StudentMetadataRow("Post Office Branch", details.postOffice)
                                    StudentMetadataRow("Address Particulars", details.address)
                                }
                            }
                        }
                    }
            }
        }
    }
}
}


@Composable
fun StudentMetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
    }
}
