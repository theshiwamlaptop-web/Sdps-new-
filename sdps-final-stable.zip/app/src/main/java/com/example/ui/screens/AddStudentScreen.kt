package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Student
import com.example.ui.SchoolViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.Calendar
import com.example.ui.theme.glassCardColors

fun formatName(name: String): String {
    if (name.isBlank()) return ""
    return name.trim().replace(Regex("\\s+"), " ").split(" ").joinToString(" ") { 
        if (it.isNotEmpty()) it.replaceFirstChar { char -> char.uppercase() } else ""
    }
}

@Composable
fun NewStudentCredentialDialog(
    student: Student,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val credentialsText = """
        S.D. PUBLIC SCHOOL - STUDENT ACCOUNT CREATED
        ------------------------------------------
        Student Name: ${student.name}
        Admission ID: ${student.admissionNo.ifBlank { student.id }}
        User ID: ${student.studentId}
        Class: ${student.className}
        Initial Password: ${student.DOB} (Format: DD-MM-YYYY)
        Account Status: INITIAL DOB PASSWORD
        ------------------------------------------
        Note: Log in using User ID and Initial Password (DOB). You can update your password after logging in.
    """.trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("STUDENT ACCOUNT CREATED", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Student registered successfully! Present or share these credentials with the student/parent:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Student Name: ${student.name}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text("Admission ID: ${student.admissionNo.ifBlank { student.id }}", style = MaterialTheme.typography.bodyMedium)
                        Text("User ID: ${student.studentId}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("Class: ${student.className}", style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Text("Initial Password (DOB): ${student.DOB}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                        
                        Surface(
                            color = Color(0xFFFFF3E0),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                "Account Status: INITIAL DOB PASSWORD",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFFE65100)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("User ID", student.studentId))
                            Toast.makeText(context, "User ID copied!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Copy User ID", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Password", student.DOB))
                            Toast.makeText(context, "Initial Password copied!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Copy Password", fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val shareIntent = android.content.Intent().apply {
                        action = android.content.Intent.ACTION_SEND
                        putExtra(android.content.Intent.EXTRA_TEXT, credentialsText)
                        type = "text/plain"
                    }
                    context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Student Credentials"))
                }
            ) {
                Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Share")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddStudentScreen(viewModel: SchoolViewModel, onNavigate: (AppScreen) -> Unit) {
    val context = LocalContext.current
    val prefillClass by viewModel.prefillClass.collectAsState()
    val editingStudent by viewModel.editingStudent.collectAsState()

    var newlyRegisteredStudent by remember { mutableStateOf<Student?>(null) }

    if (newlyRegisteredStudent != null) {
        NewStudentCredentialDialog(
            student = newlyRegisteredStudent!!,
            onDismiss = {
                newlyRegisteredStudent = null
                onNavigate(AppScreen.STUDENTS)
            }
        )
    }

    var studentName by remember(editingStudent) { mutableStateOf(editingStudent?.name ?: "") }
    var className by remember(editingStudent, prefillClass) { mutableStateOf(editingStudent?.className ?: prefillClass) }
    var rollNo by remember(editingStudent) { mutableStateOf(editingStudent?.rollNo ?: "") }
    var fatherName by remember(editingStudent) { mutableStateOf(editingStudent?.fatherName ?: "") }
    var motherName by remember(editingStudent) { mutableStateOf(editingStudent?.motherName ?: "") }
    var phone by remember(editingStudent) { mutableStateOf(editingStudent?.phone ?: "") }
    var address by remember(editingStudent) { mutableStateOf(editingStudent?.address ?: "") }
    var dob by remember(editingStudent) { mutableStateOf(editingStudent?.DOB ?: "") }
    
    // Transport
    var hasTransport by remember(editingStudent) { mutableStateOf(editingStudent?.hasTransport ?: false) }
    var transportSlab by remember(editingStudent) { mutableStateOf(editingStudent?.transportSlab?.ifEmpty { "0-5 km" } ?: "0-5 km") }
    
    var isClassDropdownExpanded by remember { mutableStateOf(false) }
    var isTransportDropdownExpanded by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    
    val datePickerState = rememberDatePickerState()

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        val cal = Calendar.getInstance().apply { timeInMillis = millis }
                        // Ensure it's not a future date
                        if (cal.timeInMillis > System.currentTimeMillis()) {
                            Toast.makeText(context, "Invalid DOB. Cannot be in the future.", Toast.LENGTH_SHORT).show()
                        } else {
                            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
                            dob = sdf.format(cal.time)
                            showDatePicker = false
                        }
                    }
                }) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (editingStudent != null) "Edit Student" else "Register Student") },
                navigationIcon = {
                    IconButton(onClick = { 
                        viewModel.setEditingStudent(null)
                        onNavigate(AppScreen.DASHBOARD) 
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(containerColor = MaterialTheme.colorScheme.surface) {
                Button(
                    onClick = {
                        val formattedName = formatName(studentName)
                        val formattedFatherName = formatName(fatherName)
                        
                        // Validation
                        if (formattedName.isBlank() || className.isBlank() || dob.isBlank() || formattedFatherName.isBlank() || phone.isBlank()) {
                            Toast.makeText(context, "Please fill all mandatory fields (Name, Class, DOB, Father's Name, Phone)", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        
                        if (phone.length != 10 || phone.any { !it.isDigit() }) {
                            Toast.makeText(context, "Phone number must be exactly 10 digits", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val finalId = editingStudent?.studentId ?: "STU_${java.util.UUID.randomUUID().toString().replace("-", "").take(8).uppercase()}"
                        val finalAdmissionNo = editingStudent?.admissionNo ?: "ADM_${System.currentTimeMillis()}" 

                        val newStudent = Student(
                            studentId = finalId,
                            id = finalId,
                            name = formattedName,
                            className = className,
                            rollNo = rollNo,
                            admissionNo = finalAdmissionNo,
                            fatherName = formattedFatherName,
                            motherName = formatName(motherName),
                            phone = phone,
                            address = address,
                            DOB = dob,
                            hasTransport = hasTransport,
                            transportSlab = transportSlab,
                            transportFee = if (hasTransport) {
                                when (transportSlab) {
                                    "0-5 km" -> 500.0
                                    "5-10 km" -> 1000.0
                                    "10-15 km" -> 1500.0
                                    else -> 0.0
                                }
                            } else 0.0,
                            // Preserve existing values if editing
                            dateOfAdmission = editingStudent?.dateOfAdmission ?: SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date()),
                            attendanceStatus = editingStudent?.attendanceStatus ?: "Present",
                            feeStatus = editingStudent?.feeStatus ?: "Pending",
                            role = editingStudent?.role ?: "STUDENT",
                            photoUrl = editingStudent?.photoUrl ?: "",
                            aadhaarNo = editingStudent?.aadhaarNo ?: ""
                        )
                        viewModel.addOrUpdateStudent(newStudent, isEdit = (editingStudent != null))
                        viewModel.setEditingStudent(null)
                        if (editingStudent != null) {
                            Toast.makeText(context, "Student Updated Successfully", Toast.LENGTH_SHORT).show()
                            onNavigate(AppScreen.STUDENTS)
                        } else {
                            newlyRegisteredStudent = newStudent
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(if (editingStudent != null) "Update Student" else "Save Student")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Basic Info
            RegistrationSection(title = "Basic Information", icon = Icons.Filled.Person) {
                OutlinedTextField(
                    value = studentName,
                    onValueChange = { studentName = it },
                    label = { Text("Full Name *") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = className,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Class *") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { isClassDropdownExpanded = true }) {
                                    Icon(Icons.Filled.ArrowDropDown, "Select")
                                }
                            }
                        )
                        DropdownMenu(expanded = isClassDropdownExpanded, onDismissRequest = { isClassDropdownExpanded = false }) {
                            SchoolClassesList.forEach { cl ->
                                DropdownMenuItem(text = { Text(cl) }, onClick = { className = cl; isClassDropdownExpanded = false })
                            }
                        }
                    }
                    OutlinedTextField(
                        value = rollNo,
                        onValueChange = { rollNo = it },
                        label = { Text("Roll No") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                OutlinedTextField(
                    value = dob,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Date of Birth (DD-MM-YYYY) *") },
                    modifier = Modifier.fillMaxWidth().clickable { showDatePicker = true },
                    enabled = false,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            // Parent Info
            RegistrationSection(title = "Parent & Contact Details", icon = Icons.Filled.FamilyRestroom) {
                OutlinedTextField(
                    value = fatherName,
                    onValueChange = { fatherName = it },
                    label = { Text("Father's Name *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = motherName,
                    onValueChange = { motherName = it },
                    label = { Text("Mother's Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { 
                        if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                            phone = it 
                        }
                    },
                    label = { Text("Mobile Number *") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Residential Address") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }

            // Transport Info
            RegistrationSection(title = "Transport Configuration", icon = Icons.Filled.DirectionsBus) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { hasTransport = !hasTransport }.padding(vertical = 8.dp)) {
                    Checkbox(checked = hasTransport, onCheckedChange = { hasTransport = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enable Transport Facility")
                }
                AnimatedVisibility(visible = hasTransport) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = transportSlab,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Distance Slab") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { isTransportDropdownExpanded = true }) {
                                    Icon(Icons.Filled.ArrowDropDown, "Select")
                                }
                            }
                        )
                        DropdownMenu(expanded = isTransportDropdownExpanded, onDismissRequest = { isTransportDropdownExpanded = false }) {
                            listOf("0-5 km", "5-10 km", "10-15 km").forEach { slab ->
                                DropdownMenuItem(text = { Text(slab) }, onClick = { transportSlab = slab; isTransportDropdownExpanded = false })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RegistrationSection(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = glassCardColors(),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
            HorizontalDivider()
            content()
        }
    }
}
