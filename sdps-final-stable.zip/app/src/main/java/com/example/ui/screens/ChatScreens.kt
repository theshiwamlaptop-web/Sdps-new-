package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.SchoolViewModel
import com.example.ui.components.UserProfileAvatar
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import com.example.ui.theme.glassCardColors

data class ChatContactInfo(
    val id: String,
    val name: String,
    val role: String,
    val photoUrl: String,
    val category: String, // "ADMIN", "TEACHER", "STUDENT"
    val subtitle: String = "",
    val phone: String = "",
    val email: String = ""
)

data class ChatListItem(
    val contact: ChatContactInfo,
    val lastMessage: ChatMessage?,
    val unreadCount: Int
)

@Composable
fun ChatScreen(viewModel: SchoolViewModel) {
    val chatsMessages by viewModel.chatsState.collectAsStateWithLifecycle()
    val activeChatRecipientId by viewModel.activeChatUserId.collectAsStateWithLifecycle()
    val teachers by viewModel.teachersState.collectAsStateWithLifecycle()
    val students by viewModel.studentsState.collectAsStateWithLifecycle()
    val users by viewModel.usersState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    var isConversationOpen by rememberSaveable { mutableStateOf(false) }
    var showNewChatDialog by remember { mutableStateOf(false) }

    BackHandler(enabled = isConversationOpen) {
        isConversationOpen = false
        viewModel.setActiveChatRecipient("")
    }

    // Role-based permitted contacts computation
    val permittedContacts = remember(currentUser, teachers, students, users) {
        val myId = currentUser?.userId ?: ""
        val myRole = currentUser?.role?.uppercase()?.trim() ?: "STUDENT"

        val adminContacts = users.filter { it.userId != myId && (it.role.uppercase() in listOf("PRINCIPAL", "HEAD_ADMIN", "ADMIN")) }
            .map {
                ChatContactInfo(
                    id = it.userId,
                    name = it.name,
                    role = if (it.role.uppercase() == "PRINCIPAL") "Principal" else "School Admin",
                    photoUrl = it.avatarUrl,
                    category = "ADMIN",
                    subtitle = "Administration",
                    phone = it.phone,
                    email = it.email
                )
            }

        val teacherContacts = teachers.filter { it.teacherId != myId && !it.isDeleted }
            .map {
                ChatContactInfo(
                    id = it.teacherId,
                    name = it.name,
                    role = "Teacher • ${it.subject}",
                    photoUrl = it.photoUrl,
                    category = "TEACHER",
                    subtitle = if (it.classTeacherOf.isNotBlank()) "Class Teacher of ${it.classTeacherOf}" else it.subject,
                    phone = it.phone,
                    email = it.email
                )
            }

        val studentContacts = students.filter { it.studentId != myId && !it.isDeleted }
            .map {
                ChatContactInfo(
                    id = it.studentId,
                    name = it.name,
                    role = "Student • ${it.className}",
                    photoUrl = it.photoUrl,
                    category = "STUDENT",
                    subtitle = "Class ${it.className} (Roll #${it.rollNo.ifBlank { it.rollNumber.toString() }})",
                    phone = it.phone,
                    email = "${it.studentId.lowercase()}@sdps.edu"
                )
            }

        when (myRole) {
            "PRINCIPAL", "HEAD_ADMIN", "ADMIN" -> adminContacts + teacherContacts + studentContacts
            "TEACHER", "CLASS_TEACHER" -> adminContacts + teacherContacts + studentContacts
            "STUDENT" -> adminContacts + teacherContacts // Students can message Administration & Faculty
            else -> adminContacts + teacherContacts
        }
    }

    val contactsMap = remember(permittedContacts) {
        permittedContacts.associateBy { it.id }
    }

    // Process and sort recent conversations
    val recentChats by remember(chatsMessages, currentUser, contactsMap) {
        derivedStateOf {
            val myId = currentUser?.userId ?: ""
            if (myId.isBlank()) return@derivedStateOf emptyList<ChatListItem>()

            val grouped = chatsMessages
                .filter { it.senderId == myId || it.receiverId == myId }
                .groupBy { if (it.senderId == myId) it.receiverId else it.senderId }

            val list = grouped.mapNotNull { entry ->
                val otherId = entry.key
                val contact = contactsMap[otherId] ?: ChatContactInfo(
                    id = otherId,
                    name = "User ($otherId)",
                    role = "Contact",
                    photoUrl = "avatar_graduate",
                    category = "OTHER",
                    subtitle = "School Community"
                )
                val lastMsg = entry.value.maxByOrNull { it.timestamp }
                val unreadCount = entry.value.count { it.receiverId == myId && !it.isRead }
                ChatListItem(contact = contact, lastMessage = lastMsg, unreadCount = unreadCount)
            }.sortedByDescending { it.lastMessage?.timestamp ?: 0L }

            list
        }
    }

    val activeContactInfo = remember(activeChatRecipientId, contactsMap) {
        val recipientId = activeChatRecipientId
        if (!recipientId.isNullOrBlank()) {
            contactsMap[recipientId] ?: ChatContactInfo(
                id = recipientId,
                name = "User ($recipientId)",
                role = "Contact",
                photoUrl = "avatar_graduate",
                category = "OTHER",
                subtitle = "School Community"
            )
        } else null
    }

    // Mark messages as read when conversation is opened
    LaunchedEffect(activeChatRecipientId) {
        val recipientId = activeChatRecipientId
        if (!recipientId.isNullOrBlank()) {
            viewModel.markChatMessagesAsRead(recipientId)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTablet = maxWidth > 680.dp

        if (isTablet) {
            Row(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    ChatListScreen(
                        recentChats = recentChats,
                        currentUser = currentUser,
                        activeChatId = activeChatRecipientId ?: "",
                        onChatSelected = { id ->
                            viewModel.setActiveChatRecipient(id)
                            isConversationOpen = true
                        },
                        onOpenNewChat = { showNewChatDialog = true }
                    )
                }
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Box(modifier = Modifier.weight(1.8f).fillMaxHeight()) {
                    if (activeContactInfo != null) {
                        ConversationScreen(
                            contactInfo = activeContactInfo,
                            chatsMessages = chatsMessages.filter {
                                (it.senderId == currentUser?.userId && it.receiverId == activeContactInfo.id) ||
                                (it.senderId == activeContactInfo.id && it.receiverId == currentUser?.userId)
                            }.sortedByDescending { it.timestamp },
                            currentUser = currentUser,
                            onBack = { viewModel.setActiveChatRecipient("") },
                            onSendMessage = { msg, replyId -> viewModel.sendChatMessage(msg, replyId) },
                            onSendAttachmentMessage = { msg, uri, type, fileName, replyId, cb ->
                                viewModel.sendChatMessageWithAttachment(msg, uri, type, fileName, replyId, cb)
                            },
                            onDeleteMessage = { msgId -> viewModel.deleteChatMessage(msgId) },
                            isTablet = true
                        )
                    } else {
                        EmptyChatSelectionState(onStartNewChat = { showNewChatDialog = true })
                    }
                }
            }
        } else {
            AnimatedContent(
                targetState = isConversationOpen && activeContactInfo != null,
                transitionSpec = {
                    if (targetState) {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith slideOutHorizontally { width -> -width / 3 } + fadeOut()
                    } else {
                        slideInHorizontally { width -> -width / 3 } + fadeIn() togetherWith slideOutHorizontally { width -> width } + fadeOut()
                    }
                },
                label = "chat_navigation_transition"
            ) { isConversationActive ->
                if (isConversationActive && activeContactInfo != null) {
                    ConversationScreen(
                        contactInfo = activeContactInfo,
                        chatsMessages = chatsMessages.filter {
                            (it.senderId == currentUser?.userId && it.receiverId == activeContactInfo.id) ||
                            (it.senderId == activeContactInfo.id && it.receiverId == currentUser?.userId)
                        }.sortedByDescending { it.timestamp },
                        currentUser = currentUser,
                        onBack = {
                            isConversationOpen = false
                            viewModel.setActiveChatRecipient("")
                        },
                        onSendMessage = { msg, replyId -> viewModel.sendChatMessage(msg, replyId) },
                        onSendAttachmentMessage = { msg, uri, type, fileName, replyId, cb ->
                            viewModel.sendChatMessageWithAttachment(msg, uri, type, fileName, replyId, cb)
                        },
                        onDeleteMessage = { msgId -> viewModel.deleteChatMessage(msgId) },
                        isTablet = false
                    )
                } else {
                    ChatListScreen(
                        recentChats = recentChats,
                        currentUser = currentUser,
                        activeChatId = activeChatRecipientId ?: "",
                        onChatSelected = { id ->
                            viewModel.setActiveChatRecipient(id)
                            isConversationOpen = true
                        },
                        onOpenNewChat = { showNewChatDialog = true }
                    )
                }
            }
        }
    }

    if (showNewChatDialog) {
        NewConversationDialog(
            contacts = permittedContacts,
            onDismiss = { showNewChatDialog = false },
            onContactSelected = { contact ->
                showNewChatDialog = false
                viewModel.setActiveChatRecipient(contact.id)
                isConversationOpen = true
            }
        )
    }
}

// ==========================================
// 1. CONVERSATION LIST VIEW
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    recentChats: List<ChatListItem>,
    currentUser: User?,
    activeChatId: String,
    onChatSelected: (String) -> Unit,
    onOpenNewChat: () -> Unit
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) } // 0: All, 1: Unread, 2: Teachers, 3: Admin, 4: Students
    val haptic = LocalHapticFeedback.current
    var isSimulatedLoading by remember { mutableStateOf(false) }

    val filteredChats by remember(recentChats, searchQuery, selectedTab) {
        derivedStateOf {
            var list = recentChats

            // Tab filter
            list = when (selectedTab) {
                1 -> list.filter { it.unreadCount > 0 }
                2 -> list.filter { it.contact.category == "TEACHER" }
                3 -> list.filter { it.contact.category == "ADMIN" }
                4 -> list.filter { it.contact.category == "STUDENT" }
                else -> list
            }

            // Search query filter
            if (searchQuery.isNotBlank()) {
                val query = searchQuery.trim().lowercase()
                list = list.filter {
                    it.contact.name.lowercase().contains(query) ||
                    it.contact.role.lowercase().contains(query) ||
                    (it.lastMessage?.message?.lowercase()?.contains(query) == true)
                }
            }

            list
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "School Messenger",
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Instant secure communication hub",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        FilledTonalIconButton(
                            onClick = onOpenNewChat,
                            modifier = Modifier.testTag("new_chat_btn")
                        ) {
                            Icon(Icons.Filled.EditNote, contentDescription = "New Message")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Clean search input
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("chat_search_input"),
                        placeholder = { Text("Search conversations, teachers, scholars...", fontSize = 14.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = Color.Transparent
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Filter chips row
                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        edgePadding = 0.dp,
                        divider = {},
                        indicator = {},
                        modifier = Modifier.fillMaxWidth().height(36.dp)
                    ) {
                        val tabs = listOf("All Chats", "Unread", "Teachers", "Admin", "Students")
                        tabs.forEachIndexed { index, label ->
                            val isSelected = selectedTab == index
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedTab = index },
                                label = {
                                    Text(
                                        label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.padding(end = 8.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                border = null
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenNewChat,
                icon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                text = { Text("New Message", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(bottom = 16.dp).testTag("fab_new_message")
            )
        }
    ) { padding ->
        if (isSimulatedLoading) {
            ChatListShimmer(padding)
        } else if (filteredChats.isEmpty()) {
            EmptyConversationsView(
                searchQuery = searchQuery,
                selectedTab = selectedTab,
                onStartChat = onOpenNewChat,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(padding),
                contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp)
            ) {
                items(filteredChats, key = { it.contact.id }) { item ->
                    ChatListRow(
                        item = item,
                        currentUser = currentUser,
                        isSelected = item.contact.id == activeChatId,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onChatSelected(item.contact.id)
                        }
                    )
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 76.dp, end = 16.dp),
                        thickness = 0.5.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatListRow(
    item: ChatListItem,
    currentUser: User?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val bgColor by animateColorAsState(
        if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        else if (item.unreadCount > 0) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
        else MaterialTheme.colorScheme.surface,
        label = "chat_row_bg"
    )

    val isLastMsgFromMe = item.lastMessage?.senderId == currentUser?.userId

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = { showMenu = true },
                    onTap = { onClick() }
                )
            },
        color = bgColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                UserProfileAvatar(
                    avatarUrl = item.contact.photoUrl,
                    size = 52.dp,
                    contentDescription = item.contact.name,
                    containerColor = when (item.contact.category) {
                        "ADMIN" -> MaterialTheme.colorScheme.tertiaryContainer
                        "TEACHER" -> MaterialTheme.colorScheme.primaryContainer
                        else -> MaterialTheme.colorScheme.secondaryContainer
                    }
                )

                // Category mini badge
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(
                            when (item.contact.category) {
                                "ADMIN" -> Color(0xFF8B5CF6)
                                "TEACHER" -> Color(0xFF3B82F6)
                                else -> Color(0xFF10B981)
                            }
                        )
                        .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        item.contact.name,
                        fontWeight = if (item.unreadCount > 0) FontWeight.ExtraBold else FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    val timeStr = formatChatTimestamp(item.lastMessage?.timestamp ?: 0L)
                    Text(
                        timeStr,
                        fontSize = 11.sp,
                        fontWeight = if (item.unreadCount > 0) FontWeight.Bold else FontWeight.Normal,
                        color = if (item.unreadCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = when (item.contact.category) {
                            "ADMIN" -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                            "TEACHER" -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                            else -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        }
                    ) {
                        Text(
                            item.contact.role,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isLastMsgFromMe && item.lastMessage != null) {
                            Icon(
                                imageVector = if (item.lastMessage.isRead) Icons.Default.DoneAll else Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp),
                                tint = if (item.lastMessage.isRead) Color(0xFF3B82F6) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                "You: ",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Text(
                            text = item.lastMessage?.message ?: "Tap to start conversation",
                            color = if (item.unreadCount > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (item.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }

                    if (item.unreadCount > 0) {
                        Badge(
                            containerColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text(
                                item.unreadCount.toString(),
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                DropdownMenuItem(
                    text = { Text("View Details") },
                    leadingIcon = { Icon(Icons.Default.Info, null) },
                    onClick = {
                        showMenu = false
                        Toast.makeText(context, "${item.contact.name} (${item.contact.role})", Toast.LENGTH_SHORT).show()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Mark as Read") },
                    leadingIcon = { Icon(Icons.Default.MarkChatRead, null) },
                    onClick = { showMenu = false }
                )
            }
        }
    }
}

// ==========================================
// 2. CHAT DETAIL / CONVERSATION VIEW
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationScreen(
    contactInfo: ChatContactInfo,
    chatsMessages: List<ChatMessage>,
    currentUser: User?,
    onBack: () -> Unit,
    onSendMessage: (String, String) -> Unit,
    onSendAttachmentMessage: (String, Uri?, String, String, String, (Boolean, String?) -> Unit) -> Unit = { _, _, _, _, _, _ -> },
    onDeleteMessage: (String) -> Unit,
    isTablet: Boolean
) {
    val haptic = LocalHapticFeedback.current
    val listState = rememberLazyListState()
    var messageText by rememberSaveable { mutableStateOf("") }
    var replyingToMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var showContactInfoDialog by remember { mutableStateOf(false) }
    var attachedUri by remember { mutableStateOf<Uri?>(null) }
    var attachedFileName by remember { mutableStateOf("") }
    var attachedType by remember { mutableStateOf("") }
    var isSendingAttachment by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Group messages with date separators
    val groupedMessages = remember(chatsMessages) {
        val list = mutableListOf<ChatViewItem>()
        var lastDateStr = ""

        chatsMessages.forEach { msg ->
            val dateStr = formatChatDateHeader(msg.timestamp)
            if (dateStr != lastDateStr) {
                if (lastDateStr.isNotEmpty()) {
                    list.add(ChatViewItem.DateHeader(lastDateStr))
                }
                lastDateStr = dateStr
            }
            list.add(ChatViewItem.MessageItem(msg))
        }
        if (lastDateStr.isNotEmpty()) {
            list.add(ChatViewItem.DateHeader(lastDateStr))
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { showContactInfoDialog = true }
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            UserProfileAvatar(
                                avatarUrl = contactInfo.photoUrl,
                                size = 40.dp,
                                contentDescription = contactInfo.name,
                                containerColor = when (contactInfo.category) {
                                    "ADMIN" -> MaterialTheme.colorScheme.tertiaryContainer
                                    "TEACHER" -> MaterialTheme.colorScheme.primaryContainer
                                    else -> MaterialTheme.colorScheme.secondaryContainer
                                }
                            )
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                                    .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                contactInfo.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                contactInfo.role,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (!isTablet) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_btn")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        Toast.makeText(context, "Voice call to ${contactInfo.name} initiated via school VoIP.", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.Call, contentDescription = "Call")
                    }
                    IconButton(onClick = { showContactInfoDialog = true }) {
                        Icon(Icons.Default.Info, contentDescription = "Contact Info")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                )
            )
        },
        bottomBar = {
            MessageComposer(
                text = messageText,
                replyingTo = replyingToMessage,
                attachedUri = attachedUri,
                attachedFileName = attachedFileName,
                isUploading = isSendingAttachment,
                onTextChange = { messageText = it },
                onCancelReply = { replyingToMessage = null },
                onAttachFile = { uri, name, type ->
                    attachedUri = uri
                    attachedFileName = name
                    attachedType = type
                },
                onClearAttachment = {
                    attachedUri = null
                    attachedFileName = ""
                    attachedType = ""
                },
                onSend = {
                    if (messageText.isNotBlank() || attachedUri != null) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (attachedUri != null) {
                            isSendingAttachment = true
                            val uriToSend = attachedUri
                            val nameToSend = attachedFileName
                            val typeToSend = attachedType
                            val replyId = replyingToMessage?.messageId ?: ""
                            onSendAttachmentMessage(
                                messageText,
                                uriToSend,
                                typeToSend,
                                nameToSend,
                                replyId
                            ) { success, err ->
                                isSendingAttachment = false
                                if (success) {
                                    messageText = ""
                                    attachedUri = null
                                    attachedFileName = ""
                                    attachedType = ""
                                    replyingToMessage = null
                                } else {
                                    Toast.makeText(context, "Attachment upload failed: ${err ?: "Error"}", Toast.LENGTH_LONG).show()
                                }
                            }
                        } else {
                            onSendMessage(messageText, replyingToMessage?.messageId ?: "")
                            messageText = ""
                            replyingToMessage = null
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            // Secure connection indicator banner
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(11.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Messages are encrypted & saved locally for offline access",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (chatsMessages.isEmpty()) {
                EmptyConversationHistory(contactInfo = contactInfo)
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    reverseLayout = true,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    items(groupedMessages, key = { item ->
                        when (item) {
                            is ChatViewItem.MessageItem -> item.message.messageId
                            is ChatViewItem.DateHeader -> "header_${item.date}"
                        }
                    }) { item ->
                        when (item) {
                            is ChatViewItem.DateHeader -> {
                                ChatDateDivider(date = item.date)
                            }
                            is ChatViewItem.MessageItem -> {
                                val msg = item.message
                                val isMe = msg.senderId == currentUser?.userId
                                MessageBubble(
                                    message = msg,
                                    isMe = isMe,
                                    onReply = { replyingToMessage = msg },
                                    onCopy = {
                                        clipboardManager.setText(AnnotatedString(msg.message))
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        Toast.makeText(context, "Message copied to clipboard", Toast.LENGTH_SHORT).show()
                                    },
                                    onDelete = {
                                        onDeleteMessage(msg.messageId)
                                        Toast.makeText(context, "Message deleted", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showContactInfoDialog) {
        ContactDetailsDialog(
            contact = contactInfo,
            onDismiss = { showContactInfoDialog = false }
        )
    }
}

sealed class ChatViewItem {
    data class MessageItem(val message: ChatMessage) : ChatViewItem()
    data class DateHeader(val date: String) : ChatViewItem()
}

// ==========================================
// 3. MESSAGE BUBBLE & COMPOSER
// ==========================================
@Composable
fun MessageBubble(
    message: ChatMessage,
    isMe: Boolean,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    var showContextMenu by remember { mutableStateOf(false) }
    var showFullScreenImage by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val timeString = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(message.timestamp))

    val bubbleShape = if (isMe) {
        RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
    } else {
        RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    }

    val bubbleColor = if (isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isMe) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

    // Check if message content has an attachment URL
    val rawText = message.message
    val isStorageUrl = rawText.contains("firebasestorage.googleapis.com") || rawText.startsWith("http://") || rawText.startsWith("https://")
    val isImage = message.attachmentType == "image" || (isStorageUrl && (rawText.contains(".jpg", ignoreCase = true) || rawText.contains(".jpeg", ignoreCase = true) || rawText.contains(".png", ignoreCase = true) || rawText.contains(".webp", ignoreCase = true) || rawText.contains("image", ignoreCase = true)))
    val isPdfOrDoc = message.attachmentType == "pdf" || message.attachmentType == "file" || (isStorageUrl && !isImage)

    // Separate text and URL if formatted as text\nurl
    val parts = rawText.split("\n")
    val urlPart = parts.find { it.startsWith("http://") || it.startsWith("https://") } ?: (if (isStorageUrl) rawText else "")
    val nonUrlText = parts.filter { !it.startsWith("http://") && !it.startsWith("https://") }.joinToString("\n").trim()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Box {
            Surface(
                shape = bubbleShape,
                color = bubbleColor,
                shadowElevation = 0.5.dp,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onLongPress = { showContextMenu = true }
                        )
                    }
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    // 1. Image attachment
                    if (isImage && urlPart.isNotBlank()) {
                        AsyncImage(
                            model = urlPart,
                            contentDescription = "Chat Attachment Image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 120.dp, max = 220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { showFullScreenImage = urlPart }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // 2. Document attachment
                    if (isPdfOrDoc && urlPart.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.background,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlPart)).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Open File"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Link: $urlPart", Toast.LENGTH_LONG).show()
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = "Document",
                                    tint = if (isMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Attached Document / File",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Tap to view in browser/reader",
                                        fontSize = 10.sp,
                                        color = if (isMe) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.OpenInNew,
                                    contentDescription = null,
                                    tint = if (isMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // 3. Accompanying text
                    val displayText = if ((isImage || isPdfOrDoc) && nonUrlText.isNotBlank()) {
                        nonUrlText
                    } else if (!isImage && !isPdfOrDoc) {
                        rawText
                    } else {
                        ""
                    }

                    if (displayText.isNotBlank()) {
                        Text(
                            text = displayText,
                            color = textColor,
                            fontSize = 14.sp,
                            lineHeight = 19.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            timeString,
                            color = textColor.copy(alpha = 0.75f),
                            fontSize = 10.sp
                        )

                        if (isMe) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (message.isRead) Icons.Default.DoneAll else Icons.Default.Check,
                                contentDescription = if (message.isRead) "Read" else "Sent",
                                modifier = Modifier.size(13.dp),
                                tint = if (message.isRead) Color(0xFF60A5FA) else textColor.copy(alpha = 0.75f)
                            )
                        }
                    }
                }
            }

            DropdownMenu(
                expanded = showContextMenu,
                onDismissRequest = { showContextMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Copy Text") },
                    leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                    onClick = {
                        showContextMenu = false
                        onCopy()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Reply") },
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.Reply, null) },
                    onClick = {
                        showContextMenu = false
                        onReply()
                    }
                )
                if (isMe) {
                    DropdownMenuItem(
                        text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showContextMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }

    if (showFullScreenImage != null) {
        Dialog(onDismissRequest = { showFullScreenImage = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.Black,
                modifier = Modifier.fillMaxWidth().wrapContentHeight()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(
                        model = showFullScreenImage,
                        contentDescription = "Fullscreen image preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { showFullScreenImage = null }) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

@Composable
fun ChatDateDivider(date: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Text(
                text = date,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun MessageComposer(
    text: String,
    replyingTo: ChatMessage?,
    attachedUri: Uri? = null,
    attachedFileName: String = "",
    isUploading: Boolean = false,
    onTextChange: (String) -> Unit,
    onCancelReply: () -> Unit,
    onAttachFile: (Uri, String, String) -> Unit = { _, _, _ -> },
    onClearAttachment: () -> Unit = {},
    onSend: () -> Unit
) {
    val context = LocalContext.current

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            var fileName = "attachment_${System.currentTimeMillis()}"
            var mime = context.contentResolver.getType(uri) ?: ""
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIdx != -1 && cursor.moveToFirst()) {
                        fileName = cursor.getString(nameIdx)
                    }
                }
            } catch (_: Exception) {}
            
            val detectedType = if (mime.startsWith("image/") || fileName.endsWith(".jpg", true) || fileName.endsWith(".png", true) || fileName.endsWith(".jpeg", true)) {
                "image"
            } else {
                "pdf"
            }
            onAttachFile(uri, fileName, detectedType)
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            // Reply Preview Banner
            if (replyingTo != null) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(28.dp)
                                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Replying to message", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    replyingTo.message,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(onClick = onCancelReply, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Attachment preview chip banner
            if (attachedUri != null) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = attachedFileName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        IconButton(onClick = onClearAttachment, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Clear attachment", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                // Attach button
                IconButton(
                    onClick = { filePickerLauncher.launch("*/*") },
                    enabled = !isUploading,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Attach File",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                OutlinedTextField(
                    value = text,
                    onValueChange = onTextChange,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    placeholder = { Text(if (attachedUri != null) "Add caption (optional)..." else "Type your message...", fontSize = 14.sp) },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() })
                )

                val isEnabled = (text.isNotBlank() || attachedUri != null) && !isUploading
                val buttonColor by animateColorAsState(
                    if (isEnabled) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceVariant,
                    label = "send_btn_color"
                )
                val iconColor by animateColorAsState(
                    if (isEnabled) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    label = "send_icon_color"
                )

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = onSend,
                    enabled = isEnabled,
                    modifier = Modifier.testTag("chat_send_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(buttonColor),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isUploading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(
                                Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = iconColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. NEW CONVERSATION & CONTACT PICKER DIALOG
// ==========================================
@Composable
fun NewConversationDialog(
    contacts: List<ChatContactInfo>,
    onDismiss: () -> Unit,
    onContactSelected: (ChatContactInfo) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }

    val filteredContacts = remember(contacts, searchQuery, selectedCategory) {
        var list = contacts
        if (selectedCategory != "ALL") {
            list = list.filter { it.category == selectedCategory }
        }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) ||
                it.role.lowercase().contains(q) ||
                it.subtitle.lowercase().contains(q)
            }
        }
        list
    }

    Dialog(onDismissRequest = onDismiss) {
        ElevatedCard(
            shape = RoundedCornerShape(20.dp),
            colors = glassCardColors(),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "New Message",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by name, subject, or role...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(20.dp)) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("ALL" to "All", "TEACHER" to "Faculty", "ADMIN" to "Admin", "STUDENT" to "Scholars").forEach { (catKey, catLabel) ->
                        val isSelected = selectedCategory == catKey
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier
                                .clickable { selectedCategory = catKey }
                                .padding(vertical = 2.dp)
                        ) {
                            Text(
                                catLabel,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (filteredContacts.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No contacts found matching criteria",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredContacts, key = { it.id }) { contact ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onContactSelected(contact) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserProfileAvatar(
                                        avatarUrl = contact.photoUrl,
                                        size = 40.dp,
                                        contentDescription = contact.name,
                                        containerColor = when (contact.category) {
                                            "ADMIN" -> MaterialTheme.colorScheme.tertiaryContainer
                                            "TEACHER" -> MaterialTheme.colorScheme.primaryContainer
                                            else -> MaterialTheme.colorScheme.secondaryContainer
                                        }
                                    )

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            contact.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            contact.role,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Icon(
                                        Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Message",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. CONTACT DETAILS DIALOG
// ==========================================
@Composable
fun ContactDetailsDialog(
    contact: ChatContactInfo,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        ElevatedCard(
            shape = RoundedCornerShape(20.dp),
            colors = glassCardColors(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                UserProfileAvatar(
                    avatarUrl = contact.photoUrl,
                    size = 72.dp,
                    contentDescription = contact.name,
                    containerColor = when (contact.category) {
                        "ADMIN" -> MaterialTheme.colorScheme.tertiaryContainer
                        "TEACHER" -> MaterialTheme.colorScheme.primaryContainer
                        else -> MaterialTheme.colorScheme.secondaryContainer
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    contact.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center
                )

                Text(
                    contact.role,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )

                if (contact.subtitle.isNotBlank()) {
                    Text(
                        contact.subtitle,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(16.dp))

                // Detail rows
                ContactDetailRow(Icons.Default.Badge, "Institutional ID", contact.id)
                if (contact.phone.isNotBlank()) {
                    ContactDetailRow(Icons.Default.Phone, "Phone Number", contact.phone)
                }
                if (contact.email.isNotBlank()) {
                    ContactDetailRow(Icons.Default.Email, "Email Address", contact.email)
                }
                ContactDetailRow(Icons.Default.Security, "Access Privilege", contact.category)

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Close Details")
                }
            }
        }
    }
}

@Composable
fun ContactDetailRow(icon: ImageVector, title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ==========================================
// 6. EMPTY & LOADING STATES
// ==========================================
@Composable
fun EmptyConversationsView(
    searchQuery: String,
    selectedTab: Int,
    onStartChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        if (searchQuery.isNotEmpty()) Icons.Default.SearchOff else Icons.Outlined.ChatBubbleOutline,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                if (searchQuery.isNotEmpty()) "No results found" else "No Conversations Yet",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                if (searchQuery.isNotEmpty()) "We couldn't find any chats matching '$searchQuery'. Try checking spelling or clear search."
                else "Start communicating with teachers, class administrators, or scholars in real-time.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onStartChat,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.AddComment, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start a Conversation", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun EmptyConversationHistory(contactInfo: ChatContactInfo) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            UserProfileAvatar(
                avatarUrl = contactInfo.photoUrl,
                size = 64.dp,
                contentDescription = contactInfo.name,
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                "Say Hello to ${contactInfo.name}!",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                "You are connected with ${contactInfo.role}. Send your first message below to begin.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun EmptyChatSelectionState(onStartNewChat: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(88.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Outlined.Chat,
                        contentDescription = null,
                        modifier = Modifier.size(44.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Select a conversation",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "Choose from existing discussions on the left or compose a new message.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
                onClick = onStartNewChat,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Compose Message")
            }
        }
    }
}

@Composable
fun ChatListShimmer(padding: PaddingValues) {
    val transition = rememberInfiniteTransition(label = "chat_shimmer")
    val alpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chat_shimmer_alpha"
    )
    val color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = alpha)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        repeat(6) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(52.dp).clip(CircleShape).background(color))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Box(modifier = Modifier.fillMaxWidth(0.45f).height(14.dp).clip(RoundedCornerShape(6.dp)).background(color))
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(modifier = Modifier.fillMaxWidth(0.3f).height(10.dp).clip(RoundedCornerShape(4.dp)).background(color))
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(modifier = Modifier.fillMaxWidth(0.8f).height(12.dp).clip(RoundedCornerShape(6.dp)).background(color))
                }
            }
        }
    }
}

// ==========================================
// 7. TIME & DATE FORMATTING UTILITIES
// ==========================================
fun formatChatTimestamp(timestamp: Long): String {
    if (timestamp <= 0L) return ""
    val now = Calendar.getInstance()
    val msgTime = Calendar.getInstance().apply { timeInMillis = timestamp }

    return if (now.get(Calendar.YEAR) == msgTime.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == msgTime.get(Calendar.DAY_OF_YEAR)
    ) {
        SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(timestamp))
    } else if (now.get(Calendar.YEAR) == msgTime.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) - msgTime.get(Calendar.DAY_OF_YEAR) == 1
    ) {
        "Yesterday"
    } else if (now.get(Calendar.YEAR) == msgTime.get(Calendar.YEAR)) {
        SimpleDateFormat("MMM d", Locale.ENGLISH).format(Date(timestamp))
    } else {
        SimpleDateFormat("dd/MM/yy", Locale.ENGLISH).format(Date(timestamp))
    }
}

fun formatChatDateHeader(timestamp: Long): String {
    if (timestamp <= 0L) return "Recent"
    val now = Calendar.getInstance()
    val msgTime = Calendar.getInstance().apply { timeInMillis = timestamp }

    return if (now.get(Calendar.YEAR) == msgTime.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == msgTime.get(Calendar.DAY_OF_YEAR)
    ) {
        "Today"
    } else if (now.get(Calendar.YEAR) == msgTime.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) - msgTime.get(Calendar.DAY_OF_YEAR) == 1
    ) {
        "Yesterday"
    } else if (now.get(Calendar.YEAR) == msgTime.get(Calendar.YEAR)) {
        SimpleDateFormat("EEEE, MMMM d", Locale.ENGLISH).format(Date(timestamp))
    } else {
        SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH).format(Date(timestamp))
    }
}
