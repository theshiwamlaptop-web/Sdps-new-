package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun ComposeMascot(
    state: MascotState,
    modifier: Modifier = Modifier
) {
    val lookX by animateFloatAsState(
        targetValue = when (state) {
            MascotState.TYPING_USER -> -20f
            MascotState.TYPING_PASSWORD -> 0f
            else -> 0f
        },
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "lookX"
    )

    val lookY by animateFloatAsState(
        targetValue = when (state) {
            MascotState.TYPING_USER -> 12f
            MascotState.TYPING_PASSWORD -> 5f
            MascotState.LOADING -> -10f
            MascotState.ERROR -> 15f
            MascotState.SUCCESS -> -15f
            else -> 0f
        },
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "lookY"
    )

    val smile by animateFloatAsState(
        targetValue = when (state) {
            MascotState.SUCCESS -> 1f
            MascotState.ERROR -> -1f
            MascotState.LOADING -> 0.5f
            MascotState.TYPING_USER -> 0.2f
            MascotState.TYPING_PASSWORD -> 0.0f
            else -> 0.1f
        },
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "smile"
    )

    val handCoverProgress by animateFloatAsState(
        targetValue = if (state == MascotState.TYPING_PASSWORD) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 250f),
        label = "handCoverProgress"
    )
    
    val primaryColor = MaterialTheme.colorScheme.primary
    val skinColor = Color(0xFFFFD1B3) // Light skin tone
    val hairColor = Color(0xFF3E2723) // Dark brown
    val eyeColor = Color(0xFF212121)

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2
        val cy = h / 2

        val headRadius = w * 0.32f
        val headCy = cy - h * 0.18f
        
        // Body (torso)
        val bodyWidth = w * 0.55f
        val bodyHeight = h * 0.38f
        val bodyTop = headCy + headRadius * 0.75f
        
        // Legs
        val legWidth = w * 0.12f
        val legHeight = h * 0.18f
        val legTop = bodyTop + bodyHeight * 0.8f
        val leftLegCx = cx - bodyWidth * 0.25f
        val rightLegCx = cx + bodyWidth * 0.25f

        drawRoundRect(
            color = primaryColor,
            topLeft = Offset(leftLegCx - legWidth / 2, legTop),
            size = Size(legWidth, legHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(legWidth / 2, legWidth / 2)
        )
        drawRoundRect(
            color = primaryColor,
            topLeft = Offset(rightLegCx - legWidth / 2, legTop),
            size = Size(legWidth, legHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(legWidth / 2, legWidth / 2)
        )
        
        // Shoes
        drawRoundRect(
            color = Color.DarkGray,
            topLeft = Offset(leftLegCx - legWidth * 0.8f, legTop + legHeight * 0.7f),
            size = Size(legWidth * 1.6f, legWidth * 1.0f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(legWidth * 0.5f, legWidth * 0.5f)
        )
        drawRoundRect(
            color = Color.DarkGray,
            topLeft = Offset(rightLegCx - legWidth * 0.8f, legTop + legHeight * 0.7f),
            size = Size(legWidth * 1.6f, legWidth * 1.0f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(legWidth * 0.5f, legWidth * 0.5f)
        )

        // Draw Body Torso
        drawRoundRect(
            color = primaryColor,
            topLeft = Offset(cx - bodyWidth / 2, bodyTop),
            size = Size(bodyWidth, bodyHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.2f, w * 0.2f)
        )

        // Head
        drawCircle(
            color = skinColor,
            radius = headRadius,
            center = Offset(cx, headCy)
        )

        // Hair Base
        drawArc(
            color = hairColor,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(cx - headRadius * 1.05f, headCy - headRadius * 1.05f),
            size = Size(headRadius * 2.1f, headRadius * 2.1f)
        )
        // Hair bang
        drawCircle(
            color = hairColor,
            radius = headRadius * 0.35f,
            center = Offset(cx - headRadius * 0.3f, headCy - headRadius * 0.65f)
        )

        // Eyes
        val eyeSpacing = headRadius * 0.4f
        val eyeCy = headCy + lookY
        val eyeCxLeft = cx - eyeSpacing + lookX
        val eyeCxRight = cx + eyeSpacing + lookX

        if (handCoverProgress < 0.8f) { // Hide eyes when covered by hands in password mode
            if (state == MascotState.ERROR) {
                // Sad / stressed closed eyes
                drawLine(
                    color = eyeColor,
                    start = Offset(eyeCxLeft - headRadius * 0.12f, eyeCy),
                    end = Offset(eyeCxLeft + headRadius * 0.12f, eyeCy),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = eyeColor,
                    start = Offset(eyeCxRight - headRadius * 0.12f, eyeCy),
                    end = Offset(eyeCxRight + headRadius * 0.12f, eyeCy),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
            } else {
                drawCircle(
                    color = eyeColor,
                    radius = headRadius * 0.12f,
                    center = Offset(eyeCxLeft, eyeCy)
                )
                drawCircle(
                    color = eyeColor,
                    radius = headRadius * 0.12f,
                    center = Offset(eyeCxRight, eyeCy)
                )
                // Eye highlights
                drawCircle(
                    color = Color.White,
                    radius = headRadius * 0.04f,
                    center = Offset(eyeCxLeft - headRadius * 0.04f, eyeCy - headRadius * 0.04f)
                )
                drawCircle(
                    color = Color.White,
                    radius = headRadius * 0.04f,
                    center = Offset(eyeCxRight - headRadius * 0.04f, eyeCy - headRadius * 0.04f)
                )
            }
        }

        // Mouth
        val mouthCy = headCy + headRadius * 0.35f + lookY * 0.4f
        val mouthCx = cx + lookX * 0.4f
        val mouthPath = Path().apply {
            if (smile > 0.5f) { // Happy/Success
                moveTo(mouthCx - headRadius * 0.25f, mouthCy)
                quadraticTo(mouthCx, mouthCy + headRadius * 0.4f, mouthCx + headRadius * 0.25f, mouthCy)
            } else if (smile < -0.5f) { // Sad/Error
                moveTo(mouthCx - headRadius * 0.2f, mouthCy + headRadius * 0.15f)
                quadraticTo(mouthCx, mouthCy - headRadius * 0.15f, mouthCx + headRadius * 0.2f, mouthCy + headRadius * 0.15f)
            } else if (smile > 0f) { // Slight smile
                moveTo(mouthCx - headRadius * 0.15f, mouthCy)
                quadraticTo(mouthCx, mouthCy + headRadius * 0.15f, mouthCx + headRadius * 0.15f, mouthCy)
            } else { // Neutral/Typing Password
                moveTo(mouthCx - headRadius * 0.1f, mouthCy)
                lineTo(mouthCx + headRadius * 0.1f, mouthCy)
            }
        }
        drawPath(
            path = mouthPath,
            color = Color(0xFFD84315),
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )

        // Arms / Hands
        val armWidth = w * 0.13f
        val armLength = h * 0.25f
        
        val leftShoulderX = cx - bodyWidth * 0.4f
        val leftShoulderY = bodyTop + h * 0.08f
        val rightShoulderX = cx + bodyWidth * 0.4f
        val rightShoulderY = bodyTop + h * 0.08f

        // Idle arm position (down by sides)
        val idleLeftHandX = leftShoulderX - armWidth * 0.5f
        val idleLeftHandY = leftShoulderY + armLength
        val idleRightHandX = rightShoulderX + armWidth * 0.5f
        val idleRightHandY = rightShoulderY + armLength
        
        // Covering eyes position (hands up near eyes)
        val coverLeftHandX = eyeCxLeft - headRadius * 0.1f
        val coverLeftHandY = eyeCy + headRadius * 0.2f
        val coverRightHandX = eyeCxRight + headRadius * 0.1f
        val coverRightHandY = eyeCy + headRadius * 0.2f
        
        // Interpolated Hand Positions
        val leftHandX = idleLeftHandX + (coverLeftHandX - idleLeftHandX) * handCoverProgress
        val leftHandY = idleLeftHandY + (coverLeftHandY - idleLeftHandY) * handCoverProgress
        val rightHandX = idleRightHandX + (coverRightHandX - idleRightHandX) * handCoverProgress
        val rightHandY = idleRightHandY + (coverRightHandY - idleRightHandY) * handCoverProgress

        // Draw Arms
        drawLine(
            color = primaryColor,
            start = Offset(leftShoulderX, leftShoulderY),
            end = Offset(leftHandX, leftHandY),
            strokeWidth = armWidth,
            cap = StrokeCap.Round
        )
        drawLine(
            color = primaryColor,
            start = Offset(rightShoulderX, rightShoulderY),
            end = Offset(rightHandX, rightHandY),
            strokeWidth = armWidth,
            cap = StrokeCap.Round
        )

        // Draw Hands
        drawCircle(
            color = skinColor,
            radius = armWidth * 0.8f,
            center = Offset(leftHandX, leftHandY)
        )
        drawCircle(
            color = skinColor,
            radius = armWidth * 0.8f,
            center = Offset(rightHandX, rightHandY)
        )
    }
}

