package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

// DAOs

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUser(userId: String): User?

    @Query("SELECT * FROM users WHERE phone = :phone LIMIT 1")
    suspend fun getUserByPhone(phone: String): User?

    @Query("SELECT * FROM users WHERE userId != '' AND name != '' AND name != 'Unknown'")
    fun getAllUsersFlow(): Flow<List<User>>

    @Query("SELECT * FROM users")
    suspend fun getAllUsersList(): List<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<User>)

    @Delete
    suspend fun deleteUser(user: User)

    @Query("DELETE FROM users WHERE userId = :userId")
    suspend fun deleteUserById(userId: String)
}

@Dao
interface StudentDao {
    @Query("SELECT * FROM students")
    fun getAllStudentsFlow(): Flow<List<Student>>

    @Query("SELECT * FROM students")
    suspend fun getAllStudentsList(): List<Student>

    @Query("SELECT * FROM students WHERE studentId = :id OR id = :id LIMIT 1")
    suspend fun getStudentById(id: String): Student?

    @Query("SELECT * FROM students WHERE admissionNo = :admissionNo LIMIT 1")
    suspend fun getStudentByAdmissionNo(admissionNo: String): Student?

    @Query("SELECT * FROM students WHERE phone = :phone LIMIT 1")
    suspend fun getStudentByPhone(phone: String): Student?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(items: List<Student>)

    @Query("DELETE FROM students WHERE studentId = :studentId")
    suspend fun deleteStudentById(studentId: String)
}

@Dao
interface TeacherDao {
    @Query("SELECT * FROM teachers")
    fun getAllTeachersFlow(): Flow<List<Teacher>>

    @Query("SELECT * FROM teachers")
    suspend fun getAllTeachersList(): List<Teacher>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacher(teacher: Teacher)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeachers(items: List<Teacher>)

    @Query("SELECT * FROM teachers WHERE teacherId = :teacherId LIMIT 1")
    suspend fun getTeacherById(teacherId: String): Teacher?

    @Query("SELECT * FROM teachers WHERE phone = :phone LIMIT 1")
    suspend fun getTeacherByPhone(phone: String): Teacher?

    @Query("DELETE FROM teachers WHERE teacherId = :teacherId")
    suspend fun deleteTeacherById(teacherId: String)
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance")
    fun getAllAttendanceFlow(): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE className = :className AND date = :date")
    fun getAttendanceForClassAndDateFlow(className: String, date: String): Flow<List<Attendance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: List<Attendance>)
}

@Dao
interface FeeDao {
    @Query("SELECT * FROM fees")
    fun getAllFeesFlow(): Flow<List<Fee>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFee(fee: Fee)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFees(items: List<Fee>)

    @Query("DELETE FROM fees WHERE feeId = :feeId")
    suspend fun deleteFeeById(feeId: String)
}

@Dao
interface HomeworkDao {
    @Query("SELECT * FROM homework")
    fun getAllHomeworkFlow(): Flow<List<Homework>>

    @Query("SELECT * FROM homework WHERE homeworkId = :homeworkId LIMIT 1")
    suspend fun getHomeworkById(homeworkId: String): Homework?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomeworks(items: List<Homework>)

    @Query("DELETE FROM homework WHERE homeworkId = :homeworkId")
    suspend fun deleteHomeworkById(homeworkId: String)
}

@Dao
interface NoticeDao {
    @Query("SELECT * FROM notices ORDER BY createdAt DESC")
    fun getAllNoticesFlow(): Flow<List<Notice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotice(notice: Notice)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotices(items: List<Notice>)

    @Query("DELETE FROM notices WHERE noticeId = :noticeId")
    suspend fun deleteNoticeById(noticeId: String)
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable")
    fun getAllTimetablesFlow(): Flow<List<Timetable>>

    @Query("SELECT * FROM timetable")
    suspend fun getAllTimetablesList(): List<Timetable>

    @Query("SELECT * FROM timetable WHERE className = :className LIMIT 1")
    suspend fun getTimetableForClass(className: String): Timetable?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetable(timetable: Timetable)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetables(items: List<Timetable>)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY timestamp ASC")
    fun getAllChatsFlow(): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chats WHERE messageId = :messageId LIMIT 1")
    suspend fun getMessageById(messageId: String): ChatMessage?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessages(items: List<ChatMessage>)

    @Query("UPDATE chats SET isRead = 1, status = 'read' WHERE receiverId = :receiverId AND senderId = :senderId AND isRead = 0")
    suspend fun markMessagesAsRead(senderId: String, receiverId: String)

    @Query("DELETE FROM chats WHERE messageId = :messageId")
    suspend fun deleteMessage(messageId: String)
}

@Dao
interface FeeLedgerDao {
    @Query("SELECT * FROM fee_ledger_entries WHERE studentId = :studentId")
    fun getLedgerForStudentFlow(studentId: String): Flow<List<FeeLedgerEntry>>

    @Query("SELECT * FROM fee_ledger_entries WHERE studentId = :studentId")
    suspend fun getLedgerForStudent(studentId: String): List<FeeLedgerEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: FeeLedgerEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntries(entries: List<FeeLedgerEntry>)

    @Query("SELECT * FROM fee_ledger_entries")
    fun getAllLedgerEntriesFlow(): Flow<List<FeeLedgerEntry>>
}

@Dao
interface FeeRateHistoryDao {
    @Query("SELECT * FROM fee_rate_history ORDER BY setAt ASC")
    fun getAllRatesFlow(): Flow<List<FeeRateHistory>>

    @Query("SELECT * FROM fee_rate_history ORDER BY setAt ASC")
    suspend fun getAllRates(): List<FeeRateHistory>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRate(rate: FeeRateHistory)
}

@Dao
interface FeeEventChargeDao {
    @Query("SELECT * FROM fee_event_charges ORDER BY createdAt ASC")
    fun getAllEventChargesFlow(): Flow<List<FeeEventCharge>>

    @Query("SELECT * FROM fee_event_charges WHERE month = :month AND (className = :className OR className = 'ALL')")
    suspend fun getEventChargesForClassMonth(className: String, month: String): List<FeeEventCharge>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEventCharge(charge: FeeEventCharge)

    @Query("DELETE FROM fee_event_charges WHERE eventChargeId = :id")
    suspend fun deleteEventCharge(id: String)
}

// Database

@Database(
    entities = [
        User::class,
        Student::class,
        Teacher::class,
        Attendance::class,
        Fee::class,
        Homework::class,
        Notice::class,
        Timetable::class,
        ChatMessage::class,
        FeeLedgerEntry::class,
        AuditLog::class,
        TeacherAttendance::class,
        Payroll::class,
        AppNotification::class,
        ClassBook::class,
        IssuedBook::class,
        LeaveRequest::class,
        CalendarEvent::class,
        FeeRateHistory::class,
        FeeEventCharge::class
    ],
    version = 14,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun studentDao(): StudentDao
    abstract fun teacherDao(): TeacherDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun feeDao(): FeeDao
    abstract fun homeworkDao(): HomeworkDao
    abstract fun noticeDao(): NoticeDao
    abstract fun timetableDao(): TimetableDao
    abstract fun chatDao(): ChatDao
    abstract fun feeLedgerDao(): FeeLedgerDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun teacherAttendanceDao(): TeacherAttendanceDao
    abstract fun payrollDao(): PayrollDao
    abstract fun notificationDao(): NotificationDao
    abstract fun classBookDao(): ClassBookDao
    abstract fun issuedBookDao(): IssuedBookDao
    abstract fun leaveRequestDao(): LeaveRequestDao
    abstract fun calendarEventDao(): CalendarEventDao
    abstract fun feeRateHistoryDao(): FeeRateHistoryDao
    abstract fun feeEventChargeDao(): FeeEventChargeDao
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogsFlow(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLogs(logs: List<AuditLog>)
}

@Dao
interface TeacherAttendanceDao {
    @Query("SELECT * FROM teacher_attendance ORDER BY date DESC")
    fun getAllTeacherAttendanceFlow(): Flow<List<TeacherAttendance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacherAttendance(attendance: TeacherAttendance)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacherAttendances(attendances: List<TeacherAttendance>)

    @Query("SELECT * FROM teacher_attendance WHERE teacherId = :teacherId ORDER BY date DESC")
    fun getAttendanceForTeacherFlow(teacherId: String): Flow<List<TeacherAttendance>>
}

@Dao
interface PayrollDao {
    @Query("SELECT * FROM payrolls")
    fun getAllPayrollsFlow(): Flow<List<Payroll>>

    @Query("SELECT * FROM payrolls WHERE teacherId = :teacherId")
    fun getPayrollsForTeacherFlow(teacherId: String): Flow<List<Payroll>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayroll(payroll: Payroll)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayrolls(payrolls: List<Payroll>)

    @Query("DELETE FROM payrolls WHERE teacherId = :teacherId")
    suspend fun deletePayrollsByTeacher(teacherId: String)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(): Flow<List<AppNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Query("UPDATE app_notifications SET isRead = 1 WHERE notificationId = :id")
    suspend fun markAsRead(id: String)

    @Query("DELETE FROM app_notifications WHERE notificationId = :id")
    suspend fun deleteNotificationById(id: String)
}

@Dao
interface ClassBookDao {
    @Query("SELECT * FROM class_books")
    fun getAllClassBooksFlow(): Flow<List<ClassBook>>

    @Query("SELECT * FROM class_books WHERE className = :className")
    fun getClassBooksForClassFlow(className: String): Flow<List<ClassBook>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClassBook(book: ClassBook)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClassBooks(books: List<ClassBook>)

    @Query("DELETE FROM class_books WHERE bookId = :bookId")
    suspend fun deleteClassBookById(bookId: String)
}

@Dao
interface IssuedBookDao {
    @Query("SELECT * FROM issued_books")
    fun getAllIssuedBooksFlow(): Flow<List<IssuedBook>>

    @Query("SELECT * FROM issued_books WHERE studentId = :studentId")
    fun getIssuedBooksForStudentFlow(studentId: String): Flow<List<IssuedBook>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssuedBook(book: IssuedBook)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssuedBooks(books: List<IssuedBook>)

    @Query("DELETE FROM issued_books WHERE issueId = :issueId")
    suspend fun deleteIssuedBookById(issueId: String)
}


@Dao
interface LeaveRequestDao {
    @Query("SELECT * FROM leave_requests ORDER BY timestamp DESC")
    fun getAllLeaveRequestsFlow(): Flow<List<LeaveRequest>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveRequest(leaveRequest: LeaveRequest)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveRequests(requests: List<LeaveRequest>)
    @Query("DELETE FROM leave_requests WHERE requestId = :requestId")
    suspend fun deleteLeaveRequestById(requestId: String)
}


@Dao
interface CalendarEventDao {
    @Query("SELECT * FROM calendar_events ORDER BY date ASC, createdAt DESC")
    fun getAllCalendarEventsFlow(): Flow<List<CalendarEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarEvent(event: CalendarEvent)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarEvents(events: List<CalendarEvent>)

    @Query("DELETE FROM calendar_events WHERE id = :eventId")
    suspend fun deleteCalendarEventById(eventId: String)

    @Query("SELECT * FROM calendar_events WHERE id = :eventId LIMIT 1")
    suspend fun getCalendarEventById(eventId: String): CalendarEvent?
}
