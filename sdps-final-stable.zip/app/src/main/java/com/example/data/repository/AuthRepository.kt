package com.example.data.repository

import com.example.data.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface AuthRepository {
    val currentUserFlow: StateFlow<User?>
    suspend fun login(userId: String, role: String, fullname: String, password: String): Result<User>
    suspend fun loginWithCredential(credential: com.google.firebase.auth.AuthCredential, user: User): Result<User>
    suspend fun findUserByPhone(phone: String): User?
    suspend fun logout()
    suspend fun changePassword(userId: String, oldPassword: String?, newPasswordHash: String): Result<Unit>
    suspend fun updateUserProfile(user: User): Result<Unit>
    fun getAllUsers(): Flow<List<User>>
    suspend fun addUser(user: User): Result<Unit>
    suspend fun checkAndRestoreSession(): User?
}
