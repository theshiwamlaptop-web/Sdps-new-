package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import androidx.room.withTransaction
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest
import java.util.UUID

// Academic year order: April is month 0 ... March is month 11.
fun academicMonthIndex(month: String): Int {
    val order = listOf("April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March")
    val idx = order.indexOf(month)
    return if (idx >= 0) idx else 0
}

// Finds whichever rate (for this exact class, or "ALL" if no class-specific one exists)
// was the most recently effective ON OR BEFORE the target month — never a later one.
// This is what makes past months immune to a rate change made later in the year.
fun findEffectiveFeeRate(rates: List<FeeRateHistory>, className: String, feeType: String, month: String): Double {
    val targetIdx = academicMonthIndex(month)
    val candidates = rates.filter {
        it.feeType == feeType &&
        (it.className == className || it.className == "ALL") &&
        academicMonthIndex(it.effectiveFromMonth) <= targetIdx
    }
    if (candidates.isEmpty()) return 0.0
    // Prefer a class-specific rate over "ALL" when both qualify for the same month;
    // among same-specificity candidates, the most recently effective one wins.
    val classSpecific = candidates.filter { it.className == className }
    val pool = if (classSpecific.isNotEmpty()) classSpecific else candidates
    return pool.maxByOrNull { academicMonthIndex(it.effectiveFromMonth) * 10000L + it.setAt }?.amount ?: 0.0
}

// Describes the state of the Firestore -> local Room sync, so the UI can tell the difference
// between "still loading", "genuinely no records", and "the cloud read actually failed".
sealed class CloudSyncStatus {
    object Idle : CloudSyncStatus()
    object Syncing : CloudSyncStatus()
    object Synced : CloudSyncStatus()
    // No Firebase Auth session, so every Firestore read will be rejected by the security rules.
    object NotAuthenticated : CloudSyncStatus()
    data class Failed(val collection: String, val reason: String, val isPermissionDenied: Boolean) : CloudSyncStatus()
}

interface SchoolRepository : AuthRepository {
    // Backend configurations
    val isFirebaseModeFlow: StateFlow<Boolean>
    val syncStatusFlow: StateFlow<CloudSyncStatus>
    fun toggleFirebaseMode(enabled: Boolean)
    suspend fun applyDefaultPassword(userId: String): Result<Unit>
    suspend fun verifyResetDetails(userId: String, dob: String): Result<Unit>
    suspend fun resetPasswordWithDob(userId: String, newPasswordHash: String): Result<Unit>
    suspend fun updateUserDob(userId: String, newDob: String, requesterId: String): Result<Unit>
    suspend fun auditAndMigrateAccounts(): Result<Unit>
    suspend fun adminSetCustomPassword(targetUserId: String, newPassword: String, adminUserId: String): Result<Unit>
    suspend fun adminResetPasswordToDob(targetUserId: String, adminUserId: String): Result<Unit>
    suspend fun adminGenerateTemporaryPassword(targetUserId: String, adminUserId: String): Result<String>

    suspend fun deleteUserAccount(userId: String): Result<Unit>

    // Students
    fun getAllStudents(): Flow<List<Student>>
    suspend fun updateStudent(student: Student): Result<Unit>
    suspend fun checkStudentExists(studentId: String): Boolean
    suspend fun addStudent(student: Student): Result<Unit>
    suspend fun deleteStudent(studentId: String): Result<Unit>

    // Teachers
    fun getAllTeachers(): Flow<List<Teacher>>
    suspend fun addTeacher(teacher: Teacher): Result<Unit>
    suspend fun deleteTeacher(teacherId: String): Result<Unit>

    // Payroll
    fun getAllPayrolls(): Flow<List<Payroll>>
    fun getPayrollsForTeacher(teacherId: String): Flow<List<Payroll>>
    suspend fun addOrUpdatePayroll(payroll: Payroll): Result<Unit>
    suspend fun savePayrolls(payrolls: List<Payroll>): Result<Unit>
    suspend fun deletePayrollsByTeacher(teacherId: String): Result<Unit>

    // Attendance
    fun getAllAttendance(): Flow<List<Attendance>>
    fun getAttendanceForClassAndDate(className: String, date: String): Flow<List<Attendance>>
    suspend fun markAttendance(attendanceList: List<Attendance>): Result<Unit>

    // Fees
    fun getAllFees(): Flow<List<Fee>>
    suspend fun addFee(fee: Fee): Result<Unit>
    suspend fun deleteFee(feeId: String): Result<Unit>

    // Monthly traditional fee ledgers
    fun getAllFeeLedgerEntries(): Flow<List<FeeLedgerEntry>>
    fun getFeeLedgerForStudentFlow(studentId: String): Flow<List<FeeLedgerEntry>>
    suspend fun getFeeLedgerForStudent(studentId: String): List<FeeLedgerEntry>
    suspend fun saveFeeLedgerEntry(entry: FeeLedgerEntry): Result<Unit>
    suspend fun saveFeeLedgerEntries(entries: List<FeeLedgerEntry>): Result<Unit>

    // Fee rate history (effective-dated, class-wise) — a fee change here applies only from
    // its effectiveFromMonth onward; months before that keep whatever rate was active then.
    fun getAllFeeRatesFlow(): Flow<List<FeeRateHistory>>
    suspend fun setFeeRate(className: String, feeType: String, amount: Double, effectiveFromMonth: String, setByUserId: String): Result<Unit>
    suspend fun getEffectiveFeeRate(className: String, feeType: String, month: String): Double

    // One-time/event charges applied to a class (or ALL) for a specific month
    fun getAllFeeEventChargesFlow(): Flow<List<FeeEventCharge>>
    suspend fun addFeeEventCharge(className: String, month: String, label: String, amount: Double, createdByUserId: String): Result<Unit>
    suspend fun getFeeEventChargesForClassMonth(className: String, month: String): List<FeeEventCharge>

    // Homework
    fun getAllHomework(): Flow<List<Homework>>
    suspend fun addHomework(homework: Homework): Result<Unit>
    suspend fun deleteHomework(homeworkId: String): Result<Unit>
    suspend fun uploadFileToStorage(uri: android.net.Uri, storagePath: String, mimeType: String = ""): Result<String>
    suspend fun uploadHomeworkAttachment(uri: android.net.Uri, className: String, homeworkId: String, fileName: String): Result<String>
    suspend fun uploadChatAttachment(uri: android.net.Uri, conversationId: String, messageId: String, fileName: String): Result<String>
    suspend fun deleteStorageFile(fileUrl: String): Result<Unit>

    // Notices
    fun getAllNotices(): Flow<List<Notice>>
    suspend fun addNotice(notice: Notice): Result<Unit>
    suspend fun deleteNotice(noticeId: String): Result<Unit>

    // Timetable
    fun getAllTimetables(): Flow<List<Timetable>>
    suspend fun saveTimetable(timetable: Timetable, allowOverride: Boolean = false, overrideReason: String = ""): Result<Unit>

    // Real-Time Chats
    fun getAllChats(): Flow<List<ChatMessage>>
    suspend fun sendMessage(message: ChatMessage): Result<Unit>
    suspend fun markMessagesAsRead(senderId: String, receiverId: String): Result<Unit>
    suspend fun deleteChatMessage(messageId: String): Result<Unit>

    // Audit Logs
    fun getAllAuditLogs(): Flow<List<AuditLog>>
    suspend fun addAuditLog(log: AuditLog): Result<Unit>

    // Notifications
    fun getAllNotifications(): Flow<List<AppNotification>>
    suspend fun addNotification(notification: AppNotification): Result<Unit>
    suspend fun markNotificationAsRead(id: String): Result<Unit>
    suspend fun deleteNotification(id: String): Result<Unit>

    // Book Distribution
    fun getAllClassBooks(): Flow<List<ClassBook>>
    fun getClassBooksForClass(className: String): Flow<List<ClassBook>>
    suspend fun saveClassBook(book: ClassBook): Result<Unit>
    suspend fun deleteClassBook(bookId: String): Result<Unit>

    fun getAllIssuedBooks(): Flow<List<IssuedBook>>
    fun getIssuedBooksForStudent(studentId: String): Flow<List<IssuedBook>>
    suspend fun issueBook(issuedBook: IssuedBook): Result<Unit>
    suspend fun deleteIssuedBook(issueId: String): Result<Unit>

    // Teacher Attendance & Duty
    fun getAllTeacherAttendance(): Flow<List<TeacherAttendance>>
    fun getAttendanceForTeacher(teacherId: String): Flow<List<TeacherAttendance>>
    suspend fun addTeacherAttendance(attendance: TeacherAttendance): Result<Unit>

    // New Architectural Features
    suspend fun assignClassTeacher(teacherBId: String, className: String, actionUserId: String, actionUserName: String): Result<Unit>
    suspend fun removeClassTeacher(teacherId: String, actionUserId: String, actionUserName: String): Result<Unit>
    suspend fun seed10StudentsPerClass(): Result<Unit>
    suspend fun promoteToAdmin(teacherId: String): Result<Unit>
    suspend fun demoteToTeacher(adminTeacherId: String): Result<Unit>
    suspend fun performSchoolStructureMigration(): Result<Unit>

    // School Calendar
    fun getAllCalendarEvents(): Flow<List<CalendarEvent>>
    suspend fun saveCalendarEvent(event: CalendarEvent): Result<Unit>
    suspend fun deleteCalendarEvent(eventId: String): Result<Unit>

    // Leave Requests
    fun getAllLeaveRequests(): Flow<List<LeaveRequest>>
    suspend fun saveLeaveRequest(request: LeaveRequest): Result<Unit>
    suspend fun deleteLeaveRequest(requestId: String): Result<Unit>
    fun forceSync()
}

class SchoolRepositoryImpl(
    private val context: Context,
    private val db: AppDatabase
) : SchoolRepository {

    // SupervisorJob is essential here: this scope backs ~20 independent long-running
    // background tasks (seeding, session restore, auth binding, every Firestore->Room
    // sync listener...). With a plain Job, ONE uncaught exception in ANY of them
    // cancels this whole scope permanently — silently killing all other sync for the
    // rest of the app's life, with no crash, no error, just data that stops updating.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Mode state persistence using Memory / Prefs fallback
    // Set default value as 'true' to use Firebase Firestore as the main cloud database
    private val _isFirebaseMode = MutableStateFlow(true)
    override val isFirebaseModeFlow: StateFlow<Boolean> = _isFirebaseMode.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    override val currentUserFlow: StateFlow<User?> = _currentUser.asStateFlow()

    // Observable cloud-sync status. Without this, a failed Firestore sync (no auth session,
    // permission denied, offline) left the local DB empty and the UI just showed
    // "no students" — indistinguishable from a school that genuinely has no students.
    private val _syncStatus = MutableStateFlow<CloudSyncStatus>(CloudSyncStatus.Idle)
    override val syncStatusFlow: StateFlow<CloudSyncStatus> = _syncStatus.asStateFlow()

    private val prefs by lazy { context.getSharedPreferences("school_erp_prefs", android.content.Context.MODE_PRIVATE) }

    private var authStateListener: FirebaseAuth.AuthStateListener? = null
    private val snapshotListeners = mutableListOf<com.google.firebase.firestore.ListenerRegistration>()
    private var currentSyncedUserId: String? = null
    private var currentSyncedUserRole: String? = null


    // Firebase objects
    private val firebaseAuth: FirebaseAuth? by lazy {
        try { FirebaseAuth.getInstance() } catch (e: Exception) { null }
    }
    private val firestore: FirebaseFirestore? by lazy {
        try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }
    }
    private val firebaseStorage: FirebaseStorage? by lazy {
        try { FirebaseStorage.getInstance() } catch (e: Exception) { null }
    }

    init {
        // Automatically checks if DB seeding is required and starts Real-time background sync
        scope.launch {
            checkFirebaseConnectivityAndLog()
            seedInitialDataIfNeeded()
            val restored = checkAndRestoreSession()
            if (restored != null) {
                startBackgroundFirebaseSync()
            }
        }

        val auth = firebaseAuth
        if (auth != null) {
            val listener = FirebaseAuth.AuthStateListener { currentAuth ->
                val fUser = currentAuth.currentUser
                if (fUser != null) {
                    android.util.Log.i("SchoolRepository", "AuthStateListener: User is logged in (${fUser.uid}). Restoring session and starting sync...")
                    scope.launch {
                        if (_currentUser.value == null) {
                            checkAndRestoreSession()
                        }
                        startBackgroundFirebaseSync()
                    }
                }
            }
            authStateListener = listener
            auth.addAuthStateListener(listener)
        }
    }

    private fun checkFirebaseConnectivityAndLog() {
        Log.i("SchoolRepository", "⚙️ Starting App Startup Connectivity Audit...")
        val auth = firebaseAuth
        val fs = firestore
        if (auth == null || fs == null) {
            Log.d("SchoolRepository", "Firebase Auth or Firestore SDK objects are null inside the repository (missing dependencies or internal errors). Initializing in Offline Sandbox Mode.")
            return
        }

        val hasApps = com.google.firebase.FirebaseApp.getApps(context).isNotEmpty()
        if (!hasApps) {
            Log.d("SchoolRepository", "Default FirebaseApp is not initialized (missing google-services.json or initialization bypassed). Running in fallback Offline Sandbox Mode.")
            return
        }

        Log.i("SchoolRepository", "✅ Firebase App successfully detected and active.")
        Log.i("SchoolRepository", "📡 Current Auth Account: ${auth.currentUser?.email ?: "None (Guest / No active session)"}")

        if (auth.currentUser != null) {
            Log.i("SchoolRepository", "📡 Testing Firestore Connection / Access Rules on 'students'...")
            fs.collection("students").limit(1).get()
                .addOnSuccessListener { querySnapshot ->
                    Log.i("SchoolRepository", "🏆 Firestore active connection verified successfully! Retrieved 'students' documents with count: ${querySnapshot.size()}. Room-to-Firestore live bridge is fully active.")
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "⚠️ Firestore connection status check returned non-critical warning: ${e.message}", e)
                }
        } else {
            Log.i("SchoolRepository", "📡 App Startup: Running in standard session mode. Real-time sync engages upon user sign-in.")
        }
    }

    override fun toggleFirebaseMode(enabled: Boolean) {
        _isFirebaseMode.value = enabled
        Log.d("SchoolRepository", "Toggled Firebase Sync Mode: $enabled")
    }

    private fun sha256Hex(input: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(input.toByteArray(Charsets.UTF_8))
            hash.fold("") { str, it -> str + "%02x".format(it) }
        } catch (e: Exception) {
            input
        }
    }

    private fun normalizeDob(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return ""
        val cleaned = trimmed.replace("/", "-").replace(".", "-").replace(" ", "")
        val parts = cleaned.split("-")
        if (parts.size == 3) {
            val p0 = parts[0].padStart(2, '0')
            val p1 = parts[1].padStart(2, '0')
            val p2 = parts[2]
            if (p0.length == 4) {
                return "${p2.padStart(2, '0')}-${p1}-${p0}"
            }
            if (p2.length == 4) {
                return "${p0}-${p1}-${p2}"
            }
        }
        return cleaned
    }

    /*
     * BACKGROUND SYNC BRIDGE LOGIC:
     * We attach real-time Snapshot Listeners to all Firestore collections.
     * When online, updates from other sources (or our local saves) trigger these listeners,
     * which instantly upsert / delete corresponding entries in our Room Database.
     * Consequently, Room serves as our unified offline-ready cache. The CRUD retrieval flows (getAllStudents, etc.)
     * listen directly to Room, providing an instant, cohesive, offline-capable reactive data-binding system.
     */


    override fun getAllLeaveRequests(): Flow<List<LeaveRequest>> = db.leaveRequestDao().getAllLeaveRequestsFlow()
    override suspend fun saveLeaveRequest(request: LeaveRequest): Result<Unit> = runCatching {
        db.leaveRequestDao().insertLeaveRequest(request)
        if (_isFirebaseMode.value) {
            firestore?.collection("leave_requests")?.document(request.requestId)?.set(request)?.await()
        }
    }
    override suspend fun deleteLeaveRequest(requestId: String): Result<Unit> = runCatching {
        db.leaveRequestDao().deleteLeaveRequestById(requestId)
        if (_isFirebaseMode.value) {
            firestore?.collection("leave_requests")?.document(requestId)?.delete()?.await()
        }
    }
    override fun forceSync() {
        startBackgroundFirebaseSync(force = true)
    }

    private fun stopBackgroundFirebaseSync() {
        synchronized(snapshotListeners) {
            snapshotListeners.forEach { listener ->
                try { listener.remove() } catch (e: Exception) {
                    Log.e("SchoolRepository", "Error removing snapshot listener", e)
                }
            }
            snapshotListeners.clear()
            currentSyncedUserId = null
            currentSyncedUserRole = null
            Log.d("SchoolRepository", "Stopped and cleared all active Firebase snapshot listeners.")
        }
    }

    // Binds the current Firebase Auth UID to this app-level user id so the Firestore
    // security rules can resolve the caller's role. The rules only accept the binding
    // when the verified token email matches the user document's email, so this cannot
    // be used to claim another account. Safe to call repeatedly (idempotent).
    private suspend fun ensureUidIndexBinding(appUserId: String) {
        try {
            val fs = firestore ?: return
            val authUid = firebaseAuth?.currentUser?.uid ?: return
            if (appUserId.isBlank()) return
            fs.collection("uid_index").document(authUid)
                .set(mapOf("userId" to appUserId, "boundAt" to System.currentTimeMillis()))
                .await()
            Log.d("SchoolRepository", "uid_index binding ensured: authUid=$authUid -> $appUserId")
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to bind uid_index for '$appUserId'. Role-based Firestore access will be denied until this succeeds.", e)
        }
    }

    private fun startBackgroundFirebaseSync(force: Boolean = false) {
        val fs = firestore ?: return
        val currentAuth = firebaseAuth?.currentUser
        val localUser = _currentUser.value
        if (currentAuth == null && localUser == null) {
            Log.d("SchoolRepository", "Skipping background sync: User is not authenticated.")
            _syncStatus.value = CloudSyncStatus.NotAuthenticated
            return
        }

        // A logged-in app user without a Firebase Auth session cannot pass the Firestore
        // security rules (every rule starts with isAuthenticated()). Registering listeners
        // anyway just produced PERMISSION_DENIED errors that were logged and never surfaced,
        // leaving the Principal staring at an empty student list. Report it instead.
        if (currentAuth == null) {
            Log.e("SchoolRepository", "Cloud sync blocked: app user '${localUser?.userId}' has no Firebase Auth session, so all Firestore reads will be denied by security rules.")
            _syncStatus.value = CloudSyncStatus.NotAuthenticated
            return
        }

        val effectiveUserId = localUser?.userId ?: currentAuth.uid
        val effectiveRole = localUser?.role?.uppercase()?.trim() ?: "STUDENT"

        // Make sure this Auth identity is bound to the app-level user id, otherwise the
        // security rules cannot resolve the caller's role and every role-gated read/write
        // (creating students, updating fees, payroll, ...) is rejected. Reads that only
        // need isAuthenticated() work immediately, so this does not block sync startup.
        scope.launch { ensureUidIndexBinding(effectiveUserId) }
        val isAdminOrPrincipal = effectiveRole in listOf("PRINCIPAL", "HEAD_ADMIN", "ADMIN")
        val isTeacher = effectiveRole in listOf("TEACHER", "CLASS_TEACHER")

        synchronized(snapshotListeners) {
            if (!force && effectiveUserId == currentSyncedUserId && effectiveRole == currentSyncedUserRole && snapshotListeners.isNotEmpty()) {
                Log.d("SchoolRepository", "Sync already active for user: $effectiveUserId ($effectiveRole). Skipping duplicate registration.")
                return
            }
            stopBackgroundFirebaseSync()
            currentSyncedUserId = effectiveUserId
            currentSyncedUserRole = effectiveRole
        }

        Log.d("SchoolRepository", "Initializing Optimized Firestore -> Room Background Sync for $effectiveUserId ($effectiveRole)...")
        _syncStatus.value = CloudSyncStatus.Syncing

        // 1. Students Synchronization (Batch Processed)
        try {
            val listener = fs.collection("students").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    val denied = error.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED
                    Log.e("SchoolRepository", "Firestore Sync Error [students] path=students authUid=${firebaseAuth?.currentUser?.uid} appUser=$effectiveUserId role=$effectiveRole code=${error.code}: ${error.message}", error)
                    _syncStatus.value = CloudSyncStatus.Failed("students", error.message ?: "Unknown error", denied)
                    return@addSnapshotListener
                }
                Log.d("SchoolRepository", "Firestore [students] snapshot received: ${snapshot?.size() ?: 0} total docs, ${snapshot?.documentChanges?.size ?: 0} changes.")
                _syncStatus.value = CloudSyncStatus.Synced
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Student>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        val docId = change.document.id
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(docId)
                        } else {
                            try {
                                var s = change.document.toObject(Student::class.java)
                                if (s != null) {
                                    if (s.studentId.isBlank()) s = s.copy(studentId = docId)
                                    toInsert.add(s)
                                }
                            } catch (e: Exception) {
                                val data = change.document.data
                                if (data != null) {
                                    val fallback = Student(
                                        studentId = data["studentId"] as? String ?: docId,
                                        id = data["id"] as? String ?: "",
                                        name = data["name"] as? String ?: "Unknown",
                                        className = data["className"] as? String ?: "",
                                        rollNo = data["rollNo"] as? String ?: "",
                                        DOB = data["DOB"] as? String ?: data["dob"] as? String ?: "",
                                        gender = data["gender"] as? String ?: "Not Specified",
                                        fatherName = data["fatherName"] as? String ?: "",
                                        motherName = data["motherName"] as? String ?: "",
                                        guardianName = data["guardianName"] as? String ?: "",
                                        phone = data["phone"] as? String ?: "",
                                        address = data["address"] as? String ?: "",
                                        admissionNo = data["admissionNo"] as? String ?: "",
                                        photoUrl = data["photoUrl"] as? String ?: "",
                                        status = data["status"] as? String ?: "Active",
                                        isDeleted = data["isDeleted"] as? Boolean ?: false,
                                        feeStatus = data["feeStatus"] as? String ?: "Unpaid"
                                    )
                                    toInsert.add(fallback)
                                }
                            }
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.studentDao().deleteStudentById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.studentDao().insertStudents(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register students listener", e)
        }

        // 2. Teachers Synchronization (Batch Processed)
        try {
            val listener = fs.collection("teachers").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [teachers]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Teacher>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        val docId = change.document.id
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(docId)
                        } else {
                            try {
                                var t = change.document.toObject(Teacher::class.java)
                                if (t != null) {
                                    if (t.teacherId.isBlank()) t = t.copy(teacherId = docId)
                                    toInsert.add(t)
                                }
                            } catch (e: Exception) {
                                Log.e("SchoolRepository", "Error parsing Teacher doc $docId", e)
                            }
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.teacherDao().deleteTeacherById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.teacherDao().insertTeachers(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register teachers listener", e)
        }

        // 3. Attendance Synchronization (Batch Processed)
        try {
            val listener = fs.collection("attendance").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [attendance]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Attendance>()
                    changes.forEach { change ->
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            val att = change.document.toObject(Attendance::class.java)
                            if (att != null) toInsert.add(att)
                        }
                    }
                    if (toInsert.isNotEmpty()) {
                        db.withTransaction {
                            db.attendanceDao().insertAttendance(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register attendance listener", e)
        }

        // 4. Fees Synchronization (Batch Processed)
        try {
            val listener = fs.collection("fees").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [fees]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Fee>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            val fee = change.document.toObject(Fee::class.java)
                            if (fee != null) toInsert.add(fee)
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.feeDao().deleteFeeById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.feeDao().insertFees(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register fees listener", e)
        }

        // 5. Homework Synchronization (Batch Processed)
        try {
            val listener = fs.collection("homework").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [homework]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Homework>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            val hw = change.document.toObject(Homework::class.java)
                            if (hw != null) toInsert.add(hw)
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.homeworkDao().deleteHomeworkById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.homeworkDao().insertHomeworks(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register homework listener", e)
        }

        // 6. Notices Synchronization (Global, Batch Processed)
        try {
            val listener = fs.collection("notices").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [notices]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Notice>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            var notice = change.document.toObject(Notice::class.java)
                            if (notice != null) {
                                if (notice.noticeId.isBlank()) notice = notice.copy(noticeId = change.document.id)
                                toInsert.add(notice)
                            }
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.noticeDao().deleteNoticeById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.noticeDao().insertNotices(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register notices listener", e)
        }

        // 7. Calendar Events Synchronization (Global, Batch Processed)
        try {
            val listener = fs.collection("calendar_events").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [calendar_events]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<CalendarEvent>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            var ev = change.document.toObject(CalendarEvent::class.java)
                            if (ev != null) {
                                if (ev.id.isBlank()) ev = ev.copy(id = change.document.id)
                                toInsert.add(ev)
                            }
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.calendarEventDao().deleteCalendarEventById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.calendarEventDao().insertCalendarEvents(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register calendar events listener", e)
        }

        // 8. Timetable Synchronization (Batch Processed)
        try {
            val listener = fs.collection("timetable").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [timetable]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<Timetable>()
                    changes.forEach { change ->
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            var tt = change.document.toObject(Timetable::class.java)
                            if (tt != null) {
                                if (tt.timetableId.isBlank()) tt = tt.copy(timetableId = change.document.id)
                                toInsert.add(tt)
                            }
                        }
                    }

                    if (toInsert.isNotEmpty()) {
                        db.withTransaction {
                            db.timetableDao().insertTimetables(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register timetable listener", e)
        }

        // 9. Chats Synchronization (Batch Processed)
        try {
            val listener = fs.collection("chats").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [chats]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<ChatMessage>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            var msg = change.document.toObject(ChatMessage::class.java)
                            if (msg != null) {
                                if (msg.messageId.isBlank()) msg = msg.copy(messageId = change.document.id)
                                toInsert.add(msg)
                            }
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.chatDao().deleteMessage(it) }
                        if (toInsert.isNotEmpty()) {
                            db.chatDao().insertChatMessages(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register chats listener", e)
        }

        // 10. Fee Ledger Entries Synchronization (Admin / Principal ONLY)
        if (isAdminOrPrincipal) {
            try {
                val listener = fs.collection("fee_ledger_entries").addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("SchoolRepository", "Firestore Sync Error [fee_ledger_entries]: ${error.message}", error)
                        return@addSnapshotListener
                    }
                    val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                    if (changes.isEmpty()) return@addSnapshotListener

                    scope.launch(Dispatchers.IO) {
                        val toInsert = mutableListOf<FeeLedgerEntry>()
                        changes.forEach { change ->
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                val entry = change.document.toObject(FeeLedgerEntry::class.java)
                                if (entry != null) toInsert.add(entry)
                            }
                        }
                        if (toInsert.isNotEmpty()) {
                            db.withTransaction {
                                db.feeLedgerDao().insertLedgerEntries(toInsert)
                            }
                        }
                    }
                }
                synchronized(snapshotListeners) { snapshotListeners.add(listener) }
            } catch (e: Exception) {
                Log.e("SchoolRepository", "Failed to register fee_ledger_entries listener", e)
            }
        }

        // 11. Users Synchronization (Batch Processed)
        try {
            val listener = fs.collection("users").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [users]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<User>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        var userObj = change.document.toObject(User::class.java)
                        if (userObj != null) {
                            if (userObj.userId.isBlank()) {
                                userObj = userObj.copy(userId = change.document.id)
                            }
                            if (userObj.userId.isNotBlank()) {
                                var processedUser = userObj
                                if (processedUser.name.isBlank() || processedUser.name.equals("Unknown", ignoreCase = true)) {
                                    val s = db.studentDao().getStudentById(processedUser.userId)
                                    val t = db.teacherDao().getTeacherById(processedUser.userId)
                                    val resolvedName = s?.name ?: t?.name ?: processedUser.email.substringBefore("@").ifBlank { processedUser.userId }
                                    if (resolvedName.isNotBlank() && !resolvedName.equals("Unknown", ignoreCase = true)) {
                                        processedUser = processedUser.copy(name = resolvedName)
                                    }
                                }

                                if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                    if (processedUser.name.isNotBlank() && !processedUser.name.equals("Unknown", ignoreCase = true)) {
                                        toInsert.add(processedUser)
                                        val cur = _currentUser.value
                                        if (cur != null && (processedUser.userId == cur.userId || processedUser.email == cur.email)) {
                                            _currentUser.value = processedUser
                                        }
                                    }
                                } else {
                                    toDelete.add(processedUser.userId)
                                }
                            }
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.userDao().deleteUserById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.userDao().insertUsers(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register users listener", e)
        }

        // 12. Audit Logs Synchronization (Admin / Principal ONLY, Recent 100)
        if (isAdminOrPrincipal) {
            try {
                val listener = fs.collection("audit_logs")
                    .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                    .limit(100)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("SchoolRepository", "Firestore Sync Error [audit_logs]: ${error.message}", error)
                            return@addSnapshotListener
                        }
                        val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                        if (changes.isEmpty()) return@addSnapshotListener

                        scope.launch(Dispatchers.IO) {
                            val toInsert = mutableListOf<AuditLog>()
                            changes.forEach { change ->
                                if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                    val logObj = change.document.toObject(AuditLog::class.java)
                                    if (logObj != null) toInsert.add(logObj)
                                }
                            }
                            if (toInsert.isNotEmpty()) {
                                db.withTransaction {
                                    db.auditLogDao().insertAuditLogs(toInsert)
                                }
                            }
                        }
                    }
                synchronized(snapshotListeners) { snapshotListeners.add(listener) }
            } catch (e: Exception) {
                Log.e("SchoolRepository", "Failed to register audit_logs listener", e)
            }
        }

        // 13. Teacher Attendance Synchronization (Admin/Principal and Teachers ONLY)
        if (isAdminOrPrincipal || isTeacher) {
            try {
                val listener = fs.collection("teacher_attendance").addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("SchoolRepository", "Firestore Sync Error [teacher_attendance]: ${error.message}", error)
                        return@addSnapshotListener
                    }
                    val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                    if (changes.isEmpty()) return@addSnapshotListener

                    scope.launch(Dispatchers.IO) {
                        val toInsert = mutableListOf<TeacherAttendance>()
                        changes.forEach { change ->
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                val taObj = change.document.toObject(TeacherAttendance::class.java)
                                if (taObj != null) toInsert.add(taObj)
                            }
                        }
                        if (toInsert.isNotEmpty()) {
                            db.withTransaction {
                                db.teacherAttendanceDao().insertTeacherAttendances(toInsert)
                            }
                        }
                    }
                }
                synchronized(snapshotListeners) { snapshotListeners.add(listener) }
            } catch (e: Exception) {
                Log.e("SchoolRepository", "Failed to register teacher_attendance listener", e)
            }
        }

        // 14. Payrolls Synchronization (Admin / Principal ONLY)
        if (isAdminOrPrincipal) {
            try {
                val listener = fs.collection("payrolls").addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("SchoolRepository", "Firestore Sync Error [payrolls]: ${error.message}", error)
                        return@addSnapshotListener
                    }
                    val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                    if (changes.isEmpty()) return@addSnapshotListener

                    scope.launch(Dispatchers.IO) {
                        val toInsert = mutableListOf<Payroll>()
                        val toDelete = mutableListOf<String>()

                        changes.forEach { change ->
                            if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                toDelete.add(change.document.id)
                            } else {
                                val payroll = change.document.toObject(Payroll::class.java)
                                if (payroll != null) toInsert.add(payroll)
                            }
                        }

                        db.withTransaction {
                            toDelete.forEach { db.payrollDao().deletePayrollsByTeacher(it) }
                            if (toInsert.isNotEmpty()) {
                                db.payrollDao().insertPayrolls(toInsert)
                            }
                        }
                    }
                }
                synchronized(snapshotListeners) { snapshotListeners.add(listener) }
            } catch (e: Exception) {
                Log.e("SchoolRepository", "Failed to register payrolls listener", e)
            }
        }

        // 15. Notifications Synchronization (Global)
        try {
            val listener = fs.collection("notifications").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [notifications]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<AppNotification>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            val notif = change.document.toObject(AppNotification::class.java)
                            if (notif != null) toInsert.add(notif)
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.notificationDao().deleteNotificationById(it) }
                        toInsert.forEach { db.notificationDao().insertNotification(it) }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register notifications listener", e)
        }

        // 16. Class Books Synchronization (Global)
        try {
            val listener = fs.collection("class_books").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [class_books]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<ClassBook>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            val book = change.document.toObject(ClassBook::class.java)
                            if (book != null) toInsert.add(book)
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.classBookDao().deleteClassBookById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.classBookDao().insertClassBooks(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register class_books listener", e)
        }

        // 17. Issued Books Synchronization (Global)
        try {
            val listener = fs.collection("issued_books").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [issued_books]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<IssuedBook>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            val issued = change.document.toObject(IssuedBook::class.java)
                            if (issued != null) toInsert.add(issued)
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.issuedBookDao().deleteIssuedBookById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.issuedBookDao().insertIssuedBooks(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register issued_books listener", e)
        }

        // 18. Leave Requests Synchronization (Global)
        try {
            val listener = fs.collection("leave_requests").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [leave_requests]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener

                scope.launch(Dispatchers.IO) {
                    val toInsert = mutableListOf<LeaveRequest>()
                    val toDelete = mutableListOf<String>()

                    changes.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            toDelete.add(change.document.id)
                        } else {
                            val req = change.document.toObject(LeaveRequest::class.java)
                            if (req != null) toInsert.add(req)
                        }
                    }

                    db.withTransaction {
                        toDelete.forEach { db.leaveRequestDao().deleteLeaveRequestById(it) }
                        if (toInsert.isNotEmpty()) {
                            db.leaveRequestDao().insertLeaveRequests(toInsert)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register leave_requests listener", e)
        }

        // 19. Fee Rate History Synchronization
        try {
            val listener = fs.collection("fee_rate_history").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [fee_rate_history]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener
                scope.launch(Dispatchers.IO) {
                    changes.forEach { change ->
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            val rate = change.document.toObject(FeeRateHistory::class.java)
                            if (rate != null) db.feeRateHistoryDao().insertRate(rate)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register fee_rate_history listener", e)
        }

        // 20. Fee Event Charge Synchronization
        try {
            val listener = fs.collection("fee_event_charges").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Sync Error [fee_event_charges]: ${error.message}", error)
                    return@addSnapshotListener
                }
                val changes = snapshot?.documentChanges ?: return@addSnapshotListener
                if (changes.isEmpty()) return@addSnapshotListener
                scope.launch(Dispatchers.IO) {
                    changes.forEach { change ->
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            val charge = change.document.toObject(FeeEventCharge::class.java)
                            if (charge != null) db.feeEventChargeDao().insertEventCharge(charge)
                        } else {
                            db.feeEventChargeDao().deleteEventCharge(change.document.id)
                        }
                    }
                }
            }
            synchronized(snapshotListeners) { snapshotListeners.add(listener) }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register fee_event_charges listener", e)
        }

    }

    override suspend fun loginWithCredential(credential: com.google.firebase.auth.AuthCredential, user: User): Result<User> {
        return try {
            val auth = firebaseAuth
            if (auth != null) {
                val authResult = kotlinx.coroutines.withTimeout(8000) { auth.signInWithCredential(credential).await() }
                if (authResult.user == null) {
                    throw Exception("Verification failed!")
                }
            }

            // Provision user profile in firestore if missing
            firestore?.let { fs ->
                try {
                    val doc = fs.collection("users").document(user.userId).get()?.await()
                    if (doc?.exists() != true) {
                        kotlinx.coroutines.withTimeout(5000) { fs.collection("users").document(user.userId).set(user).await() }
                    }
                } catch (e: Exception) {
                    Log.e("SchoolRepository", "Error provisioning user profile to Firestore on OTP login", e)
                }
            }

            val authUid = auth?.currentUser?.uid
            val finalUser = if (authUid != null) user.copy(uid = authUid) else user
            db.userDao().insertUser(finalUser)

            prefs.edit().putString("last_logged_in_user_id", finalUser.userId).apply()
            _currentUser.value = finalUser
            startBackgroundFirebaseSync()
            Result.success(finalUser)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun findUserByPhone(phone: String): User? {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return null

        // Seeding Master Principal check
        if (cleanPhone == "9523256847") {
            var master = db.userDao().getUser("theshiwamlaptop@gmail.com")
            if (master == null) {
                master = User(
                    userId = "theshiwamlaptop@gmail.com",
                    name = "Shiwam Sir",
                    role = "PRINCIPAL",
                    roleCode = "HA-99",
                    email = "theshiwamlaptop@gmail.com",
                    phone = "9523256847",
                    passwordHash = sha256Hex("23-07-2010"),
                    isFirstLogin = false,
                    className = "All",
                    dob = "23-07-2010"
                )
                db.userDao().insertUser(master)
            }
            // Instantly provision to Firestore if missing
            firestore?.let { fs ->
                try {
                    val doc = fs.collection("users").document("theshiwamlaptop@gmail.com").get()?.await()
                    if (doc?.exists() != true) {
                        fs.collection("users").document("theshiwamlaptop@gmail.com").set(master)
                    }
                } catch (e: Exception) {
                    Log.e("SchoolRepository", "Error provisioning Master Principal to Firestore", e)
                }
            }
            return master
        }

        // Try Room local
        var localUser = db.userDao().getUserByPhone(cleanPhone)

        // Try getting user from Firestore if local record is absent
        if (localUser == null && firestore != null) {
            try {
                val query = firestore?.collection("users")
                    ?.whereEqualTo("phone", cleanPhone)
                    ?.get()
                    ?.await()
                val doc = query?.documents?.firstOrNull()
                if (doc != null && doc.exists()) {
                    localUser = doc.toObject(User::class.java)
                    if (localUser != null) {
                        db.userDao().insertUser(localUser!!)
                    }
                }
            } catch (e: Exception) {
                Log.e("SchoolRepository", "Firestore search by phone exception", e)
            }
        }
        return localUser
    }

    /**
     * FIREBASE AUTHENTICATION FLOWS:
     * User authentication leverages both FirebaseAuth (primary cloud access credentials)
     * and a SQLite local backup check (for uninterrupted offline portals).
     */
private val SEED_CREDENTIALS = mapOf(
        "SDPS-ADM-01" to listOf("admin@sdps.com", "ADMIN", "S.D.P.S. Admin", "01-01-1980"),
        "SDPS-TCH-01" to listOf("teacher@sdps.com", "CLASS_TEACHER", "S.D.P.S. Teacher", "01-01-1985"),
        "SDPS-STU-01" to listOf("student@sdps.com", "STUDENT", "S.D.P.S. Student", "01-01-2010")
    )

    /**
     * FIREBASE AUTHENTICATION FLOWS:
     * Real credential authentication with Firebase Auth, Firestore sync, and local Room persistence.
     */
    override suspend fun login(userId: String, role: String, fullname: String, password: String): Result<User> {
        return try {
            val processedId = userId.trim()
            if (processedId.isEmpty()) return Result.failure(Exception("User ID cannot be empty!"))
            if (password.isEmpty()) return Result.failure(Exception("Password cannot be empty!"))

            val idLower = processedId.lowercase(java.util.Locale.ROOT)
            val cleanPhone = processedId.replace("+91", "").replace(" ", "").replace("-", "").trim()
            val isBlocked = idLower == "prin99" || idLower == "sdps-owner"
            if (isBlocked) {
                return Result.failure(Exception("This User ID is restricted. Please enter valid credentials!"))
            }

            // 1. MASTER PRINCIPAL (Shivam Sir)
            val isMasterPrincipal = (idLower == "theshiwamlaptop@gmail.com" || cleanPhone == "9523256847" || idLower == "shiwamsir" || idLower == "principal" || processedId == "theshiwamlaptop@gmail.com")
            if (isMasterPrincipal) {
                var masterUser = db.userDao().getUser("theshiwamlaptop@gmail.com")
                if (masterUser == null) {
                    val fs = firestore
                    if (fs != null) {
                        try {
                            val fsDoc = kotlinx.coroutines.withTimeoutOrNull(4000) {
                                fs.collection("users").document("theshiwamlaptop@gmail.com").get().await()
                            }
                            if (fsDoc != null && fsDoc.exists()) {
                                masterUser = fsDoc.toObject(User::class.java)
                            }
                        } catch (e: Exception) {}
                    }
                }
                if (masterUser == null) {
                    masterUser = User(
                        userId = "theshiwamlaptop@gmail.com",
                        uid = firebaseAuth?.currentUser?.uid ?: "",
                        name = "Shiwam Sir",
                        role = "PRINCIPAL",
                        roleCode = "HA-99",
                        email = "theshiwamlaptop@gmail.com",
                        phone = "9523256847",
                        passwordHash = sha256Hex("23-07-2010"),
                        isFirstLogin = false,
                        className = "All",
                        dob = "23-07-2010"
                    )
                    db.userDao().insertUser(masterUser)
                }

                val isPassOk = (sha256Hex(password) == masterUser.passwordHash) ||
                               (masterUser.passwordHash == password)
                if (!isPassOk) {
                    return Result.failure(Exception("Incorrect password for Principal!"))
                }

                // Migrate plain text password to hash if stored unhashed
                if (masterUser.passwordHash == password) {
                    masterUser = masterUser.copy(passwordHash = sha256Hex(password))
                    db.userDao().insertUser(masterUser)
                }

                prefs.edit().putString("last_logged_in_user_id", "theshiwamlaptop@gmail.com").apply()
                _currentUser.value = masterUser

                // Authenticate with Firebase Auth
                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value) {
                    try {
                        val authResult = kotlinx.coroutines.withTimeout(4000) {
                            try { auth.signInWithEmailAndPassword("theshiwamlaptop@gmail.com", password).await() }
                            catch (ae: Exception) {
                                if ((ae as? FirebaseAuthException)?.errorCode == "ERROR_USER_NOT_FOUND") {
                                    auth.createUserWithEmailAndPassword("theshiwamlaptop@gmail.com", password).await()
                                } else {
                                    throw ae
                                }
                            }
                        }
                        val masterAuthUid = authResult.user?.uid ?: throw Exception("Firebase authentication returned no user")
                        masterUser = masterUser.copy(uid = masterAuthUid)
                        db.userDao().insertUser(masterUser)
                        _currentUser.value = masterUser
                    } catch (e: Exception) {
                        Log.e("SchoolRepository", "Master Firebase authentication failed", e)
                        return Result.failure(Exception("Firebase authentication failed: ${e.message ?: "unknown error"}", e))
                    }
                }
                val fs = firestore
                if (fs != null) {
                    try {
                        kotlinx.coroutines.withTimeoutOrNull(4000) {
                            fs.collection("users").document("theshiwamlaptop@gmail.com").set(masterUser).await()
                        }
                    } catch (e: Exception) {
                        Log.w("SchoolRepository", "Master Firestore cloud sync non-blocking warning: ${e.message}")
                    }
                }
                startBackgroundFirebaseSync()
                return Result.success(masterUser)
            }

            // 2. STRICT 12 CLASS TEACHERS
            val TEACHER_SEED = mapOf(
                "tchr.nursery" to Pair("Nursery", "Teacher Nursery"), "tchr.lkg" to Pair("LKG", "Teacher LKG"),
                "tchr.ukg" to Pair("UKG", "Teacher UKG"), "tchr.class1" to Pair("Class 1", "Teacher Class 1"),
                "tchr.class2" to Pair("Class 2", "Teacher Class 2"), "tchr.class3" to Pair("Class 3", "Teacher Class 3"),
                "tchr.class4" to Pair("Class 4", "Teacher Class 4"), "tchr.class5" to Pair("Class 5", "Teacher Class 5"),
                "tchr.class6" to Pair("Class 6", "Teacher Class 6"), "tchr.class7" to Pair("Class 7", "Teacher Class 7"),
                "tchr.class8" to Pair("Class 8", "Teacher Class 8"), "tchr.class9" to Pair("Class 9", "Teacher Class 9"),
                "tchr.class10" to Pair("Class 10", "Teacher Class 10")
            )
            if (TEACHER_SEED.containsKey(idLower)) {
                val (className, teacherName) = TEACHER_SEED[idLower]!!
                var teacherUser = db.userDao().getUser(idLower)
                if (teacherUser == null) {
                    val fs = firestore
                    if (fs != null) {
                        try {
                            val fsDoc = kotlinx.coroutines.withTimeoutOrNull(4000) {
                                fs.collection("users").document(idLower).get().await()
                            }
                            if (fsDoc != null && fsDoc.exists()) {
                                teacherUser = fsDoc.toObject(User::class.java)
                            }
                        } catch (e: Exception) {}
                    }
                }
                val teacherDob = "01-01-1985"
                if (teacherUser == null) {
                    teacherUser = User(
                        userId = idLower, uid = firebaseAuth?.currentUser?.uid ?: "", name = teacherName, role = "CLASS_TEACHER",
                        roleCode = "TC-12", email = "$idLower@sdps.com", phone = "9999999999", passwordHash = sha256Hex(teacherDob),
                        isFirstLogin = false, className = className, dob = teacherDob
                    )
                    db.userDao().insertUser(teacherUser)
                }

                val isPassOk = (sha256Hex(password) == teacherUser.passwordHash) || (teacherUser.passwordHash == password)
                if (!isPassOk) return Result.failure(Exception("Incorrect password for Teacher!"))

                if (teacherUser.passwordHash == password) {
                    teacherUser = teacherUser.copy(passwordHash = sha256Hex(password))
                    db.userDao().insertUser(teacherUser)
                }

                val existingTeacher = db.teacherDao().getTeacherById(idLower)
                if (existingTeacher == null) {
                    db.teacherDao().insertTeacher(Teacher(idLower, teacherName, "All", className, "9999999999", "$idLower@sdps.com", joiningDate = teacherDob))
                }
                prefs.edit().putString("last_logged_in_user_id", idLower).apply()
                _currentUser.value = teacherUser

                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value) {
                    try {
                        val authResult = kotlinx.coroutines.withTimeout(4000) {
                            try { auth.signInWithEmailAndPassword("$idLower@sdps.com", password).await() }
                            catch (ae: Exception) {
                                if ((ae as? FirebaseAuthException)?.errorCode == "ERROR_USER_NOT_FOUND") {
                                    auth.createUserWithEmailAndPassword("$idLower@sdps.com", password).await()
                                } else {
                                    throw ae
                                }
                            }
                        }
                        val teacherAuthUid = authResult.user?.uid ?: throw Exception("Firebase authentication returned no user")
                        teacherUser = teacherUser.copy(uid = teacherAuthUid)
                        db.userDao().insertUser(teacherUser)
                        _currentUser.value = teacherUser
                    } catch (e: Exception) {
                        Log.e("SchoolRepository", "Teacher Firebase authentication failed", e)
                        return Result.failure(Exception("Firebase authentication failed: ${e.message ?: "unknown error"}", e))
                    }
                }
                val fs = firestore
                if (fs != null) {
                    try {
                        kotlinx.coroutines.withTimeoutOrNull(4000) {
                            fs.collection("users").document(idLower).set(teacherUser).await()
                            fs.collection("teachers").document(idLower).set(Teacher(idLower, teacherName, "All", className, "9999999999", "$idLower@sdps.com")).await()
                        }
                    } catch (e: Exception) {}
                }
                startBackgroundFirebaseSync()
                return Result.success(teacherUser)
            }

            // 3. GENERAL USER (Student, Teacher, Admin, Staff)
            var existingUser = db.userDao().getUser(processedId) 
                ?: db.userDao().getUser(idLower)
                ?: db.userDao().getUser(processedId.uppercase(java.util.Locale.ROOT))
            if (existingUser == null && cleanPhone.isNotEmpty()) {
                existingUser = db.userDao().getUserByPhone(cleanPhone)
            }

            // If not found locally, query Firestore
            val fs = firestore
            if (existingUser == null && fs != null) {
                try {
                    val fsDoc = kotlinx.coroutines.withTimeoutOrNull(4000) {
                        fs.collection("users").document(processedId).get().await()
                    }
                    if (fsDoc != null && fsDoc.exists()) {
                        existingUser = fsDoc.toObject(User::class.java)
                        if (existingUser != null) {
                            db.userDao().insertUser(existingUser)
                        }
                    }
                } catch (e: Exception) {
                    Log.w("SchoolRepository", "Firestore user search error: ${e.message}")
                }
            }

            // Student document lookup if still not found
            if (existingUser == null) {
                var student = db.studentDao().getStudentById(processedId)
                    ?: db.studentDao().getStudentById(idLower)
                    ?: db.studentDao().getStudentByAdmissionNo(processedId)
                    ?: db.studentDao().getStudentByAdmissionNo(idLower)
                if (student == null && cleanPhone.isNotEmpty()) {
                    student = db.studentDao().getStudentByPhone(cleanPhone)
                }
                if (student == null && fs != null) {
                    try {
                        val studentDoc = kotlinx.coroutines.withTimeoutOrNull(4000) {
                            fs.collection("students").document(processedId).get().await()
                        }
                        if (studentDoc != null && studentDoc.exists()) {
                            student = studentDoc.toObject(Student::class.java)
                        }
                    } catch (e: Exception) {
                        Log.w("SchoolRepository", "Firestore student search error: ${e.message}")
                    }
                }
                if (student != null) {
                    val initPass = student.DOB.ifBlank { "01-01-2010" }.trim()
                    existingUser = User(
                        userId = student.studentId, uid = "", name = student.name,
                        role = "STUDENT", roleCode = "ST-01", email = "${student.studentId.lowercase()}@sdps.com", phone = student.phone,
                        passwordHash = sha256Hex(initPass), isFirstLogin = true, className = student.className,
                        dob = initPass
                    )
                    db.userDao().insertUser(existingUser)
                    try { fs?.collection("users")?.document(student.studentId)?.set(existingUser) } catch(e: Exception){}
                }
            }

            // Teacher document lookup if still not found
            if (existingUser == null) {
                var teacher = db.teacherDao().getTeacherById(processedId)
                    ?: db.teacherDao().getTeacherById(idLower)
                if (teacher == null && cleanPhone.isNotEmpty()) {
                    teacher = db.teacherDao().getTeacherByPhone(cleanPhone)
                }
                if (teacher == null && fs != null) {
                    try {
                        val teacherDoc = kotlinx.coroutines.withTimeoutOrNull(4000) {
                            fs.collection("teachers").document(processedId).get().await()
                        }
                        if (teacherDoc != null && teacherDoc.exists()) {
                            teacher = teacherDoc.toObject(Teacher::class.java)
                        }
                    } catch (e: Exception) {
                        Log.w("SchoolRepository", "Firestore teacher search error: ${e.message}")
                    }
                }
                if (teacher != null) {
                    val initPass = teacher.joiningDate.ifBlank { "01-01-1990" }.trim()
                    existingUser = User(
                        userId = teacher.teacherId, uid = "", name = teacher.name,
                        role = "TEACHER", roleCode = "TC-12", email = teacher.email.ifBlank { "${teacher.teacherId.lowercase()}@sdps.com" }, phone = teacher.phone,
                        passwordHash = sha256Hex(initPass), isFirstLogin = true, className = teacher.classesAssigned,
                        dob = initPass
                    )
                    db.userDao().insertUser(existingUser)
                    try { fs?.collection("users")?.document(teacher.teacherId)?.set(existingUser) } catch(e: Exception){}
                }
            }

            // Seed account fallback
            val matchedSeed = SEED_CREDENTIALS[processedId.uppercase()]
            if (existingUser == null && matchedSeed != null) {
                val email = matchedSeed[0]
                val seedRole = matchedSeed[1]
                val seedName = matchedSeed[2]
                val seedDob = matchedSeed[3]
                existingUser = User(
                    userId = processedId.uppercase(), uid = "", name = seedName, role = seedRole,
                    roleCode = when (seedRole) { "PRINCIPAL", "HEAD_ADMIN" -> "HA-99"; "ADMIN" -> "AD-55"; "CLASS_TEACHER", "TEACHER" -> "TC-12"; else -> "ST-01" },
                    email = email, phone = "9999999999", passwordHash = sha256Hex(seedDob), isFirstLogin = false, className = "Class X",
                    dob = seedDob
                )
                db.userDao().insertUser(existingUser)
                if (seedRole == "STUDENT") {
                    if (db.studentDao().getStudentById(processedId.uppercase()) == null) db.studentDao().insertStudent(Student(studentId = processedId.uppercase(), name = seedName, className = "Class X", rollNo = "1", DOB = seedDob, phone = "9999999999", address = "SDPS Campus No. 1"))
                } else {
                    if (db.teacherDao().getTeacherById(processedId.uppercase()) == null) db.teacherDao().insertTeacher(Teacher(teacherId = processedId.uppercase(), name = seedName, subject = "Management", classesAssigned = "Class X", phone = "9999999999", email = email, joiningDate = seedDob))
                }
            }

            if (existingUser == null) {
                return Result.failure(Exception("User ID not found. Please verify your credentials or contact Administration."))
            }

            // Validate password:
            val inputPassClean = password.trim()
            val inputPassHash = sha256Hex(inputPassClean)
            val inputDobNormalized = normalizeDob(inputPassClean)

            var isValidPassword = (inputPassHash == existingUser.passwordHash) || 
                                  (existingUser.passwordHash == inputPassClean)

            if (!isValidPassword) {
                val rawDob = existingUser.dob.ifBlank {
                    if (existingUser.role == "STUDENT") db.studentDao().getStudentById(existingUser.userId)?.DOB ?: ""
                    else if (existingUser.role == "TEACHER" || existingUser.role == "CLASS_TEACHER") db.teacherDao().getTeacherById(existingUser.userId)?.joiningDate ?: ""
                    else ""
                }.trim()

                val userDobNormalized = normalizeDob(rawDob)

                val isInitialAccountState = existingUser.isFirstLogin || 
                                            existingUser.passwordHash == "temp123" || 
                                            (rawDob.isNotEmpty() && (existingUser.passwordHash == sha256Hex(rawDob) || existingUser.passwordHash == rawDob)) ||
                                            (userDobNormalized.isNotEmpty() && (existingUser.passwordHash == sha256Hex(userDobNormalized) || existingUser.passwordHash == userDobNormalized))

                if (isInitialAccountState && userDobNormalized.isNotEmpty()) {
                    if (inputDobNormalized == userDobNormalized || 
                        inputPassClean.equals(rawDob, ignoreCase = true) || 
                        inputPassHash == sha256Hex(rawDob) || 
                        sha256Hex(inputDobNormalized) == sha256Hex(userDobNormalized)) {
                        isValidPassword = true
                    }
                }
            }

            if (!isValidPassword) {
                return Result.failure(Exception("Incorrect password. Please enter valid credentials."))
            }

            // Upgrade unhashed password to sha256 hash if needed
            if (existingUser.passwordHash == password) {
                existingUser = existingUser.copy(passwordHash = sha256Hex(password))
                db.userDao().insertUser(existingUser)
                try { fs?.collection("users")?.document(existingUser.userId)?.set(existingUser) } catch(e: Exception){}
            }

            // Authenticate with Firebase Auth asynchronously/safely
            val auth = firebaseAuth
            val emailToAuth = if (existingUser.email.contains("@")) existingUser.email else "${existingUser.userId.lowercase()}@sdps.com"
            if (auth != null && isFirebaseModeFlow.value) {
                try {
                    val authResult = kotlinx.coroutines.withTimeout(4000) {
                        try { auth.signInWithEmailAndPassword(emailToAuth, password).await() }
                        catch (ae: Exception) {
                            if ((ae as? FirebaseAuthException)?.errorCode == "ERROR_USER_NOT_FOUND") {
                                auth.createUserWithEmailAndPassword(emailToAuth, password).await()
                            } else {
                                throw ae
                            }
                        }
                    }
                    val existingAuthUid = authResult.user?.uid ?: throw Exception("Firebase authentication returned no user")
                    existingUser = existingUser.copy(uid = existingAuthUid)
                    db.userDao().insertUser(existingUser)
                } catch(e: Exception) {
                    Log.e("SchoolRepository", "Firebase Auth sign-in failed", e)
                    return Result.failure(Exception("Firebase authentication failed: ${e.message ?: "unknown error"}", e))
                }
            }

            prefs.edit().putString("last_logged_in_user_id", existingUser.userId).apply()
            _currentUser.value = existingUser
            startBackgroundFirebaseSync()
            Result.success(existingUser)
        } catch (e: Exception) {
            android.util.Log.e("SchoolRepository", "Login flow exception: ${e.message}", e)
            Result.failure(Exception(e.message ?: "Incorrect User ID or password!"))
        }
    }

    override suspend fun checkAndRestoreSession(): User? {
        try {
            val lastUserId = prefs.getString("last_logged_in_user_id", null)
            val isSeed = lastUserId != null && (SEED_CREDENTIALS.containsKey(lastUserId.uppercase()) || lastUserId == "theshiwamlaptop@gmail.com")

            // Master account check first
            if (lastUserId == "theshiwamlaptop@gmail.com") {
                val dbUser = db.userDao().getUser(lastUserId) ?: User(
                    userId = "theshiwamlaptop@gmail.com",
                    name = "Shiwam Sir",
                    role = "PRINCIPAL",
                    roleCode = "HA-99",
                    email = "theshiwamlaptop@gmail.com",
                    phone = "9523256847",
                    passwordHash = sha256Hex("23-07-2010"),
                    isFirstLogin = false,
                    className = "All",
                    dob = "23-07-2010"
                )
                db.userDao().insertUser(dbUser)
                _currentUser.value = dbUser
                
                // Firebase Auth persists its own session across app restarts — no need to
                // (and no safe way to) silently re-sign-in with a hardcoded password here.
                // If auth.currentUser is null on restore, the user will simply need to log
                // in again through the normal login screen.

                startBackgroundFirebaseSync()
                return dbUser
            }

            if (lastUserId != null && lastUserId.startsWith("tchr.")) {
                val TEACHER_SEED = mapOf(
                    "tchr.nursery" to Pair("Nursery", "Teacher Nursery"),
                    "tchr.lkg" to Pair("LKG", "Teacher LKG"),
                    "tchr.ukg" to Pair("UKG", "Teacher UKG"),
                    "tchr.class1" to Pair("Class 1", "Teacher Class 1"),
                    "tchr.class2" to Pair("Class 2", "Teacher Class 2"),
                    "tchr.class3" to Pair("Class 3", "Teacher Class 3"),
                    "tchr.class4" to Pair("Class 4", "Teacher Class 4"),
                    "tchr.class5" to Pair("Class 5", "Teacher Class 5"),
                    "tchr.class6" to Pair("Class 6", "Teacher Class 6"),
                    "tchr.class7" to Pair("Class 7", "Teacher Class 7"),
                    "tchr.class8" to Pair("Class 8", "Teacher Class 8"),
                    "tchr.class9" to Pair("Class 9", "Teacher Class 9"),
                    "tchr.class10" to Pair("Class 10", "Teacher Class 10")
                )
                if (TEACHER_SEED.containsKey(lastUserId)) {
                    val (clName, tName) = TEACHER_SEED[lastUserId]!!
                    val defaultTeacherDob = "01-01-1985"
                    val dbUser = db.userDao().getUser(lastUserId) ?: User(
                        userId = lastUserId,
                        name = tName,
                        role = "CLASS_TEACHER",
                        roleCode = "TC-12",
                        email = "$lastUserId@sdps.com",
                        phone = "9999999999",
                        passwordHash = sha256Hex(defaultTeacherDob),
                        isFirstLogin = false,
                        className = clName,
                        dob = defaultTeacherDob
                    )
                    db.userDao().insertUser(dbUser)
                    _currentUser.value = dbUser
                    
                    val auth = firebaseAuth
                    if (auth != null && isFirebaseModeFlow.value && auth.currentUser == null) {
                        try {
                        try { kotlinx.coroutines.withTimeout(5000) { auth.signInWithEmailAndPassword("$lastUserId@sdps.com", defaultTeacherDob).await() } }
                        catch (ae: Exception) {
                            if ((ae as? FirebaseAuthException)?.errorCode == "ERROR_USER_NOT_FOUND") {
                                auth.createUserWithEmailAndPassword("$lastUserId@sdps.com", defaultTeacherDob).await()
                            } else {
                                throw ae
                            }
                        }
                        } catch (e: Exception) {
                            android.util.Log.e("SchoolRepository", "Failed to restore Firebase Auth for teacher", e)
                        }
                    }
                    startBackgroundFirebaseSync()
                    return dbUser
                }
            }

            val auth = firebaseAuth
            if (auth != null && isFirebaseModeFlow.value) {
                val fUser = auth.currentUser
                if (fUser != null) {
                    val email = fUser.email ?: ""
                    val userId = email.substringBefore("@")
                    if (userId.isNotEmpty()) {
                        var restoredUser: User? = null
                        val fs = firestore
                        if (fs != null) {
                            try {
                                restoredUser = kotlinx.coroutines.withTimeout(4000) {
                                    val doc = fs.collection("users").document(userId).get()?.await()
                                    if (doc != null && doc.exists()) {
                                        val mapped = doc.toObject(User::class.java)
                                        if (mapped == null || mapped.userId.isBlank() || mapped.role.isBlank() || !mapped.email.contains("@")) {
                                            throw Exception("Invalid user profile parsed")
                                        }
                                        mapped
                                    } else null
                                }
                            } catch (e: Exception) {
                                Log.e("SchoolRepository", "Error fetching profile from Firestore during autologin", e)
                            }
                        }
                        if (restoredUser == null) {
                            restoredUser = db.userDao().getUser(userId)
                        } else {
                            db.userDao().insertUser(restoredUser)
                        }

                        if (restoredUser != null) {
                            if (restoredUser.userId.isBlank() || restoredUser.role.isBlank() || !restoredUser.email.contains("@")) {
                                throw Exception("Corrupt local user profile parsed")
                            }
                            _currentUser.value = restoredUser
                            prefs.edit().putString("last_logged_in_user_id", userId).apply()
                            startBackgroundFirebaseSync()
                            return restoredUser
                        }
                    }
                }
            }

            if (lastUserId != null) {
                val offlineUser = db.userDao().getUser(lastUserId)
                if (offlineUser != null) {
                    if (offlineUser.userId.isBlank() || offlineUser.role.isBlank()) {
                        throw Exception("Corrupt offline user found")
                    }
                    _currentUser.value = offlineUser
                    startBackgroundFirebaseSync()
                    return offlineUser
                }
            }
            _currentUser.value = null
            return null
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Session restore fallback: ${e.message}. Navigating to login screen.", e)
            _currentUser.value = null
            return null
        }
    }

    override suspend fun logout() {
        stopBackgroundFirebaseSync()
        _currentUser.value = null
        prefs.edit().remove("last_logged_in_user_id").apply()
        try {
            firebaseAuth?.signOut()
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Firebase Auth sign out failure", e)
        }
    }

    override suspend fun applyDefaultPassword(userId: String): Result<Unit> {
        return try {
            val user = db.userDao().getUser(userId) ?: db.userDao().getUserByPhone(userId)
            if (user != null) {
                val dob = if (user.role.uppercase() == "STUDENT") {
                    db.studentDao().getStudentById(user.userId)?.DOB ?: "01-01-2010"
                } else {
                    "01-01-1980"
                }
                val updated = user.copy(passwordHash = sha256Hex(dob), isFirstLogin = true)
                db.userDao().insertUser(updated)
                firestore?.collection("users")?.document(user.userId)?.set(updated)?.await()
                Result.success(Unit)
            } else {
                Result.failure(Exception("User not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun verifyResetDetails(userId: String, dob: String): Result<Unit> {
        return try {
            val cleanId = userId.trim()
            val cleanDob = dob.trim()
            if (cleanId.isEmpty() || cleanDob.isEmpty()) {
                return Result.failure(Exception("User ID and Date of Birth / Verification detail cannot be empty!"))
            }

            // 0. Check Master Principal (Shivam Sir)
            val isPrincipal = cleanId.equals("theshiwamlaptop@gmail.com", ignoreCase = true) ||
                              cleanId.equals("principal", ignoreCase = true) ||
                              cleanId.equals("shiwamsir", ignoreCase = true) ||
                              cleanId == "9523256847"
            if (isPrincipal) {
                val principalDob = "23-07-2010"
                if (cleanDob == principalDob || cleanDob.replace("/", "-") == principalDob) {
                    return Result.success(Unit)
                } else {
                    return Result.failure(Exception("Date of Birth does not match Principal records."))
                }
            }

            // 1. Check Student records (Local & Firestore)
            var student = db.studentDao().getStudentById(cleanId)
                ?: db.studentDao().getStudentById(cleanId.lowercase(java.util.Locale.ROOT))
                ?: db.studentDao().getStudentByAdmissionNo(cleanId)
                ?: db.studentDao().getStudentByAdmissionNo(cleanId.lowercase(java.util.Locale.ROOT))
                ?: db.studentDao().getStudentByPhone(cleanId)

            if (student == null && firestore != null) {
                try {
                    val sDoc = firestore?.collection("students")?.document(cleanId)?.get()?.await()
                    if (sDoc != null && sDoc.exists()) {
                        student = sDoc.toObject(Student::class.java)
                        if (student != null) db.studentDao().insertStudent(student)
                    }
                } catch (e: Exception) {}
            }

            if (student != null) {
                val studentDob = student.DOB.trim()
                if (normalizeDob(studentDob) == normalizeDob(cleanDob) || studentDob.equals(cleanDob, ignoreCase = true)) {
                    return Result.success(Unit)
                } else {
                    return Result.failure(Exception("Date of Birth does not match student records."))
                }
            }

            // 2. Check Teacher records (Local & Firestore)
            var teacher = db.teacherDao().getTeacherById(cleanId)
                ?: db.teacherDao().getTeacherById(cleanId.lowercase(java.util.Locale.ROOT))
                ?: db.teacherDao().getTeacherByPhone(cleanId)

            if (teacher == null && firestore != null) {
                try {
                    val tDoc = firestore?.collection("teachers")?.document(cleanId)?.get()?.await()
                    if (tDoc != null && tDoc.exists()) {
                        teacher = tDoc.toObject(Teacher::class.java)
                        if (teacher != null) db.teacherDao().insertTeacher(teacher)
                    }
                } catch (e: Exception) {}
            }

            if (teacher != null) {
                val tJoin = teacher.joiningDate.trim()
                val tPhone = teacher.phone.trim()
                if (normalizeDob(tJoin) == normalizeDob(cleanDob) || tJoin.equals(cleanDob, ignoreCase = true) || tPhone == cleanDob) {
                    return Result.success(Unit)
                }
            }

            // 3. Check General User account
            var user = db.userDao().getUser(cleanId)
            if (user == null && firestore != null) {
                try {
                    val uDoc = firestore?.collection("users")?.document(cleanId)?.get()?.await()
                    if (uDoc != null && uDoc.exists()) {
                        user = uDoc.toObject(User::class.java)
                        if (user != null) db.userDao().insertUser(user)
                    }
                } catch (e: Exception) {}
            }

            if (user != null) {
                val userDob = user.dob.trim()
                if (userDob.isNotEmpty() && (userDob.equals(cleanDob, ignoreCase = true) || userDob.replace("/", "-").equals(cleanDob.replace("/", "-"), ignoreCase = true))) {
                    return Result.success(Unit)
                }
                if (user.phone.trim() == cleanDob || user.email.trim().equals(cleanDob, ignoreCase = true)) {
                    return Result.success(Unit)
                }
            }

            Result.failure(Exception("User ID not found or Date of Birth does not match."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun resetPasswordWithDob(userId: String, newPasswordHash: String): Result<Unit> {
        return try {
            val cleanId = userId.trim()
            var user = db.userDao().getUser(cleanId)
            if (user == null && firestore != null) {
                try {
                    val uDoc = firestore?.collection("users")?.document(cleanId)?.get()?.await()
                    if (uDoc != null && uDoc.exists()) {
                        user = uDoc.toObject(User::class.java)
                    }
                } catch (e: Exception) {}
            }

            if (user == null) {
                val student = db.studentDao().getStudentById(cleanId)
                if (student != null) {
                    user = User(
                        userId = student.studentId,
                        name = student.name,
                        role = "STUDENT",
                        email = "${student.studentId.lowercase()}@sdps.com",
                        phone = student.phone,
                        className = student.className,
                        passwordHash = sha256Hex(newPasswordHash),
                        isFirstLogin = false,
                        dob = student.DOB
                    )
                }
            }

            if (user != null) {
                val updated = user.copy(passwordHash = sha256Hex(newPasswordHash), isFirstLogin = false)
                db.userDao().insertUser(updated)
                firestore?.collection("users")?.document(user.userId)?.set(updated)?.await()
                
                // Record Audit Log & Administrative notification
                try {
                    val auditLog = AuditLog(
                        logId = java.util.UUID.randomUUID().toString(),
                        timestamp = System.currentTimeMillis(),
                        userId = updated.userId,
                        userName = updated.name,
                        action = "PASSWORD_RESET_DOB",
                        oldValue = "Initiated by: RECOVERY_DOB",
                        newValue = "Status: SUCCESS"
                    )
                    db.auditLogDao().insertAuditLog(auditLog)
                    firestore?.collection("audit_logs")?.document(auditLog.logId)?.set(auditLog)?.await()

                    val adminNotif = AppNotification(
                        notificationId = java.util.UUID.randomUUID().toString(),
                        userId = "theshiwamlaptop@gmail.com",
                        title = "Security Alert: Password Reset",
                        message = "User ${updated.name} (${updated.userId}, ${updated.role}) reset their password using verified DOB.",
                        timestamp = System.currentTimeMillis(),
                        isRead = false,
                        type = "INFO"
                    )
                    db.notificationDao().insertNotification(adminNotif)
                    firestore?.collection("notifications")?.document(adminNotif.notificationId)?.set(adminNotif)?.await()
                } catch (ae: Exception) {
                    Log.w("SchoolRepository", "Audit log write warning: ${ae.message}")
                }

                val auth = firebaseAuth
                if (auth != null) {
                    val email = if (user.email.contains("@")) user.email else "${user.userId.lowercase()}@sdps.com"
                    try {
                        if (auth.currentUser != null && auth.currentUser?.email == email) {
                            auth.currentUser?.updatePassword(newPasswordHash)?.await()
                        }
                    } catch (e: Exception) {
                        Log.w("SchoolRepository", "Firebase Auth password update warning: ${e.message}")
                    }
                }
                Result.success(Unit)
            } else {
                Result.failure(Exception("User not found."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun changePassword(userId: String, oldPassword: String?, newPasswordHash: String): Result<Unit> {
        return try {
            val cleanId = userId.trim()
            var user = db.userDao().getUser(cleanId)
            if (user == null && firestore != null) {
                try {
                    val uDoc = firestore?.collection("users")?.document(cleanId)?.get()?.await()
                    if (uDoc != null && uDoc.exists()) {
                        user = uDoc.toObject(User::class.java)
                    }
                } catch (e: Exception) {}
            }

            if (user != null) {
                if (!oldPassword.isNullOrBlank()) {
                    val isOldValid = (sha256Hex(oldPassword) == user.passwordHash) ||
                                     (user.passwordHash == oldPassword)
                    if (!isOldValid) {
                        return Result.failure(Exception("Current password is incorrect!"))
                    }
                }
                val nowStr = java.text.SimpleDateFormat("dd-MMM-yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                val updated = user.copy(
                    passwordHash = sha256Hex(newPasswordHash),
                    isFirstLogin = false,
                    passwordStatus = "CUSTOM PASSWORD SET",
                    lastPasswordChange = nowStr,
                    lastPasswordAction = "USER_CHANGED",
                    changedBy = userId
                )
                db.userDao().insertUser(updated)
                
                // Keep Firestore updated
                firestore?.collection("users")?.document(user.userId)?.set(updated)?.await()
                
                // Record Audit Log & Administrative notification
                try {
                    val auditLog = AuditLog(
                        logId = java.util.UUID.randomUUID().toString(),
                        timestamp = System.currentTimeMillis(),
                        userId = updated.userId,
                        userName = updated.name,
                        action = "PASSWORD_CHANGED",
                        oldValue = "Initiated by: SELF",
                        newValue = "Status: CUSTOM PASSWORD SET"
                    )
                    db.auditLogDao().insertAuditLog(auditLog)
                    firestore?.collection("audit_logs")?.document(auditLog.logId)?.set(auditLog)?.await()

                    val adminNotif = AppNotification(
                        notificationId = java.util.UUID.randomUUID().toString(),
                        userId = "theshiwamlaptop@gmail.com",
                        title = "Security Alert: Password Changed",
                        message = "User ${updated.name} (${updated.userId}, ${updated.role}) changed their password.",
                        timestamp = System.currentTimeMillis(),
                        isRead = false,
                        type = "INFO"
                    )
                    db.notificationDao().insertNotification(adminNotif)
                    firestore?.collection("notifications")?.document(adminNotif.notificationId)?.set(adminNotif)?.await()
                } catch (ae: Exception) {
                    Log.w("SchoolRepository", "Audit log write warning: ${ae.message}")
                }

                // Update Firebase Auth credential
                if (firebaseAuth?.currentUser != null && firebaseAuth?.currentUser?.email == user.email) {
                    try {
                        firebaseAuth?.currentUser?.updatePassword(newPasswordHash)?.await()
                    } catch (e: Exception) {
                        Log.e("SchoolRepository", "Firebase Auth password update exception: ${e.message}")
                    }
                }
                
                if (cleanId == _currentUser.value?.userId) {
                    _currentUser.value = updated
                }
                Result.success(Unit)
            } else {
                Result.failure(Exception("User $userId not found in credentials records."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun auditAndMigrateAccounts(): Result<Unit> {
        return try {
            val allStudents = db.studentDao().getAllStudentsList()
            val allTeachers = db.teacherDao().getAllTeachersList()
            
            var studentSeq = 100
            var teacherSeq = 100

            for (student in allStudents) {
                val sId = student.studentId.ifBlank { student.admissionNo }.ifBlank { "S-${++studentSeq}" }
                var u = db.userDao().getUser(sId)
                val dobClean = student.DOB.trim()
                val isDobMissing = dobClean.isBlank()
                val passStatus = if (isDobMissing) "DOB VERIFICATION REQUIRED" else if (u?.isFirstLogin != false) "INITIAL DOB PASSWORD" else "CUSTOM PASSWORD SET"
                if (u == null) {
                    val passHash = if (isDobMissing) "" else sha256Hex(dobClean)
                    u = User(
                        userId = sId,
                        name = student.name,
                        role = "STUDENT",
                        roleCode = "ST-01",
                        email = "${sId.lowercase()}@sdps.com",
                        phone = student.phone,
                        passwordHash = passHash,
                        isFirstLogin = !isDobMissing && passStatus == "INITIAL DOB PASSWORD",
                        className = student.className,
                        dob = dobClean,
                        passwordStatus = passStatus,
                        accountStatus = "ACTIVE"
                    )
                    db.userDao().insertUser(u)
                    firestore?.collection("users")?.document(sId)?.set(u)?.await()
                } else if (u.dob.isBlank() && dobClean.isNotBlank()) {
                    val newHash = if (u.passwordHash.isBlank() || u.passwordHash == sha256Hex("temp123")) sha256Hex(dobClean) else u.passwordHash
                    u = u.copy(
                        dob = dobClean,
                        passwordHash = newHash,
                        passwordStatus = if (u.passwordStatus == "DOB VERIFICATION REQUIRED") "INITIAL DOB PASSWORD" else u.passwordStatus
                    )
                    db.userDao().insertUser(u)
                    firestore?.collection("users")?.document(sId)?.set(u)?.await()
                } else if (u.dob.isBlank() && isDobMissing) {
                    if (u.passwordStatus != "DOB VERIFICATION REQUIRED") {
                        u = u.copy(passwordStatus = "DOB VERIFICATION REQUIRED")
                        db.userDao().insertUser(u)
                        firestore?.collection("users")?.document(sId)?.set(u)?.await()
                    }
                }
            }

            for (teacher in allTeachers) {
                val tId = teacher.teacherId.ifBlank { teacher.email }.ifBlank { "T-${++teacherSeq}" }
                var u = db.userDao().getUser(tId)
                val dobClean = teacher.joiningDate.trim()
                val isDobMissing = dobClean.isBlank()
                val passStatus = if (isDobMissing) "DOB VERIFICATION REQUIRED" else if (u?.isFirstLogin != false) "INITIAL DOB PASSWORD" else "CUSTOM PASSWORD SET"
                if (u == null) {
                    val passHash = if (isDobMissing) "" else sha256Hex(dobClean)
                    u = User(
                        userId = tId,
                        name = teacher.name,
                        role = "TEACHER",
                        roleCode = "TC-12",
                        email = teacher.email.ifBlank { "${tId.lowercase()}@sdps.com" },
                        phone = teacher.phone,
                        passwordHash = passHash,
                        isFirstLogin = !isDobMissing && passStatus == "INITIAL DOB PASSWORD",
                        className = teacher.classesAssigned,
                        dob = dobClean,
                        passwordStatus = passStatus,
                        accountStatus = "ACTIVE"
                    )
                    db.userDao().insertUser(u)
                    firestore?.collection("users")?.document(tId)?.set(u)?.await()
                } else if (u.dob.isBlank() && dobClean.isNotBlank()) {
                    val newHash = if (u.passwordHash.isBlank() || u.passwordHash == sha256Hex("temp123")) sha256Hex(dobClean) else u.passwordHash
                    u = u.copy(
                        dob = dobClean,
                        passwordHash = newHash,
                        passwordStatus = if (u.passwordStatus == "DOB VERIFICATION REQUIRED") "INITIAL DOB PASSWORD" else u.passwordStatus
                    )
                    db.userDao().insertUser(u)
                    firestore?.collection("users")?.document(tId)?.set(u)?.await()
                } else if (u.dob.isBlank() && isDobMissing) {
                    if (u.passwordStatus != "DOB VERIFICATION REQUIRED") {
                        u = u.copy(passwordStatus = "DOB VERIFICATION REQUIRED")
                        db.userDao().insertUser(u)
                        firestore?.collection("users")?.document(tId)?.set(u)?.await()
                    }
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error in auditAndMigrateAccounts: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun adminSetCustomPassword(targetUserId: String, newPassword: String, adminUserId: String): Result<Unit> {
        return try {
            val cleanId = targetUserId.trim()
            var user = db.userDao().getUser(cleanId)
            if (user == null && firestore != null) {
                try {
                    val uDoc = firestore?.collection("users")?.document(cleanId)?.get()?.await()
                    if (uDoc != null && uDoc.exists()) {
                        user = uDoc.toObject(User::class.java)
                    }
                } catch (e: Exception) {}
            }
            // Fallback: no auth (User) record exists yet — this happens for a student/teacher
            // who was just added and has never logged in. Build the initial record from the
            // roster (Student/Teacher) data instead of failing outright.
            if (user == null) {
                val student = db.studentDao().getStudentById(cleanId)
                if (student != null) {
                    user = User(
                        userId = student.studentId, uid = "", name = student.name, role = "STUDENT",
                        roleCode = "ST-01", email = "${student.studentId.lowercase()}@sdps.com", phone = student.phone,
                        passwordHash = sha256Hex(student.DOB.ifBlank { "01-01-2010" }), isFirstLogin = true,
                        className = student.className, dob = student.DOB
                    )
                } else {
                    val teacher = db.teacherDao().getTeacherById(cleanId)
                    if (teacher != null) {
                        user = User(
                            userId = teacher.teacherId, uid = "", name = teacher.name, role = "TEACHER",
                            roleCode = "TC-12", email = teacher.email.ifBlank { "${teacher.teacherId.lowercase()}@sdps.com" },
                            phone = teacher.phone, passwordHash = sha256Hex(teacher.joiningDate.ifBlank { "01-01-1990" }),
                            isFirstLogin = true, className = teacher.classesAssigned, dob = teacher.joiningDate
                        )
                    }
                }
            }
            if (user != null) {
                val nowStr = java.text.SimpleDateFormat("dd-MMM-yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                val updated = user.copy(
                    passwordHash = sha256Hex(newPassword.trim()),
                    isFirstLogin = false,
                    passwordStatus = "CUSTOM PASSWORD SET",
                    lastPasswordChange = nowStr,
                    lastPasswordAction = "ADMIN_SET_CUSTOM",
                    changedBy = adminUserId
                )
                db.userDao().insertUser(updated)
                firestore?.collection("users")?.document(user.userId)?.set(updated)?.await()

                val log = AuditLog(
                    logId = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    userId = adminUserId,
                    userName = _currentUser.value?.name ?: "Management",
                    action = "ADMIN_SET_CUSTOM_PASSWORD",
                    oldValue = "Target: $cleanId",
                    newValue = "Status: CUSTOM PASSWORD SET"
                )
                addAuditLog(log)

                val notif = AppNotification(
                    notificationId = java.util.UUID.randomUUID().toString(),
                    userId = user.userId,
                    title = "Password Updated",
                    message = "Your password has been updated by Principal / Administration ($adminUserId).",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SECURITY"
                )
                db.notificationDao().insertNotification(notif)
                firestore?.collection("notifications")?.document(notif.notificationId)?.set(notif)?.await()

                if (cleanId == _currentUser.value?.userId) {
                    _currentUser.value = updated
                }
                Result.success(Unit)
            } else {
                Result.failure(Exception("Target User ID $targetUserId not found."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun adminResetPasswordToDob(targetUserId: String, adminUserId: String): Result<Unit> {
        return try {
            val cleanId = targetUserId.trim()
            var user = db.userDao().getUser(cleanId)
            if (user == null && firestore != null) {
                try {
                    val uDoc = firestore?.collection("users")?.document(cleanId)?.get()?.await()
                    if (uDoc != null && uDoc.exists()) {
                        user = uDoc.toObject(User::class.java)
                    }
                } catch (e: Exception) {}
            }
            if (user == null) {
                val student = db.studentDao().getStudentById(cleanId)
                if (student != null) {
                    user = User(
                        userId = student.studentId, uid = "", name = student.name, role = "STUDENT",
                        roleCode = "ST-01", email = "${student.studentId.lowercase()}@sdps.com", phone = student.phone,
                        passwordHash = sha256Hex(student.DOB.ifBlank { "01-01-2010" }), isFirstLogin = true,
                        className = student.className, dob = student.DOB
                    )
                } else {
                    val teacher = db.teacherDao().getTeacherById(cleanId)
                    if (teacher != null) {
                        user = User(
                            userId = teacher.teacherId, uid = "", name = teacher.name, role = "TEACHER",
                            roleCode = "TC-12", email = teacher.email.ifBlank { "${teacher.teacherId.lowercase()}@sdps.com" },
                            phone = teacher.phone, passwordHash = sha256Hex(teacher.joiningDate.ifBlank { "01-01-1990" }),
                            isFirstLogin = true, className = teacher.classesAssigned, dob = teacher.joiningDate
                        )
                    }
                }
            }
            if (user != null) {
                val targetDob = user.dob.ifBlank {
                    if (user.role == "STUDENT") db.studentDao().getStudentById(cleanId)?.DOB ?: ""
                    else if (user.role == "TEACHER" || user.role == "CLASS_TEACHER") db.teacherDao().getTeacherById(cleanId)?.joiningDate ?: ""
                    else ""
                }.trim()

                if (targetDob.isBlank()) {
                    return Result.failure(Exception("Target account has no registered Date of Birth. Please verify/update DOB first."))
                }

                val nowStr = java.text.SimpleDateFormat("dd-MMM-yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                val updated = user.copy(
                    passwordHash = sha256Hex(targetDob),
                    isFirstLogin = true,
                    dob = targetDob,
                    passwordStatus = "INITIAL DOB PASSWORD",
                    lastPasswordChange = nowStr,
                    lastPasswordAction = "ADMIN_RESET_TO_DOB",
                    changedBy = adminUserId
                )
                db.userDao().insertUser(updated)
                firestore?.collection("users")?.document(user.userId)?.set(updated)?.await()

                val log = AuditLog(
                    logId = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    userId = adminUserId,
                    userName = _currentUser.value?.name ?: "Management",
                    action = "ADMIN_RESET_PASSWORD_TO_DOB",
                    oldValue = "Target: $cleanId",
                    newValue = "Status: INITIAL DOB PASSWORD"
                )
                addAuditLog(log)

                val notif = AppNotification(
                    notificationId = java.util.UUID.randomUUID().toString(),
                    userId = user.userId,
                    title = "Password Reset Notice",
                    message = "Your password has been reset to your registered Date of Birth by Principal / Administration.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SECURITY"
                )
                db.notificationDao().insertNotification(notif)
                firestore?.collection("notifications")?.document(notif.notificationId)?.set(notif)?.await()

                if (cleanId == _currentUser.value?.userId) {
                    _currentUser.value = updated
                }
                Result.success(Unit)
            } else {
                Result.failure(Exception("Target User ID $targetUserId not found."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun adminGenerateTemporaryPassword(targetUserId: String, adminUserId: String): Result<String> {
        return try {
            val cleanId = targetUserId.trim()
            var user = db.userDao().getUser(cleanId)
            if (user == null && firestore != null) {
                try {
                    val uDoc = firestore?.collection("users")?.document(cleanId)?.get()?.await()
                    if (uDoc != null && uDoc.exists()) {
                        user = uDoc.toObject(User::class.java)
                    }
                } catch (e: Exception) {}
            }
            if (user != null) {
                val adminRole = _currentUser.value?.role?.uppercase()?.trim() ?: "PRINCIPAL"
                val actionType = when (adminRole) {
                    "HEAD_ADMIN" -> "PASSWORD_RESET_BY_HEAD_ADMIN"
                    "PRINCIPAL" -> "PASSWORD_RESET_BY_PRINCIPAL"
                    else -> "PASSWORD_RESET_BY_ADMIN"
                }

                val randDigits = (1000..9999).random()
                val tempPassword = "SDPS-$randDigits"
                val nowStr = java.text.SimpleDateFormat("dd-MMM-yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())

                val updated = user.copy(
                    passwordHash = sha256Hex(tempPassword),
                    isFirstLogin = true,
                    passwordStatus = "RESET REQUIRED",
                    lastPasswordChange = nowStr,
                    lastPasswordAction = "ADMIN_TEMP_RESET",
                    changedBy = adminUserId
                )
                db.userDao().insertUser(updated)
                firestore?.collection("users")?.document(user.userId)?.set(updated)?.await()

                val log = AuditLog(
                    logId = java.util.UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    userId = adminUserId,
                    userName = _currentUser.value?.name ?: "Principal",
                    action = actionType,
                    oldValue = "Target: ${user.userId} (${user.name})",
                    newValue = "Status: RESET REQUIRED (Temporary Password Issued)"
                )
                addAuditLog(log)

                val notif = AppNotification(
                    notificationId = java.util.UUID.randomUUID().toString(),
                    userId = user.userId,
                    title = "Password Reset Notice",
                    message = "${_currentUser.value?.name ?: "Principal"} reset the password for ${user.name} ($cleanId).",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SECURITY"
                )
                db.notificationDao().insertNotification(notif)
                firestore?.collection("notifications")?.document(notif.notificationId)?.set(notif)?.await()

                if (cleanId == _currentUser.value?.userId) {
                    _currentUser.value = updated
                }
                Result.success(tempPassword)
            } else {
                Result.failure(Exception("Target User ID $targetUserId not found."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun getAllUsers(): Flow<List<User>> {
        return db.userDao().getAllUsersFlow()
    }

    override suspend fun addUser(user: User): Result<Unit> {
        return try {
            db.userDao().insertUser(user)
            firestore?.collection("users")?.document(user.userId)?.set(user)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteUserAccount(userId: String): Result<Unit> {
        return try {
            val userToDelete = db.userDao().getUser(userId)
            if (userToDelete != null) {
                db.userDao().deleteUser(userToDelete)
            } else {
                db.userDao().deleteUserById(userId)
            }
            firestore?.collection("users")?.document(userId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "deleteUserAccount error", e)
            Result.failure(e)
        }
    }

    override suspend fun updateUserDob(userId: String, newDob: String, requesterId: String): Result<Unit> {
        return try {
            val cleanId = userId.trim()
            val cleanDob = newDob.trim()
            if (cleanId.isEmpty() || cleanDob.isEmpty()) {
                return Result.failure(Exception("User ID and Date of Birth cannot be empty."))
            }

            // 1. Update Student record if exists
            val student = db.studentDao().getStudentById(cleanId)
            if (student != null) {
                val updatedStudent = student.copy(DOB = cleanDob)
                db.studentDao().insertStudent(updatedStudent)
                firestore?.collection("students")?.document(cleanId)?.set(updatedStudent)?.await()
            }

            // 2. Update User record
            val user = db.userDao().getUser(cleanId)
            val nowStr = java.text.SimpleDateFormat("dd-MMM-yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            if (user != null) {
                val shouldUpdatePassword = user.passwordStatus == "DOB VERIFICATION REQUIRED" || 
                        user.passwordHash.isBlank() || 
                        user.isFirstLogin
                val updatedUser = user.copy(
                    dob = cleanDob,
                    passwordHash = if (shouldUpdatePassword) sha256Hex(cleanDob) else user.passwordHash,
                    passwordStatus = if (user.passwordStatus == "DOB VERIFICATION REQUIRED") "INITIAL DOB PASSWORD" else user.passwordStatus,
                    isFirstLogin = if (shouldUpdatePassword) true else user.isFirstLogin,
                    lastPasswordChange = if (shouldUpdatePassword) nowStr else user.lastPasswordChange,
                    lastPasswordAction = if (shouldUpdatePassword) "DOB_VERIFIED" else user.lastPasswordAction,
                    changedBy = requesterId
                )
                db.userDao().insertUser(updatedUser)
                firestore?.collection("users")?.document(cleanId)?.set(updatedUser)?.await()
                if (_currentUser.value?.userId == cleanId) {
                    _currentUser.value = updatedUser
                }
            }

            // 3. Update Teacher record if exists
            val teacher = db.teacherDao().getTeacherById(cleanId)
            if (teacher != null) {
                val updatedTeacher = teacher.copy(joiningDate = cleanDob)
                db.teacherDao().insertTeacher(updatedTeacher)
                firestore?.collection("teachers")?.document(cleanId)?.set(updatedTeacher)?.await()
            }

            // 4. Log Audit Trail
            val log = AuditLog(
                logId = UUID.randomUUID().toString(),
                timestamp = System.currentTimeMillis(),
                userId = requesterId,
                userName = _currentUser.value?.name ?: "Principal",
                action = "UPDATE_USER_DOB",
                oldValue = "Target: $cleanId",
                newValue = "New DOB: $cleanDob"
            )
            addAuditLog(log)

            // 5. Send Notification to target user
            val notif = AppNotification(
                notificationId = UUID.randomUUID().toString(),
                userId = cleanId,
                title = "Date of Birth Verified",
                message = "Your Date of Birth has been verified and registered ($cleanDob). Your initial password is set to your Date of Birth.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "SECURITY"
            )
            db.notificationDao().insertNotification(notif)
            firestore?.collection("notifications")?.document(notif.notificationId)?.set(notif)?.await()

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error updating DOB: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun updateUserProfile(user: User): Result<Unit> {
        return try {
            db.userDao().insertUser(user)
            firestore?.collection("users")?.document(user.userId)?.set(user)?.await()
            _currentUser.value = user
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Monthly fee ledgers implementation
    override fun getAllFeeLedgerEntries(): Flow<List<FeeLedgerEntry>> {
        return db.feeLedgerDao().getAllLedgerEntriesFlow()
    }

    override fun getFeeLedgerForStudentFlow(studentId: String): Flow<List<FeeLedgerEntry>> {
        return db.feeLedgerDao().getLedgerForStudentFlow(studentId)
    }

    override suspend fun getFeeLedgerForStudent(studentId: String): List<FeeLedgerEntry> {
        return db.feeLedgerDao().getLedgerForStudent(studentId)
    }

    override suspend fun saveFeeLedgerEntry(entry: FeeLedgerEntry): Result<Unit> {
        return try {
            db.feeLedgerDao().insertLedgerEntry(entry)
            firestore?.collection("fee_ledger_entries")?.document(entry.entryId)?.set(entry)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun saveFeeLedgerEntries(entries: List<FeeLedgerEntry>): Result<Unit> {
        return try {
            db.feeLedgerDao().insertLedgerEntries(entries)
            entries.forEach { entry ->
                firestore?.collection("fee_ledger_entries")?.document(entry.entryId)?.set(entry)?.await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun getAllFeeRatesFlow(): Flow<List<FeeRateHistory>> {
        return db.feeRateHistoryDao().getAllRatesFlow()
    }

    override suspend fun setFeeRate(className: String, feeType: String, amount: Double, effectiveFromMonth: String, setByUserId: String): Result<Unit> {
        return try {
            val rate = FeeRateHistory(
                rateId = "${className}_${feeType}_${effectiveFromMonth}_${System.currentTimeMillis()}",
                className = className,
                feeType = feeType,
                amount = amount,
                effectiveFromMonth = effectiveFromMonth,
                setByUserId = setByUserId,
                setAt = System.currentTimeMillis()
            )
            db.feeRateHistoryDao().insertRate(rate)
            firestore?.collection("fee_rate_history")?.document(rate.rateId)?.set(rate)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getEffectiveFeeRate(className: String, feeType: String, month: String): Double {
        return findEffectiveFeeRate(db.feeRateHistoryDao().getAllRates(), className, feeType, month)
    }

    override fun getAllFeeEventChargesFlow(): Flow<List<FeeEventCharge>> {
        return db.feeEventChargeDao().getAllEventChargesFlow()
    }

    override suspend fun addFeeEventCharge(className: String, month: String, label: String, amount: Double, createdByUserId: String): Result<Unit> {
        return try {
            val charge = FeeEventCharge(
                eventChargeId = "${className}_${month}_${System.currentTimeMillis()}",
                className = className,
                month = month,
                label = label,
                amount = amount,
                createdByUserId = createdByUserId,
                createdAt = System.currentTimeMillis()
            )
            db.feeEventChargeDao().insertEventCharge(charge)
            firestore?.collection("fee_event_charges")?.document(charge.eventChargeId)?.set(charge)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getFeeEventChargesForClassMonth(className: String, month: String): List<FeeEventCharge> {
        return db.feeEventChargeDao().getEventChargesForClassMonth(className, month)
    }

    // STUDENTS IMPLEMENTATION
    override fun getAllStudents(): Flow<List<Student>> {
        return db.studentDao().getAllStudentsFlow()
    }

    override suspend fun updateStudent(student: Student): Result<Unit> {
        return try {
            db.studentDao().insertStudent(student)
            val fs = firestore
            if (fs != null) {
                try {
                    fs.collection("students").document(student.studentId).set(student).await()
                    val user = db.userDao().getUser(student.studentId)
                    if (user != null) {
                        val updatedUser = user.copy(
                            name = student.name,
                            className = student.className,
                            phone = student.phone
                        )
                        db.userDao().insertUser(updatedUser)
                        fs.collection("users").document(student.studentId).set(updatedUser).await()
                    }
                } catch (fsEx: Exception) {
                    android.util.Log.e("SchoolRepository", "Firestore save failed in updateStudent (offline mode fallback active)", fsEx)
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            android.util.Log.e("SchoolRepository", "Error updating student locally", e)
            Result.failure(e)
        }
    }

    override suspend fun checkStudentExists(studentId: String): Boolean {
        return try {
            val localExists = db.studentDao().getStudentById(studentId) != null
            if (localExists) return true
            val fs = firestore
            if (fs != null) {
                val doc = fs.collection("students").document(studentId).get().await()
                return doc.exists()
            }
            return false
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun addStudent(student: Student): Result<Unit> {
        return try {
            db.studentDao().insertStudent(student)
            
            // Always insert User entity in Room locally first
            val dobClean = student.DOB.trim()
            val isDobMissing = dobClean.isBlank()
            val passHash = if (isDobMissing) "" else sha256Hex(dobClean)
            val passStatus = if (isDobMissing) "DOB VERIFICATION REQUIRED" else "INITIAL DOB PASSWORD"
            var user = db.userDao().getUser(student.studentId)
            if (user == null) {
                user = User(
                    userId = student.studentId,
                    name = student.name,
                    role = "STUDENT",
                    roleCode = "ST-01",
                    email = "${student.studentId}@sdps.com".lowercase(),
                    passwordHash = passHash,
                    isFirstLogin = !isDobMissing,
                    className = student.className,
                    phone = student.phone,
                    dob = dobClean,
                    passwordStatus = passStatus,
                    accountStatus = "ACTIVE"
                )
            } else {
                user = user.copy(
                    name = student.name,
                    className = student.className,
                    phone = student.phone,
                    dob = dobClean,
                    passwordHash = if (user.passwordHash.isBlank() || isDobMissing) passHash else user.passwordHash,
                    passwordStatus = if (isDobMissing) "DOB VERIFICATION REQUIRED" else user.passwordStatus
                )
            }
            db.userDao().insertUser(user)

            val fs = firestore
            if (fs != null) {
                try {
                    fs.collection("students").document(student.studentId).set(student).await()
                    fs.collection("users").document(student.studentId).set(user).await()
                } catch (fsEx: Exception) {
                    android.util.Log.e("SchoolRepository", "Firestore save warning in addStudent", fsEx)
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            android.util.Log.e("SchoolRepository", "Error adding student locally", e)
            Result.failure(e)
        }
    }

    override suspend fun deleteStudent(studentId: String): Result<Unit> {
        return try {
            val student = db.studentDao().getStudentById(studentId)
            if (student != null) {
                val deletedStudent = student.copy(isDeleted = true, status = "DELETED")
                db.studentDao().insertStudent(deletedStudent)
                firestore?.collection("students")?.document(studentId)?.set(deletedStudent)?.await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // TEACHERS IMPLEMENTATION
    override fun getAllTeachers(): Flow<List<Teacher>> {
        return db.teacherDao().getAllTeachersFlow()
    }

    override suspend fun addTeacher(teacher: Teacher): Result<Unit> {
        return try {
            db.teacherDao().insertTeacher(teacher)
            
            // Always insert User entity in Room locally first
            val dobClean = teacher.joiningDate.trim()
            val isDobMissing = dobClean.isBlank()
            val passHash = if (isDobMissing) "" else sha256Hex(dobClean)
            val passStatus = if (isDobMissing) "DOB VERIFICATION REQUIRED" else "INITIAL DOB PASSWORD"
            var user = db.userDao().getUser(teacher.teacherId)
            if (user == null) {
                user = User(
                    userId = teacher.teacherId,
                    name = teacher.name,
                    role = "TEACHER",
                    roleCode = "TC-12",
                    email = teacher.email.ifBlank { "${teacher.teacherId}@sdps.com".lowercase() },
                    passwordHash = passHash,
                    isFirstLogin = !isDobMissing,
                    className = teacher.classesAssigned,
                    phone = teacher.phone,
                    dob = dobClean,
                    passwordStatus = passStatus,
                    accountStatus = "ACTIVE"
                )
            } else {
                user = user.copy(
                    name = teacher.name,
                    className = teacher.classesAssigned,
                    phone = teacher.phone,
                    dob = dobClean,
                    passwordHash = if (user.passwordHash.isBlank() || isDobMissing) passHash else user.passwordHash,
                    passwordStatus = if (isDobMissing) "DOB VERIFICATION REQUIRED" else user.passwordStatus
                )
            }
            db.userDao().insertUser(user)

            val fs = firestore
            if (fs != null) {
                fs.collection("teachers").document(teacher.teacherId).set(teacher).await()
                fs.collection("users").document(teacher.teacherId).set(user).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            android.util.Log.e("SchoolRepository", "Error adding teacher", e)
            Result.failure(e)
        }
    }

    override suspend fun deleteTeacher(teacherId: String): Result<Unit> {
        return try {
            val teacher = db.teacherDao().getTeacherById(teacherId)
            if (teacher != null) {
                val deletedTeacher = teacher.copy(isDeleted = true, status = "DELETED")
                db.teacherDao().insertTeacher(deletedTeacher)
                firestore?.collection("teachers")?.document(teacherId)?.set(deletedTeacher)?.await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // PAYROLL IMPLEMENTATION
    override fun getAllPayrolls(): Flow<List<Payroll>> {
        return db.payrollDao().getAllPayrollsFlow()
    }

    override fun getPayrollsForTeacher(teacherId: String): Flow<List<Payroll>> {
        return db.payrollDao().getPayrollsForTeacherFlow(teacherId)
    }

    override suspend fun addOrUpdatePayroll(payroll: Payroll): Result<Unit> {
        return try {
            db.payrollDao().insertPayroll(payroll)
            firestore?.collection("payrolls")?.document(payroll.payrollId)?.set(payroll)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun savePayrolls(payrolls: List<Payroll>): Result<Unit> {
        return try {
            db.payrollDao().insertPayrolls(payrolls)
            firestore?.run {
                val batch = batch()
                payrolls.forEach { p ->
                    val docRef = collection("payrolls").document(p.payrollId)
                    batch.set(docRef, p)
                }
                batch.commit()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deletePayrollsByTeacher(teacherId: String): Result<Unit> {
        return try {
            db.payrollDao().deletePayrollsByTeacher(teacherId)
            val snapshot = firestore?.collection("payrolls")?.whereEqualTo("teacherId", teacherId)?.get()?.await()
            snapshot?.documents?.forEach { doc -> doc.reference.delete() }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ATTENDANCE IMPLEMENTATION
    override fun getAllAttendance(): Flow<List<Attendance>> {
        return db.attendanceDao().getAllAttendanceFlow()
    }

    override fun getAttendanceForClassAndDate(className: String, date: String): Flow<List<Attendance>> {
        return db.attendanceDao().getAttendanceForClassAndDateFlow(className, date)
    }

    override suspend fun markAttendance(attendanceList: List<Attendance>): Result<Unit> {
        return try {
            db.attendanceDao().insertAttendance(attendanceList)
            val fs = firestore
            if (fs != null) {
                val batch = fs.batch()
                attendanceList.forEach { att ->
                    val docRef = fs.collection("attendance").document(att.attendanceId)
                    batch.set(docRef, att)
                }
                batch?.commit()?.await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // FEES IMPLEMENTATION
    override fun getAllFees(): Flow<List<Fee>> {
        return db.feeDao().getAllFeesFlow()
    }

    override suspend fun addFee(fee: Fee): Result<Unit> {
        return try {
            db.feeDao().insertFee(fee)
            firestore?.collection("fees")?.document(fee.feeId)?.set(fee)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteFee(feeId: String): Result<Unit> {
        return try {
            db.feeDao().deleteFeeById(feeId)
            firestore?.collection("fees")?.document(feeId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // HOMEWORK IMPLEMENTATION
    override fun getAllHomework(): Flow<List<Homework>> {
        return db.homeworkDao().getAllHomeworkFlow()
    }

    override suspend fun addHomework(homework: Homework): Result<Unit> {
        return try {
            db.homeworkDao().insertHomework(homework)
            firestore?.collection("homework")?.document(homework.homeworkId)?.set(homework)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Delete custom homework
    override suspend fun deleteHomework(homeworkId: String): Result<Unit> {
        return try {
            val existing = db.homeworkDao().getHomeworkById(homeworkId)
            if (existing != null && existing.fileUrl.isNotBlank()) {
                deleteStorageFile(existing.fileUrl)
            }
            db.homeworkDao().deleteHomeworkById(homeworkId)
            firestore?.collection("homework")?.document(homeworkId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun uploadFileToStorage(uri: android.net.Uri, storagePath: String, mimeType: String): Result<String> {
        return try {
            val storage = firebaseStorage ?: return Result.failure(Exception("Firebase Storage is not initialized."))
            val storageRef = storage.reference.child(storagePath)
            
            val contentResolver = context.contentResolver
            val inputStream = contentResolver.openInputStream(uri) 
                ?: return Result.failure(Exception("Unable to open file stream."))

            // Check file size (max 20MB)
            val fileSize = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            if (fileSize > 20 * 1024 * 1024) {
                inputStream.close()
                return Result.failure(Exception("File size exceeds 20MB limit."))
            }

            val resolvedMime = if (mimeType.isNotBlank()) mimeType else (contentResolver.getType(uri) ?: "application/octet-stream")
            val metadata = com.google.firebase.storage.StorageMetadata.Builder()
                .setContentType(resolvedMime)
                .build()

            val uploadTask = storageRef.putStream(inputStream, metadata)
            uploadTask.await()
            try { inputStream.close() } catch (_: Exception) {}

            val downloadUrl = storageRef.downloadUrl.await().toString()
            Log.i("SchoolRepository", "Successfully uploaded file to Firebase Storage: $downloadUrl")
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Upload failed for path $storagePath: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun uploadHomeworkAttachment(uri: android.net.Uri, className: String, homeworkId: String, fileName: String): Result<String> {
        val cleanClass = className.replace("/", "_").replace(" ", "_").trim()
        val cleanHwId = homeworkId.replace("/", "_").trim()
        val cleanName = fileName.replace("/", "_").trim().ifBlank { "homework_doc_${System.currentTimeMillis()}.pdf" }
        val path = "homework/$cleanClass/$cleanHwId/$cleanName"
        return uploadFileToStorage(uri, path)
    }

    override suspend fun uploadChatAttachment(uri: android.net.Uri, conversationId: String, messageId: String, fileName: String): Result<String> {
        val cleanConv = conversationId.replace("/", "_").trim()
        val cleanMsg = messageId.replace("/", "_").trim()
        val cleanName = fileName.replace("/", "_").trim().ifBlank { "chat_file_${System.currentTimeMillis()}" }
        val path = "chat/$cleanConv/$cleanMsg/$cleanName"
        return uploadFileToStorage(uri, path)
    }

    override suspend fun deleteStorageFile(fileUrl: String): Result<Unit> {
        return try {
            if (fileUrl.isBlank() || !fileUrl.contains("firebasestorage.googleapis.com")) {
                return Result.success(Unit)
            }
            val storage = firebaseStorage ?: return Result.success(Unit)
            val ref = storage.getReferenceFromUrl(fileUrl)
            ref.delete().await()
            Log.i("SchoolRepository", "Deleted storage file: $fileUrl")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("SchoolRepository", "Storage file deletion skipped or failed: ${e.message}")
            Result.success(Unit) // Non-fatal to caller
        }
    }

    // NOTICES IMPLEMENTATION
    override fun getAllNotices(): Flow<List<Notice>> {
        return db.noticeDao().getAllNoticesFlow()
    }

    // Notices insertion
    override suspend fun addNotice(notice: Notice): Result<Unit> {
        return try {
            db.noticeDao().insertNotice(notice)
            firestore?.collection("notices")?.document(notice.noticeId)?.set(notice)?.await()
            // FirebaseMessaging.getInstance().subscribeToTopic("notices") // Removed to prevent TOO_MANY_REGISTRATIONS in emulator
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // notices delete
    override suspend fun deleteNotice(noticeId: String): Result<Unit> {
        return try {
            db.noticeDao().deleteNoticeById(noticeId)
            firestore?.collection("notices")?.document(noticeId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // TIMETABLE IMPLEMENTATION
    override fun getAllTimetables(): Flow<List<Timetable>> {
        return db.timetableDao().getAllTimetablesFlow()
    }

    override suspend fun saveTimetable(timetable: Timetable, allowOverride: Boolean, overrideReason: String): Result<Unit> {
        return try {
            val allTimetables = db.timetableDao().getAllTimetablesList()
            val allTeachers = db.teacherDao().getAllTeachersList()
            val conflictResult = com.example.data.util.TimetableConflictManager.validateTimetable(
                targetTimetable = timetable,
                allTimetables = allTimetables,
                knownTeachers = allTeachers
            )

            if (conflictResult is com.example.data.util.TimetableConflictResult.Conflict) {
                val curr = _currentUser.value
                val isManagement = curr?.role?.uppercase()?.trim() in listOf("PRINCIPAL", "HEAD_ADMIN")
                if (!allowOverride || !isManagement) {
                    return Result.failure(Exception(conflictResult.message))
                } else {
                    val log = AuditLog(
                        logId = "LOG_${System.currentTimeMillis()}_${(100..999).random()}",
                        timestamp = System.currentTimeMillis(),
                        userId = curr?.userId ?: "PRINCIPAL",
                        userName = curr?.name ?: "Principal",
                        action = "Timetable Conflict Override: ${timetable.className}",
                        oldValue = conflictResult.message,
                        newValue = "Override approved for ${timetable.className}${if (overrideReason.isNotBlank()) " (Reason: $overrideReason)" else ""}"
                    )
                    addAuditLog(log)
                }
            }

            db.timetableDao().insertTimetable(timetable)
            firestore?.collection("timetable")?.document(timetable.timetableId)?.set(timetable)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // REAL-TIME CHAT IMPLEMENTATION
    override fun getAllChats(): Flow<List<ChatMessage>> {
        return db.chatDao().getAllChatsFlow()
    }

    override suspend fun sendMessage(message: ChatMessage): Result<Unit> {
        return try {
            db.chatDao().insertMessage(message)
            firestore?.collection("chats")?.document(message.messageId)?.set(message)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun markMessagesAsRead(senderId: String, receiverId: String): Result<Unit> {
        return try {
            db.chatDao().markMessagesAsRead(senderId, receiverId)
            // If firestore is connected, update unread messages in firestore
            firestore?.let { fs ->
                try {
                    val unreadDocs = fs.collection("chats")
                        .whereEqualTo("senderId", senderId)
                        .whereEqualTo("receiverId", receiverId)
                        .whereEqualTo("isRead", false)
                        .get()
                        .await()
                    
                    if (!unreadDocs.isEmpty) {
                        val batch = fs.batch()
                        unreadDocs.documents.forEach { doc ->
                            batch.update(doc.reference, mapOf("isRead" to true, "status" to "read"))
                        }
                        batch.commit().await()
                    }
                } catch (fsEx: Exception) {
                    Log.w("SchoolRepository", "Firestore mark-as-read sync skipped: ${fsEx.message}")
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteChatMessage(messageId: String): Result<Unit> {
        return try {
            val existing = db.chatDao().getMessageById(messageId)
            if (existing != null && existing.attachmentType.isNotBlank() && existing.message.contains("firebasestorage.googleapis.com")) {
                deleteStorageFile(existing.message)
            }
            db.chatDao().deleteMessage(messageId)
            firestore?.collection("chats")?.document(messageId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // AUDIT LOGGING OPERATIONS
    override fun getAllAuditLogs(): Flow<List<AuditLog>> {
        return db.auditLogDao().getAllAuditLogsFlow()
    }

    override suspend fun addAuditLog(log: AuditLog): Result<Unit> {
        return try {
            db.auditLogDao().insertAuditLog(log)
            firestore?.collection("audit_logs")?.document(log.logId)?.set(log)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // NOTIFICATIONS OPERATIONS
    override fun getAllNotifications(): Flow<List<AppNotification>> {
        return db.notificationDao().getAllNotificationsFlow()
    }

    override suspend fun addNotification(notification: AppNotification): Result<Unit> {
        return try {
            db.notificationDao().insertNotification(notification)
            firestore?.collection("notifications")?.document(notification.notificationId)?.set(notification)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun markNotificationAsRead(id: String): Result<Unit> {
        return try {
            db.notificationDao().markAsRead(id)
            firestore?.collection("notifications")?.document(id)?.update("isRead", true)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteNotification(id: String): Result<Unit> {
        return try {
            db.notificationDao().deleteNotificationById(id)
            firestore?.collection("notifications")?.document(id)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // TEACHER ATTENDANCE & DUTY OPERATIONS
    override fun getAllTeacherAttendance(): Flow<List<TeacherAttendance>> {
        return db.teacherAttendanceDao().getAllTeacherAttendanceFlow()
    }

    override fun getAttendanceForTeacher(teacherId: String): Flow<List<TeacherAttendance>> {
        return db.teacherAttendanceDao().getAttendanceForTeacherFlow(teacherId)
    }

    override suspend fun addTeacherAttendance(attendance: TeacherAttendance): Result<Unit> {
        return try {
            db.teacherAttendanceDao().insertTeacherAttendance(attendance)
            firestore?.collection("teacher_attendance")?.document(attendance.attendanceId)?.set(attendance)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // SEED INITIAL HIGH-FIDELITY SAMPLE DATA AND INTEGRATE TO FIRESTORE
    private suspend fun seedInitialDataIfNeeded() {
        try {
        val studentList = listOf(
            Student(studentId = "S101", name = "Amir Khan", className = "Class 10", rollNo = "01", DOB = "2010-04-12", fatherName = "Sajid Khan", motherName = "Rubina Khan", phone = "9988776655", address = "Pratap Nagar, Delhi", admissionNo = "ADM2024-001", photoUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&auto=format&fit=crop"),
            Student(studentId = "S102", name = "Priya Sharma", className = "Class 9", rollNo = "15", DOB = "2011-09-22", fatherName = "Rakesh Sharma", motherName = "Komal Sharma", phone = "9876543210", address = "Sector 15, Rohini, Delhi", admissionNo = "ADM2024-112", photoUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop"),
            Student(studentId = "S103", name = "Rohit Verma", className = "Class 10", rollNo = "24", DOB = "2010-12-05", fatherName = "Dinesh Verma", motherName = "Sangeeta Verma", phone = "9122334455", address = "Shakti Nagar, Delhi", admissionNo = "ADM2024-099", photoUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop"),
            Student(studentId = "S104", name = "Kavya Mishra", className = "Nursery", rollNo = "02", DOB = "2022-03-10", fatherName = "Aalok Mishra", motherName = "Preeti Mishra", phone = "9977885566", address = "Karol Bagh, Delhi", admissionNo = "ADM2025-004", photoUrl = "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=200&auto=format&fit=crop"),
            Student(studentId = "S105", name = "Arjun Goel", className = "Class 1", rollNo = "10", DOB = "2020-07-15", fatherName = "Vipul Goel", motherName = "Ritu Goel", phone = "9955442233", address = "Dwarka, Delhi", admissionNo = "ADM2024-045", photoUrl = "https://images.unsplash.com/photo-1481145184284-ad400f0aa6e0?w=200&auto=format&fit=crop"),
            Student(studentId = "S106", name = "Sneha Kumari", className = "Class 5", rollNo = "18", DOB = "2016-11-30", fatherName = "Manoj Kumar", motherName = "Chanda Devi", phone = "9966338811", address = "Preet Vihar, Delhi", admissionNo = "ADM2022-019", photoUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop")
        )

        val teacherList = listOf(
            Teacher(teacherId = "T201", name = "Mr. Ravi Sharma", subject = "Mathematics & Physics", classesAssigned = "Class 10, Class 9", phone = "9871112223", email = "ravi@sdpublic.edu"),
            Teacher(teacherId = "T202", name = "Mrs. Anjali Gupta", subject = "English Literature", classesAssigned = "Class 9, Class 10", phone = "9871112224", email = "anjali@sdpublic.edu"),
            Teacher(teacherId = "T203", name = "Mr. Vikas Kumar", subject = "Computer Science", classesAssigned = "Class 10", phone = "9871112225", email = "vikas@sdpublic.edu")
        )

        val feeList = listOf(
            Fee(
                feeId = "F301",
                studentId = "S101",
                totalFee = 20800.0,
                paidAmount = 15000.0,
                dueAmount = 5800.0,
                paymentDate = "2026-05-10",
                paymentMode = "Online",
                status = "Partial",
                tuitionFee = 12000.0,
                bookFee = 2500.0,
                dressFee = 1800.0,
                examFee = 1500.0,
                transportFee = 2000.0,
                otherFee = 1000.0,
                paymentHistory = "2026-04-10: Paid ₹10,000 via Online (Tuition Quarter 1); 2026-05-10: Paid ₹5,000 via Online (Book & Uniform Package)"
            ),
            Fee(
                feeId = "F302",
                studentId = "S102",
                totalFee = 17300.0,
                paidAmount = 17300.0,
                dueAmount = 0.0,
                paymentDate = "2026-05-11",
                paymentMode = "Cash",
                status = "Paid",
                tuitionFee = 10000.0,
                bookFee = 2500.0,
                dressFee = 1800.0,
                examFee = 1000.0,
                transportFee = 1500.0,
                otherFee = 500.0,
                paymentHistory = "2026-05-11: Full Annual billing ₹17,300 cleared completely in simple Cash."
            ),
            Fee(
                feeId = "F303",
                studentId = "S103",
                totalFee = 20800.0,
                paidAmount = 0.0,
                dueAmount = 20800.0,
                paymentDate = "N/A",
                paymentMode = "N/A",
                status = "Due",
                tuitionFee = 12000.0,
                bookFee = 2500.0,
                dressFee = 1800.0,
                examFee = 1500.0,
                transportFee = 2000.0,
                otherFee = 1000.0,
                paymentHistory = "No transaction history recorded yet."
            ),
            Fee(
                feeId = "F304",
                studentId = "S104",
                totalFee = 15000.0,
                paidAmount = 8000.0,
                dueAmount = 7000.0,
                paymentDate = "2026-05-14",
                paymentMode = "Cash",
                status = "Partial",
                tuitionFee = 8000.0,
                bookFee = 2000.0,
                dressFee = 1500.0,
                examFee = 1000.0,
                transportFee = 1500.0,
                otherFee = 1000.0,
                paymentHistory = "2026-05-14: Paid ₹8,000 Cash at Office for Nursery books & entry."
            )
        )

        val homeworkList = listOf(
            Homework("H401", "Class 10", "Mathematics", "Solve Exercises 5.2 and 5.3 (Quadratic Equations). Submit in notebook.", "2026-05-25", ""),
            Homework("H402", "Class 9", "English", "Write an essay on 'Role of Technology in Modern Education' (250 words).", "2026-05-24", ""),
            Homework("H403", "Class 10", "Computer Science", "Code a basic Calculator in Kotlin or Java. Share repository URL.", "2026-05-28", "")
        )

        val noticeList = listOf(
            Notice("N501", "Summer Vacation Announcement", "S. D Public School will remain closed for summer break from 1st June to 30th June. Homework is available in the Homework section.", "2026-05-20"),
            Notice("N502", "Fee Submission Reminder", "Please clear any outstanding academic fees for Quarter 1 by 25th May to avoid late custom charges.", "2026-05-18"),
            Notice("N503", "Inter-School Science Fair 2026", "Students are invited to register for the upcoming Science Fair on 28th May. Contact Vikas Kumar (Computer Science) for ideas.", "2026-05-15")
        )

        val calendarEventList = listOf(
            CalendarEvent(id = "CAL_1", date = "2026-05-28", title = "Inter-School Science Fair 2026", description = "Annual science exhibition for senior classes.", type = "School Event", time = "09:00 AM", targetClass = "All", createdBy = "Principal"),
            CalendarEvent(id = "CAL_2", date = "2026-06-01", title = "Summer Vacation Starts", description = "School closed for summer break.", type = "Holiday", time = "All Day", targetClass = "All", createdBy = "Management"),
            CalendarEvent(id = "CAL_3", date = "2026-07-01", title = "School Reopens", description = "Classes resume after summer break.", type = "School Event", time = "08:00 AM", targetClass = "All", createdBy = "Management"),
            CalendarEvent(id = "CAL_4", date = "2026-05-25", title = "Fee Submission Deadline", description = "Last date for Q1 fee submission.", type = "Fee Deadline", time = "05:00 PM", targetClass = "All", createdBy = "Finance Office"),
            CalendarEvent(id = "CAL_5", date = "2026-08-15", title = "Independence Day Celebration", description = "Flag hoisting ceremony and cultural performance.", type = "Holiday", time = "08:30 AM", targetClass = "All", createdBy = "Principal"),
            CalendarEvent(id = "CAL_6", date = "2026-09-10", title = "Mid-Term Examinations", description = "Half-yearly term exams start.", type = "Exam", time = "09:00 AM", targetClass = "All", createdBy = "Exam Dept")
        )

        val timetableList = listOf(
            Timetable("TT601", "Class 10", "Mon: Math (9:00), Eng (10:00), CS (11:00) | Tue: Phy (9:00), Chem (10:00), CS (11:00)"),
            Timetable("TT602", "Class 9", "Mon: Eng (9:00), Math (10:00), Art (11:00) | Tue: Hist (9:00), Math (10:00), Phy (11:00)")
        )

        val initialChatMessages = listOf(
            ChatMessage("C701", "T201", "S101", "Hi Amir, please complete your Math homework by Sunday.", System.currentTimeMillis() - 7200000),
            ChatMessage("C702", "S101", "T201", "Sure Sir, I will upload it tomorrow.", System.currentTimeMillis() - 3600000)
        )

        val attendanceList = listOf(
            Attendance("ATT801", "S101", "Class 10", "2026-05-21", "Present"),
            Attendance("ATT802", "S102", "Class 9", "2026-05-21", "Present"),
            Attendance("ATT803", "S103", "Class 10", "2026-05-21", "Absent")
        )

        // Only insert locally if database is fully empty
        val currentStudents = db.studentDao().getAllStudentsFlow().first()
        val authOk = firebaseAuth?.currentUser != null
        if (currentStudents.isEmpty()) {
            studentList.forEach { 
                db.studentDao().insertStudent(it)
                if (authOk) firestore?.collection("students")?.document(it.studentId)?.set(it)?.await()
                val sDob = it.DOB.trim().ifBlank { "01-01-2010" }
                val user = User(
                    userId = it.studentId,
                    name = it.name,
                    role = "STUDENT",
                    email = "${it.studentId}@sdps.com",
                    passwordHash = sha256Hex(sDob),
                    isFirstLogin = false,
                    className = it.className,
                    phone = it.phone,
                    dob = sDob
                )
                db.userDao().insertUser(user)
                if (authOk) firestore?.collection("users")?.document(it.studentId)?.set(user)?.await()
            }
            teacherList.forEach { 
                db.teacherDao().insertTeacher(it)
                if (authOk) firestore?.collection("teachers")?.document(it.teacherId)?.set(it)?.await()
                val tDob = it.joiningDate.trim().ifBlank { "01-01-1985" }
                val user = User(
                    userId = it.teacherId,
                    name = it.name,
                    role = "TEACHER",
                    email = "${it.teacherId}@sdps.com",
                    passwordHash = sha256Hex(tDob),
                    isFirstLogin = false,
                    className = it.classTeacherOf,
                    phone = it.phone,
                    dob = tDob
                )
                db.userDao().insertUser(user)
                if (authOk) firestore?.collection("users")?.document(it.teacherId)?.set(user)?.await()
            }
            feeList.forEach { 
                db.feeDao().insertFee(it)
                if (authOk) firestore?.collection("fees")?.document(it.feeId)?.set(it)?.await()
            }
            homeworkList.forEach { 
                db.homeworkDao().insertHomework(it)
                if (authOk) firestore?.collection("homework")?.document(it.homeworkId)?.set(it)?.await()
            }
            noticeList.forEach { 
                db.noticeDao().insertNotice(it)
                if (authOk) firestore?.collection("notices")?.document(it.noticeId)?.set(it)?.await()
            }
            timetableList.forEach { 
                db.timetableDao().insertTimetable(it)
                if (authOk) firestore?.collection("timetable")?.document(it.timetableId)?.set(it)?.await()
            }
            calendarEventList.forEach {
                db.calendarEventDao().insertCalendarEvent(it)
                if (authOk) firestore?.collection("calendar_events")?.document(it.id)?.set(it)?.await()
            }
            initialChatMessages.forEach { 
                db.chatDao().insertMessage(it)
                if (authOk) firestore?.collection("chats")?.document(it.messageId)?.set(it)?.await()
            }
            db.attendanceDao().insertAttendance(attendanceList)
            if (authOk) {
                attendanceList.forEach {
                    firestore?.collection("attendance")?.document(it.attendanceId)?.set(it)?.await()
                }
            }
            Log.d("SchoolRepository", "Seeded School Databases and synced with Firestore successfully!")
        }

        // Run student auto pre-seeding logic asynchronously
        try {
            seed10StudentsPerClass()
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Auto student seeding call failed", e)
        }
        } catch (e: Exception) {
            Log.e("SchoolRepository", "seedInitialDataIfNeeded failed (likely no network on first run) — app continues normally", e)
        }
    }

    
    override suspend fun removeClassTeacher(teacherId: String, actionUserId: String, actionUserName: String): Result<Unit> {
        return try {
            val fs = firestore
            if (fs != null) {
                fs.runTransaction { transaction ->
                    val teacherRef = fs.collection("teachers").document(teacherId)
                    transaction.update(teacherRef, "classTeacherOf", "", "classesAssigned", "")
                    
                    val userRef = fs.collection("users").document(teacherId)
                    transaction.update(userRef, "role", "TEACHER", "className", "")
                }.await()
            }
            
            // Sync to local
            val teacher = db.teacherDao().getTeacherById(teacherId)
            if (teacher != null) {
                val updated = teacher.copy(classTeacherOf = "", classesAssigned = "")
                db.teacherDao().insertTeacher(updated)
            }
            
            val user = db.userDao().getUser(teacherId)
            if (user != null) {
                db.userDao().insertUser(user.copy(role = "TEACHER", className = ""))
            }
            
            val logId = "AL_${System.currentTimeMillis()}"
            val auditLog = AuditLog(
                logId = logId,
                timestamp = System.currentTimeMillis(),
                userId = actionUserId,
                userName = actionUserName,
                action = "Removed Class Teacher designation from $teacherId",
                oldValue = "Class Teacher",
                newValue = "Teacher"
            )
            db.auditLogDao().insertAuditLog(auditLog)
            firestore?.collection("audit_logs")?.document(logId)?.set(auditLog)?.await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun assignClassTeacher(teacherBId: String, className: String, actionUserId: String, actionUserName: String): Result<Unit> {
        return try {
            val fs = firestore
            if (fs != null) {
                // Query Firestore for documents representing previous incumbents
                val previousQuery = fs.collection("teachers")
                    .whereEqualTo("classTeacherOf", className)
                    .get()
                    .await()
                
                fs.runTransaction { transaction ->
                    for (doc in previousQuery.documents) {
                        val teacherId = doc.id
                        if (teacherId != teacherBId) {
                            val teacherRef = fs.collection("teachers").document(teacherId)
                            transaction.update(teacherRef, "classTeacherOf", "", "classesAssigned", "")
                            
                            val userRef = fs.collection("users").document(teacherId)
                            transaction.update(userRef, "role", "TEACHER", "className", "")
                        }
                    }
                    
                    val teacherBRef = fs.collection("teachers").document(teacherBId)
                    transaction.update(teacherBRef, "classTeacherOf", className, "classesAssigned", className)
                    
                    val userBRef = fs.collection("users").document(teacherBId)
                    transaction.update(userBRef, "role", "CLASS_TEACHER", "className", className)
                }.await()
            }
            
            // Sync to local database
            val teachers = db.teacherDao().getAllTeachersFlow().first()
            val previousInLocal = teachers.filter { it.classTeacherOf == className || it.classesAssigned == className }
            previousInLocal.forEach { prev ->
                if (prev.teacherId != teacherBId) {
                    val updatedPrev = prev.copy(classTeacherOf = "", classesAssigned = "")
                    db.teacherDao().insertTeacher(updatedPrev)
                    
                    val user = db.userDao().getUser(prev.teacherId)
                    if (user != null) {
                        db.userDao().insertUser(user.copy(role = "TEACHER", className = ""))
                    }
                }
            }
            
            val teacherB = db.teacherDao().getTeacherById(teacherBId)
            if (teacherB != null) {
                val updatedB = teacherB.copy(classTeacherOf = className, classesAssigned = className)
                db.teacherDao().insertTeacher(updatedB)
                
                val userB = db.userDao().getUser(teacherBId)
                if (userB != null) {
                    db.userDao().insertUser(userB.copy(role = "CLASS_TEACHER", className = className))
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error assignClassTeacher: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun seed10StudentsPerClass(): Result<Unit> {
        return try {
            if (firebaseAuth?.currentUser == null) return Result.success(Unit)
            val fs = firestore ?: return Result.success(Unit)
            
            // Check if student catalog already has seeded records
            val existing = fs.collection("students").limit(1).get()?.await()
            if (existing?.isEmpty != true) {
                Log.d("SchoolRepository", "Students seed in Firestore already exists. Skipping active overwrite.")
                return Result.success(Unit)
            }
            
            val batch = fs.batch()
            val classes = listOf(
                "Nursery", "LKG", "UKG", 
                "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
            )
            val firstNames = listOf("Amit", "Aarav", "Rohan", "Siddharth", "Rahul", "Pooja", "Priya", "Neha", "Komal", "Ananya", "Sneha", "Vikram", "Aditya", "Manish", "Tanvi", "Ravi", "Sanjay", "Deepak", "Jyoti", "Karan")
            val lastNames = listOf("Kumar", "Sharma", "Singh", "Verma", "Gupta", "Mishra", "Joshi", "Patel", "Mehta", "Nair", "Rao", "Das", "Yadav", "Choudhary")
            
            classes.forEachIndexed { classIndex, className ->
                val classCode = when (className) {
                    "Nursery" -> "NUR"
                    "LKG" -> "LKG"
                    "UKG" -> "UKG"
                    "Class 1" -> "C1"
                    "Class 2" -> "C2"
                    "Class 3" -> "C3"
                    "Class 4" -> "C4"
                    "Class 5" -> "C5"
                    "Class 6" -> "C6"
                    "Class 7" -> "C7"
                    "Class 8" -> "C8"
                    "Class 9" -> "C9"
                    "Class 10" -> "C10"
                    else -> "CL"
                }
                for (roll in 1..10) {
                    val sId = "STID_${classCode}_${String.format("%02d", roll)}"
                    val fn = firstNames[(classIndex * 13 + roll) % firstNames.size]
                    val ln = lastNames[(classIndex * 11 + roll) % lastNames.size]
                    val fullName = "$fn $ln"
                    
                    val sDob = "12-10-2016"
                    val student = Student(
                        studentId = sId,
                        id = sId,
                        name = fullName,
                        className = className,

                        rollNo = roll.toString(),
                        DOB = sDob,
                        fatherName = "Father of $fullName",
                        motherName = "Mother of $fullName",
                        phone = "9876543210",
                        address = "Plot $roll, New Delhi",
                        admissionNo = "ADM_2026_${classCode}_$roll",
                        photoUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&auto=format&fit=crop",
                        rollNumber = roll,
                        attendanceStatus = if (roll % 4 == 0) "Absent" else "Present",
                        feeStatus = if (roll % 2 == 0) "Paid" else "Pending",
                        role = "STUDENT"
                    )
                    
                    db.studentDao().insertStudent(student)
                    batch?.set(fs.collection("students").document(sId), student)
                    
                    // Also seed secure User so they map nicely
                    val user = User(
                        userId = sId,
                        name = fullName,
                        role = "STUDENT",
                        email = "$sId@sdps.com",
                        passwordHash = sha256Hex(sDob),
                        isFirstLogin = false,
                        className = className,
                        phone = "9876543210",
                        dob = sDob
                    )
                    db.userDao().insertUser(user)
                    batch?.set(fs.collection("users").document(sId), user)
                }
            }
            batch?.commit()?.await()
            Log.d("SchoolRepository", "Pre-seeded 130 high-fidelity students successfully.")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error seeding students: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun promoteToAdmin(teacherId: String): Result<Unit> {
        return try {
            val fs = firestore
            if (fs != null) {
                fs.runTransaction { transaction ->
                    val teacherRef = fs.collection("teachers").document(teacherId)
                    transaction.update(teacherRef, "role", "ADMIN", "classTeacherOf", "", "classesAssigned", "")
                    val userRef = fs.collection("users").document(teacherId)
                    transaction.update(userRef, "role", "ADMIN", "roleCode", "AD-55", "className", "")
                }.await()
            }
            
            // Sync to local DB
            val teacher = db.teacherDao().getTeacherById(teacherId)
            if (teacher != null) {
                val updatedT = teacher.copy(classesAssigned = "", classTeacherOf = "")
                db.teacherDao().insertTeacher(updatedT)
            }
            val user = db.userDao().getUser(teacherId)
            if (user != null) {
                val updatedU = user.copy(role = "ADMIN", roleCode = "AD-55", className = "")
                db.userDao().insertUser(updatedU)
                if (_currentUser.value?.userId == teacherId) {
                    _currentUser.value = updatedU
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error promoteToAdmin: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun demoteToTeacher(adminTeacherId: String): Result<Unit> {
        return try {
            val fs = firestore
            if (fs != null) {
                fs.runTransaction { transaction ->
                    val teacherRef = fs.collection("teachers").document(adminTeacherId)
                    transaction.update(teacherRef, "role", "TEACHER", "classTeacherOf", "", "classesAssigned", "")
                    val userRef = fs.collection("users").document(adminTeacherId)
                    transaction.update(userRef, "role", "TEACHER", "roleCode", "TC-12", "className", "")
                }.await()
            }

            // Sync to local DB
            val teacher = db.teacherDao().getTeacherById(adminTeacherId)
            if (teacher != null) {
                val updatedT = teacher.copy(classesAssigned = "", classTeacherOf = "")
                db.teacherDao().insertTeacher(updatedT)
            }
            val user = db.userDao().getUser(adminTeacherId)
            if (user != null) {
                val updatedU = user.copy(role = "TEACHER", roleCode = "TC-12", className = "")
                db.userDao().insertUser(updatedU)
                if (_currentUser.value?.userId == adminTeacherId) {
                    _currentUser.value = updatedU
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error demoteToTeacher: ${e.message}", e)
            Result.failure(e)
        }
    }

    override suspend fun performSchoolStructureMigration(): Result<Unit> {
        return try {
            val fs = firestore
            
            // Helper function to clean classes — matches against the real class list instead of
            // guessing a suffix pattern, so it can't accidentally mangle a valid class name
            // (e.g. never strips the "10" off "Class 10") and catches any section labeling style.
            val knownClasses = listOf(
                "Nursery", "LKG", "UKG",
                "Class 1", "Class 2", "Class 3", "Class 4", "Class 5",
                "Class 6", "Class 7", "Class 8", "Class 9", "Class 10"
            ).sortedByDescending { it.length } // longest first, so "Class 10" is checked before "Class 1"
            fun cleanSectionFromClass(className: String): String {
                val trimmed = className.trim()
                if (trimmed.isBlank()) return ""
                val matched = knownClasses.firstOrNull { trimmed.equals(it, ignoreCase = true) || trimmed.startsWith(it, ignoreCase = true) }
                if (matched != null) return matched
                // Fallback for anything that doesn't cleanly start with a known class name —
                // strip a trailing " - X" / " Section X" style suffix conservatively.
                val suffixRegex = Regex("(?i)\\s*-\\s*(Section\\s*)?[A-D]\\s*$|\\s+Sec(tion)?\\.?\\s*[A-D]\\s*$")
                return trimmed.replace(suffixRegex, "").trim()
            }

            // 1. Migrate Students
            val students = db.studentDao().getAllStudentsFlow().firstOrNull() ?: emptyList()
            students.forEach { student ->
                val cleanedClass = cleanSectionFromClass(student.className)
                if (cleanedClass != student.className) {
                    val updatedStudent = student.copy(className = cleanedClass)
                    db.studentDao().insertStudent(updatedStudent)
                    if (fs != null) {
                        try {
                            fs.collection("students").document(student.studentId).set(updatedStudent)
                        } catch (e: Exception) {
                            Log.e("Migration", "Student Firestore migration fail", e)
                        }
                    }
                }
            }

            // 2. Migrate Teachers
            val teachers = db.teacherDao().getAllTeachersFlow().firstOrNull() ?: emptyList()
            teachers.forEach { teacher ->
                val cleanedClassTeacherOf = cleanSectionFromClass(teacher.classTeacherOf)
                var classesAssignedCleaned = teacher.classesAssigned
                if (teacher.classesAssigned.isNotBlank()) {
                    classesAssignedCleaned = teacher.classesAssigned.split(",").joinToString(",") { cleanSectionFromClass(it) }
                }
                if (cleanedClassTeacherOf != teacher.classTeacherOf || classesAssignedCleaned != teacher.classesAssigned) {
                    val updatedTeacher = teacher.copy(classTeacherOf = cleanedClassTeacherOf,
                        

                        classesAssigned = classesAssignedCleaned
                    )
                    db.teacherDao().insertTeacher(updatedTeacher)
                    if (fs != null) {
                        try {
                            fs.collection("teachers").document(teacher.teacherId).set(updatedTeacher)
                        } catch (e: Exception) {
                            Log.e("Migration", "Teacher Firestore migration fail", e)
                        }
                    }
                }
            }

            // 3. Migrate Attendance records
            val attendanceRecords = db.attendanceDao().getAllAttendanceFlow().firstOrNull() ?: emptyList()
            attendanceRecords.forEach { record ->
                val cleanedClass = cleanSectionFromClass(record.className)
                if (cleanedClass != record.className) {
                    val updatedAttendance = record.copy(className = cleanedClass)
                    db.attendanceDao().insertAttendance(listOf(updatedAttendance))
                    if (fs != null) {
                        try {
                            fs.collection("attendance").document(record.attendanceId).set(updatedAttendance)
                        } catch (e: Exception) {
                            Log.e("Migration", "Attendance Firestore migration fail", e)
                        }
                    }
                }
            }

            // 4. Migrate Notices
            val notices = db.noticeDao().getAllNoticesFlow().firstOrNull() ?: emptyList()
            notices.forEach { notice ->
                val cleanedClass = cleanSectionFromClass(notice.targetClass)
                if (cleanedClass != notice.targetClass) {
                    val updatedNotice = notice.copy(targetClass = cleanedClass)
                    db.noticeDao().insertNotice(updatedNotice)
                    if (fs != null) {
                        try {
                            fs.collection("notices").document(notice.noticeId).set(updatedNotice)
                        } catch (e: Exception) {
                            Log.e("Migration", "Notice Firestore migration fail", e)
                        }
                    }
                }
            }

            // 5. Migrate Homework
            val homeworkList = db.homeworkDao().getAllHomeworkFlow().firstOrNull() ?: emptyList()
            homeworkList.forEach { hw ->
                val cleanedClass = cleanSectionFromClass(hw.className)
                if (cleanedClass != hw.className) {
                    val updatedHomework = hw.copy(className = cleanedClass)
                    db.homeworkDao().insertHomework(updatedHomework)
                    if (fs != null) {
                        try {
                            fs.collection("homework").document(hw.homeworkId).set(updatedHomework)
                        } catch (e: Exception) {
                            Log.e("Migration", "Homework Firestore migration fail", e)
                        }
                    }
                }
            }

            // 6. Migrate Users
            val users = db.userDao().getAllUsersFlow().firstOrNull() ?: emptyList()
            users.forEach { user ->
                val cleanedClass = cleanSectionFromClass(user.className)
                if (cleanedClass != user.className) {
                    val updatedUser = user.copy(className = cleanedClass)
                    db.userDao().insertUser(updatedUser)
                    if (user.userId == _currentUser.value?.userId) {
                        _currentUser.value = updatedUser
                    }
                    if (fs != null) {
                        try {
                            kotlinx.coroutines.withTimeout(5000) { fs.collection("users").document(user.userId).set(updatedUser).await() }
                        } catch (e: Exception) {
                            Log.e("Migration", "User Firestore migration fail", e)
                        }
                    }
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error performingSchoolStructureMigration: ${e.message}", e)
            Result.failure(e)
        }
    }

    // BOOK DISTRIBUTION IMPLEMENTATION
    override fun getAllClassBooks(): Flow<List<ClassBook>> {
        return db.classBookDao().getAllClassBooksFlow()
    }

    override fun getClassBooksForClass(className: String): Flow<List<ClassBook>> {
        return db.classBookDao().getClassBooksForClassFlow(className)
    }

    override suspend fun saveClassBook(book: ClassBook): Result<Unit> {
        return try {
            db.classBookDao().insertClassBook(book)
            firestore?.collection("class_books")?.document(book.bookId)?.set(book)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error saving class book", e)
            Result.failure(e)
        }
    }

    override suspend fun deleteClassBook(bookId: String): Result<Unit> {
        return try {
            db.classBookDao().deleteClassBookById(bookId)
            firestore?.collection("class_books")?.document(bookId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error deleting class book", e)
            Result.failure(e)
        }
    }

    override fun getAllIssuedBooks(): Flow<List<IssuedBook>> {
        return db.issuedBookDao().getAllIssuedBooksFlow()
    }

    override fun getIssuedBooksForStudent(studentId: String): Flow<List<IssuedBook>> {
        return db.issuedBookDao().getIssuedBooksForStudentFlow(studentId)
    }

    override suspend fun issueBook(issuedBook: IssuedBook): Result<Unit> {
        return try {
            db.issuedBookDao().insertIssuedBook(issuedBook)
            firestore?.collection("issued_books")?.document(issuedBook.issueId)?.set(issuedBook)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error issuing book", e)
            Result.failure(e)
        }
    }

    override suspend fun deleteIssuedBook(issueId: String): Result<Unit> {
        return try {
            db.issuedBookDao().deleteIssuedBookById(issueId)
            firestore?.collection("issued_books")?.document(issueId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error deleting issued book", e)
            Result.failure(e)
        }
    }

    // SCHOOL CALENDAR IMPLEMENTATION
    override fun getAllCalendarEvents(): Flow<List<CalendarEvent>> {
        return db.calendarEventDao().getAllCalendarEventsFlow()
    }

    override suspend fun saveCalendarEvent(event: CalendarEvent): Result<Unit> {
        return try {
            db.calendarEventDao().insertCalendarEvent(event)
            firestore?.collection("calendar_events")?.document(event.id)?.set(event)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error saving calendar event", e)
            Result.failure(e)
        }
    }

    override suspend fun deleteCalendarEvent(eventId: String): Result<Unit> {
        return try {
            db.calendarEventDao().deleteCalendarEventById(eventId)
            firestore?.collection("calendar_events")?.document(eventId)?.delete()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Error deleting calendar event", e)
            Result.failure(e)
        }
    }
}
