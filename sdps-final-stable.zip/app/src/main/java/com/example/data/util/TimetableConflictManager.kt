package com.example.data.util

import com.example.data.model.Teacher
import com.example.data.model.Timetable
import java.util.UUID

/**
 * Structured slot representation for Timetable entries.
 */
data class TimetableSlot(
    val id: String = UUID.randomUUID().toString(),
    val timetableId: String = "",
    val className: String = "",
    val day: String = "Monday", // Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
    val period: String = "Period 1", // Period 1 .. Period 8, or custom
    val timeRange: String = "", // e.g. "09:00 - 09:45"
    val subject: String = "", // e.g. "Mathematics"
    val teacherId: String = "",
    val teacherName: String = "",
    val rawText: String = ""
)

/**
 * Result of timetable conflict validation.
 */
sealed class TimetableConflictResult {
    object NoConflict : TimetableConflictResult()

    data class Conflict(
        val message: String,
        val teacherName: String,
        val conflictingClass: String,
        val targetClass: String,
        val day: String,
        val period: String,
        val timeRange: String,
        val isTeacherConflict: Boolean = true,
        val isIntraClassConflict: Boolean = false,
        val conflictingSlotDetails: String = ""
    ) : TimetableConflictResult()
}

/**
 * Authoritative Timetable Parser and Conflict Detection Engine.
 * Ensures that no teacher is double-booked across different classes at the same day/period/time,
 * and prevents intra-class period overlapping.
 */
object TimetableConflictManager {

    val VALID_DAYS = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    val STANDARD_PERIODS = listOf(
        "Period 1", "Period 2", "Period 3", "Period 4",
        "Period 5", "Period 6", "Period 7", "Period 8"
    )

    fun normalizeDay(dayStr: String): String {
        val d = dayStr.trim().lowercase()
        return when {
            d.startsWith("mon") -> "Monday"
            d.startsWith("tue") -> "Tuesday"
            d.startsWith("wed") -> "Wednesday"
            d.startsWith("thu") -> "Thursday"
            d.startsWith("fri") -> "Friday"
            d.startsWith("sat") -> "Saturday"
            d.startsWith("sun") -> "Sunday"
            else -> dayStr.trim().replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
    }

    fun normalizePeriod(periodStr: String, fallbackIndex: Int = 1): String {
        val p = periodStr.trim()
        val numMatch = Regex("""(?:period|p|slot)\s*(\d+)""", RegexOption.IGNORE_CASE).find(p)
        if (numMatch != null) {
            val num = numMatch.groupValues[1]
            return "Period $num"
        }
        val pureNum = p.toIntOrNull()
        if (pureNum != null) {
            return "Period $pureNum"
        }
        if (p.isNotBlank()) return p
        return "Period $fallbackIndex"
    }

    /**
     * Parses the string format of scheduleData into structured TimetableSlots.
     * Compatible with:
     * - "Mon: Math (9:00), CS (10:00) | Tue: Phy (9:00), Art (10:00)"
     * - "Mon: Period 1: Math (Rahul Kumar) (09:00-09:45), Period 2: English (Anjali) (09:45-10:30)"
     * - "Mon: Math - Rahul Kumar (Period 1), English - Anjali (Period 2)"
     * - Newlines or pipe separated day blocks
     */
    fun parseScheduleData(
        className: String,
        scheduleData: String,
        timetableId: String = "",
        knownTeachers: List<Teacher> = emptyList()
    ): List<TimetableSlot> {
        if (scheduleData.isBlank()) return emptyList()

        val slots = mutableListOf<TimetableSlot>()
        val dayBlocks = scheduleData.split(Regex("""[|\n]""")).map { it.trim() }.filter { it.isNotEmpty() }

        for (block in dayBlocks) {
            val colonIdx = block.indexOf(':')
            if (colonIdx == -1) continue

            val dayPart = block.substring(0, colonIdx).trim()
            val day = normalizeDay(dayPart)
            val periodsPart = block.substring(colonIdx + 1).trim()

            // Split periods by comma or semicolon or newline
            val rawPeriodEntries = periodsPart.split(Regex("""[,;\n]""")).map { it.trim() }.filter { it.isNotEmpty() }

            var slotIndex = 1
            for (entry in rawPeriodEntries) {
                val parsed = parseSinglePeriodEntry(
                    className = className,
                    day = day,
                    entryText = entry,
                    fallbackIndex = slotIndex,
                    timetableId = timetableId,
                    knownTeachers = knownTeachers
                )
                slots.add(parsed)
                slotIndex++
            }
        }

        return slots
    }

    private fun parseSinglePeriodEntry(
        className: String,
        day: String,
        entryText: String,
        fallbackIndex: Int,
        timetableId: String,
        knownTeachers: List<Teacher>
    ): TimetableSlot {
        var text = entryText.trim()
        var period = ""
        var timeRange = ""
        var teacherName = ""
        var teacherId = ""
        var subject = ""

        // 1. Extract explicit Period if present: e.g. "Period 3" or "P3"
        val periodMatch = Regex("""\b(?:Period|Slot|P)\s*(\d+)\b""", RegexOption.IGNORE_CASE).find(text)
        if (periodMatch != null) {
            period = "Period ${periodMatch.groupValues[1]}"
            text = text.replace(periodMatch.value, "").trim()
        }

        // 2. Extract time range in parentheses or stand-alone: e.g. (9:00), (09:00 - 10:00), 9:00-10:00
        val timeRangeMatch = Regex("""\(?\b(\d{1,2}(?::\d{2})?\s*(?:AM|PM|am|pm)?\s*(?:-|to)\s*\d{1,2}(?::\d{2})?\s*(?:AM|PM|am|pm)?)\)?""").find(text)
        if (timeRangeMatch != null) {
            timeRange = timeRangeMatch.groupValues[1].trim()
            text = text.replace(timeRangeMatch.value, "").trim()
        } else {
            val singleTimeMatch = Regex("""\(?\b(\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)?)\)?""").find(text)
            if (singleTimeMatch != null) {
                timeRange = singleTimeMatch.groupValues[1].trim()
                text = text.replace(singleTimeMatch.value, "").trim()
            }
        }

        // 3. Match against known teachers
        for (t in knownTeachers) {
            if (t.name.isNotBlank() && text.contains(t.name, ignoreCase = true)) {
                teacherName = t.name
                teacherId = t.teacherId
                text = text.replace(Regex("""\b${Regex.escape(t.name)}\b""", RegexOption.IGNORE_CASE), "").trim()
                break
            } else if (t.teacherId.isNotBlank() && text.contains(t.teacherId, ignoreCase = true)) {
                teacherName = t.name.ifBlank { t.teacherId }
                teacherId = t.teacherId
                text = text.replace(Regex("""\b${Regex.escape(t.teacherId)}\b""", RegexOption.IGNORE_CASE), "").trim()
                break
            }
        }

        // 4. If teacher not matched by database, check parentheses or dash for teacher name
        if (teacherName.isBlank()) {
            val parenTeacherMatch = Regex("""\(([^)]+)\)""").find(text)
            if (parenTeacherMatch != null) {
                val candidate = parenTeacherMatch.groupValues[1].trim()
                // If candidate is not purely time, treat as teacher name or details
                if (!candidate.contains(Regex("""^\d"""))) {
                    teacherName = candidate
                    text = text.replace(parenTeacherMatch.value, "").trim()
                }
            } else if (text.contains("-")) {
                val parts = text.split("-").map { it.trim() }
                if (parts.size >= 2) {
                    subject = parts[0]
                    teacherName = parts[1]
                    text = ""
                }
            }
        }

        // Clean up punctuation and remaining text as subject
        if (subject.isBlank()) {
            subject = text.replace(Regex("""^[:\-–—,\s]+|[:\-–—,\s]+$"""), "")
                .replace(Regex("""[()]"""), "")
                .trim()
        }

        if (period.isBlank()) {
            period = normalizePeriod(period, fallbackIndex)
        }

        if (subject.isBlank()) {
            subject = "Academic Period $fallbackIndex"
        }

        return TimetableSlot(
            id = UUID.randomUUID().toString(),
            timetableId = timetableId,
            className = className,
            day = day,
            period = period,
            timeRange = timeRange,
            subject = subject,
            teacherId = teacherId,
            teacherName = teacherName,
            rawText = entryText
        )
    }

    /**
     * Serializes a list of structured slots back into a standard, clean scheduleData string.
     */
    fun serializeSlots(slots: List<TimetableSlot>): String {
        if (slots.isEmpty()) return ""

        val groupedByDay = slots.groupBy { normalizeDay(it.day) }
        val dayEntries = mutableListOf<String>()

        // Maintain consistent day order Monday -> Saturday
        val orderedDays = VALID_DAYS.filter { groupedByDay.containsKey(it) } +
                (groupedByDay.keys - VALID_DAYS.toSet())

        for (day in orderedDays) {
            val daySlots = groupedByDay[day] ?: continue
            val periodStrings = daySlots.map { slot ->
                val sb = StringBuilder()
                sb.append(slot.period).append(": ").append(slot.subject)
                if (slot.teacherName.isNotBlank()) {
                    sb.append(" (").append(slot.teacherName).append(")")
                }
                if (slot.timeRange.isNotBlank()) {
                    sb.append(" [").append(slot.timeRange).append("]")
                }
                sb.toString()
            }
            dayEntries.add("$day: ${periodStrings.joinToString(", ")}")
        }

        return dayEntries.joinToString(" | ")
    }

    /**
     * Checks whether two time intervals or period designations overlap.
     */
    fun isSlotOverlap(slotA: TimetableSlot, slotB: TimetableSlot): Boolean {
        // Must be on the same day
        if (!normalizeDay(slotA.day).equals(normalizeDay(slotB.day), ignoreCase = true)) {
            return false
        }

        // Compare explicit period numbers (e.g. "Period 3" vs "Period 3")
        val periodA = normalizePeriod(slotA.period)
        val periodB = normalizePeriod(slotB.period)
        val periodMatch = periodA.equals(periodB, ignoreCase = true)

        // If both have time ranges, check interval overlap
        val timeIntervalA = parseTimeInterval(slotA.timeRange)
        val timeIntervalB = parseTimeInterval(slotB.timeRange)

        if (timeIntervalA != null && timeIntervalB != null) {
            val (startA, endA) = timeIntervalA
            val (startB, endB) = timeIntervalB
            // Interval overlap: startA < endB and startB < endA
            return (startA < endB && startB < endA)
        }

        // If at least one has exact time, compare matching or period match
        if (slotA.timeRange.isNotBlank() && slotB.timeRange.isNotBlank()) {
            if (slotA.timeRange.trim().equals(slotB.timeRange.trim(), ignoreCase = true)) {
                return true
            }
        }

        return periodMatch
    }

    private fun parseTimeInterval(timeStr: String): Pair<Int, Int>? {
        if (timeStr.isBlank()) return null
        val clean = timeStr.replace(Regex("""[\[\]()]"""), "").trim()
        val parts = clean.split(Regex("""\s*(?:-|to)\s*"""))
        if (parts.size == 2) {
            val startMin = parseTimeToMinutes(parts[0])
            val endMin = parseTimeToMinutes(parts[1])
            if (startMin != null && endMin != null && endMin > startMin) {
                return Pair(startMin, endMin)
            }
        }
        val singleMin = parseTimeToMinutes(clean)
        if (singleMin != null) {
            return Pair(singleMin, singleMin + 45) // assume 45 min default duration
        }
        return null
    }

    private fun parseTimeToMinutes(timeStr: String): Int? {
        val t = timeStr.trim().lowercase()
        val isPM = t.contains("pm")
        val isAM = t.contains("am")
        val numOnly = t.replace(Regex("""[^\d:]"""), "").trim()
        if (numOnly.isBlank()) return null

        val parts = numOnly.split(":")
        val rawHours = parts.getOrNull(0)?.toIntOrNull() ?: return null
        val rawMinutes = parts.getOrNull(1)?.toIntOrNull() ?: 0

        var hours = rawHours
        if (isPM && hours < 12) hours += 12
        if (isAM && hours == 12) hours = 0

        return hours * 60 + rawMinutes
    }

    fun isSameTeacher(teacherA: String, teacherB: String, knownTeachers: List<Teacher>): Boolean {
        if (teacherA.isBlank() || teacherB.isBlank()) return false
        val cleanA = teacherA.trim()
        val cleanB = teacherB.trim()

        if (cleanA.equals(cleanB, ignoreCase = true)) return true

        // Match by known teachers list (id vs name or vice versa)
        val matchA = knownTeachers.find { it.name.equals(cleanA, ignoreCase = true) || it.teacherId.equals(cleanA, ignoreCase = true) }
        val matchB = knownTeachers.find { it.name.equals(cleanB, ignoreCase = true) || it.teacherId.equals(cleanB, ignoreCase = true) }

        if (matchA != null && matchB != null && matchA.teacherId == matchB.teacherId) {
            return true
        }

        return false
    }

    /**
     * Primary conflict validator for saving/updating a timetable record.
     * Evaluates:
     * 1. Intra-class slot conflicts (two periods simultaneously in the target class)
     * 2. Cross-class teacher conflicts (the same teacher scheduled in two different classes at the same slot)
     * 3. Edit-mode safety (ignores the previous record for the same timetableId/className)
     */
    fun validateTimetable(
        targetTimetable: Timetable,
        allTimetables: List<Timetable>,
        knownTeachers: List<Teacher>
    ): TimetableConflictResult {
        val targetSlots = parseScheduleData(
            className = targetTimetable.className,
            scheduleData = targetTimetable.scheduleData,
            timetableId = targetTimetable.timetableId,
            knownTeachers = knownTeachers
        )

        // 1. Check intra-class slot conflicts
        for (i in targetSlots.indices) {
            for (j in i + 1 until targetSlots.size) {
                val slotA = targetSlots[i]
                val slotB = targetSlots[j]
                if (isSlotOverlap(slotA, slotB)) {
                    return TimetableConflictResult.Conflict(
                        message = "${targetTimetable.className} already has '${slotA.subject}' assigned during ${slotA.day} ${slotA.period}.",
                        teacherName = slotA.teacherName.ifBlank { slotB.teacherName },
                        conflictingClass = targetTimetable.className,
                        targetClass = targetTimetable.className,
                        day = slotA.day,
                        period = slotA.period,
                        timeRange = slotA.timeRange.ifBlank { slotB.timeRange },
                        isTeacherConflict = false,
                        isIntraClassConflict = true,
                        conflictingSlotDetails = "${slotA.subject} vs ${slotB.subject}"
                    )
                }
            }
        }

        // 2. Filter other timetables (Edit-Mode Safety: ignore targetTimetable's own existing record)
        val otherTimetables = allTimetables.filter {
            it.timetableId != targetTimetable.timetableId &&
                    !it.className.equals(targetTimetable.className, ignoreCase = true)
        }

        // Parse all slots from other classes
        val otherSlots = mutableListOf<TimetableSlot>()
        for (tt in otherTimetables) {
            otherSlots.addAll(
                parseScheduleData(
                    className = tt.className,
                    scheduleData = tt.scheduleData,
                    timetableId = tt.timetableId,
                    knownTeachers = knownTeachers
                )
            )
        }

        // 3. Check teacher conflicts across other classes
        for (targetSlot in targetSlots) {
            val teacherInSlot = targetSlot.teacherName.ifBlank { targetSlot.teacherId }
            if (teacherInSlot.isBlank()) continue

            for (otherSlot in otherSlots) {
                val otherTeacher = otherSlot.teacherName.ifBlank { otherSlot.teacherId }
                if (otherTeacher.isBlank()) continue

                if (isSameTeacher(teacherInSlot, otherTeacher, knownTeachers) && isSlotOverlap(targetSlot, otherSlot)) {
                    val displayName = knownTeachers.find {
                        it.name.equals(teacherInSlot, ignoreCase = true) || it.teacherId.equals(teacherInSlot, ignoreCase = true)
                    }?.name ?: teacherInSlot

                    val timeStr = if (targetSlot.timeRange.isNotBlank()) " (${targetSlot.timeRange})" else ""
                    val message = "Teacher $displayName is already assigned to ${otherSlot.className} during ${targetSlot.day} ${targetSlot.period}$timeStr."

                    return TimetableConflictResult.Conflict(
                        message = message,
                        teacherName = displayName,
                        conflictingClass = otherSlot.className,
                        targetClass = targetTimetable.className,
                        day = targetSlot.day,
                        period = targetSlot.period,
                        timeRange = targetSlot.timeRange,
                        isTeacherConflict = true,
                        isIntraClassConflict = false,
                        conflictingSlotDetails = "${otherSlot.className} (${otherSlot.subject})"
                    )
                }
            }
        }

        return TimetableConflictResult.NoConflict
    }

    /**
     * Checks if a single slot being prepared in the UI has any conflicts before adding it.
     */
    fun checkSingleSlotConflict(
        slot: TimetableSlot,
        currentTimetableId: String,
        allTimetables: List<Timetable>,
        currentClassSlots: List<TimetableSlot>,
        knownTeachers: List<Teacher>
    ): TimetableConflictResult {
        // 1. Check against current class slots (excluding slot with same id)
        for (existing in currentClassSlots) {
            if (existing.id != slot.id && isSlotOverlap(slot, existing)) {
                return TimetableConflictResult.Conflict(
                    message = "${slot.className} already has '${existing.subject}' assigned during ${slot.day} ${slot.period}.",
                    teacherName = slot.teacherName,
                    conflictingClass = slot.className,
                    targetClass = slot.className,
                    day = slot.day,
                    period = slot.period,
                    timeRange = slot.timeRange,
                    isTeacherConflict = false,
                    isIntraClassConflict = true,
                    conflictingSlotDetails = existing.subject
                )
            }
        }

        // 2. Check against other classes for teacher conflict
        val teacherInSlot = slot.teacherName.ifBlank { slot.teacherId }
        if (teacherInSlot.isNotBlank()) {
            val otherTimetables = allTimetables.filter {
                it.timetableId != currentTimetableId &&
                        !it.className.equals(slot.className, ignoreCase = true)
            }

            for (tt in otherTimetables) {
                val slotsInOther = parseScheduleData(
                    className = tt.className,
                    scheduleData = tt.scheduleData,
                    timetableId = tt.timetableId,
                    knownTeachers = knownTeachers
                )
                for (otherSlot in slotsInOther) {
                    val otherTeacher = otherSlot.teacherName.ifBlank { otherSlot.teacherId }
                    if (otherTeacher.isNotBlank() &&
                        isSameTeacher(teacherInSlot, otherTeacher, knownTeachers) &&
                        isSlotOverlap(slot, otherSlot)
                    ) {
                        val displayName = knownTeachers.find {
                            it.name.equals(teacherInSlot, ignoreCase = true) || it.teacherId.equals(teacherInSlot, ignoreCase = true)
                        }?.name ?: teacherInSlot

                        val timeStr = if (slot.timeRange.isNotBlank()) " (${slot.timeRange})" else ""
                        val message = "Teacher $displayName is already assigned to ${otherSlot.className} during ${slot.day} ${slot.period}$timeStr."

                        return TimetableConflictResult.Conflict(
                            message = message,
                            teacherName = displayName,
                            conflictingClass = otherSlot.className,
                            targetClass = slot.className,
                            day = slot.day,
                            period = slot.period,
                            timeRange = slot.timeRange,
                            isTeacherConflict = true,
                            isIntraClassConflict = false,
                            conflictingSlotDetails = "${otherSlot.className} (${otherSlot.subject})"
                        )
                    }
                }
            }
        }

        return TimetableConflictResult.NoConflict
    }
}
