package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val userId: String = "",
    val uid: String = "",
    val name: String = "",
    val role: String = "", // HEAD_ADMIN, ADMIN, TEACHER, STUDENT, PRINCIPAL, CLASS_TEACHER
    val roleCode: String = "",
    val email: String = "",
    val phone: String = "",
    val passwordHash: String = "temp123", // default temporary password
    val isFirstLogin: Boolean = true,
    val className: String = "",
    val avatarUrl: String = "avatar_graduate",
    val themePreference: String = "SYSTEM", // LIGHT, DARK, SYSTEM
    val enableMuteNotifications: Boolean = false,
    val enableHomeworkAlerts: Boolean = true,
    val enableFeeAlerts: Boolean = true,
    val enableAttendanceAlerts: Boolean = true,
    val dob: String = "",
    val passwordStatus: String = "", // "INITIAL DOB PASSWORD", "CUSTOM PASSWORD SET", "RESET REQUIRED", "DOB VERIFICATION REQUIRED"
    val lastPasswordChange: String = "",
    val lastPasswordAction: String = "",
    val changedBy: String = "",
    val accountStatus: String = "ACTIVE"
) {
    fun getEffectivePasswordStatus(): String {
        if (passwordStatus == "DOB VERIFICATION REQUIRED" || (dob.isBlank() && role != "PRINCIPAL" && role != "HEAD_ADMIN")) {
            return "DOB VERIFICATION REQUIRED"
        }
        if (passwordStatus.isNotBlank()) return passwordStatus
        if (isFirstLogin || passwordHash == "temp123") return "INITIAL DOB PASSWORD"
        return "CUSTOM PASSWORD SET"
    }
}

@Entity(tableName = "students")
data class Student(
    @PrimaryKey val studentId: String = "",
    val id: String = "",
    val name: String = "",
    val className: String = "",
    val rollNo: String = "",
    val DOB: String = "",
    val gender: String = "Not Specified",
    val fatherName: String = "",
    val motherName: String = "",
    val guardianName: String = "",
    val phone: String = "",
    val address: String = "",
    val admissionNo: String = "",
    val photoUrl: String = "",
    val postOffice: String = "Main P.O.",
    val district: String = "Central District",
    val aadhaarNo: String = "",
    val dateOfAdmission: String = "",
    val rollNumber: Int = 1,
    val attendanceStatus: String = "Present",
    val status: String = "Active",
    val linkedSiblings: String = "",
    val isDeleted: Boolean = false,
    val feeStatus: String = "Unpaid",
    val role: String = "STUDENT",
    val approvedBy: String = "",
    val approvedAt: String = "",
    val submittedBy: String = "",
    val submittedByRole: String = "",
    val submittedAt: String = "",
    val rejectionReason: String = "",
        val deletedBy: String = "",
    val deletedAt: String = "",
    val lastModifiedBy: String = "",
    val lastModifiedAt: String = "",
    val auditLog: String = "",
    val hasTransport: Boolean = false,
    val transportSlab: String = "0-5 km", // 0-5 km, 5-10 km, 10-15 km
    val transportFee: Double = 500.0,
    val transportStartDate: String = "",
    val transportEndDate: String = ""
)

@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey val teacherId: String = "",
    val name: String = "",
    val subject: String = "",
    val gender: String = "Male",
    val classesAssigned: String = "", // Comma-separated or descriptive string
    val phone: String = "",
    val email: String = "",
    val classTeacherOf: String = "", // exact field required by user for transaction demotion
    val primarySubject: String = "", // exact field required by user for primary expert selection
    val secondarySubjects: String = "", // exact field required by user for secondary multi-select
    val photoUrl: String = "",
    val qualification: String = "",
    val experience: String = "",
    val joiningDate: String = "",
    val role: String = "Teacher",
    val isDeleted: Boolean = false,
    val status: String = "ACTIVE"
)

@Entity(tableName = "payrolls")
data class Payroll(
    @PrimaryKey val payrollId: String = "",
    val teacherId: String = "",
    val month: String = "", // April, May, June, July, August, September, October, November, December, January, February, March
    val basicSalary: Double = 0.0,
    val bonus: Double = 0.0,
    val allowances: Double = 0.0,
    val deductions: Double = 0.0,
    val netSalary: Double = 0.0,
    val status: String = "Pending", // Paid, Pending
    val paymentDetails: String = "", // NEFT reference, etc.
    val remarks: String = "",
    val lastUpdated: String = ""
)

@Entity(tableName = "attendance")
data class Attendance(
    @PrimaryKey val attendanceId: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val className: String = "",
    val markedByTeacherId: String = "",
    val markedByTeacherName: String = "",
    val date: String = "", // YYYY-MM-DD
    val timestamp: Long = 0L,
    val status: String = "" // Present, Absent, Late, Leave
)

@Entity(tableName = "fees")
data class Fee(
    @PrimaryKey val feeId: String = "",
    val studentId: String = "",
    val totalFee: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0, // calculated
    val paymentDate: String = "",
    val paymentMode: String = "", // Cash, Online
    val status: String = "", // Paid, Partial, Due
    val tuitionFee: Double = 12000.0,
    val bookFee: Double = 2500.0,
    val dressFee: Double = 1800.0,
    val examFee: Double = 1500.0,
    val transportFee: Double = 2000.0,
    val otherFee: Double = 1000.0,
    val paymentHistory: String = "No transaction history recorded yet."
)

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey val homeworkId: String = "",
    val className: String = "",
    val subject: String = "",
    val description: String = "",
    val dueDate: String = "",
    val fileUrl: String = ""
)

@Entity(tableName = "notices")
data class Notice(
    @PrimaryKey val noticeId: String = "",
    val title: String = "",
    val description: String = "",
    val createdBy: String = "", // sender name or ID
    val senderRole: String = "",
    val createdAt: Long = 0L,
    val targetType: String = "ALL", // "ALL" or "SPECIFIC_CLASS"
    val targetClass: String = "",
    val noticeCategory: String = "ACADEMIC",
    val isUrgent: Boolean = false,
    val attachmentType: String = "NONE", // NONE, IMAGE, PDF, VIDEO
    val attachmentUrl: String = "",
    val verifiedByPrincipal: Boolean = false
)

@Entity(tableName = "timetable")
data class Timetable(
    @PrimaryKey val timetableId: String = "",
    val className: String = "",
    val scheduleData: String = "" // Serialized timetable or daily periods
)

@Entity(tableName = "chats")
data class ChatMessage(
    @PrimaryKey val messageId: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val message: String = "",
    val timestamp: Long = 0L,
    val isRead: Boolean = false,
    val isDelivered: Boolean = false,
    val attachmentType: String = "", // "image", "pdf", "homework", "notice", ""
    val status: String = "sent", // "pending", "sent", "delivered", "read"
    val replyToMessageId: String = "",
    val reactions: String = "" // serialized JSON of reactions map or simple string
)

@Entity(tableName = "fee_ledger_entries")
data class FeeLedgerEntry(
    @PrimaryKey val entryId: String = "", // Joint/unique e.g.: "S101_April"
    val studentId: String = "",
    val month: String = "", // April, May,...
    val receiptNo: String = "",
    val paymentDate: String = "",
    val admissionFee: Double = 0.0,
    val tuitionFee: Double = 0.0,
    val gameFee: Double = 0.0,
    val examFee: Double = 0.0,
    val transportFee: Double = 0.0,
    val arrear: Double = 0.0,
    val paidAmount: Double = 0.0,
    val remarks: String = "",
    val lateFee: Double = 0.0,
    val concession: Double = 0.0,
    val totalPayable: Double = 0.0,
    val balance: Double = 0.0,
    val paymentMode: String = "Cash",
    val transactionId: String = "",
    val paymentStatus: String = "Pending",
    val refundAmount: Double = 0.0,
    // Itemized one-time/event charges applied to this specific student-month, so the
    // student can see exactly what each rupee is for. Stored as "Label:Amount|Label2:Amount2".
    val eventChargeDetails: String = "",
    val eventFeeTotal: Double = 0.0
)

// Tracks every fee-rate change with the month it takes effect from, per class (or "ALL").
// A month's fee is calculated using whichever rate was effective AT THAT MONTH — never
// retroactively changed for months before the effective month, regardless of paid status.
@Entity(tableName = "fee_rate_history")
data class FeeRateHistory(
    @PrimaryKey val rateId: String = "",
    val className: String = "", // specific class, or "ALL" for admission/exam/game fee etc.
    val feeType: String = "", // TUITION, TRANSPORT_0_5, TRANSPORT_5_10, TRANSPORT_10_15, ADMISSION, EXAM, GAME
    val amount: Double = 0.0,
    val effectiveFromMonth: String = "", // e.g. "July" — academic-year month name
    val setByUserId: String = "",
    val setAt: Long = 0L
)

// A one-time/event charge the Principal applies to a class (or "ALL") for a specific month —
// e.g. "Sports Day Fee". Multiple can exist for the same class+month. Applied to every
// student in that class for that month, and shown to the student by its label for transparency.
@Entity(tableName = "fee_event_charges")
data class FeeEventCharge(
    @PrimaryKey val eventChargeId: String = "",
    val className: String = "", // specific class, or "ALL"
    val month: String = "",
    val label: String = "", // e.g. "Sports Day Fee"
    val amount: Double = 0.0,
    val createdByUserId: String = "",
    val createdAt: Long = 0L
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey val logId: String = "",
    val timestamp: Long = 0L,
    val userId: String = "",
    val userName: String = "",
    val action: String = "", // e.g., "Updated Fee Ledger for S101"
    val oldValue: String = "",
    val newValue: String = ""
)

@Entity(tableName = "teacher_attendance")
data class TeacherAttendance(
    @PrimaryKey val attendanceId: String = "",
    val teacherId: String = "",
    val teacherName: String = "",
    val date: String = "", // YYYY-MM-DD
    val checkInTime: String = "", // HH:MM
    val checkOutTime: String = "", // HH:MM
    val status: String = "", // Present, Absent, On Duty, Leave
    val remarks: String = "",
    val dutyLocation: String = "Main Campus"
)

@Entity(tableName = "app_notifications")
data class AppNotification(
    @PrimaryKey val notificationId: String = "",
    val userId: String = "", // recipient user ID or ROLE (e.g., "PRINCIPAL", matching submitter's userId)
    val title: String = "",
    val message: String = "",
    val timestamp: Long = 0L,
    val isRead: Boolean = false,
    val type: String = "INFO" // INFO, APPROVAL_PENDING, APPROVED, REJECTED
)

@Entity(tableName = "class_books")
data class ClassBook(
    @PrimaryKey val bookId: String = "",
    val className: String = "",
    val bookName: String = "",
    val author: String = "",
    val subject: String = "",
    val price: Double = 0.0
)

@Entity(tableName = "issued_books")
data class IssuedBook(
    @PrimaryKey val issueId: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val className: String = "",
    val bookName: String = "",
    val issueDate: String = "",
    val issuedBy: String = "",
    val status: String = "Issued"
)

data class FeeConfig(
    val admissionFee: Double = 2000.0,
    val tuitionFee: Double = 1000.0,
    val gameFee: Double = 150.0,
    val examFee: Double = 500.0,
    val transportSlab1: Double = 400.0,
    val transportSlab2: Double = 800.0,
    val transportSlab3: Double = 1200.0
)
@Entity(tableName = "calendar_events")
data class CalendarEvent(
    @PrimaryKey val id: String = "",
    val date: String = "",
    val title: String = "",
    val description: String = "",
    val type: String = "School Event",
    val time: String = "",
    val targetClass: String = "All",
    val createdBy: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "leave_requests")
data class LeaveRequest(
    @PrimaryKey val requestId: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val className: String = "",
    val startDate: String = "", // YYYY-MM-DD
    val endDate: String = "",
    val reason: String = "",
    val status: String = "", // Pending, Approved, Rejected
    val timestamp: Long = 0L,
    val reviewedBy: String = ""
)
