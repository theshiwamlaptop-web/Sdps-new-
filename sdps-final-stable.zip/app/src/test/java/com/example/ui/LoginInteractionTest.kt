package com.example.ui

import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.repository.SchoolRepositoryImpl
import com.example.ui.screens.PremiumLoginScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LoginInteractionTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var viewModel: SchoolViewModel
    private lateinit var repository: SchoolRepositoryImpl

    @Before
    fun setUp() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = SchoolRepositoryImpl(context, db)
        repository.toggleFirebaseMode(false)
        viewModel = SchoolViewModel(repository)
    }

    @Test
    fun testUserIdFieldInteraction() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        val userIdNode = composeTestRule.onNodeWithTag("login_userid_field")
        userIdNode.assertExists()
        userIdNode.performClick()
        userIdNode.performTextInput("TESTUSER")
        composeTestRule.waitForIdle()
        userIdNode.assertTextContains("TESTUSER")
    }

    @Test
    fun testPasswordFieldInteraction() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        val passwordNode = composeTestRule.onNodeWithTag("login_password_field")
        passwordNode.assertExists()
        passwordNode.performClick()
        passwordNode.performTextInput("Secret123")
        composeTestRule.waitForIdle()
        passwordNode.assertExists()
    }

    @Test
    fun testRoleSelectorInteraction() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        val roleSelector = composeTestRule.onNodeWithTag("role_selector")
        roleSelector.assertExists()
        roleSelector.performClick()
        composeTestRule.waitForIdle()

        val teacherOption = composeTestRule.onNodeWithTag("role_item_class_teacher")
        teacherOption.assertExists()
        teacherOption.performClick()
        composeTestRule.waitForIdle()
        
        roleSelector.assertTextContains("Teacher")
    }

    @Test
    fun testForgotPasswordButtonClickable() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        val forgotBtn = composeTestRule.onNodeWithTag("forgot_password_button")
        forgotBtn.assertExists()
        forgotBtn.performClick()
        composeTestRule.waitForIdle()
    }

    @Test
    fun testFullLoginFlowInteraction() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        val loginButton = composeTestRule.onNodeWithTag("login_button")
        loginButton.assertExists()
        loginButton.assertIsNotEnabled()

        composeTestRule.onNodeWithTag("login_userid_field").performTextInput("theshiwamlaptop@gmail.com")
        composeTestRule.onNodeWithTag("login_password_field").performTextInput("ASDFGHJKL")
        composeTestRule.waitForIdle()

        loginButton.assertIsEnabled()
        loginButton.performClick()
        composeTestRule.waitForIdle()
    }

    @Test
    fun testTabSwitchingAndOtpField() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        val otpTab = composeTestRule.onNodeWithTag("tab_otp")
        otpTab.assertExists()
        otpTab.performClick()
        composeTestRule.waitForIdle()

        val phoneField = composeTestRule.onNodeWithTag("login_phone_field")
        phoneField.assertExists()
        phoneField.performTextInput("+919876543210")
        composeTestRule.waitForIdle()
        phoneField.assertTextContains("+919876543210")

        val sendOtpButton = composeTestRule.onNodeWithTag("login_send_otp_button")
        sendOtpButton.assertExists()
        sendOtpButton.assertIsEnabled()
    }
}
