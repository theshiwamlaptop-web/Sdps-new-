package com.example.ui

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.repository.SchoolRepositoryImpl
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PremiumLoginScreen
import com.example.ui.screens.StudentManagementScreen
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36])
class CriticalScreensUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var viewModel: SchoolViewModel

    @Before
    fun setUp() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repository = SchoolRepositoryImpl(context, db)
        repository.toggleFirebaseMode(false)
        viewModel = SchoolViewModel(repository)
    }

    // --- LOGIN SCREEN TESTS ---

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.Pixel8)
    fun loginScreen_phonePortrait() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/login_phone_portrait.png")
    }

    @Test
    @Config(qualifiers = "w915dp-h412dp-420dpi")
    fun loginScreen_phoneLandscape() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/login_phone_landscape.png")
    }

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.PixelTablet)
    fun loginScreen_tablet() {
        composeTestRule.setContent {
            MyApplicationTheme {
                PremiumLoginScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/login_tablet.png")
    }

    // --- DASHBOARD SCREEN TESTS ---

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.Pixel8)
    fun dashboardScreen_phonePortrait() = runBlocking {
        viewModel.loginUser("theshiwamlaptop@gmail.com", "PRINCIPAL", "Principal User", "ASDFGHJKL")
        composeTestRule.setContent {
            MyApplicationTheme {
                DashboardScreen(viewModel = viewModel, onNavigate = {})
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/dashboard_phone_portrait.png")
    }

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.PixelTablet)
    fun dashboardScreen_tablet() = runBlocking {
        viewModel.loginUser("theshiwamlaptop@gmail.com", "PRINCIPAL", "Principal User", "ASDFGHJKL")
        composeTestRule.setContent {
            MyApplicationTheme {
                DashboardScreen(viewModel = viewModel, onNavigate = {})
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/dashboard_tablet.png")
    }

    // --- STUDENT LIST SCREEN TESTS ---

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.Pixel8)
    fun studentListScreen_phonePortrait() = runBlocking {
        viewModel.loginUser("theshiwamlaptop@gmail.com", "PRINCIPAL", "Principal User", "ASDFGHJKL")
        composeTestRule.setContent {
            MyApplicationTheme {
                StudentManagementScreen(viewModel = viewModel, onNavigate = {})
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/student_list_phone_portrait.png")
    }

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.PixelTablet)
    fun studentListScreen_tablet() = runBlocking {
        viewModel.loginUser("theshiwamlaptop@gmail.com", "PRINCIPAL", "Principal User", "ASDFGHJKL")
        composeTestRule.setContent {
            MyApplicationTheme {
                StudentManagementScreen(viewModel = viewModel, onNavigate = {})
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/student_list_tablet.png")
    }

    // --- CHAT SCREEN TESTS ---

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.Pixel8)
    fun chatScreen_studentView() = runBlocking {
        viewModel.loginUser("SDPS-STU-01", "STUDENT", "Student User", "01-01-2010")
        composeTestRule.setContent {
            MyApplicationTheme {
                ChatScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/chat_student_view.png")
    }

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.Pixel8)
    fun chatScreen_teacherView() = runBlocking {
        viewModel.loginUser("tchr.nursery", "CLASS_TEACHER", "Teacher User", "01-01-1985")
        composeTestRule.setContent {
            MyApplicationTheme {
                ChatScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/chat_teacher_view.png")
    }

    @Test
    @Config(qualifiers = RobolectricDeviceQualifiers.Pixel8)
    fun chatScreen_principalPrivacyBlocked() = runBlocking {
        viewModel.loginUser("theshiwamlaptop@gmail.com", "PRINCIPAL", "Principal User", "ASDFGHJKL")
        composeTestRule.setContent {
            MyApplicationTheme {
                ChatScreen(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onRoot().captureRoboImage("src/test/screenshots/chat_principal_blocked.png")
    }
}
