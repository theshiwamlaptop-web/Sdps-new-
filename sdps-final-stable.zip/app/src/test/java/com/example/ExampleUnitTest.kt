package com.example

import org.junit.Test
import java.io.File

class ExampleUnitTest {
    @Test
    fun findUnbalancedBraces() {
        val file = File("src/main/java/com/example/ui/screens/SchoolAppScreens.kt")
        if (!file.exists()) {
            println("File does not exist at absolute path: ${file.absolutePath}")
            return
        }
        
        val lines = file.readLines()
        var depth = 0
        var inMultiLineComment = false
        
        println("=== BRACE LEVEL ANALYSIS ===")
        for (i in lines.indices) {
            val line = lines[i]
            val lineNumber = i + 1
            
            // Analyze characters in the line
            var j = 0
            var inSingleLineComment = false
            var inString = false
            var stringChar = ' '
            
            while (j < line.length) {
                val c = line[j]
                
                if (inMultiLineComment) {
                    if (c == '*' && j + 1 < line.length && line[j + 1] == '/') {
                        inMultiLineComment = false
                        j += 2
                        continue
                    }
                } else if (inSingleLineComment) {
                    break // Rest of the line is a comment
                } else if (inString) {
                    if (c == '\\') {
                        j += 2 // Skip escaped character
                        continue
                    }
                    if (c == stringChar) {
                        inString = false
                    }
                } else {
                    // Check comment starts
                    if (c == '/' && j + 1 < line.length) {
                        if (line[j + 1] == '/') {
                            inSingleLineComment = true
                            j += 2
                            continue
                        } else if (line[j + 1] == '*') {
                            inMultiLineComment = true
                            j += 2
                            continue
                        }
                    }
                    
                    // Check string starts
                    if (c == '"' || c == '\'') {
                        inString = true
                        stringChar = c
                    }
                    
                    // Check brace increments/decrements
                    if (c == '{') {
                        depth++
                        // Print increments for major functions to trace blocks
                        if (depth == 1) {
                            println("Line $lineNumber: Open block level 1: ${line.trim()}")
                        }
                    } else if (c == '}') {
                        depth--
                        if (depth < 0) {
                            println("Line $lineNumber: ERROR - Unmatched closing brace! ${line.trim()}")
                        }
                        if (depth == 0) {
                            println("Line $lineNumber: Closes block level 1: ${line.trim()}")
                        }
                    }
                }
                j++
            }
        }
        println("==============================")
        println("Final depth at end of file: $depth")
        assert(depth == 0) { "Brace depth is unbalanced! Final depth is $depth" }
    }
}
