package com.example.data.repository

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.ChatMessage
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest=Config.NONE)
class SchoolRepositoryTest {

    @Test
    fun testLoginFlows() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val repository = SchoolRepositoryImpl(context, db)
        
        // Disable Firebase mode for local testing
        repository.toggleFirebaseMode(false)

        val accounts = listOf(
            Triple("theshiwamlaptop@gmail.com", "PRINCIPAL", "23-07-2010"),
            Triple("SDPS-ADM-01", "ADMIN", "01-01-1980"),
            Triple("tchr.nursery", "CLASS_TEACHER", "01-01-1985"),
            Triple("SDPS-STU-01", "STUDENT", "01-01-2010")
        )

        for ((id, role, pass) in accounts) {
            println("Testing login for: $id")
            val result = repository.login(id, role, "Test Name", pass)
            assertTrue("Login failed for $id: ${result.exceptionOrNull()?.message}", result.isSuccess)
            
            val user = result.getOrNull()
            assertTrue("User is null", user != null)
            assertTrue("Role mismatch: expected $role but got ${user?.role}", user?.role == role || (user?.role == "TEACHER" && role == "CLASS_TEACHER") || (user?.role == "CLASS_TEACHER" && role == "TEACHER"))
        }
    }

    @Test
    fun testChatMessageLifecycle() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val repository = SchoolRepositoryImpl(context, db)
        repository.toggleFirebaseMode(false)

        val testMessage = com.example.data.model.ChatMessage(
            messageId = "CHAT_TEST_001",
            senderId = "T201",
            receiverId = "S101",
            message = "Hello, please review your class homework assignment.",
            timestamp = System.currentTimeMillis(),
            isRead = false,
            status = "sent"
        )

        // 1. Send message
        val sendRes = repository.sendMessage(testMessage)
        assertTrue("Message send should succeed", sendRes.isSuccess)

        // 2. Query messages
        val chats = repository.getAllChats().first()
        assertTrue("Chat list should contain test message", chats.any { it.messageId == "CHAT_TEST_001" })

        // 3. Mark as read
        val markReadRes = repository.markMessagesAsRead(senderId = "T201", receiverId = "S101")
        assertTrue("Mark messages as read should succeed", markReadRes.isSuccess)

        val updatedChats = repository.getAllChats().first()
        val readMsg = updatedChats.find { it.messageId == "CHAT_TEST_001" }
        assertTrue("Message should be marked as read", readMsg?.isRead == true)

        // 4. Delete message
        val deleteRes = repository.deleteChatMessage("CHAT_TEST_001")
        assertTrue("Delete message should succeed", deleteRes.isSuccess)

        val finalChats = repository.getAllChats().first()
        assertTrue("Chat list should not contain deleted message", finalChats.none { it.messageId == "CHAT_TEST_001" })
    }
}
