import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

# Add deletion logic after saving the master principal
old_master = """                        val doc = kotlinx.coroutines.withTimeoutOrNull(5000) { fs.collection("users").document("theshiwamlaptop@gmail.com").get().await() }
                        // Overwrite with correct details
                        fs.collection("users").document("theshiwamlaptop@gmail.com").set(masterUser).await()
                    } catch (e: Exception) {}"""

new_master = """                        val doc = kotlinx.coroutines.withTimeoutOrNull(5000) { fs.collection("users").document("theshiwamlaptop@gmail.com").get().await() }
                        // Overwrite with correct details
                        fs.collection("users").document("theshiwamlaptop@gmail.com").set(masterUser).await()
                        
                        // Delete all other principals
                        val allPrincipals = fs.collection("users").whereEqualTo("role", "PRINCIPAL").get().await()
                        allPrincipals.documents.forEach { pDoc ->
                            if (pDoc.id != "theshiwamlaptop@gmail.com") {
                                fs.collection("users").document(pDoc.id).delete().await()
                            }
                        }
                    } catch (e: Exception) {}"""

content = content.replace(old_master, new_master)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
