import os

filepath = "app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt"
with open(filepath, "r") as f:
    content = f.read()

if "import androidx.compose.ui.draw.clip" in content:
    content = content.replace("import androidx.compose.ui.draw.clip", "import androidx.compose.ui.draw.clip\nimport androidx.compose.ui.draw.drawBehind")
    with open(filepath, "w") as f:
        f.write(content)
    print("Success")
else:
    print("import not found")
