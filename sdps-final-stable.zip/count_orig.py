with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    lines = f.readlines()

for i in range(977, 1145):
    line = lines[i]
    if '{' in line or '}' in line:
        print(f"{i+1}: {line.strip()}")
