import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

# For myStudent call
target1 = """                    StudentDetailDialogLayout(
                        student = myStudent,
                        fee = studentFee,
                        attendance = studentAttendance,
                        onDismiss = {},
                        canEdit = isManagement,
                        onSave = { updated -> viewModel.updateStudent(updated) },
                        onOpenFeeLedger = {
                            selectedStudentForFeeLedger = myStudent
                        }
                    )"""
repl1 = """                    StudentDetailDialogLayout(
                        student = myStudent,
                        fee = studentFee,
                        attendance = studentAttendance,
                        onDismiss = {},
                        canEdit = isManagement,
                        onSave = { updated -> viewModel.updateStudent(updated) },
                        onOpenFeeLedger = {
                            selectedStudentForFeeLedger = myStudent
                        },
                        showUserId = (roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN"),
                        allStudents = students,
                        currentUser = currentUser
                    )"""
content = content.replace(target1, repl1)

# For selectedStudentForIDCard call
target2 = """            StudentDetailDialogLayout(
                student = currentStudent,
                fee = studentFee,
                attendance = studentAttendance,
                onDismiss = { selectedStudentForIDCard = null },
                canEdit = isManagement,
                onSave = { updated -> viewModel.updateStudent(updated); selectedStudentForIDCard = updated },
                onOpenFeeLedger = {
                    selectedStudentForFeeLedger = currentStudent
                    selectedStudentForIDCard = null
                }
            )"""
repl2 = """            StudentDetailDialogLayout(
                student = currentStudent,
                fee = studentFee,
                attendance = studentAttendance,
                onDismiss = { selectedStudentForIDCard = null },
                canEdit = roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN" || (roleStr == "CLASS_TEACHER" && currentStudent.className.equals(teacherClass, ignoreCase = true)),
                onSave = { updated -> viewModel.updateStudent(updated); selectedStudentForIDCard = updated },
                onOpenFeeLedger = {
                    selectedStudentForFeeLedger = currentStudent
                    selectedStudentForIDCard = null
                },
                showUserId = (roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN"),
                allStudents = students,
                currentUser = currentUser
            )"""
content = content.replace(target2, repl2)

# For selectedStudentDialog in SchoolDirectoryScreen
target3 = """                StudentDetailDialogLayout(
                    student = currentStudent,
                    fee = studentFee,
                    attendance = studentAttendance,
                    onDismiss = { selectedStudentDialog = null },
                    canEdit = isManagement,
                    onSave = { updated -> viewModel.updateStudent(updated); selectedStudentDialog = updated },
                    onOpenFeeLedger = {
                        // Not handling fee ledger from directory to keep it simple, or handle if needed
                    }
                )"""
repl3 = """                StudentDetailDialogLayout(
                    student = currentStudent,
                    fee = studentFee,
                    attendance = studentAttendance,
                    onDismiss = { selectedStudentDialog = null },
                    canEdit = roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN" || (roleStr == "CLASS_TEACHER" && currentStudent.className.equals(teacherClass, ignoreCase = true)),
                    onSave = { updated -> viewModel.updateStudent(updated); selectedStudentDialog = updated },
                    onOpenFeeLedger = {},
                    showUserId = (roleStr == "PRINCIPAL" || roleStr == "ADMIN" || roleStr == "HEAD_ADMIN"),
                    allStudents = viewModel.studentsState.collectAsState().value,
                    currentUser = currentUser
                )"""
content = content.replace(target3, repl3)

with open(filepath, 'w') as f:
    f.write(content)

