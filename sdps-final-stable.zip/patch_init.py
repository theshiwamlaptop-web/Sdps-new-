import re

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'r') as f:
    content = f.read()

init_block = '''    init {
        viewModelScope.launch {
            // Silently seed standard students in background per prompt requirements
            try {
                repository.seed10StudentsPerClass()
            } catch (e: Exception) {
                // Ignore silent failure
            }
        }
        viewModelScope.launch {
            // Perform safe school structure migration on startup
            try {
                repository.performSchoolStructureMigration()
            } catch (e: Exception) {
                // Ignore silent failure
            }
        }
        viewModelScope.launch {
            _isSessionChecking.value = true
            try {
                val restored = repository.checkAndRestoreSession()
                updateNavigationTargetForUser(restored)
            } catch (e: Exception) {
                android.util.Log.e("SchoolViewModel", "Initial session restoration bypass: ${e.message}")
                _loginError.value = e.message ?: "डेटा त्रुटि या अमान्य रिकॉर्ड मिला! हटा दिया गया। कृपया फिर से लॉगिन करें।"
                repository.logout()
                _navigationState.value = NavigationTarget.LOGIN_SCREEN
            } finally {
                _isSessionChecking.value = false
            }
        }
        viewModelScope.launch {
            repository.currentUserFlow.collect { user -> 
                 if (user != null && (user.role == "CLASS_TEACHER" || user.role == "TEACHER")) {
                    _selectedClassForAttendance.value = user.className.trim()
                }
            }
        }
    }'''

content = content.replace(init_block, "")

# insert right before the last closing brace
last_brace = content.rfind('}')
if last_brace != -1:
    content = content[:last_brace] + init_block + "\n" + content[last_brace:]

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'w') as f:
    f.write(content)
