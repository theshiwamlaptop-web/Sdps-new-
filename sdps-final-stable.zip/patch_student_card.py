import re
with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

t = """                            canDelete = isManagement,
                            onDeleteClick = {
                                viewModel.deleteStudent(student.studentId)
                                Toast.makeText(context, "Student soft-deleted", Toast.LENGTH_SHORT).show()
                            },"""
r = """                            canDelete = isManagement,
                            onDeleteClick = {
                                val currentUserId = currentUser?.userId ?: ""
                                val currentUserName = currentUser?.name ?: "Admin"
                                val currentRole = currentUser?.role?.uppercase() ?: ""
                                
                                if (currentRole == "PRINCIPAL") {
                                    viewModel.deleteUserAccount(student.studentId)
                                    viewModel.deleteStudent(student.studentId)
                                    Toast.makeText(context, "Student deleted permanently.", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.requestDeletion(
                                        targetId = student.studentId,
                                        targetType = "STUDENT",
                                        targetName = student.name,
                                        requesterName = currentUserName,
                                        requesterId = currentUserId
                                    )
                                    Toast.makeText(context, "Deletion request sent to Principal.", Toast.LENGTH_SHORT).show()
                                }
                            },"""

content = content.replace(t, r)

t2 = """    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Confirm Soft Deletion") },
            text = { Text("Are you sure you want to soft-delete ${student.name}? Full student archive will be preserved on the cloud under auditing records.") },
            confirmButton = {"""
r2 = """    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Confirmation") },
            text = { Text("Are you sure you want to delete ${student.name}? Principals perform permanent deletion, Admins will send a request to the Principal.") },
            confirmButton = {"""
content = content.replace(t2, r2)
            
with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
    f.write(content)
