import android.net.ConnectivityManager
import android.net.NetworkCapabilities
fun main() {
    println(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}
