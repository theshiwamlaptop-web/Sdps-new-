import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

bad = '''        // 1. Students Synchronization Listeners
        try {
            val listener = fs.collection("students").addSnapshotListener { snapshot, error ->
                android.util.Log.d("DEBUG_NET", "SnapshotListener [students] triggered, error: ${error?.message}")'''

good = '''        // 1. Students Synchronization Listeners
        try {
            val listener = fs.collection("students").addSnapshotListener { snapshot, error ->
                android.util.Log.d("DEBUG_TRACE", "SnapshotListener [students] triggered, error: ${error?.message}, snapshot size: ${snapshot?.size()}")'''

content = content.replace(bad, good)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
