def find_unclosed():
    with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
        lines = f.readlines()
    stack = []
    for i, line in enumerate(lines):
        clean = line.strip()
        if clean.startswith('//'): continue
        for char in clean:
            if char == '{': stack.append(i+1)
            elif char == '}': 
                if stack: stack.pop()
    print(f"Unclosed braces overall: {stack}")
    for idx in stack:
        print(f"Line {idx}: {lines[idx-1].strip()}")

find_unclosed()
