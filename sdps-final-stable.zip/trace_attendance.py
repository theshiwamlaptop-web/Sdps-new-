import sys

def check():
    with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", 'r', encoding='utf-8') as f:
        lines = f.readlines()
        
    count = 1
    for line_num in range(4128, 4610):
        line = lines[line_num]
        
        # very simple brace counter
        for c in line:
            if c == '{': count += 1
            elif c == '}': count -= 1
            
        print(f"L{line_num+1}: {count} {line.strip()[:40]}")
        if count == 0:
            print(f"REACHED ZERO AT {line_num+1}!")
            break
            
check()
