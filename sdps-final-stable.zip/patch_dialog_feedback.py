import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

target = """                        var saveError by remember { mutableStateOf("") }
                        if (saveError.isNotEmpty()) {
                            Text(saveError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
                        }
                        TextButton(onClick = {
                            if (editName.isBlank() || editClass.isBlank() || editRollNo.isBlank()) {
                                saveError = "Name, Class, and Roll No are mandatory."
                                return@TextButton
                            }
                            
                            val updated = student.copy(
                                name = editName,
                                className = editClass,
                                rollNo = editRollNo,
                                DOB = editDOB,
                                gender = editGender,
                                fatherName = editFather,
                                motherName = editMother,
                                guardianName = editGuardian,
                                phone = editPhone,
                                address = editAddress,
                                dateOfAdmission = editDateOfAdmission,
                                status = editStatus,
                                linkedSiblings = editLinkedSiblings,
                                lastModifiedBy = currentUser?.name ?: "Unknown",
                                lastModifiedAt = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                            )
                            onSave(updated)
                            isEditing = false
                        }) {
                            Text("Save")
                        }"""

replacement = """                        var saveError by remember { mutableStateOf("") }
                        var showConfirmation by remember { mutableStateOf(false) }
                        val context = LocalContext.current
                        var isSaving by remember { mutableStateOf(false) }
                        
                        if (saveError.isNotEmpty()) {
                            Text(saveError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
                        }
                        
                        if (showConfirmation) {
                            AlertDialog(
                                onDismissRequest = { showConfirmation = false },
                                title = { Text("Confirm Update") },
                                text = { Text("Are you sure you want to update ${student.name}'s details?") },
                                confirmButton = {
                                    TextButton(onClick = {
                                        showConfirmation = false
                                        isSaving = true
                                        val updated = student.copy(
                                            name = editName,
                                            className = editClass,
                                            rollNo = editRollNo,
                                            DOB = editDOB,
                                            gender = editGender,
                                            fatherName = editFather,
                                            motherName = editMother,
                                            guardianName = editGuardian,
                                            phone = editPhone,
                                            address = editAddress,
                                            dateOfAdmission = editDateOfAdmission,
                                            status = editStatus,
                                            linkedSiblings = editLinkedSiblings,
                                            lastModifiedBy = currentUser?.name ?: "Unknown",
                                            lastModifiedAt = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                                        )
                                        // Simulate small delay for loading state
                                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                            onSave(updated)
                                            isSaving = false
                                            isEditing = false
                                            Toast.makeText(context, "Student profile updated successfully!", Toast.LENGTH_SHORT).show()
                                        }, 500)
                                    }) { Text("Confirm") }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showConfirmation = false }) { Text("Cancel") }
                                }
                            )
                        }

                        TextButton(onClick = {
                            if (editName.isBlank() || editClass.isBlank() || editRollNo.isBlank()) {
                                saveError = "Name, Class, and Roll No are mandatory."
                                return@TextButton
                            }
                            showConfirmation = true
                        }, enabled = !isSaving) {
                            if (isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Saving...")
                            } else {
                                Text("Save")
                            }
                        }"""
content = content.replace(target, replacement)
with open(filepath, 'w') as f:
    f.write(content)

