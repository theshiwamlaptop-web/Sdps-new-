import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    text = f.read()

text = text.replace('Log.e("SchoolRepository", "❌ Firebase Auth', 'Log.d("SchoolRepository", "Firebase Auth')
text = text.replace('Log.e("SchoolRepository", "❌ Default FirebaseApp', 'Log.d("SchoolRepository", "Default FirebaseApp')

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(text)

