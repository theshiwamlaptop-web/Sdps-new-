import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

target = """        // Logo
        Box(
            modifier = Modifier.size(96.dp).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.School,
                contentDescription = "School Logo",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
        }"""

replacement = """        // Logo with Golden Radial Shadow
        Box(
            modifier = Modifier
                .size(140.dp)
                .background(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(Color(0xFFFFB703).copy(alpha = 0.3f), Color.Transparent),
                        radius = 200f
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo_sdps),
                contentDescription = "School Logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(120.dp).padding(8.dp)
            )
        }"""

content = content.replace(target, replacement)
with open(filepath, 'w') as f:
    f.write(content)

