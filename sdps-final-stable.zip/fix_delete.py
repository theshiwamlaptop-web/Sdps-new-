with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

text = text.replace("""                                if (idToDelete != user.userId) {
                                    selectedUser = user
                                } else {
                                Toast.makeText(context, "Deletions failed. Please try again.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },""", """                                if (idToDelete != user.userId) {
                                    selectedUser = user
                                }
                            } else {
                                Toast.makeText(context, "Deletions failed. Please try again.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },""")

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
