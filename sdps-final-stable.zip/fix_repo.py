import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

# I will just revert my previous patch conceptually or fix it directly using regex

# First, fix the broken implementation
bad_impl = "override suspend fun checkStudentExists(studentId: String): Boolean\n    suspend fun addStudent(student: Student): Result<Unit> {"

good_impl = """override suspend fun checkStudentExists(studentId: String): Boolean {
        return try {
            val localExists = db.studentDao().getStudentById(studentId) != null
            if (localExists) return true
            val fs = firestore
            if (fs != null) {
                val doc = fs.collection("students").document(studentId).get().await()
                return doc.exists()
            }
            return false
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun addStudent(student: Student): Result<Unit> {"""

content = content.replace(bad_impl, good_impl)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
