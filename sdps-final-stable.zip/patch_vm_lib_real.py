import re

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'r') as f:
    content = f.read()

old_save = """    fun saveClassBook(book: ClassBook) {
        viewModelScope.launch {
            repository.saveClassBook(book)
        }
    }"""
new_save = """    fun saveClassBook(book: ClassBook) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT" || role == "PARENT") {
                _toastMessage.value = "Unauthorized"
                return@launch
            }
            repository.saveClassBook(book)
        }
    }"""
content = content.replace(old_save, new_save)

old_del = """    fun deleteClassBook(bookId: String) {
        viewModelScope.launch {
            repository.deleteClassBook(bookId)
        }
    }"""
new_del = """    fun deleteClassBook(bookId: String) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT" || role == "PARENT") {
                _toastMessage.value = "Unauthorized"
                return@launch
            }
            repository.deleteClassBook(bookId)
        }
    }"""
content = content.replace(old_del, new_del)

old_issue = """    fun issueBook(issuedBook: IssuedBook) {
        viewModelScope.launch {
            repository.issueBook(issuedBook)
        }
    }"""
new_issue = """    fun issueBook(issuedBook: IssuedBook) {
        viewModelScope.launch {
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT" || role == "PARENT") {
                _toastMessage.value = "Unauthorized"
                return@launch
            }
            repository.issueBook(issuedBook)
        }
    }"""
content = content.replace(old_issue, new_issue)

old_del_iss = """    fun deleteIssuedBook(issueId: String) {
        viewModelScope.launch { repository.deleteIssuedBook(issueId) }
    }"""
new_del_iss = """    fun deleteIssuedBook(issueId: String) {
        viewModelScope.launch { 
            val role = repository.currentUserFlow.value?.role?.uppercase()?.trim() ?: ""
            if (role == "STUDENT" || role == "PARENT") {
                _toastMessage.value = "Unauthorized"
                return@launch
            }
            repository.deleteIssuedBook(issueId) 
        }
    }"""
content = content.replace(old_del_iss, new_del_iss)

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'w') as f:
    f.write(content)
