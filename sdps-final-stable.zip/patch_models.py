with open("app/src/main/java/com/example/data/model/Models.kt", "r") as f:
    c = f.read()

t = """data class Teacher(
    @PrimaryKey val teacherId: String = "",
    val name: String = "",
    val subject: String = "",
    val classesAssigned: String = "", // Comma-separated or descriptive string
    val phone: String = "",
    val email: String = "",
    val classTeacherOf: String = "", // exact field required by user for transaction demotion"""

r = """data class Teacher(
    @PrimaryKey val teacherId: String = "",
    val name: String = "",
    val subject: String = "",
    val gender: String = "Male",
    val classesAssigned: String = "", // Comma-separated or descriptive string
    val phone: String = "",
    val email: String = "",
    val classTeacherOf: String = "", // exact field required by user for transaction demotion"""

c = c.replace(t, r)

with open("app/src/main/java/com/example/data/model/Models.kt", "w") as f:
    f.write(c)
