import re

with open("app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt", "r") as f:
    content = f.read()

old_block = """    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgBrush)
            .windowInsetsPadding(WindowInsets.ime),
        contentAlignment = Alignment.Center
    ) {"""

new_block = """    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind { drawRect(bgBrush) }
            .windowInsetsPadding(WindowInsets.ime),
        contentAlignment = Alignment.Center
    ) {"""

content = content.replace(old_block, new_block)
content = content.replace("import androidx.compose.ui.draw.clip", "import androidx.compose.ui.draw.clip\nimport androidx.compose.ui.draw.drawBehind")

with open("app/src/main/java/com/example/ui/screens/PremiumLoginScreen.kt", "w") as f:
    f.write(content)
