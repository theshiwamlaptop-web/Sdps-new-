import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

# Update password check and object creation
old_principal = """            val isMasterPrincipal = (processedId == "theshiwamlaptop@gmail.com" || processedId == "9523256847")
            if (isMasterPrincipal) {
                if (password != "password123") {
                    return Result.failure(Exception("गलत पासवर्ड!"))
                }
                var masterUser = db.userDao().getUser("theshiwamlaptop@gmail.com")
                if (masterUser == null) {
                    masterUser = User(
                        userId = "theshiwamlaptop@gmail.com",
                        uid = firebaseAuth?.currentUser?.uid ?: "",
                        name = "Master Principal",
                        role = "PRINCIPAL",
                        roleCode = "HA-99",
                        email = "theshiwamlaptop@gmail.com",
                        phone = "9523256847",
                        passwordHash = sha256Hex("password123"),
                        isFirstLogin = false,
                        className = "All"
                    )
                    db.userDao().insertUser(masterUser)
                }
                val fs = firestore
                if (fs != null) {
                    try {
                        val doc = kotlinx.coroutines.withTimeoutOrNull(5000) { fs.collection("users").document("theshiwamlaptop@gmail.com").get().await() }
                        if (doc == null || !doc.exists()) {
                            fs.collection("users").document("theshiwamlaptop@gmail.com").set(masterUser).await()
                        }
                    } catch (e: Exception) {}
                }
                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value) {
                    try {
                        try { auth.signInWithEmailAndPassword("theshiwamlaptop@gmail.com", "password123").await() } 
                        catch (ae: Exception) { auth.createUserWithEmailAndPassword("theshiwamlaptop@gmail.com", "password123").await() }"""

new_principal = """            val isMasterPrincipal = (processedId == "theshiwamlaptop@gmail.com" || processedId == "9523256847")
            if (isMasterPrincipal) {
                if (password != "ASDFGHJKL") {
                    return Result.failure(Exception("गलत पासवर्ड!"))
                }
                var masterUser = db.userDao().getUser("theshiwamlaptop@gmail.com")
                if (masterUser == null || masterUser.name != "Shiwam Sir") {
                    masterUser = User(
                        userId = "theshiwamlaptop@gmail.com",
                        uid = firebaseAuth?.currentUser?.uid ?: "",
                        name = "Shiwam Sir",
                        role = "PRINCIPAL",
                        roleCode = "HA-99",
                        email = "theshiwamlaptop@gmail.com",
                        phone = "9523256847",
                        passwordHash = sha256Hex("ASDFGHJKL"),
                        isFirstLogin = false,
                        className = "All"
                    )
                    db.userDao().insertUser(masterUser)
                }
                val fs = firestore
                if (fs != null) {
                    try {
                        val doc = kotlinx.coroutines.withTimeoutOrNull(5000) { fs.collection("users").document("theshiwamlaptop@gmail.com").get().await() }
                        // Overwrite with correct details
                        fs.collection("users").document("theshiwamlaptop@gmail.com").set(masterUser).await()
                    } catch (e: Exception) {}
                }
                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value) {
                    try {
                        try { auth.signInWithEmailAndPassword("theshiwamlaptop@gmail.com", "ASDFGHJKL").await() } 
                        catch (ae: Exception) { 
                            try { auth.createUserWithEmailAndPassword("theshiwamlaptop@gmail.com", "ASDFGHJKL").await() }
                            catch(createEx: Exception) {
                                // If password changed but user exists, we might need to update password or just fail. 
                                // To be safe, just try signing in again.
                            }
                        }"""

content = content.replace(old_principal, new_principal)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
