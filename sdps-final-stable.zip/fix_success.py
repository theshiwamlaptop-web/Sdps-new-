import re
with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

pattern = r"(\s+selectedUser = user\s+)\} else \{"
replacement = r"\1}\n                            } else {"
text = re.sub(pattern, replacement, text)

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
