import re

with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

content = content.replace("viewModel.login(userId, password, selectedRole)", "viewModel.loginUser(userId, selectedRole, \"\", password)")
content = content.replace("viewModel.verifyOTPAndLogin(verificationId, otpCode, context)", "viewModel.verifyOtpAndLogin(verificationId, otpCode, phoneInput)")

send_otp_old = """viewModel.sendOTP(phoneInput, activity) { vId ->
                                verificationId = vId
                            }"""
send_otp_new = """viewModel.startPhoneVerification(phoneInput, activity, { vId -> verificationId = vId }, { /* error */ })"""
content = content.replace(send_otp_old, send_otp_new)

reset_pwd_old = """viewModel.resetPassword(resetInput, context)"""
reset_pwd_new = """viewModel.sendPasswordReset(resetInput, {}, {})"""
content = content.replace(reset_pwd_old, reset_pwd_new)

with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
    f.write(content)
print("Patched Login methods successfully")
