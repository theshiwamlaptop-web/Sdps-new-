import re

with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

start_idx = content.find("fun LoginScreen(viewModel: SchoolViewModel)")
if start_idx != -1:
    end_idx = content.find("// 4. TEACHER MANAGEMENT", start_idx)
    if end_idx != -1:
        new_content = content[:start_idx] + content[end_idx:]
        with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
            f.write(new_content)
        print("Successfully removed old LoginScreen")
    else:
        print("Could not find end of old LoginScreen")
else:
    print("Could not find old LoginScreen")
