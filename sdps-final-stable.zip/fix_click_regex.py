import re
with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

pattern = r"\)\s*,\s*modifier = Modifier\.testTag\(\"submit_change_password\"\)"
replacement = r")\n                        }\n                    },\n                    modifier = Modifier.testTag(\"submit_change_password\")"
text = re.sub(pattern, replacement, text)

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
