import re
with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

text = re.sub(r'\}\s*\}\s*1 -> \{ // CLASSES COMPREHENSIVE ASSIGNMENT', r'}\n                        }\n                    }\n                }\n                1 -> { // CLASSES COMPREHENSIVE ASSIGNMENT', text)

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
