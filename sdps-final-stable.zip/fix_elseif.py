with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

import re
# Fix extra closing braces before `else` and `else if`
text = re.sub(r'\}\s*\n\s*\}\s*else', '} else', text)

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)

