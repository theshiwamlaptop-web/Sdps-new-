import re

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'r') as f:
    content = f.read()

target = """    fun addOrUpdateStudent(student: Student) {
        viewModelScope.launch {
            val user = repository.currentUserFlow.value"""

replacement = """    fun addOrUpdateStudent(student: Student) {
        viewModelScope.launch {
            android.util.Log.d("SchoolViewModel", "Adding student: ${student.name}, FirebaseAuth current user: ${com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid}")
            val user = repository.currentUserFlow.value"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched SchoolViewModel")
else:
    print("Not found in SchoolViewModel")
