import re

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    text = f.read()

pattern = r'        val scrollBehavior = TopAppBarDefaults\.enterAlwaysScrollBehavior\(rememberTopAppBarState\(\)\)\n        Scaffold\(\n            modifier = modifier\.nestedScroll\(scrollBehavior\.nestedScrollConnection\),'
replacement = """        val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
        val isDashboardOrLogin = currentScreen == AppScreen.LOGIN || currentScreen == AppScreen.SPLASH || currentScreen == AppScreen.DASHBOARD
        Scaffold(
            modifier = if (isDashboardOrLogin) modifier else modifier.nestedScroll(scrollBehavior.nestedScrollConnection),"""

text = re.sub(pattern, replacement, text)

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(text)

