import re
import os

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

# Update signature
old_sig = """@Composable
fun StudentDetailDialogLayout(
    student: Student,
    fee: Fee?,
    attendance: List<Attendance>,
    onDismiss: () -> Unit,
    onOpenFeeLedger: () -> Unit = {},
    canEdit: Boolean = false,
    onSave: (Student) -> Unit = {}
) {"""

new_sig = """@Composable
fun StudentDetailDialogLayout(
    student: Student,
    fee: Fee?,
    attendance: List<Attendance>,
    onDismiss: () -> Unit,
    onOpenFeeLedger: () -> Unit = {},
    canEdit: Boolean = false,
    onSave: (Student) -> Unit = {},
    showUserId: Boolean = false,
    allStudents: List<Student> = emptyList(),
    currentUser: User? = null
) {"""

content = content.replace(old_sig, new_sig)

# find the save button click
old_save = """                        TextButton(onClick = {
                            val updated = student.copy(
                                name = editName,
                                className = editClass,
                                rollNo = editRollNo,
                                DOB = editDOB,
                                gender = editGender,
                                fatherName = editFather,
                                motherName = editMother,
                                guardianName = editGuardian,
                                phone = editPhone,
                                address = editAddress,
                                dateOfAdmission = editDateOfAdmission,
                                status = editStatus,
                                linkedSiblings = editLinkedSiblings
                            )
                            onSave(updated)
                            isEditing = false
                        }) {
                            Text("Save")
                        }"""

new_save = """                        var saveError by remember { mutableStateOf("") }
                        if (saveError.isNotEmpty()) {
                            Text(saveError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
                        }
                        TextButton(onClick = {
                            if (editName.isBlank() || editClass.isBlank() || editRollNo.isBlank()) {
                                saveError = "Name, Class, and Roll No are mandatory."
                                return@TextButton
                            }
                            
                            val updated = student.copy(
                                name = editName,
                                className = editClass,
                                rollNo = editRollNo,
                                DOB = editDOB,
                                gender = editGender,
                                fatherName = editFather,
                                motherName = editMother,
                                guardianName = editGuardian,
                                phone = editPhone,
                                address = editAddress,
                                dateOfAdmission = editDateOfAdmission,
                                status = editStatus,
                                linkedSiblings = editLinkedSiblings,
                                lastModifiedBy = currentUser?.name ?: "Unknown",
                                lastModifiedAt = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                            )
                            onSave(updated)
                            isEditing = false
                        }) {
                            Text("Save")
                        }"""
content = content.replace(old_save, new_save)

with open(filepath, 'w') as f:
    f.write(content)
