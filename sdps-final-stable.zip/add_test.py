import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

target = """            // ONE-TIME FORCE SYNC FOR THE USER"""

replacement = """            // TEST ID FOR USER VERIFICATION
            if (fs != null) {
                try {
                    val testStudent = Student(
                        studentId = "S-TEST-999",
                        name = "Firebase Verification Student",
                        className = "Class 10",
                        section = "A",
                        rollNo = "999",
                        dob = "2010-01-01",
                        fatherName = "Test Father",
                        motherName = "Test Mother",
                        phone = "9999999999",
                        address = "Test Address",
                        admissionNo = "ADM-999",
                        photoUrl = ""
                    )
                    fs.collection("students").document("S-TEST-999").set(testStudent).await()
                    db.studentDao().insertStudent(testStudent)
                    android.util.Log.d("SchoolRepository", "Successfully inserted TEST STUDENT to Firebase!")
                } catch (e: Exception) {
                    android.util.Log.e("SchoolRepository", "Failed to insert test student to Firebase", e)
                }
            }

            // ONE-TIME FORCE SYNC FOR THE USER"""

if target in content:
    content = content.replace(target, replacement)
    print("Added Test Student")

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)

