import re

with open("sync.kt", "r") as f:
    sync_code = f.read()

# We can replace the scope.launch blocks.
# For Student:
sync_code = sync_code.replace("""                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.studentDao().insertStudent(student)
                            }
                        }""", """                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            studentsToInsert.add(student)
                        } else {
                            scope.launch { db.studentDao().deleteStudentById(student.studentId) }
                        }""")

sync_code = sync_code.replace("""                snapshot?.documentChanges?.forEach { change ->""", """                val studentsToInsert = mutableListOf<Student>()
                snapshot?.documentChanges?.forEach { change ->""")

sync_code = sync_code.replace("""            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register students listener", e)
        }""", """                scope.launch { if (studentsToInsert.isNotEmpty()) db.studentDao().insertStudents(studentsToInsert) }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register students listener", e)
        }""")

with open("sync_fixed.kt", "w") as f:
    f.write(sync_code)
