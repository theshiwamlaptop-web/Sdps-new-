    private fun startBackgroundFirebaseSync() {
        val fs = firestore ?: return
        if (firebaseAuth?.currentUser == null) {
            android.util.Log.d("SchoolRepository", "Skipping background sync: User is not authenticated.")
            return
        }
        android.util.Log.d("DEBUG_TRACE", "startBackgroundFirebaseSync() called")
        Log.d("SchoolRepository", "Initializing Real-time Firestore to Room Background Sync...")

        // Clear existing listeners to prevent duplicates if called multiple times (e.g., after login)
        snapshotListeners.forEach { it.remove() }
        snapshotListeners.clear()

        // 1. Students Synchronization Listeners
        try {
            val listener = fs.collection("students").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [students]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    try {
                        var student = change.document.toObject(Student::class.java)
                        if (student != null && student.studentId.isBlank()) {
                            student = student.copy(studentId = change.document.id)
                        }
                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.studentDao().insertStudent(student)
                            }
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("SchoolRepository", "Error parsing Student: ${change.document.data}", e)
                        // Manual fallback mapping
                        try {
                            val data = change.document.data
                            if (data != null) {
                                val fallbackStudent = Student(
                                    studentId = data["studentId"] as? String ?: change.document.id,
                                    id = data["id"] as? String ?: "",
                                    name = data["name"] as? String ?: "Unknown",
                                    className = data["className"] as? String ?: "",
                                    rollNo = data["rollNo"] as? String ?: "",
                                    DOB = data["DOB"] as? String ?: data["dob"] as? String ?: "",
                                    gender = data["gender"] as? String ?: "Not Specified",
                                    fatherName = data["fatherName"] as? String ?: "",
                                    motherName = data["motherName"] as? String ?: "",
                                    guardianName = data["guardianName"] as? String ?: "",
                                    phone = data["phone"] as? String ?: "",
                                    address = data["address"] as? String ?: "",
                                    admissionNo = data["admissionNo"] as? String ?: "",
                                    photoUrl = data["photoUrl"] as? String ?: "",
                                    status = data["status"] as? String ?: "Active",
                                    isDeleted = data["isDeleted"] as? Boolean ?: false,
                                    feeStatus = data["feeStatus"] as? String ?: "Unpaid"
                                )
                                scope.launch {
                                    if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                        db.studentDao().insertStudent(fallbackStudent)
                                    } else {
                                        val existing = db.studentDao().getStudentById(fallbackStudent.studentId)
                                        if (existing != null) {
                                            db.studentDao().insertStudent(existing.copy(isDeleted = true, status = "DELETED"))
                                        }
                                    }
                                }
                            }
                        } catch (e2: Exception) {
                            android.util.Log.e("SchoolRepository", "Fallback parsing failed", e2)
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register students listener", e)
        }

        // 2. Teachers Synchronization Listeners
        try {
            val listener = fs.collection("teachers").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [teachers]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    try {
                        var teacher = change.document.toObject(Teacher::class.java)
                        if (teacher != null && teacher.teacherId.isBlank()) {
                            teacher = teacher.copy(teacherId = change.document.id)
                        }
                        scope.launch {
                            if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                db.teacherDao().insertTeacher(teacher)
                            }
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("SchoolRepository", "Error parsing Teacher: ${change.document.data}", e)
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register teachers listener", e)
        }

        // 3. Attendance Synchronization Listeners
        try {
            val listener = fs.collection("attendance").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [attendance]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    val att = change.document.toObject(Attendance::class.java)
                    scope.launch {
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            db.attendanceDao().insertAttendance(listOf(att))
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register attendance listener", e)
        }

        // 4. Fees Synchronization Listeners
        try {
            val listener = fs.collection("fees").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [fees]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    val fee = change.document.toObject(Fee::class.java)
                    scope.launch {
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            db.feeDao().insertFee(fee)
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register fees listener", e)
        }

        // 5. Homework Synchronization Listeners
        try {
            val listener = fs.collection("homework").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [homework]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    val hw = change.document.toObject(Homework::class.java)
                    scope.launch {
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            db.homeworkDao().insertHomework(hw)
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register homework listener", e)
        }

        // 6. Notices Synchronization Listeners
        try {
            val listener = fs.collection("notices").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [notices]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    var notice = change.document.toObject(Notice::class.java)
                    if (notice != null && notice.noticeId.isBlank()) {
                        notice = notice.copy(noticeId = change.document.id)
                    }
                    scope.launch {
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            db.noticeDao().insertNotice(notice)
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register notices listener", e)
        }

        // 7. Timetable Synchronization Listeners
        try {
            val listener = fs.collection("timetable").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [timetable]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    var tt = change.document.toObject(Timetable::class.java)
                    if (tt != null && tt.timetableId.isBlank()) {
                        tt = tt.copy(timetableId = change.document.id)
                    }
                    scope.launch {
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            db.timetableDao().insertTimetable(tt)
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register timetable listener", e)
        }

        // 8. Chats Synchronization Listeners
        try {
            val listener = fs.collection("chats").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SchoolRepository", "Firestore Synclist Error [chats]: ${error.message}", error)
                                        return@addSnapshotListener
                }
                snapshot?.documentChanges?.forEach { change ->
                    var msg = change.document.toObject(ChatMessage::class.java)
                    if (msg != null && msg.messageId.isBlank()) {
                        msg = msg.copy(messageId = change.document.id)
                    }
                    scope.launch {
                        if (change.type != com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                            db.chatDao().insertMessage(msg)
                        }
                    }
                }
            }
            snapshotListeners.add(listener)
        } catch (e: Exception) {
            Log.e("SchoolRepository", "Failed to register chats listener", e)
        }

        // 9. Fee Ledger Entries Synchronization Listeners
        try {
