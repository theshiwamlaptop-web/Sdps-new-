import re

filepath = 'app/src/main/java/com/example/ui/theme/Color.kt'
with open(filepath, 'r') as f:
    content = f.read()

target = """// Light Theme
val LightPrimary = Color(0xFF0F172A)
val LightSecondary = Color(0xFF3B82F6)
val LightTertiary = Color(0xFF10B981)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Premium Dark Theme (Inspired by the reference image)
val DarkPrimary = Color(0xFF00E5FF) // Neon Cyan
val DarkSecondary = Color(0xFF8B5CF6) // Neon Purple
val DarkTertiary = Color(0xFF10B981) // Neon Green
val DarkBackground = Color(0xFF020617) // Very deep slate, almost black
val DarkSurface = Color(0xFF0B1120) // Slightly lighter slate for cards
val DarkSurfaceVariant = Color(0xFF162032) // Floating card color
val DarkOnPrimary = Color(0xFF020617)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF1E293B)"""

replacement = """// Royal SDPS Branding Colors
val RoyalCrimson = Color(0xFFB30000)
val RoyalGold = Color(0xFFFFB703)
val NavyBlue = Color(0xFF0F2027)

// Light Theme
val LightPrimary = RoyalCrimson
val LightSecondary = RoyalGold
val LightTertiary = NavyBlue
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Premium Dark Theme (Midnight & Gold)
val DarkPrimary = RoyalGold 
val DarkSecondary = RoyalCrimson 
val DarkTertiary = NavyBlue 
val DarkBackground = Color(0xFF050B14) // Midnight Navy
val DarkSurface = Color(0xFF0B1320) // Slightly lighter navy for cards
val DarkSurfaceVariant = Color(0xFF152033) // Floating card color
val DarkOnPrimary = Color(0xFF020617)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF1E293B)"""

content = content.replace(target, replacement)
with open(filepath, 'w') as f:
    f.write(content)

