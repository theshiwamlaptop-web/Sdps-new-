with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt.formatted", "r") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if len(line) - len(line.lstrip()) > 100:
        print(f"Line {i+1} is deeply nested! {line.strip()[:50]}")
