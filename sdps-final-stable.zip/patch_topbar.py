import re

filepath = 'app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'
with open(filepath, 'r') as f:
    content = f.read()

target = """                    title = {
                        Column {
                            Text(
                                text = "S. D Public School",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Text(
                                text = currentScreen.title,"""

replacement = """                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (currentScreen == AppScreen.DASHBOARD) {
                                Image(
                                    painter = painterResource(id = R.drawable.logo_sdps),
                                    contentDescription = "Logo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                            Column {
                                Text(
                                    text = "S. D Public School",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                                Text(
                                    text = currentScreen.title,"""

content = content.replace(target, replacement)
with open(filepath, 'w') as f:
    f.write(content)

