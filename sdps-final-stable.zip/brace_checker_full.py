import sys

def check_braces(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    count = 0
    for i, line in enumerate(lines):
        for char in line:
            if char == '{': count += 1
            elif char == '}': count -= 1
        if count < 0:
            print(f"Error: Negative brace count at line {i+1}")
            count = 0
    print(f"Final brace count: {count}")

check_braces("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt")
