with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    lines = f.readlines()

for i in range(1, len(lines)):
    if lines[i] in ["                }\n", "                }"]:
        prev = lines[i-1]
        if '}' in prev:
            spaces = len(prev) - len(prev.lstrip(' '))
            if spaces <= 16:
                print(f"Line {i+1}: prev has <=16 spaces: '{prev.rstrip()}'")
        else:
            print(f"Line {i+1}: prev has NO brace: '{prev.rstrip()}'")
