import re

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'r') as f:
    content = f.read()

old_vm = """val existsLocally = studentsState.value.any { it.studentId == student.studentId }
                if (existsLocally) {
                    _toastMessage.value = "Duplicate Error: Student ID ${student.studentId} already exists."
                    return@launch
                }"""

new_vm = """val existsLocally = repository.checkStudentExists(student.studentId)
                if (existsLocally) {
                    _toastMessage.value = "Validation Error: Student ID ${student.studentId} already exists in database. Please generate a unique ID."
                    return@launch
                }"""

content = content.replace(old_vm, new_vm)

with open('app/src/main/java/com/example/ui/SchoolViewModel.kt', 'w') as f:
    f.write(content)
