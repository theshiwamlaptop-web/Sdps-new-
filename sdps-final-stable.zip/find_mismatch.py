import re

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    lines = f.readlines()

def get_indent(line):
    return len(line) - len(line.lstrip())

balance = 0
expected_indents = []
for i, line in enumerate(lines):
    clean_line = line.strip()
    if not clean_line or clean_line.startswith('//'):
        continue
    
    # very naive check
    for char in clean_line:
        if char == '{':
            balance += 1
        elif char == '}':
            balance -= 1

print(f"Total lines: {len(lines)}")
