import re
with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    content = f.read()

t = """        // Principal permanent deletion capability (Visible ONLY to the Principal)
        if (user.role.uppercase() == "PRINCIPAL") {"""
r = """        // Principal permanent deletion capability (Visible ONLY to the Principal)
        if (user.role.uppercase() == "PRINCIPAL") {
            val principalsCount = usersList.count { it.role.uppercase() == "PRINCIPAL" }
            val canDeleteThisUser = if (selectedUser.userId == user.userId) principalsCount > 1 else true
            if (canDeleteThisUser) {"""

content = content.replace(t, r)

t2 = """                    Text(
                        text = if (selectedUser.userId == user.userId) "🚨 Delete Principal Account Permanently" else "🚨 Delete This Account Permanently",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }"""
r2 = """                    Text(
                        text = if (selectedUser.userId == user.userId) "🚨 Delete Principal Account Permanently" else "🚨 Delete This Account Permanently",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        }"""
content = content.replace(t2, r2)
with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(content)
