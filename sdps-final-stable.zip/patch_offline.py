import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

bad_offline = '''                    if (offlineUser.userId.isBlank() || offlineUser.role.isBlank()) {
                        throw Exception("Corrupt offline user found")
                    }
                    _currentUser.value = offlineUser
                    return offlineUser
                }
            }'''
good_offline = '''                    if (offlineUser.userId.isBlank() || offlineUser.role.isBlank()) {
                        throw Exception("Corrupt offline user found")
                    }
                    _currentUser.value = offlineUser
                    startBackgroundFirebaseSync()
                    return offlineUser
                }
            }'''

content = content.replace(bad_offline, good_offline)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
print("Patched offline sync.")
