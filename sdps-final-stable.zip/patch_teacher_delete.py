import re
with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

t = """                        onClick = {
                            val idToDelete = teacherObj.teacherId
                            viewModel.deleteUserAccount(idToDelete)
                            viewModel.deleteTeacher(idToDelete)
                            selectedTeacherForProfile = null
                            showDeleteConfirmationDialog = false
                            Toast.makeText(context, "शिक्षक खाता हमेशा के लिए मिटा दिया गया!", Toast.LENGTH_LONG).show()
                        }"""
r = """                        onClick = {
                            val idToDelete = teacherObj.teacherId
                            val currentUserId = viewModel.currentUser.value?.userId ?: ""
                            val currentUserName = viewModel.currentUser.value?.name ?: "Admin"
                            val currentUserRole = viewModel.currentUser.value?.role?.uppercase() ?: ""
                            
                            if (currentUserRole == "PRINCIPAL") {
                                viewModel.deleteUserAccount(idToDelete)
                                viewModel.deleteTeacher(idToDelete)
                                selectedTeacherForProfile = null
                                showDeleteConfirmationDialog = false
                                Toast.makeText(context, "Teacher deleted permanently.", Toast.LENGTH_LONG).show()
                            } else if (currentUserRole == "ADMIN" || currentUserRole == "HEAD_ADMIN") {
                                viewModel.requestDeletion(
                                    targetId = idToDelete,
                                    targetType = "TEACHER",
                                    targetName = teacherObj.name,
                                    requesterName = currentUserName,
                                    requesterId = currentUserId
                                )
                                showDeleteConfirmationDialog = false
                                Toast.makeText(context, "Deletion request sent to Principal.", Toast.LENGTH_LONG).show()
                            }
                        }"""
content = content.replace(t, r)

t2 = """                    // Fail-safe permanent account deletion button
                    Button(
                        onClick = { showDeleteConfirmationDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("delete_teacher_perm_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("परमानेंट डिलीट करें (Permanent Delete)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }"""
r2 = """                    // Fail-safe permanent account deletion button
                    val currentUserRole = viewModel.currentUser.value?.role?.uppercase() ?: ""
                    if (currentUserRole == "PRINCIPAL" || currentUserRole == "ADMIN" || currentUserRole == "HEAD_ADMIN") {
                        val btnText = if (currentUserRole == "PRINCIPAL") "परमानेंट डिलीट करें (Permanent Delete)" else "डिलीट करने का अनुरोध करें (Request Deletion)"
                        Button(
                            onClick = { showDeleteConfirmationDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("delete_teacher_perm_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(btnText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }"""
content = content.replace(t2, r2)
with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
    f.write(content)
