stack = []
for i, line in enumerate(open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt")):
    if i < 136: continue
    if i > 878: break
    
    clean = line.strip()
    if clean.startswith('//'): continue
    
    for char in clean:
        if char == '{': stack.append(i+1)
        elif char == '}': 
            if stack: stack.pop()

print("Unclosed braces opened at lines:")
for l in stack:
    print(l)
