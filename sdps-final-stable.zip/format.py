import sys

def check(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
        
    count = 0
    issues = []
    for i, line in enumerate(lines):
        for char in line:
            if char == '{': count += 1
            elif char == '}': count -= 1
        
        if line.strip() == "} else {":
            if count != 3:
                issues.append(f"Line {i+1} }} else {{ at count {count} (expected 3 probably?)")
    print(f"Final count: {count}")
    return issues

print(check('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt'))
