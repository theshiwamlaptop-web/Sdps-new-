import re
with open("app/src/main/java/com/example/data/repository/SchoolRepository.kt", "r") as f:
    content = f.read()

def repl(m):
    # m.group(1) is the spaces before if
    # m.group(2) is the log line
    return m.group(1) + "if (error != null) {\n" + m.group(1) + "    " + m.group(2) + "\n" + m.group(1) + "    scheduleSyncRestart()\n" + m.group(1) + "    return@addSnapshotListener\n" + m.group(1) + "}"

new_content = re.sub(r'([ \t]+)if\s*\(error\s*!=\s*null\)\s*\{\s*\n[ \t]+(Log\.e\("SchoolRepository",\s*"Firestore Synclist Error[^"]+":\s*\$\{error\.message\}",\s*error\))\s*\n[ \t]+return@addSnapshotListener\s*\n[ \t]+\}', repl, content)

print("Replaced instances:", content.count("return@addSnapshotListener") - new_content.count("return@addSnapshotListener") + new_content.count("scheduleSyncRestart()"))
