import re

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'r') as f:
    content = f.read()

bad_master = '''                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value) {
                    try {
                        try { auth.signInWithEmailAndPassword("theshiwamlaptop@gmail.com", "ASDFGHJKL").await() } 
                         catch (ae: Exception) { 
                             try { auth.createUserWithEmailAndPassword("theshiwamlaptop@gmail.com", "ASDFGHJKL").await() }
                            catch(createEx: Exception) {'''

good_master = '''                val auth = firebaseAuth
                
                fun isNetworkAvailable(): Boolean {
                    val connectivityManager = context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
                    val network = connectivityManager.activeNetwork ?: return false
                    val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
                    return activeNetwork.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                           activeNetwork.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) ||
                           activeNetwork.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
                }

                if (auth != null && isFirebaseModeFlow.value && isNetworkAvailable()) {
                    try {
                        try { auth.signInWithEmailAndPassword("theshiwamlaptop@gmail.com", "ASDFGHJKL").await() } 
                         catch (ae: Exception) { 
                             try { auth.createUserWithEmailAndPassword("theshiwamlaptop@gmail.com", "ASDFGHJKL").await() }
                            catch(createEx: Exception) {'''

content = content.replace(bad_master, good_master)

bad_teacher = '''                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value) {
                    try {
                        try { auth.signInWithEmailAndPassword("$idLower@sdps.com", "tchr123").await() } 
                         catch (ae: Exception) { auth.createUserWithEmailAndPassword("$idLower@sdps.com", "tchr123").await() }
                    } catch (e: Exception) {}
                }'''

good_teacher = '''                val auth = firebaseAuth
                if (auth != null && isFirebaseModeFlow.value && isNetworkAvailable()) {
                    try {
                        try { auth.signInWithEmailAndPassword("$idLower@sdps.com", "tchr123").await() } 
                         catch (ae: Exception) { auth.createUserWithEmailAndPassword("$idLower@sdps.com", "tchr123").await() }
                    } catch (e: Exception) {
                        android.util.Log.e("SchoolRepository", "Teacher Auth Failed", e)
                    }
                }'''
content = content.replace(bad_teacher, good_teacher)

with open('app/src/main/java/com/example/data/repository/SchoolRepository.kt', 'w') as f:
    f.write(content)
print("Patched principals and teachers.")
