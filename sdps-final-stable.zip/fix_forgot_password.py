import re
with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "r") as f:
    content = f.read()

# Replace the text of the alert dialog for Forgot Password
old_dialog = """        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .background(
                                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                                    colors = listOf(Color(0xFFFFB703).copy(alpha = 0.3f), Color.Transparent),
                                    radius = 120f
                                ),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        SchoolLogoImage(
                            contentDescription = "School Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(64.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Reset Password")
                }
            },
            text = {
                OutlinedTextField(
                    value = resetInput,
                    onValueChange = { resetInput = it },
                    label = { Text("Enter Email or Phone") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = { 
                    viewModel.sendPasswordReset(resetInput, {}, {})
                    showResetDialog = false
                }) { Text("Send Reset Link") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )"""

new_dialog = """        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Forgot Password") },
            text = {
                Column {
                    Text("Temporary bypass using Default Password.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = resetInput,
                        onValueChange = { resetInput = it },
                        label = { Text("Enter User ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { 
                    viewModel.applyDefaultPassword(
                        resetInput.trim(),
                        onSuccess = { 
                            android.widget.Toast.makeText(context, "Default password applied. Please login with 'DefaultPassword123' and change your password.", android.widget.Toast.LENGTH_LONG).show()
                            showResetDialog = false 
                        },
                        onFailure = { 
                            android.widget.Toast.makeText(context, "Error: User ID not found.", android.widget.Toast.LENGTH_LONG).show()
                            showResetDialog = false 
                        }
                    )
                }) { Text("Use Default Password") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )"""

if "AlertDialog(\n            onDismissRequest = { showResetDialog = false }," in content:
    print("Found alert dialog")
    # Actually just string replace the whole block
    content = content.replace(old_dialog, new_dialog)
    with open("app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt", "w") as f:
        f.write(content)
else:
    print("Not found")

