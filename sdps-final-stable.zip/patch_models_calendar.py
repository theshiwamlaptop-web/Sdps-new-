with open('app/src/main/java/com/example/data/model/Models.kt', 'r') as f:
    content = f.read()

target = "data class CalendarEvent(val date: String, val title: String, val type: String)"

replacement = """@Entity(tableName = "calendar_events")
data class CalendarEvent(
    @PrimaryKey val id: String = "",
    val date: String = "",
    val title: String = "",
    val description: String = "",
    val type: String = "School Event",
    val time: String = "",
    val targetClass: String = "All",
    val createdBy: String = "",
    val createdAt: Long = System.currentTimeMillis()
)"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/data/model/Models.kt', 'w') as f:
        f.write(content)
    print("Models.kt patched successfully")
else:
    print("Target not found in Models.kt")
