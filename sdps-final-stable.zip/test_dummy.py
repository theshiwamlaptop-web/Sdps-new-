print("dummy")
