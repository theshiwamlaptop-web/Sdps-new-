import os

filepath = "app/src/main/java/com/example/data/repository/SchoolRepository.kt"
with open(filepath, "r") as f:
    content = f.read()

target = """            // ONE-TIME FORCE SYNC FOR THE USER
            if (fs != null) {"""

replacement = """            // ONE-TIME FORCE SYNC FOR THE USER
            if (fs != null && firebaseAuth?.currentUser != null) {"""

if target in content:
    content = content.replace(target, replacement)
    with open(filepath, "w") as f:
        f.write(content)
    print("Success")
else:
    print("Target not found")
