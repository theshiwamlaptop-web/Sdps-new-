import re

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    content = f.read()

imports_to_add = """
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.ui.input.nestedscroll.nestedScroll
"""
if "import androidx.compose.material3.rememberTopAppBarState" not in content:
    content = content.replace("import androidx.compose.material3.TopAppBar", imports_to_add + "\nimport androidx.compose.material3.TopAppBar")

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(content)

