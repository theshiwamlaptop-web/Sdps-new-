import re
with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

text = re.sub(r"\)\s*if \(showPasswordDialog\) \{", ")\n    }\n    if (showPasswordDialog) {", text, count=1)

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
