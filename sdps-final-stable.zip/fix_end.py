with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "r") as f:
    text = f.read()

text = text.replace("""                        }
                    }
                            if (showAssignTeacherDialog && selectedTeacherForClassAssign != null) {""", """                        }
                    }
                }
            }
        }
                            if (showAssignTeacherDialog && selectedTeacherForClassAssign != null) {""")

with open("app/src/main/java/com/example/ui/screens/SettingsScreen.kt", "w") as f:
    f.write(text)
