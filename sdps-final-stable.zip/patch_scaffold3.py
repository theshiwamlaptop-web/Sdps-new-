import re

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'r') as f:
    content = f.read()

# Add BackHandler import
if 'import androidx.activity.compose.BackHandler' not in content:
    content = content.replace('import androidx.compose.material3.TopAppBar', 'import androidx.activity.compose.BackHandler\nimport androidx.compose.material3.TopAppBar')

# Fix nestedScroll duplicate modifier
content = content.replace('''        },
        modifier = modifier
    ) { innerPadding ->''', '''        }
    ) { innerPadding ->''')

content = content.replace('''Scaffold(
            modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),''', '''Scaffold(
            modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),''')

with open('app/src/main/java/com/example/ui/screens/SchoolAppScreens.kt', 'w') as f:
    f.write(content)
